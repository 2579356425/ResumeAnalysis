import os
import paramiko
from flask import Flask, render_template, request, redirect, jsonify, url_for
from flask_cors import *#解决跨域
#解决No 'Access-Control-Allow-Origin' header is present on the requested resource.问题
from flask_restful import Api,Resource,reqparse
from werkzeug.utils import secure_filename

from resumeTemplate import resumeTemplate
from resumeGenerate import resumeGenerate
from resume_ie import *
from OCRshibie.Python_SDK.test_code.OCRTest import *
from resume_sql import Resume
from job_sql import Job
from user import User
from resumeAnalysis import resumeAnalysis
from statistics_sql import Statistics
from person_post import Person_post
from portrait import Portrait
from talentMyspic import talentMyspic
from position_match import Position_match

app = Flask(__name__)
CORS(app,suport_credentials=True)#解决跨域问题
api = Api(app)

#导入数据库包
from flask_sqlalchemy import SQLAlchemy
#这里登陆的是root用户，要填上自己的密码，MySQL的默认端口是3306，填上之前创建的数据库名rpds
app.config['SQLALCHEMY_DATABASE_URI']='mysql+pymysql://root:Yitiaoyu1@sh-cynosdbmysql-grp-i3qavwac.sql.tencentcdb.com:25998/rpds'
#设置这一项是每次请求结束后都会自动提交数据库中的变动
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=True
# 是否显示底层执行的SQL语句
# app.config['SQLALCHEMY_ECHO'] = True

# 加载信息提取的模型(人岗匹配抽取实体用)
# ie_default = Taskflow("information_extraction", schema=['职位', '技术', '学历', '专业'])
ie_default = Taskflow("information_extraction", schema=['职位', '技术', '学历', '专业', '年龄','工作年限'],task_path=r'C:\Users\lcf\.paddlenlp\gangwei_check')
basepath = os.path.dirname(__file__)
db = SQLAlchemy(app) #实例化

#测试数据库连接
# with app.app_context():
#     sql = "select * from resume"
#     result = db.session.execute(sql)
#     print(result.fetchall())

# 注册
@app.route('/registerUser', methods=['POST'])
def registerUser():
    data = request.form
    print(data)
    username = data.get("username")
    password = data.get("password")
    args=(username,password,"0") # 0表示普通用户，注册只能是普通用户
    user = User()
    user.register(args)
    user.close()
    return "200"

# 登录
@app.route('/loginUser', methods=['POST'])
def loginUser():
    data = request.form
    print(data)
    username = data.get("username")
    password = data.get("password")
    user = User()
    result = user.login()
    user.close()
    for user in result:
        if username==user[1] and password==user[2]:
            return jsonify((username, password))
    return jsonify(("500"))

#查询解析的简历数
@app.route('/resume_count',methods=['GET','POST'])
def resume_count():
    resume = Resume()
    results = resume.resume_count()
    resume.close()
    return jsonify(results)

#查询今日解析的简历数
@app.route('/resume_count_today',methods=['GET','POST'])
def resume_count_today():
    resume = Resume()
    results = resume.resume_count_today()
    resume.close()
    return jsonify(results)

# 查询专科、本科、硕士、博士的简历数
@app.route('/resume_count_edu',methods=['GET','POST'])
def resume_count_edu():
    resume = Resume()
    results = resume.resume_count_edu()
    resume.close()
    return jsonify(results)

# 查询人才画像数量
@app.route('/getTalent_count', methods=['GET', 'POST'])
def getTalent_count():
    statistics = Statistics()
    results = statistics.talent_count()
    statistics.close()
    return jsonify(results)

# 查询人岗匹配的数量
@app.route('/getPerson_post_count', methods=['GET', 'POST'])
def getPerson_post_count():
    statistics = Statistics()
    results = statistics.person_post_count()
    statistics.close()
    return jsonify(results)

# 修改人才画像的数量
@app.route('/update_talent', methods=['GET', 'POST'])
def update_talent():
    # id = int(request.form.get("id"))
    statistics = Statistics()
    results = statistics.update_talent()
    statistics.close()
    return jsonify(results)

# 修改人岗匹配的数量
@app.route('/update_person_post', methods=['GET', 'POST'])
def update_person_post():
    # id = int(request.form.get("id"))
    statistics = Statistics()
    results = statistics.update_person_post()
    statistics.close()
    return jsonify(results)

#接收前端传来的简历
@app.route('/save_upload_resume', methods=['GET', 'POST'])
def upload_data():
    fileObj = request.files.get('resume')
    filename = fileObj.filename
    print("filename------------",filename)
    upload_path = os.path.abspath(os.path.join(basepath,  filename))
    print("upload_path",upload_path)
    fileObj.save(upload_path)
    return "200"

#在线制作简历/简历添加
@app.route('/save_resume', methods = ['POST','GET'])
def saveResume():
    data = request.form
    #id = data.get('id')
    name_per = data.get('name_per')
    sex_per = data.get('sex_per')
    email_per = data.get('email_per')
    age_per = data.get('age_per')
    address_per = data.get('address_per')
    highest_edu_per = data.get('highest_edu_per')
    major_per = data.get('major_per')
    adm_date = data.get('adm_date')
    gra_date = data.get('gra_date')
    gra_school_per = data.get('gra_school_per')
    path_resume = data.get('path_resume')
    phone_per = data.get('phone_per')
    lan_skill_per = data.get('lan_skill_per')
    prof_skill_per = data.get('prof_skill_per')
    soft_skill_per = data.get('soft_skill_per')
    office_skill_per = data.get('office_skill_per')
    awards_per = data.get('awards_per')
    degree_per = data.get('degree_per')
    certificates = data.get('certificates')
    political_status = data.get('political_status')
    school_level = data.get('school_level')
    courses = data.get('courses')
    job_title = data.get('job_title')
    company_name = data.get('company_name')
    job_function = data.get('job_function')
    work_description = data.get('work_description')
    social_description = data.get('social_description')
    project_description = data.get('project_description')
    training_description = data.get('training_description')
    training_organization_name = data.get('training_organization_name')
    self_evaluation = data.get('self_evaluation')
    candidate_job_title = data.get('candidate_job_title')
    resume=Resume()
    args=(name_per,sex_per,email_per,age_per,phone_per,address_per, \
            highest_edu_per,major_per,adm_date,gra_date,gra_school_per,path_resume, \
            lan_skill_per,prof_skill_per,soft_skill_per,office_skill_per, \
            awards_per,degree_per,certificates,political_status,school_level,courses, \
            job_title,company_name,job_function,work_description,social_description, \
            project_description,training_description,training_organization_name,self_evaluation, \
            candidate_job_title)
    resume.insert(args)
    result=resume.select_resume()
    resume.close()
    print(jsonify(result))

#删除简历
@app.route('/resumeDelete', methods = ['POST','GET'])
def resumeDelete():
    resume_id = request.form.get("id")
    print("简历ID的类型",type(resume_id))
    print("简历ID", resume_id)
    resume=Resume()
    resume.delete(resume_id)
    resume.close()
    return "200"

#简历查询(所有)
# @app.route('/getResumeInfo',methods=['GET','POST'])
# def getResumeInfo():
#     resume = Resume()
#     results = resume.select_resume()        #results是tuple类型的
#     #print("查询结果",results)
#     resume.close()
#     return jsonify(results)

#简历查询(所有)
@app.route('/getResumeInfo',methods=['GET','POST'])
def getResumeInfo():
    username = request.form.get("username")
    resume = Resume()
    #results = resume.select_resume()  # results是tuple类型的
    results = resume.select_resume(username)        #results是tuple类型的
    #print("查询结果",results)
    resume.close()
    return jsonify(results)

#简历查询(关键词查询)
# @app.route('/getResumeInfoByKeyword',methods=['GET','POST'])
# def getResumeInfoByKeyword():
#     keyword = request.form.get("keyword")
#     resume = Resume()
#     results = resume.select_resumeByKeyword(keyword)        #results是tuple类型的
#     #print("查询结果",results)
#     resume.close()
#     return jsonify(results)

#简历查询(关键词查询)
@app.route('/getResumeInfoByKeyword',methods=['GET','POST'])
def getResumeInfoByKeyword():
    keyword = request.form.get("keyword")
    username = request.form.get("username")
    resume = Resume()
    #results = resume.select_resumeByKeyword(keyword)        #results是tuple类型的
    results = resume.select_resumeByKeyword(keyword, username)
    #print("查询结果",results)
    resume.close()
    return jsonify(results)

#简历查询(筛选)
# @app.route('/getResumeInfoBySelect',methods=['GET','POST'])
# def getResumeInfoBySelect():
#     name_per = request.form.get('name_per')
#     sex_per = request.form.get('sex_per')
#     low_age_result= request.form.get("low_age")
#     high_age_result = request.form.get("high_age")
#     print("low_age_result",low_age_result)
#     low_age = 1
#     high_age=200
#     if len(low_age_result) != 0 and low_age_result !="undefined":
#         low_age=int(low_age_result)
#     if len(high_age_result) != 0 and high_age_result !="undefined":
#         high_age=int(high_age_result)
#     work_description = request.form.get("work_description")
#     highest_edu_per = request.form.get("highest_edu_per")
#     major_per = request.form.get("major_per")
#     prof_skill_per=request.form.get("prof_skill_per")
#     search_dict = {}
#     search_dict["low_age"] = low_age
#     search_dict["high_age"] = high_age
#     search_dict["name_per"] = name_per
#     search_dict["sex_per"] = sex_per
#     search_dict["work_description"] = work_description
#     search_dict["highest_edu_per"] = highest_edu_per
#     search_dict["major_per"] = major_per
#     search_dict["prof_skill_per"] = prof_skill_per
#     search_value = []
#     for key, value in search_dict.items():
#         if value:
#             if isinstance(value, str):
#                 value='%'+value+'%'
#             search_value.append(value)
#     print("search_dict", search_dict)
#     search_value = tuple(search_value)
#     print("search_value",search_value)
#     resume = Resume()
#     results = resume.select_resumeBySelect(search_dict,search_value)
#     print("筛选结果",results)
#     resume.close()
#     return jsonify(results)

#简历查询(筛选)
@app.route('/getResumeInfoBySelect',methods=['GET','POST'])
def getResumeInfoBySelect():
    name_per = request.form.get('name_per')
    sex_per = request.form.get('sex_per')
    low_age_result= request.form.get("low_age")
    high_age_result = request.form.get("high_age")
    username = request.form.get("username")
    low_age = 1
    high_age=200
    if len(low_age_result) != 0 and low_age_result !="undefined":
        low_age=int(low_age_result)
    if len(high_age_result) != 0 and high_age_result !="undefined":
        high_age=int(high_age_result)
    work_description = request.form.get("work_description")
    highest_edu_per = request.form.get("highest_edu_per")
    major_per = request.form.get("major_per")
    prof_skill_per=request.form.get("prof_skill_per")
    search_dict = {}
    search_dict["low_age"] = low_age
    search_dict["high_age"] = high_age
    search_dict["name_per"] = name_per
    search_dict["sex_per"] = sex_per
    search_dict["work_description"] = work_description
    search_dict["highest_edu_per"] = highest_edu_per
    search_dict["major_per"] = major_per
    search_dict["prof_skill_per"] = prof_skill_per
    search_value = []
    for key, value in search_dict.items():
        if value:
            if value != "有" and value != "无":
                if isinstance(value, str):
                    value = '%' + value + '%'
                search_value.append(value)
            else:
                pass
    print("search_dict", search_dict)
    search_value = tuple(search_value)
    print("search_value",search_value)
    resume = Resume()
    #results = resume.select_resumeBySelect(search_dict,search_value)
    results = resume.select_resumeBySelect(search_dict, search_value, username)
    print("筛选结果",results)
    resume.close()
    return jsonify(results)

#更新简历
# @app.route('/resumeUpdate', methods = ['POST','GET'])
# def resumeUpdate():
#     data = request.form
#     resume_id=int(data.get('id'))
#     print("简历ID",resume_id)
#     name_per = data.get('name_per')
#     sex_per = data.get('sex_per')
#     email_per = data.get('email_per')
#     age_per = data.get('age_per')
#     if age_per:
#         age_per=int(age_per)
#     phone_per = data.get('phone_per')
#     address_per = data.get('address_per')
#     highest_edu_per = data.get('highest_edu_per')
#     major_per = data.get('major_per')
#     adm_date = data.get('adm_date')
#     gra_date = data.get('gra_date')
#     gra_school_per = data.get('gra_school_per')
#     path_resume = data.get('path_resume')
#     lan_skill_per = data.get('lan_skill_per')
#     prof_skill_per = data.get('prof_skill_per')
#     soft_skill_per = data.get('soft_skill_per')
#     office_skill_per = data.get('office_skill_per')
#     awards_per = data.get('awards_per')
#     degree_per = data.get('degree_per')
#     certificates = data.get('certificates')
#     political_status = data.get('political_status')
#     school_level = data.get('school_level')
#     courses = data.get('courses')
#     job_title = data.get('job_title')
#     company_name = data.get('company_name')
#     job_function = data.get('job_function')
#     work_description = data.get('work_description')
#     social_description = data.get('social_description')
#     project_description = data.get('project_description')
#     training_description = data.get('training_description')
#     training_organization_name = data.get('training_organization_name')
#     self_evaluation = data.get('self_evaluation')
#     candidate_job_title = data.get('candidate_job_title')
#     resume=Resume()
#     resume.update(name_per,sex_per,email_per,age_per,phone_per,
#                   address_per,highest_edu_per,major_per, adm_date, gra_date,
#                   gra_school_per, path_resume,lan_skill_per, prof_skill_per,
#                   soft_skill_per, office_skill_per,awards_per, degree_per,
#                   certificates, political_status, school_level, courses,job_title,
#                   company_name, job_function, work_description, social_description,
#                project_description, training_description, training_organization_name,
#                self_evaluation,candidate_job_title,resume_id)
#     resume.close()
#     return "200"

#更新简历
@app.route('/resumeUpdate', methods = ['POST','GET'])
def resumeUpdate():
    data = request.form
    resume_id = int(data.get('id'))
    print("简历ID", resume_id)
    name_per = data.get('name_per')
    sex_per = data.get('sex_per')
    email_per = data.get('email_per')
    age_per = data.get('age_per')
    if age_per:
        age_per=int(age_per)
    phone_per = data.get('phone_per')
    qq = data.get('qq')
    weixin = data.get('weixin')
    address_per = data.get('address_per')
    height = data.get('height')
    weight = data.get('weight')
    race = data.get('race')
    nationality = data.get('nationality')
    marital_status = data.get('marital_status')
    highest_edu_per = data.get('highest_edu_per')
    adm_date = data.get('adm_date')
    gra_date = data.get('gra_date')
    gra_school_per = data.get('gra_school_per')
    major_per = data.get('major_per')
    lan_skill_per = data.get('lan_skill_per')
    prof_skill_per = data.get('prof_skill_per')
    office_skill_per = data.get('office_skill_per')
    awards_per = data.get('awards_per')
    certificates = data.get('certificates')
    political_status = data.get('political_status')
    postal_code = data.get('postal_code')
    school_level = data.get('school_level')
    courses = data.get('courses')
    edu_gpa = data.get('edu_gpa')
    job_title = data.get('job_title')
    company_name = data.get('company_name')
    work_date = data.get('work_date')
    work_description = data.get('work_description')
    work_industry = data.get('work_industry')
    work_year = data.get('work_year')
    project_name = data.get('project_name')
    project_position = data.get('project_position')
    project_date = data.get('project_date')
    project_description = data.get('project_description')
    social_pos=data.get('social_pos')
    social_description = data.get('social_description')
    social_cpy = data.get('social_cpy')
    social_date = data.get('social_date')
    train_org = data.get('train_org')
    training_description = data.get('training_description')
    train_date = data.get('train_date')
    self_evaluation = data.get('self_evaluation')
    candidate_job_title = data.get('candidate_job_title')
    parsing_time = data.get('parsing_time')
    resume_type = data.get('resume_type')
    resume_name = data.get('resume_name')
    path_resume = data.get('path_resume')
    avatar_url = data.get('avatar_url')
    pred_salary = data.get('pred_salary')
    pos_tags = data.get('pos_tags')
    skills_tags = data.get('skills_tags')
    username = data.get('username')
    resume=Resume()
    resume.update(name_per,sex_per,email_per,age_per,phone_per,qq,weixin,address_per,height,weight,race,nationality,marital_status,
               highest_edu_per,adm_date,gra_date,gra_school_per,major_per,lan_skill_per,prof_skill_per,office_skill_per,awards_per,certificates,
              political_status,postal_code,school_level,courses,edu_gpa,job_title,company_name,work_date,
              work_description,work_industry,work_year,
              project_name,project_position,project_date,project_description,
              social_pos,social_description,social_cpy,social_date,
              train_org,training_description,train_date,self_evaluation,
              candidate_job_title,parsing_time,resume_type,resume_name,path_resume,avatar_url,
              pred_salary,pos_tags,skills_tags,username,resume_id)
    resume.close()
    return "200"

#岗位添加
@app.route('/save_job', methods = ['POST','GET'])
def save_Job():
    data = request.form
    job_name = data.get('job_name')
    job_function = data.get('job_function')
    company_name = data.get('company_name')
    company_intro = data.get('company_intro')
    company_industry = data.get('company_industry')
    department = data.get('department')
    num_hire = data.get('num_hire')
    address = data.get('address')
    major_post = data.get('major_post')
    edu_require_post = data.get('edu_require_post')
    language_post = data.get('language_post')
    soft_post = data.get('soft_post')
    experience_post = data.get('experience_post')
    prof_skill_post = data.get('prof_skill_post')
    school_level = data.get('school_level')
    certificates = data.get('certificates')
    gender = data.get('gender')
    age = data.get('age')
    management_requirement = data.get('management_requirement')
    professional_requirement = data.get('professional_requirement')
    industry_requirement = data.get('industry_requirement')
    salary = data.get('salary')
    benefit = data.get('benefit')
    email = data.get('email')
    phone = data.get('phone')
    publish_time=data.get("publish_time")
    job_requirement=data.get("job_requirement")
    print("publish_time",publish_time)
    job=Job()
    args=(job_name,job_function,company_name,company_intro, \
            company_industry,department,num_hire,address,major_post,edu_require_post, \
            language_post,soft_post,experience_post,prof_skill_post, \
            school_level,certificates,gender,age,management_requirement, \
            professional_requirement,industry_requirement,salary,benefit,email,phone,publish_time,job_requirement)
    job.insert(args)
    result=job.select_job()
    job.close()
    print(jsonify(result))
    return "200"

#删除岗位
@app.route('/jobDelete', methods = ['POST','GET'])
def jobDelete():
    job_id = request.form.get('id')
    print("岗位ID", job_id)
    job=Job()
    job.delete(job_id)
    job.close()
    return "200"

#查询岗位信息(全部)
@app.route('/getJobInfo',methods=['GET','POST'])
def getJobInfo():
    job = Job()
    results = job.select_job()
    #print("查询结果",results)
    job.close()
    return jsonify(results)

#岗位查询(关键词查询)
@app.route('/getJobInfoByKeyword',methods=['GET','POST'])
def getJobInfoByKeyword():
    keyword = request.form.get("keyword")
    job = Job()
    results = job.select_jobByKeyword(keyword)
    print("查询结果",results)
    job.close()
    return jsonify(results)

#岗位查询(筛选)
@app.route('/getJobInfoBySelect',methods=['GET','POST'])
def getJobInfoBySelect():
    publish_time = request.form.get("publish_time")
    int_time = 10000
    if len(publish_time) != 0:
        if publish_time == "7日内":
            int_time = 7
        elif publish_time == "1个月内":
            int_time = 30
        else:
            int_time = 90
    big_city = request.form.get("big_city")
    small_city = request.form.get("small_city")
    address=""
    if len(small_city) !=0 and len(big_city) !=0:
        if big_city == "北京" or big_city == "上海" or big_city == "天津" or big_city == "重庆" or big_city == "香港" or big_city == "澳门" or small_city == "全部":
            address=big_city
        else:
            address=small_city
    company_industry_result = request.form.get("company_industry")
    if company_industry_result:
        company_industry_list = company_industry_result.split("/")
        initial_look=['互联网','医学','销售','教育','设计','金融','管理']
        company_industry = ""
        look = ""
        if company_industry_result == "全部" or "全部" in company_industry_list:
            company_industry = ""
            look=""
        else:
            if len(company_industry_list) == 1 and "其他" in company_industry_list:   #只有其他
                flag = 1
                look=initial_look
                company_industry = ""
            elif "其他" not in company_industry_list:   #无其他
                company_industry=company_industry_list[:]
                look=""
            elif "其他" in company_industry_list and len(company_industry_list) > 1:  #其他+look
                company_industry = list()
                for line in company_industry_list:
                    if line != "其他":
                        company_industry.append(line)
                if len(company_industry) == 7:
                    look=""
                else:
                    look = list(set(initial_look) - set(company_industry))   #取差集
                company_industry = ""
    else:
        company_industry = ""
        look = ""

    search_dict = {}
    search_dict["publish_time"] = int_time
    search_dict["address"] = address
    search_dict["company_industry"] = company_industry
    search_dict["not_company_industry"] = look
    search_value = []
    for key, value in search_dict.items():
        if value:
            if isinstance(value, str):
                value = '%' + value + '%'
            if key != "not_company_industry":
                if isinstance(value, list):
                    old_value = value[:]
                    value = list()
                    for line in old_value:
                        new_line = "%" + line + "%"
                        value.append(new_line)
                        search_value.append(new_line)
                    continue
            else:
                for line in value:
                    search_value.append(line)
                continue
            search_value.append(value)
    print("search_dict", search_dict)
    search_value = tuple(search_value)
    print("search_value", search_value)
    job = Job()
    results = job.select_jobBySelect(search_dict,search_value)
    print("筛选结果",results)
    job.close()
    return jsonify(results)

#更新岗位
@app.route('/jobUpdate', methods = ['POST','GET'])
def jobUpdate():
    data = request.form
    print(data)
    job_id=int(data.get('id'))
    print("岗位ID",job_id)
    job_name = data.get('job_name')
    job_function = data.get('job_function')
    company_name = data.get('company_name')
    company_intro = data.get('company_intro')
    company_industry = data.get('company_industry')
    department = data.get('department')
    num_hire = data.get('num_hire')
    address = data.get('address')
    major_post = data.get('major_post')
    edu_require_post = data.get('edu_require_post')
    language_post = data.get('language_post')
    soft_post = data.get('soft_post')
    experience_post = data.get('experience_post')
    prof_skill_post = data.get('prof_skill_post')
    school_level = data.get('school_level')
    certificates = data.get('certificates')
    gender = data.get('gender')
    age = data.get('age')
    management_requirement = data.get('management_requirement')
    professional_requirement = data.get('professional_requirement')
    industry_requirement = data.get('industry_requirement')
    salary = data.get('salary')
    benefit = data.get('benefit')
    email = data.get('email')
    phone = data.get('phone')
    publish_time = data.get("publish_time")
    job_requirement = data.get("job_requirement")
    job=Job()
    job.update(job_name,job_function,company_name,company_intro, \
            company_industry,department,num_hire,address,major_post,edu_require_post, \
            language_post,soft_post,experience_post,prof_skill_post, \
            school_level,certificates,gender,age,management_requirement, \
            professional_requirement,industry_requirement,salary,benefit,email,phone,publish_time,job_requirement,job_id)
    job.close()
    return "200"

# 获取简历模板数据（商务简约）
@app.route('/getResumeTemplates_easy_business',methods=['get'])
def getResumeTemplates_easy_business():
    template = resumeTemplate()
    results = template.getResumeTemplate_easy_business()
    template.close()
    return jsonify(results)

# 获取简历模板数据（精美时尚）
@app.route('/getResumeTemplates_exquisite_fashion',methods=['get'])
def getResumeTemplates_exquisite_fashion():
    print('已收到请求')
    template = resumeTemplate()
    results = template.getResumeTemplates_exquisite_fashion()
    template.close()
    return jsonify(results)

# 获取简历模板数据（通用表格）
@app.route('/getResumeTemplates_table',methods=['get'])
def getResumeTemplates_table():
    template = resumeTemplate()
    results = template.getResumeTemplates_table()
    template.close()
    return jsonify(results)

# 获取简历模板数据（沉稳严谨）
@app.route('/getResumeTemplates_steady_rigorous',methods=['get'])
def getResumeTemplates_steady_rigorous():
    template = resumeTemplate()
    results = template.getResumeTemplates_steady_rigorous()
    template.close()
    return jsonify(results)

# 获取简历模板数据（个性创意）
@app.route('/getResumeTemplates_individual_creativity',methods=['get'])
def getResumeTemplates_individual_creativity():
    template = resumeTemplate()
    results = template.getResumeTemplates_individual_creativity()
    template.close()
    return jsonify(results)

# 获取简历模板数据（毕业生）
@app.route('/getResumeTemplates_graduate',methods=['get'])
def getResumeTemplates_graduate():
    template = resumeTemplate()
    results = template.getResumeTemplates_graduate()
    template.close()
    return jsonify(results)

# 上传简历模板
@app.route('/uploadResumeTemplate',methods=['POST'])
@cross_origin()
def uploadResumeTemplate():
    data = request.form
    # print(data)
    resumeTemplateType = data.get('type')
    resumeTemplatePath = data.get('path')
    # 上传文件
    f = request.files['file']
    filename = secure_filename(f.filename)
    print(filename)
    basepath = os.path.dirname(__file__)  # 当前文件所在路径
    print(basepath)
    # 验证文件格式
    types = ['jpg', 'png']
    if filename.split('.')[-1] in types:
        # 获取上传文件的服务器存储地址
        file_path = os.path.join(basepath, '{0}'.format(filename))
        print(file_path)
        # 文件存储
        f.save(file_path)
    args = (resumeTemplatePath + filename, resumeTemplateType)
    print('args:', args)
    template = resumeTemplate()
    template.uploadResumeTemplate(args)
    template.close()
    outinfo = filename + '上传成功'
    return jsonify(outinfo)

# 删除简历模板
@app.route('/deleteResumeTemplate', methods=['POST'])
def deleteResumeTemplate():
    data = request.form
    resumeTemplateUrl = data.get('resumeTemplateUrl')
    print("resumeTemplateUrl:", resumeTemplateUrl)
    template = resumeTemplate()
    template.deleteResumeTemplate(resumeTemplateUrl)
    template.close()
    return "200"

# 简历生成
@app.route('/resumeGenerate', methods=['post'])
def resume_generate():
    # 获取数据
    data = request.form
    print(data)
    name = data.get('name')
    gender = data.get('gender')
    address = data.get('address')
    phone = data.get('phone')
    birthday = data.get('birthday')
    educationForm_startTime = data.get('educationForm.startTime')
    educationForm_endTime = data.get('educationForm.endTime')
    educationForm_university = data.get('educationForm.university')
    educationForm_major = data.get('educationForm.major')
    educationForm_gpa = data.get('educationForm.gpa')
    educationForm_certificate = data.get('educationForm.certificate')
    educationForm_course = data.get('educationForm.course')
    projectForm0_startTime = data.get('projectForm0_startTime')
    projectForm0_endTime = data.get('projectForm0_endTime')
    projectForm0_projectName = data.get('projectForm0.projectName')
    projectForm0_projectDescription = data.get('projectForm0.projectDescription')
    projectForm1_startTime = data.get('projectForm1_startTime')
    projectForm1_endTime = data.get('projectForm1_endTime')
    projectForm1_projectName = data.get('projectForm1.projectName')
    projectForm1_projectDescription = data.get('projectForm1.projectDescription')
    skill = data.get('skill')
    selfDescription = data.get('selfDescription')

    # 改写数据格式
    args=(name, gender, address, phone, birthday, educationForm_startTime, educationForm_endTime, educationForm_university, educationForm_major,
          educationForm_gpa, educationForm_certificate, educationForm_course, projectForm0_startTime, projectForm0_endTime, projectForm0_projectName,
          projectForm0_projectDescription, projectForm1_startTime, projectForm1_endTime, projectForm1_projectName, projectForm1_projectDescription,
          skill, selfDescription)
    # print('args:', args)
    context = {}
    context['name'] = name
    if(gender=="1"):
        context['gender'] = '男'
    else:
        context['gender'] = '女'
    context['address'] = address
    context['phone'] = phone
    context['birthday'] = birthday
    context['start_time1'] = educationForm_startTime
    context['end_time1'] = educationForm_endTime
    context['university'] = educationForm_university
    context['major'] = educationForm_major
    context['gpa'] = educationForm_gpa
    context['certificate'] = educationForm_certificate
    context['course'] = educationForm_course
    context['start_time2'] = projectForm0_startTime
    context['end_time2'] = projectForm0_endTime
    context['campus_job'] = projectForm0_projectName
    context['campus_work'] = projectForm0_projectDescription
    context['start_time3'] = projectForm1_startTime
    context['end_time3'] = projectForm1_endTime
    context['internship_job'] = projectForm1_projectName
    context['internship_work'] = projectForm1_projectDescription
    context['skill'] = skill
    context['self_assessment'] = selfDescription
    # print(context)
    # 生成简历
    template = resumeGenerate()
    template.generateWord(context)
    template.close()

    return r"F:\resume/"+ context['name'] + ".docx"

# 获取生成的简历
@app.route('/getResumeGenerate',methods=['get'])
def getResumeGenerate():
    template = resumeGenerate()
    results = template.get_resumeGenerate()
    template.close()
    print('jsonify(results):', jsonify(results))
    return jsonify(results)

# 信息提取
@app.route('/getResumeGenerate',methods=['get'])
def getResumeinformation():
    data = request.form
    resume_path = data.get('url')
    # word格式
    if resume_path.endswith('.docx') or resume_path.endswith('.doc'):
        paragraphs_text = get_paragraphs_text(resume_path)
        res = get_info(paragraphs_text)
        return jsonify(res)
    # pdf格式
    elif resume_path.endswith('.pdf'):
        img_output = "output"
        pyMuPDF_fitz(resume_path, img_output)
        res = get_info_tupian("output/images_0.jpeg")
        print(res)
        return jsonify(res)
    # 图片格式 这里没有固定 算是一个小bug
    else:
        text = request_smartstructure_file(resume_path)
        # 调用API
        text = eval(text)
        # 转为字典
        pap = Data_cleaning_api(text)
        res = get_info(pap)
        print(res)
        return jsonify(res)

# 查询简历
@app.route('/getUserResume',methods=['post'])
def getUserResume():
    data = request.form
    user = data.get('user')
    resume = resumeAnalysis()
    if(user == 'admin'):
        results = resume.selectAllResume()  # results是tuple类型的
    else:
        results = resume.selectUserResume(user)
    resume.close()
    return jsonify(results)

# 接收前端传来的简历(简历解析的上传，需要返回简历路径)
@app.route('/save_upload_resume2', methods=['GET', 'POST'])
def upload_data2():
    fileObj = request.files.get('resume')
    filename = fileObj.filename
    print("filename------------",filename)
    upload_path = os.path.abspath(os.path.join(basepath,  filename))
    print("upload_path",upload_path)
    fileObj.save(upload_path)
    return jsonify(upload_path)

# 解析简历
@app.route('/resume_analysis',methods=['get', 'post'])
def analysisResume():
    data = request.form
    resumeUrl = data.get('resumeUrl')
    resumeName = data.get('resumeName')
    username = data.get('username')
    print('前端传递的信息：', resumeUrl, resumeName, username)
    apiUrl = 'http://resumesdk.market.alicloudapi.com/ResumeParser'
    # 解析，插入数据库
    resume1 = resumeAnalysis()
    res_js = resume1.analysis(apiUrl, resumeUrl, resumeName)
    args = resume1.handleInfo(res_js,username, resumeUrl, resumeName)
    print('args:', args)
    # 查询
    resume2 = Resume()
    resume2.insert(args)
    res = resume2.select_resume(username)
    print('res:', res)
    return jsonify(res)

# 简历解析页面删除简历
@app.route('/resumeDelete2', methods = ['POST','GET'])
def resumeDelete2():
    resume_id = request.form.get("id")
    print("简历ID的类型",type(resume_id))
    print("简历ID", resume_id)
    username = request.form.get('username')
    print('username:', username)
    resume=Resume()
    resume.delete(resume_id)
    result = resume.select_resume(username)
    resume.close()
    return jsonify(result)

# 人才指数计算
@app.route('/talent_myspic', methods = ['POST','GET'])
def talent_myspic():
    data = request.form
    name_per = data.get('name_per')
    sex_per = data.get('sex_per')
    age_per = data.get('age_per')
    highest_edu_per = data.get('highest_edu_per')
    major_per = data.get('major_per')
    gra_school_per = data.get('gra_school_per')
    work = data.get('work')
    skills_tags = data.get('skills_tags')
    political_status = data.get('political_status')
    address_per = data.get('address_per')
    pred_salary = data.get('pred_salary')
    talentEvl = talentMyspic()
    result = talentEvl.evaluate(name_per, sex_per, age_per, highest_edu_per, major_per, gra_school_per, work, skills_tags, political_status, address_per, pred_salary)
    talentEvl.close()
    return result

# 人物画像生成
@app.route('/portrait', methods = ['post', 'get'])
def personPortrait():
    resumeId = request.form.get('id')
    resume = Resume()
    resumeInfo = resume.selectById(resumeId)
    print(resumeInfo)
    portrait = Portrait()
    item_info = portrait.portrait(resumeInfo)
    print(item_info)
    return item_info

# 以岗推人
@app.route('/select_perPost', methods=['GET', 'POST'])
def select_perPost():
    postName = request.form.get("postName")
    postDescription = request.form.get("postDescription")
    perPost=Person_post()
    results = perPost.postToPerson(postName, postDescription, ie_default)
    perPost.close()
    return jsonify(results)

# 以人推岗
@app.route('/select_postPer', methods=['GET', 'POST'])
def select_postPer():
    id = request.form.get('resumeId')
    job = Job()
    job_result = job.select_fun_req()
    resume = Resume()
    resume_result = resume.selectSAHWMById(id)
    # print("job_result:", len(job_result), job_result)
    # print("resume_result:", len(resume_result), resume_result)
    # print("job_result:", len(job_result), job_result[0])
    # print("resume_result:", len(resume_result), resume_result[0])

    # 简历信息
    position_match = Position_match()
    skills_tags = resume_result[0][0]
    age_per = resume_result[0][1]
    highest_edu_per = resume_result[0][2]
    work_year = resume_result[0][3]
    major_per = resume_result[0][4]

    position_list = []  # 返回结果，给人匹配到的岗位
    positionInfo_list = []  # 传的岗位信息[{'岗位名': '***', '岗位信息': '***'},……]
    # 岗位信息
    for positionInfo in job_result:
        positionInfo_dict = {}
        positionInfo_dict['岗位名'] = positionInfo[0]
        positionInfo_dict['岗位信息'] = positionInfo[1]+positionInfo[2]
        positionInfo_list.append(positionInfo_dict)
        positionInfo_dict={}
    # 匹配到的岗位列表
    position_match.personToPost(skills_tags, age_per, highest_edu_per, work_year, major_per, positionInfo_list, ie_default, position_list)
    print(position_list)

    # 要返回给前端的数据
    results_list = []
    for position in position_list:
        results_list.append(job.selectByjobName("'"+str(position)+"'"))
    print("results_list:", results_list)
    position_match.close()
    resume.close()
    job.close()
    return jsonify(results_list)

# 选择模板
@app.route('/chose_resume', methods=['POST'])
def chose_resume():
    data = request.form
    print(data)
    resume_name = data.get("resume_name")
    project_path = os.path.dirname(os.path.abspath(__file__))
    file_path = project_path + '/chose_resume/' + resume_name + '.txt'
    # 读文件，，将文件中的字符串读出来返回
    with open(file_path, 'r', encoding='utf-8') as f:
        # 获取内容
        txt = f.readlines()
    txt = ''.join(txt)
    print(txt)
    return txt


# 测试数据写入
# def analysisResume333(resumeUrl, resumeName, username):
#     apiUrl = 'http://resumesdk.market.alicloudapi.com/ResumeParser'
#     # 解析，插入数据库
#     resume1 = resumeAnalysis()
#     res_js = resume1.analysis(apiUrl, resumeUrl, resumeName)
#     args = resume1.handleInfo(res_js,username, resumeUrl, resumeName)
#     print('args:', args)
#     resume2 = Resume()
#     resume2.insert(args)

if __name__ == '__main__':
    app.run(host='127.0.0.1', port='5000', debug=False)


    # personPortrait(33)
    # path = r"E:\研究生工作\十二届软件杯\测试数据\296-300/"
    # word_list = os.listdir(path)
    # for word in word_list:
    #     filePath = path + word
    #     analysisResume333(filePath, word, 'admin')
    #     print(filePath)