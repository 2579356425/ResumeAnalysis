# coding: utf-8
import base64
import requests
import json


def test_parse(url, fpath, fname):
    # 读取文件内容
    cont = open(fpath, 'rb').read()
    # base_cont = base64.b64encode(cont)  # python2
    base_cont = base64.b64encode(cont).decode('utf8')  # python3

    # 构造json请求
    data = {
        'file_name': fpath,  # 简历文件名（需包含正确的后缀名）
        'file_cont': base_cont,  # 简历内容（base64编码的简历内容）
        'need_avatar': 1,  # 是否需要提取头像图片
        'ocr_type': 1,  # 1为高级ocr
    }

    appcode = 'd3bfcbb5613740c69f7339f3de5eecef'
    headers = {'Authorization': 'APPCODE ' + appcode,
               'Content-Type': 'application/json; charset=UTF-8',
               }
    # 发送请求
    data_js = json.dumps(data)
    res = requests.post(url=url, data=data_js, headers=headers)

    # 解析结果
    res_js = json.loads(res.text)

    print(json.dumps(res_js, indent=4, ensure_ascii=False))  # 打印全部结果
    with open("./ieResult/" + fname.split(".")[0] + ".txt", 'w', encoding="utf-8") as w:
        w.write(str(json.dumps(res_js, indent=4, ensure_ascii=False)))

    return res_js


def decode(code, imgname):
    with open(imgname, 'wb') as file:
        jiema = base64.b64decode(code)
        file.write(jiema)


if __name__ == '__main__':
    url = 'http://resumesdk.market.alicloudapi.com/ResumeParser'
    fpath = r'C:\Users\82470\Desktop\dataset_CV/1.pdf'
    fname = '1.pdf'
    a = '/9j/4AAQSkZJRgABAgAAAQABAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAEEAMMDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwDpcUYoorzD7cMUYoooAMUYoooAMUYoooAMUYoooAMUYoJA6mmtIq9T+VMTaW47FGKaJFPQ0ocHoaLMFKLFxRiiikMMUYoooAMUYoooAMUYoooAMUYoooAMUUUUAFFFFABRRRQAUUUUAFRT3Eduu6Rseg7mpScAmuXv7tppXYkqnO3HetqNL2jPOzLHLCU7rd7GhNriIcKmf+BVUfXpccKtY+cj0prHivRjhqa6HxtbPMZPaVi42rXLMW3nPrTGv7g/8tW/OqmRigEbq1VOK6HmyxteW8395YN5OBgSv/31Tor+eE5WVvxOaq9TQcdB1p8kdrELE1k+ZSf3mpDrV0j5aTcM9DXR2t0lzGGVhkjkelcP0qeG4eNwwcrj0rCthozXu6Hr5dntbDytVbkvU7mis7TdSW6TYx+cDv3rRry5wcXZn3eHxFPEU1Upu6YUUUVJsFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAR3H/HvJg4+U1xkrFgQe1dbqNx9ns3YAE44FcfK4LEjoa9DBxdmz5DiWpHnjG+thhb5ajLUuSeAM1Its55xXobHyKhOo/cRXycYp2SKtpatnpU32YfxLQ5I6IZfWkr2M3eRmhW+bJq69quOlQNbEHpQmmZVMJWhuMBz2oppUqcGlBFBhr1LFrcvbzK6HBFdjZXSXdusi8How9DXDgnORW7oE7iVo93DckGuTF0lKPN1R9Hw9jpUq6ov4ZfmdHRRRXlH3wUUUUAFFFFABRRRQAUUUUAFFFFABRRRQBga/OCyxg9Otc/gs2OprS1qXffMOOOOKr2EW+XeR0r2qEeWmj85zBvF4+UF3sWbezEagtyxqwEA7VIaTFVc+ho4WnSioxQmB6U0jIp+KMUzfkRHsBprIMdBU2KQigxlSi+hUa3Q9qry2WQSnBrRIpMU+ZnDWwFGorNGHyDgjBHWrVnM0NxG4JGD1FLfQAMJVHXrVZGwwNOSUkfNShLC17dnod8rblB9RS1HbgC3QDkbRUleC9z9Vg24psKKKKRQUUUUAFFFFABRRRQAUUUUAFB6UUHpQBxWonN9IMAfNViwXCmob4f6dLkAfN2qxZ/dr24/Aj8+wcf8AbpN92W6BS0qj2pXPp4q4oTNLsp4FLU8xryEO2mlamIpjCqUjOUSJqZmpGFRkVRyzRFcLvhYH0rIHBFa8p/dt9KyQ'

    # name = 'decode.jpg'
    # decode(a, name)
    # test_parse(url, fname)
