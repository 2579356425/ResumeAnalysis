#-*- coding=utf-8 -*-
import numpy
import pymysql as mysql
from DB import Database
import os,re

class Job():
    def __init__(self):
        self.connection = Database().get_connention()
        self.cursor = self.connection.cursor()

    def close(self):
        self.connection.close()
        self.cursor.close()

    def insert(self, args):
        sql='insert into job(job_name,job_function,company_name,company_intro,' \
            'company_industry,department,num_hire,address,major_post,edu_require_post,' \
            'language_post,soft_post,experience_post,prof_skill_post,' \
            'school_level,certificates,gender,age,management_requirement,' \
            'professional_requirement,industry_requirement,salary,benefit,email,phone,publish_time,job_requirement)' \
            ' values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,' \
            '%s,%s,%s,%s,%s,%s,%s)'
        try:
            self.cursor.execute(sql, args)
            self.connection.commit()
            print('insert successfully')
            return True
        except Exception as err:
            print(err)
            result = re.search("Duplicate entry.*key.*PRIMARY", str(err))
            if (result == None):
                self.connection.rollback()

    def select_job(self):
        sql = 'select * from job'
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            #print(result)
            return result
        except Exception as err:
            print(err)

    def select_jobBySelect(self,search_dict,search_value):
        sql = "select * from job where datediff(curdate(),publish_time) < %s"
        if search_dict["address"]:
            sql = sql + " and (address like %s)"
        if search_dict["company_industry"]:
            if len(search_dict["company_industry"]) == 1:
                sql = sql + " and (company_industry like %s)"
            if len(search_dict["company_industry"]) > 1:
                sql = sql + " and (company_industry like %s"
                for i in search_dict["company_industry"][1:]:
                    sql = sql + " or company_industry like %s"
                sql = sql + ")"
        if search_dict["not_company_industry"]:
            if len(search_dict["not_company_industry"]) == 1:
                sql = sql + " and (company_industry <> %s)"
            if len(search_dict["not_company_industry"]) > 1:
                sql = sql + " and (company_industry <> %s"
                for i in search_dict["not_company_industry"][1:]:
                    sql = sql + " and company_industry <> %s"
                sql = sql + ")"
        print("岗位筛选sql",sql)
        try:
            self.cursor.execute(sql,search_value)
            result = self.cursor.fetchall()
            return result
        except Exception as err:
            print(err)

    # 关键词查询
    def select_jobByKeyword(self, keyword):
        """
        支持岗位名称、职能描述、公司名称、公司行业、工作地址、专业要求、
        学历要求、专业技能要求、学校要求、证书、性别要求
        """
        sql = "select * from job where job_name like '%%%s%%' or job_function like '%%%s%%' or company_name like '%%%s%%' " \
              "or company_industry like '%%%s%%' or address like '%%%s%%' or major_post like '%%%s%%' or edu_require_post like '%%%s%%'" \
              "or prof_skill_post like '%%%s%%' or school_level like '%%%s%%' or certificates like '%%%s%%' or gender like '%%%s%%' or job_requirement like '%%%s%%'" % (
              keyword, keyword, keyword, keyword, keyword, keyword, keyword, keyword, keyword,keyword, keyword, keyword)
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            # print(result)
            return result
        except Exception as err:
            print(err)

    def delete(self,id):
        sql = 'delete from job where id = %s' %id
        try:
            self.cursor.execute(sql)
            print('delete successfully')
            self.connection.commit()
        except Exception as err:
            print(err)
            self.connection.rollback()

    def update(self,job_name,job_function,company_name,company_intro, \
            company_industry,department,num_hire,address,major_post,edu_require_post, \
            language_post,soft_post,experience_post,prof_skill_post, \
            school_level,certificates,gender,age,management_requirement, \
            professional_requirement,industry_requirement,salary,benefit,email,phone,publish_time,job_requirement,id):
        sql = "update job set job_name='%s',job_function='%s',company_name='%s'," \
              "company_intro='%s',company_industry='%s',department='%s',num_hire='%s'," \
              "address='%s',certificates='%s',gender='%s', age='%s'," \
              "major_post='%s',edu_require_post='%s',language_post='%s',soft_post='%s'," \
              "experience_post='%s',prof_skill_post='%s',school_level='%s'," \
              "management_requirement='%s', professional_requirement='%s',industry_requirement='%s'," \
              " salary='%s',benefit='%s', email='%s'," \
              " phone='%s', publish_time='%s',job_requirement='%s' where id=%s" %(job_name,job_function,company_name,company_intro, \
            company_industry,department,num_hire,address,major_post,edu_require_post, \
            language_post,soft_post,experience_post,prof_skill_post, \
            school_level,certificates,gender,age,management_requirement, \
            professional_requirement,industry_requirement,salary,benefit,email,phone,publish_time,job_requirement,id)
        try:
            self.cursor.execute(sql)
            self.connection.commit()
            print('update successfully')
        except Exception as err:
            print(err)
            self.connection.rollback()

    # 执行完各种操作的刷新操作
    def reload(self, ids):
        sql = "select * from job where id in (%s)" % (','.join(str(id) for id in ids))
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            # print(result)
            return result
        except Exception as err:
            print(err)

    # 查询所有岗位的job_function和job_requirement
    def select_fun_req(self):
        sql = 'select job_name,job_function,job_requirement from job'
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            # print(result)
            return result
        except Exception as err:
            print(err)

    # 根据岗位名查询岗位信息
    def selectByjobName(self, jobName):
        sql = 'select * from job where job_name = %s' %jobName
        print("sql:", sql)
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            # print(result)
            return result
        except Exception as err:
            print(err)