#-*- coding=utf-8 -*-
# @Time    : 2022/6/10 9:12
# @Author  : Caleb
# @File    : DB.py
# @Software: PyCharm

import pymysql as mysql

class Database():
    def __init__(self):
        self.connection = mysql.connect(
                            host = 'sh-cynosdbmysql-grp-i3qavwac.sql.tencentcdb.com',
                            port = 25998,
                            user = 'root',
                            passwd = 'Yitiaoyu1',
                            database = 'rpds',
                            charset='utf8',use_unicode=True)
        self.cursor = self.connection.cursor()
        print('连接成功')

    def show_table(self):
        # 显示当前数据库所有表
        self.cursor.execute("SHOW TABLES")
        for x in self.cursor:
            print(x)

    def get_connention(self):
        return self.connection

    def get_cursor(self):
        return self.cursor

#db = Database()
#db.show_table()




