#-*- coding=utf-8 -*-
import numpy
import pymysql as mysql
from DB import Database
import os,re

class PerPost():
    def __init__(self):
        self.connection = Database().get_connention()
        self.cursor = self.connection.cursor()

    def close(self):
        self.connection.close()
        self.cursor.close()

    def select_perPost(self,search_dict,search_value,age_limit):
        sql = "select * from resume where 1=1"

        if search_dict["postName"]:
            sql = sql + " and (job_title like %s)"

        if search_dict["major"]:
            if len(search_dict["major"]) == 1:
                sql = sql + " and (major_per like %s)"
            if len(search_dict["major"]) > 1:
                sql = sql + " and (major_per like %s"
                for i in search_dict["major"][1:]:
                    sql = sql + " or major_per like %s"
                sql = sql + ")"

        if search_dict["skill"]:
            if len(search_dict["skill"]) == 1:
                sql = sql + " and (lower(skills_tags) like %s)"
            if len(search_dict["skill"]) > 1:
                sql = sql + " and (lower(skills_tags) like %s"
                for i in search_dict["skill"][1:]:
                    sql = sql + " or lower(skills_tags) like %s"
                sql = sql + ")"

        # if search_dict["office"]:
        #     if len(search_dict["skill"]) == 1:
        #         sql = sql + " and (lower(office_skill_per) like %s)"
        #     if len(search_dict["skill"]) > 1:
        #         sql = sql + " and (lower(office_skill_per) like %s"
        #         for i in search_dict["skill"][1:]:
        #             sql = sql + " or lower(office_skill_per) like %s"
        #         sql = sql + ")"

        if search_dict["work_year"]:
            sql = sql + " and (CAST(work_year as UNSIGNED) > %s)"

        if search_dict["age"]:
            if age_limit == "上":
                sql = sql + " and (CAST(age_per as UNSIGNED) > %s)"
            else:
                sql = sql + " and (CAST(age_per as UNSIGNED) < %s)"

        if search_dict["edu"]:
            if len(search_dict["edu"]) == 1:
                sql = sql + " and (highest_edu_per like %s)"
            if len(search_dict["edu"]) > 1:
                sql = sql + " and (highest_edu_per like %s"
                for i in search_dict["edu"][1:]:
                    sql = sql + " or highest_edu_per like %s"
                sql = sql + ")"
                sql = sql + "order by case highest_edu_per when '博士' then 1 when '硕士' then 2 when '本科' then 3 when '大专' then 4 when '高中' then 5 when '中专' then 6 end asc"

        print("sql",sql)
        try:
            self.cursor.execute(sql,search_value)
            result = self.cursor.fetchall()
            return result
        except Exception as err:
            print(err)