from paddlenlp import Taskflow
from zipfile import ZipFile
from bs4 import BeautifulSoup
from ordered_set import OrderedSet
import os
import fitz  # fitz就是pip install PyMuPDF
from tqdm import tqdm
import datetime
import math
import re

from OCRshibie.Python_SDK.test_code.OCRTest import *
# 导入图片识别模块

# 定义提取的内容
schema = ['姓名', '出生年月', '年龄','最高学历','毕业院校', '工作年限','电话','性别', '项目名称', '项目责任', '项目时间', '籍贯', '政治面貌', '落户市县', '学位', '毕业时间', '工作时间', '工作内容', '职务', '工作单位']
# schema = ['姓名', '出生日期', '电话']
# ie_default = Taskflow("information_extraction", schema=schema,task_path=r'E:\研究生工作\十二届软件杯\resume-analysis-system-back\checkpoint\base')
ie_default = Taskflow("information_extraction", schema=schema, task_path = r"C:\Users\lcf\.paddlenlp\taskflow\information_extraction\uie-base")
# API模型
# ie_custom = Taskflow("information_extraction", schema=schema,task_path=r'E:\研究生工作\十二届软件杯\resume-analysis-system-back\checkpoint\model_best')
ie_custom = Taskflow("information_extraction", schema=schema,task_path=r'C:\Users\lcf\.paddlenlp\taskflow\information_extraction\model_best')
# ie_custom = Taskflow("information_extraction", schema=schema)
# 微调模型
# pprint(ie_default("姓名小李性别男出生日期2000年04月民族汉族联系电话13602173036"))
# a = ie_default("2月8日上午北京冬奥会自由式滑雪女子大跳台决赛中中国选手谷爱凌以188.25分获得金牌！")
# pprint(a)


# 从docx文件中抽取文本，定义函数
def get_paragraphs_text(path):
    # 打开docx文件
    document = ZipFile(path)
    xml = document.read("word/document.xml")
    wordObj = BeautifulSoup(xml.decode("utf-8"), "lxml")

    # 找到所有的<w:t>、<w:br/>和<w:p>标签，这些标签包含了文字内容、换行符和段落符号
    text_tags = wordObj.find_all(["w:t", "w:p"])
    # 保存提取的文字
    extracted_text = ""
    # 用于存储已提取的行
    extracted_lines = set()
    # 遍历每个标签
    for tag in text_tags:
        # 如果是<w:t>标签，提取文字内容
        if tag.name == "w:t":
            text = tag.text.strip()
            text = text.replace(' ', '')
            if text:
                extracted_text += text


        # 如果是<w:p>标签，添加段落符号（仅在非空行时添加）
        elif tag.name == "w:p":
            if extracted_text and extracted_text[-1] != "\n":
                extracted_text += "\n"

    lines = extracted_text.split("\n")
    my_ordered_set = OrderedSet(lines)
    # 输出提取的文字
    newtext = ";".join(my_ordered_set)
    return newtext




def replace_non_digit(string):
    """
    将字符串中的非数字字符替换为空字符
    """
    new_string = ''
    for char in string:
        if char.isdigit():
            new_string += char
        else:
            new_string += ''
    return new_string






# 计算工作时间方法
def calculate_work_years(work_periods):
    current_year = datetime.datetime.now().year
    current_month = datetime.datetime.now().month
    total_months = 0
    for period in work_periods:
        # 替换可能的分隔符为统一的格式
        period = period.replace("-", "～")
        # 处理“至今”情况
        period = period.replace("至今", f"{current_year}.{current_month}")
        # 提取开始和结束的年份和月份
        match = re.match(r'(\d{4})(?:\.(\d{1,2}))?～(\d{4})(?:\.(\d{1,2}))?', period)
        if match:
            start_year, start_month, end_year, end_month = match.groups()
            start_year, end_year = int(start_year), int(end_year)
            start_month = int(start_month) if start_month else 1
            end_month = int(end_month) if end_month else 12
            # 计算工作月数
            months = (end_year - start_year) * 12 + end_month - start_month + 1
            total_months += months
    # 计算工作年限，向上取整
    work_years = math.ceil(total_months / 12)
    return work_years



# 获取抽取信息
def get_info(paragraphs_text):
    s = OrderedSet()
    # 创建一个空字典，用于存放抽取结果
    schema_dict = {}
    # 使用微调后的模型抽取信息
    a = ie_custom(paragraphs_text)
    periods = 0
    # 使用微调前的模型抽取信息
    b = ie_default(paragraphs_text)
    # 遍历预定义的schema
    try:
        for i in schema:
            if i in a[0]:
                if i == '性别':  # 如果当前字段是性别
                    # 如果预测结果是男或女，则直接使用该结果
                    if a[0][i][0]['text'] in ['男', '女']:
                        schema_dict[i] = a[0][i][0]['text']
                    # 如果微调后的模型预测结果不是男或女，但微调前的模型预测结果是男或女，则使用微调前的模型的预测结果
                    elif i in b[0] and b[0][i][0]['text'] in ['男', '女']:
                        schema_dict[i] = b[0][i][0]['text']
                    else:  # 如果两个模型的预测结果都不是男或女，则该字段为空
                        schema_dict[i] = ''
                elif i == '年龄':  # 如果当前字段是年龄
                    if re.sub(r'\D', '', a[0][i][0]['text']):
                        # 将非数字的字符替换为空
                        text1 = re.sub(r'\D', '', a[0][i][0]['text'])
                        # 如果字符串长度小于等于 2 ，截取两位，否则截取四位
                        if len(text1) <= 2:
                            result = text1[:2]
                            schema_dict[i] = result
                        elif len(text1) >2:
                            result = text1[:4]
                            schema_dict[i] = str(2023 - int(result) + 1)
                elif i=='工作年限':
                    try:
                        for work_period in a[0][i]:
                                s.add(work_period['text'])
                        schema_dict[i]=calculate_work_years(s)
                    except Exception as e:
                        schema_dict[i]='0'
                else:  # 如果当前字段不是性别也不是年龄，则直接使用微调后的模型的预测结果
                    schema_dict[i] = a[0][i][0]['text']
            else:  # 如果微调后的模型无法识别当前字段
                if i in b[0]:  # 如果微调前的模型能识别当前字段
                    if i == '性别':  # 如果当前字段是性别
                        # 如果预测结果是男或女，则直接使用该结果
                        if b[0][i][0]['text'] in ['男', '女']:
                            schema_dict[i] = b[0][i][0]['text']
                        else:  # 如果预测结果不是男或或者女，则该字段为空
                            schema_dict[i] = ''
                    elif i == '年龄':  # 如果当前字段是年龄
                        if re.sub(r'\D', '', b[0][i][0]['text']):
                            # 将非数字的字符替换为空
                            text1 = re.sub(r'\D', '', b[0][i][0]['text'])
                            # 如果字符串长度小于等于 2 ，截取两位，否则截取四位
                            if len(text1) <= 2:
                                result = text1[:2]
                                schema_dict[i] = result
                            elif len(text1) >2:
                                result = text1[:4]
                                schema_dict[i] = str(2023 - int(result) + 1)
                    elif i=='工作年限':
                        try:
                            for work_period in b[0][i]:
                                    s.add(work_period['text'])
                            schema_dict[i]=calculate_work_years(s)
                        except Exception as e:
                            schema_dict[i]='0'
                    else:  # 如果当前字段不是性别也不是年龄，则直接使用微调前的模型的预测结果
                        schema_dict[i] = b[0][i][0]['text']
                else:  # 如果微调前的模型也无法识别当前字段，则该字段为空
                    schema_dict[i] = ''
    except TypeError:
        text1=""
    # 最高学历规则
    if schema_dict['最高学历'] == "":
        if "博士" in paragraphs_text or "博士研究生" in paragraphs_text:
            schema_dict['最高学历'] = "博士"
        elif "硕士" in paragraphs_text or "硕士研究生" in paragraphs_text:
            schema_dict['最高学历'] = "硕士"
        elif "本科" in paragraphs_text:
            schema_dict['最高学历'] = "本科"
        elif "大专" in paragraphs_text or "职业学院" in paragraphs_text or "专科" in paragraphs_text or "职业技术学院" in paragraphs_text:
            schema_dict['最高学历'] = "大专"
        elif '中专' in paragraphs_text:
            schema_dict['最高学历'] = "中专"
        else:
            schema_dict['最高学历'] = ""
    #     从最高博士到最低中专筛检
    return schema_dict



#
def get_word(path):
    filenames = os.listdir(path)
    result = []
    for filename in tqdm(filenames):
        full_path = os.path.join(path, filename)
        if os.path.isfile(full_path) and filename.endswith('.docx'):  # 添加对文件后缀的检查
            try:
                paragraphs_text = get_paragraphs_text(full_path)
                print(paragraphs_text)
                res = get_info(paragraphs_text)
                res['filename'] = filename
                # 最高学历规则
                if res['最高学历'] == "":
                    if "博士" in paragraphs_text or "博士研究生" in paragraphs_text:
                        res['最高学历'] = "博士"
                    elif "硕士" in paragraphs_text or "硕士研究生" in paragraphs_text:
                        res['最高学历'] = "硕士"
                    elif "本科" in paragraphs_text :
                        res['最高学历'] = "本科"
                    elif "大专" in paragraphs_text or "职业学院" in paragraphs_text or "专科" in paragraphs_text or "职业技术学院" in paragraphs_text:
                        res['最高学历'] = "大专"
                    elif '中专' in paragraphs_text:
                        res['最高学历'] = "中专"
                    else:
                        res['最高学历'] = ""
                #     从最高博士到最低中专筛检




                result.append(res)
            except Exception as e:  # 捕获所有异常
                print(f"处理文件 {filename} 时发生错误: {e}")
    return result
def get_word1(path):
    filenames = os.listdir(path)
    result = []
    for filename in tqdm(filenames):
        full_path = os.path.join(path, filename)
        if os.path.isfile(full_path) and filename.endswith('.docx'):  # 添加对文件后缀的检查
            try:
                paragraphs_text = get_paragraphs_text(full_path)
                print(paragraphs_text)
                res = get_info(paragraphs_text)
                res['filename'] = filename
                # 最高学历规则
                if res['最高学历'] == "":
                    if "博士" in paragraphs_text or "博士研究生" in paragraphs_text:
                        res['最高学历'] = "博士"
                    elif "硕士" in paragraphs_text or "硕士研究生" in paragraphs_text:
                        res['最高学历'] = "硕士"
                    elif "本科" in paragraphs_text :
                        res['最高学历'] = "本科"
                    elif "大专" in paragraphs_text or "职业学院" in paragraphs_text or "专科" in paragraphs_text or "职业技术学院" in paragraphs_text:
                        res['最高学历'] = "大专"
                    elif '中专' in paragraphs_text:
                        res['最高学历'] = "中专"
                    else:
                        res['最高学历'] = ""
                #     从最高博士到最低中专筛检




                result.append(res)
            except Exception as e:  # 捕获所有异常
                print(f"处理文件 {filename} 时发生错误: {e}")
    return result
# 将PDF转为图片格式
def pyMuPDF_fitz(pdfPath, imagePath):
    startTime_pdf2img = datetime.datetime.now()  # 开始时间

    print("imagePath=" + imagePath)
    pdfDoc = fitz.open(pdfPath)
    for pg in range(pdfDoc.page_count):
        page = pdfDoc[pg]
        rotate = int(0)
        # 每个尺寸的缩放系数为4，这将为我们生成分辨率提高4的图像。
        # 此处若是不做设置，默认图片大小为：792X612, dpi=96
        zoom_x = 4  # (1.33333333-->1056x816)   (2-->1584x1224)
        zoom_y = 4
        mat = fitz.Matrix(zoom_x, zoom_y).prerotate(rotate)
        pix = page.get_pixmap(matrix=mat, alpha=False)

        if not os.path.exists(imagePath):  # 判断存放图片的文件夹是否存在
            os.makedirs(imagePath)  # 若图片文件夹不存在就创建

        pix.save(imagePath + '/' + 'images_%s.jpeg' % pg)  # 将图片写入指定的文件夹内

    endTime_pdf2img = datetime.datetime.now()  # 结束时间
    print('pdf转图片时间=', (endTime_pdf2img - startTime_pdf2img).seconds)




def get_info_tupian(Path):
    # 传入图片路径
    s = OrderedSet()
    # 创建一个空字典，用于存放抽取结果
    schema_dict = {}
    # 使用微调后的模型抽取信息
    a = ie_custom({"doc": Path})
    periods = 0
    # 使用微调前的模型抽取信息
    b = ie_default({"doc": Path})
    # 遍历预定义的schema
    try:
        for i in schema:
            if i in a[0]:
                if i == '性别':  # 如果当前字段是性别
                    # 如果预测结果是男或女，则直接使用该结果
                    if a[0][i][0]['text'] in ['男', '女']:
                        schema_dict[i] = a[0][i][0]['text']
                    # 如果微调后的模型预测结果不是男或女，但微调前的模型预测结果是男或女，则使用微调前的模型的预测结果
                    elif i in b[0] and b[0][i][0]['text'] in ['男', '女']:
                        schema_dict[i] = b[0][i][0]['text']
                    else:  # 如果两个模型的预测结果都不是男或女，则该字段为空
                        schema_dict[i] = ''
                elif i == '年龄':  # 如果当前字段是年龄
                    if re.sub(r'\D', '', a[0][i][0]['text']):
                        # 将非数字的字符替换为空
                        text1 = re.sub(r'\D', '', a[0][i][0]['text'])
                        # 如果字符串长度小于等于 2 ，截取两位，否则截取四位
                        if len(text1) <= 2:
                            result = text1[:2]
                            schema_dict[i] = result
                        elif len(text1) >2:
                            result = text1[:4]
                            schema_dict[i] = str(2023 - int(result) + 1)
                elif i=='工作年限':
                    try:
                        for work_period in a[0][i]:
                                s.add(work_period['text'])
                        schema_dict[i]=calculate_work_years(s)
                    except Exception as e:
                        schema_dict[i]='0'
                else:  # 如果当前字段不是性别也不是年龄，则直接使用微调后的模型的预测结果
                    schema_dict[i] = a[0][i][0]['text']
            else:  # 如果微调后的模型无法识别当前字段
                if i in b[0]:  # 如果微调前的模型能识别当前字段
                    if i == '性别':  # 如果当前字段是性别
                        # 如果预测结果是男或女，则直接使用该结果
                        if b[0][i][0]['text'] in ['男', '女']:
                            schema_dict[i] = b[0][i][0]['text']
                        else:  # 如果预测结果不是男或或者女，则该字段为空
                            schema_dict[i] = ''
                    elif i == '年龄':  # 如果当前字段是年龄
                        if re.sub(r'\D', '', b[0][i][0]['text']):
                            # 将非数字的字符替换为空
                            text1 = re.sub(r'\D', '', b[0][i][0]['text'])
                            # 如果字符串长度小于等于 2 ，截取两位，否则截取四位
                            if len(text1) <= 2:
                                result = text1[:2]
                                schema_dict[i] = result
                            elif len(text1) >2:
                                result = text1[:4]
                                schema_dict[i] = str(2023 - int(result) + 1)
                    elif i=='工作年限':
                        try:
                            for work_period in b[0][i]:
                                    s.add(work_period['text'])
                            schema_dict[i]=calculate_work_years(s)
                        except Exception as e:
                            schema_dict[i]='0'
                    else:  # 如果当前字段不是性别也不是年龄，则直接使用微调前的模型的预测结果
                        schema_dict[i] = b[0][i][0]['text']
                else:  # 如果微调前的模型也无法识别当前字段，则该字段为空
                    schema_dict[i] = ''
    except TypeError:
        text1=""
    # 最高学历规则
    if schema_dict['最高学历'] == "":
        if "博士" in paragraphs_text or "博士研究生" in paragraphs_text:
            schema_dict['最高学历'] = "博士"
        elif "硕士" in paragraphs_text or "硕士研究生" in paragraphs_text:
            schema_dict['最高学历'] = "硕士"
        elif "本科" in paragraphs_text:
            schema_dict['最高学历'] = "本科"
        elif "大专" in paragraphs_text or "职业学院" in paragraphs_text or "专科" in paragraphs_text or "职业技术学院" in paragraphs_text:
            schema_dict['最高学历'] = "大专"
        elif '中专' in paragraphs_text:
            schema_dict['最高学历'] = "中专"
        else:
            schema_dict['最高学历'] = ""
    #     从最高博士到最低中专筛检
    return schema_dict

if __name__ == '__main__':

    # word提取测试
    path = 'C:/Users/82470/Desktop/23software/dataset/dataset_CV/dataset_CV/CV/13.docx'

    paragraphs_text = get_paragraphs_text(path)
    # print(paragraphs_text)
    res = get_info(paragraphs_text)
    # result = get_word('C:/Users/82470/Desktop/23software/dataset/dataset_CV/dataset_CV/CV')
    print(res)
    #     路径
    # result_pd = pd.DataFrame(result)
    # result_pd.to_excel('ie微调.xlsx')

#     图片测试

    path1 = 'C:/software/OCRshibie/Python_SDK/test_code/2.jpg'
    text = request_smartstructure_file(path)
    # text = request_smartstructure_file(image_path)
    # 调用API
    text = eval(text)
    # 转为字典
    pap = Data_cleaning_api(text)
    res = get_info(pap)
    print(res)

    # PDF提取测试
    # PDF_Path = "C:/Users/82470/Desktop/23software/2.pdf"
    # # pdf路径
    # img_output = "output"
    # # 输出图片路径
    # pyMuPDF_fitz(PDF_Path, img_output)
    # res = get_info_tupian("output/images_0.jpeg")
    # # 根据图片路径直接提取
    # print(res)










