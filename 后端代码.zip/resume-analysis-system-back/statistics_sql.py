#-*- coding=utf-8 -*-
import numpy
import pymysql as mysql
from DB import Database
import os,re
from skimage.io import imsave

class Statistics():
    def __init__(self):
        self.connection = Database().get_connention()
        self.cursor = self.connection.cursor()

    def close(self):
        self.connection.close()
        self.cursor.close()

    # 查询人才画像数
    def talent_count(self):
        sql = 'select talent_portrait from statistics'
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            return result
        except Exception as err:
            print(err)

    # 查询人岗匹配的数量
    def person_post_count(self):
        sql = 'select person_post from statistics'
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            return result
        except Exception as err:
            print(err)

    # 更新人才画像生成的数量
    def update_talent(self):
        sql = "update statistics set talent_portrait=talent_portrait+1 where id = 1"
        try:
            self.cursor.execute(sql)
            self.connection.commit()
            print('update successfully')
        except Exception as err:
            print(err)
            self.connection.rollback()

    # 更新人岗匹配的次数
    def update_person_post(self):
        sql = "update statistics set person_post=person_post+1 where id = 1"
        try:
            self.cursor.execute(sql)
            self.connection.commit()
            print('人岗匹配次数更新成功')
        except Exception as err:
            print(err)
            self.connection.rollback()
