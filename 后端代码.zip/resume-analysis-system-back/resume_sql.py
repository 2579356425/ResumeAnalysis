#-*- coding=utf-8 -*-
import numpy
import pymysql as mysql
from DB import Database
import os,re
from skimage.io import imsave

class Resume():
    def __init__(self):
        self.connetion = Database().get_connention()
        self.cursor = self.connetion.cursor()

    def close(self):
        self.connetion.close()
        self.cursor.close()

    def insert(self, args):
        sql = 'insert into resume(name_per,sex_per,email_per,age_per,phone_per,qq,weixin,' \
              'address_per,height,weight,race,nationality,marital_status,' \
              'highest_edu_per,adm_date,gra_date,gra_school_per,major_per,' \
              'lan_skill_per,prof_skill_per,office_skill_per,awards_per,certificates,' \
              'political_status,postal_code,school_level,courses,edu_gpa,job_title,company_name,work_date,' \
              'work_description,work_industry,work_year,' \
              'project_name,project_position,project_date,project_description,' \
              'social_pos,social_description,social_cpy,social_date,' \
              'train_org,training_description,train_date,self_evaluation,' \
              'candidate_job_title,parsing_time,resume_type,resume_name,path_resume,avatar_url,' \
              'pred_salary,pos_tags,skills_tags,username)' \
              '  values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,' \
              '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,' \
              '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,' \
              '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,' \
              '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,' \
              '%s,%s,%s,%s,%s,%s)'

        # sql = 'insert into resume(name_per, sex_per, email_per, age_per, phone_per, qq, weixin, address_per, height, weight' \
        #       'race, nationality, marital_status, highest_edu_per, adm_date, gra_date, gra_school_per, major_per, courses, edu_gpa' \
        #       'school_level, lan_skill_per, prof_skill_per, office_skill_per, certificates, awards_per, political_status, postal_code, job_title, company_name, ' \
        #       'work_date, work_description, work_industry, work_year, project_date, project_name, project_position, project_description, social_date, social_cpy, ' \
        #       'social_description, social_pos, train_date, train_org, training_description, self_evaluation, candidate_job_title, parsing_time, resume_type, resume_name, ' \
        #       'path_resume, avatar_url, pred_salary, pos_tags, skills_tags, username)'\
        #       '  values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,' \
        #       '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,' \
        #       '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,' \
        #       '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,' \
        #       '%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,' \
        #       '%s,%s,%s,%s,%s,%s)'

        try:
            self.cursor.execute(sql, args)
            self.connetion.commit()
            print('insert successfully')
            return True
        except Exception as err:
            print(err)
            result = re.search("Duplicate entry.*key.*PRIMARY", str(err))
            if (result == None):
                self.connetion.rollback()

    def select_resume(self,username):
        print("username:", username)
        if username != "admin":
            sql = 'select * from resume where username = %s' %username
        else:
            sql = 'select * from resume'
        print('sql:', sql)
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            print('result:', result)
            return result
        except Exception as err:
            print(err)

    def selectById(self,id):
        sql = 'select * from resume where id = %s' %id
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            print('select successfully')
            self.connetion.commit()
            return result
        except Exception as err:
            print(err)
            self.connetion.rollback()

    def select_resumeBySelect(self,search_dict,search_value,username):
        sql = 'select * from resume where (age_per between %s and %s)'
        if search_dict["name_per"]:
            sql = sql + " and (name_per like %s)"
        if search_dict["sex_per"]:
            sql = sql + " and (sex_per like %s)"
        if search_dict["work_description"]:
            if search_dict["work_description"] == "有":
                sql = sql + " and (work_description <>'')"  # 有
            else:
                sql = sql + " and ((work_description is NULL) or (work_description = ''))"  # 无
        if search_dict["highest_edu_per"]:
            sql = sql + " and (highest_edu_per like %s)"
        if search_dict["major_per"]:
            sql = sql + " and (major_per like %s)"
        if search_dict["prof_skill_per"]:
            sql = sql + " and (prof_skill_per like %s)"

        if username != "admin":
            search_value_list=list(search_value)
            search_value_list.append(username)
            search_value=tuple(search_value_list)
            sql = sql + " and username = %s"
        try:
            self.cursor.execute(sql,search_value)
            result = self.cursor.fetchall()
            print("简历筛选查询成功")
            return result
        except Exception as err:
            print(err)

    #关键词查询
    def select_resumeByKeyword(self,keyword,username):
        """
        支持姓名、性别、地址、毕业院校、最高学历、专业、专业技能、
        证书、政治面貌、学校水平、工作公司、职位名、职位所属技能、工作描述(工作经历)、项目描述
        """
        if username != "admin":
            sql = "select * from resume where (name_per like '%%%s%%' or sex_per like '%%%s%%' or address_per like '%%%s%%' " \
                  "or gra_school_per like '%%%s%%' or highest_edu_per like '%%%s%%' or major_per like '%%%s%%' or prof_skill_per like '%%%s%%'" \
                  " or certificates like '%%%s%%' or political_status like '%%%s%%' or school_level like '%%%s%%' or company_name like '%%%s%%'" \
                  " or job_title like '%%%s%%' or work_description like '%%%s%%' or project_description like '%%%s%%') and username = %s" % (
                  keyword, keyword, keyword,keyword, keyword, keyword, keyword, keyword, keyword, keyword,
                  keyword, keyword, keyword, keyword,username)
        else:
            sql = "select * from resume where name_per like '%%%s%%' or sex_per like '%%%s%%' or address_per like '%%%s%%' " \
              "or gra_school_per like '%%%s%%' or highest_edu_per like '%%%s%%' or major_per like '%%%s%%' or prof_skill_per like '%%%s%%'" \
              " or certificates like '%%%s%%' or political_status like '%%%s%%' or school_level like '%%%s%%' or company_name like '%%%s%%'" \
              " or job_title like '%%%s%%' or work_description like '%%%s%%' or project_description like '%%%s%%'" %(keyword,keyword,keyword,keyword,keyword,keyword,keyword,keyword,keyword,keyword,keyword,keyword,keyword,keyword)
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            #print(result)
            return result
        except Exception as err:
            print(err)


    def delete(self,id):
        sql = 'delete from resume where id = %s' %id
        try:
            self.cursor.execute(sql)
            print('delete successfully')
            self.connetion.commit()
        except Exception as err:
            print(err)
            self.connetion.rollback()


    def update(self,name_per,sex_per,email_per,age_per,phone_per,qq,weixin,address_per,height,weight,race,nationality,marital_status,
               highest_edu_per,adm_date,gra_date,gra_school_per,major_per,lan_skill_per,prof_skill_per,office_skill_per,awards_per,certificates,
              political_status,postal_code,school_level,courses,edu_gpa,job_title,company_name,work_date,
              work_description,work_industry,work_year,
              project_name,project_position,project_date,project_description,
              social_pos,social_description,social_cpy,social_date,
              train_org,training_description,train_date,self_evaluation,
              candidate_job_title,parsing_time,resume_type,resume_name,path_resume,avatar_url,
              pred_salary,pos_tags,skills_tags,username,id):
        sql = "update resume set name_per='%s',sex_per='%s',email_per= '%s',age_per='%s'," \
              "phone_per='%s',qq='%s',weixin='%s',address_per='%s',height='%s',weight='%s',race='%s',nationality='%s',marital_status='%s'," \
              "highest_edu_per='%s',adm_date='%s',gra_date='%s',gra_school_per='%s',major_per='%s'," \
              "lan_skill_per='%s',prof_skill_per='%s',office_skill_per='%s',awards_per='%s',certificates='%s'," \
              "political_status='%s',postal_code='%s',school_level='%s',courses='%s',edu_gpa='%s'," \
              "job_title='%s',company_name='%s',work_date='%s',work_description='%s',work_industry='%s',work_year='%s'," \
              "project_name='%s',project_position='%s',project_date='%s',project_description='%s'," \
              "social_pos='%s',social_description='%s',social_cpy='%s',social_date='%s'," \
              "train_org='%s',training_description='%s',train_date='%s',self_evaluation='%s'," \
              "candidate_job_title='%s',parsing_time='%s',resume_type='%s',resume_name='%s',path_resume='%s',avatar_url='%s'," \
              "pred_salary='%s',pos_tags='%s',skills_tags='%s',username = '%s' where id = %s" %(name_per,sex_per,email_per,age_per,phone_per,qq,weixin,address_per,height,weight,race,nationality,marital_status,highest_edu_per,adm_date,gra_date,gra_school_per,major_per,
              lan_skill_per,prof_skill_per,office_skill_per,awards_per,certificates,
              political_status,postal_code,school_level,courses,edu_gpa,job_title,company_name,work_date,
              work_description,work_industry,work_year,project_name,project_position,project_date,project_description,
              social_pos,social_description,social_cpy,social_date,train_org,training_description,train_date,self_evaluation,
              candidate_job_title,parsing_time,resume_type,resume_name,path_resume,avatar_url,pred_salary,pos_tags,skills_tags,username,id)
        try:
            self.cursor.execute(sql)
            self.connetion.commit()
            print('update successfully')
        except Exception as err:
            print(err)
            self.connetion.rollback()

    # 执行完各种操作的刷新操作
    def reload(self,ids):
        sql = "select * from resume where id in (%s)" % (','.join(str(id) for id in ids))
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            # print(result)
            return result
        except Exception as err:
            print(err)

    #查询解析的简历数
    def resume_count(self):
        sql = 'select count(*) from resume'
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            print(result)
            return result[0][0]
        except Exception as err:
            print(err)

    # 查询今日解析的简历数
    def resume_count_today(self):
        sql = 'select count(*) from resume where DATE(parsing_time) = CURDATE()'
        # sql="select SUM(case when highest_edu_per = '本科' then 1 else 0 end),SUM(case when highest_edu_per = '硕士' then 1 else 0 end),SUM(case when highest_edu_per = '博士' then 1 else 0 end) from resume"
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            print(result)
            return result[0][0]
        except Exception as err:
            print(err)

    # 查询专科、本科、硕士、博士的简历数
    def resume_count_edu(self):
        sql = "select SUM(case when highest_edu_per = '专科' or highest_edu_per='大专' then 1 else 0 end), SUM(case when highest_edu_per = '本科' then 1 else 0 end),SUM(case when highest_edu_per = '硕士' then 1 else 0 end),SUM(case when highest_edu_per = '博士' then 1 else 0 end) from resume"
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            zhuanke = int(result[0][0])
            undergra = int(result[0][1])
            master = int(result[0][2])
            doctor = int(result[0][3])
            new_result=list()
            new_result.append(zhuanke)
            new_result.append(undergra)
            new_result.append(master)
            new_result.append(doctor)
            return new_result
        except Exception as err:
            print(err)

    # 查询指定简历的skills_tags, age_per, highest_edu_per, work_year, major_per这五个字段
    def selectSAHWMById(self,id):
        sql = 'select skills_tags, age_per, highest_edu_per, work_year, major_per from resume where id = %s' %id
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            print('select successfully')
            self.connetion.commit()
            return result
        except Exception as err:
            print(err)
            self.connetion.rollback()