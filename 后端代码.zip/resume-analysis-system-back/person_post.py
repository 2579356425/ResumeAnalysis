# -*- coding: utf-8 -*-
# 人岗匹配

from DB import Database
import os,re
from paddlenlp import Taskflow
from perPost_sql import PerPost

class Person_post():
    def __init__(self):
        self.connetion = Database().get_connention()
        self.cursor = self.connetion.cursor()

    def close(self):
        self.connetion.close()
        self.cursor.close()

    # 以岗推人
    def postToPerson(self,postName,postDescription, ie_default):
        entity = ie_default(postDescription)
        print(entity)

        keys_list = list()
        for key in entity[0].keys():
            keys_list.append(key)
        new_skill_list = list()
        if "技术" in keys_list:
            skill = entity[0]['技术']
            skill_list = list()
            for line in skill:
                skill_list.append(line['text'])
            print("skill", skill_list)
            new_skill_list = skill_list[:]
            if "办公" in skill_list:
                new_skill_list.append("PPT")
                new_skill_list.append("EXCEL")
                new_skill_list.append("WORD")
                new_skill_list.append("OFFICE")

        edu_list = list()
        if "学历" in keys_list:
            get_edu = entity[0]['学历'][0]['text']
            print("edu", get_edu)
            edu_list = list(get_edu)
            edu = "".join(edu_list[:2])
            print("edu", edu)
            if edu == "中专":
                edu_list = ['博士', '硕士', '本科', '大专', '高中', '中专']
            elif edu == "高中":
                edu_list = ['博士', '硕士', '本科', '大专', '高中']
            elif edu == "大专":
                edu_list = ['博士', '硕士', '本科', '大专']
            elif edu == "本科":
                edu_list = ['博士', '硕士', '本科']
            elif edu == "硕士":
                edu_list = ['博士', '硕士']
            elif edu == "博士":
                edu_list = ['博士']
            else:
                edu_list = []

        major_list = list()
        if "专业" in keys_list:
            major = entity[0]['专业']
            print("major", major)
            for line in major:
                major_list.append(line['text'])
            print("major", major_list)

        age = ""
        age_limit=""
        if "年龄" in keys_list:
            get_age = entity[0]['年龄'][0]['text']
            age_list = list(get_age)
            age_limit = age_list[-1]
            print(age_limit)
            age = get_age.split("岁")[0]
            print("age", age)
            if age.isdigit():
                age = int(age)
            else:
                age = ""

        new_work_year = ""
        if "工作年限" in keys_list:
            Chinese_year = {"一": 1, "两": 2, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}
            Chinese_year_key = ["一", "二", "两", "三", "四", "五", "六", "七", "八", "九", "十"]
            get_work_year = entity[0]['工作年限'][0]['text']
            work_year = get_work_year.split("年")[0]  # 获取“年”前面的内容
            print("work_year", work_year)
            if work_year in Chinese_year_key:
                new_work_year = Chinese_year[work_year]
            else:
                new_work_year = work_year
            print("new_work_year", new_work_year)
            if str(new_work_year).isdigit():
                new_work_year = int(new_work_year)
            else:
                new_work_year = ""


        search_dict = {}
        search_dict["postName"] = postName
        search_dict["major"] = major_list
        search_dict["skill"] = new_skill_list
        search_dict["work_year"] = new_work_year
        search_dict["age"] = age
        search_dict["edu"] = edu_list
        search_value = []
        for key, value in search_dict.items():
            if value:
                if isinstance(value, str):
                    value = '%' + value + '%'
                if isinstance(value, list):
                    old_value = value[:]
                    for line in old_value:
                        new_line = "%" + line + "%"
                        search_value.append(new_line)
                else:
                    search_value.append(value)

        print("search_dict", search_dict)
        search_value = tuple(search_value)
        print("search_value", search_value)
        perPost=PerPost()
        result=perPost.select_perPost(search_dict, search_value, age_limit)
        return result


# if __name__ == '__main__':
# #     postName = "机器学习工程师"
# #     postDescription = '任职要求：1、本科及以上学历，计算机、通信、电子、自动化等相关专业2、一年以上机器视觉与图像处理行业项目开发经验3、熟练掌握图像处理算法原理，精通OpenCV，熟悉Halcon等视觉算法库及工具4、精通C++/C#编程语言5、对图像识别算法有深刻理解及应用经验优先6、具有强的协调沟通能力、分析解决问题能力及团队合作精神7、熟悉神经网络、支持向量机、深度学习等优先考虑7、 熟悉主流的机器学习算法，能够熟练使用深度学习TensorFlow、Caffe等深度学习框架；8、30岁以下9、2年以上的工作经验'
#     postName = "市场营销"
#     postDescription = "1.熟练使用办公软件，可以独立制作表格、PPT等；2.良好的沟通能力，善于维护客户关系；3.有拓展、策划经验能力者优先考虑。4.本科以上5.10年以上相关工作经验"
#     #postDescription ="1.大专及以上学历，1-2年相关工作经验；2.熟悉平面设计软件及视频剪辑等，设计感好；3.工作责任心强，沟通及理解能力强。"
#     #postDescription ="1.2年及以上产品运营经验；2.主动性强，逻辑清晰，沟通能力强，能独立负责和落地运营项目能调动资源为运营目标服务；3.有较强数据分析能力、数据敏感性强。"
#     #scription="1、本科及以上学历，计算机、通信、电子、自动化等相关专业2、一年以上机器视觉与图像处理行业项目开发经验3、熟练掌握图像处理算法原理，精通OpenCV，熟悉Halcon等视觉算法库及工具4、精通C++编程语言5、对图像识别算法有深刻理解及应用经验优先6、具有强的协调沟通能力、分析解决问题能力及团队合作精神7、熟悉神经网络、支持向量机、深度学习等优先考虑"
#     pp = Person_post()
#     result=pp.postToPerson(postName,postDescription)
#     print(result)
