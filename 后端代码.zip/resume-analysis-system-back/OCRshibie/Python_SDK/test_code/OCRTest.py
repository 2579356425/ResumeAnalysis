from OCRshibie.Python_SDK.ecloud import CMSSEcloudOcrClient
# 需要更改路径
import json
import base64


accesskey = '8a9cdd612af34f5e86b8b10b291ef34a'
secretkey = '1576ee9112774792a20820776dff5dae'
# key
url = 'https://api-wuxi-1.cmecloud.cn:8443'

def request_smartstructure_file(image_path):
    # print("请求智能结构化接口")
    requesturl = '/api/ocr/v1/webimage'
    # 接口类型
    # /api/ocr/v1/webimage
    imagepath = image_path
    # 图片地址
    try:
        ocr_client = CMSSEcloudOcrClient(accesskey, secretkey, url)
        response = ocr_client.request_ocr_service_file(requestpath=requesturl, imagepath= imagepath)
        # print(response.text)
        # print(type(response.text))
        return response.text

    except ValueError as e:
        print(e)

def request_webimage_file():
    print("请求File参数")
    requesturl = '/api/ocr/v1/webimage'
    imagepath = 'C:\\Users\\zhuli\\Desktop\\smartlib_python_sdk\\test_code\\sfz.jpg'
    try:
        ocr_client = CMSSEcloudOcrClient(accesskey, secretkey, url)
        response = ocr_client.request_ocr_service_file(requestpath=requesturl, imagepath= imagepath)
        print(response.text)
        
    except ValueError as e:
        print(e)

def request_webimage_base64():
    print("请求Base64参数")
    imagepath = 'D:\\JG-CMSS\\PaaS_MrZ\\智库2023\\SDK\\PythonSDK\\Python_SDK\\test_code\\sfz.jpg'
    requesturl = '/api/ocr/v1/webimage'
    with open(imagepath, 'rb') as f:
        img = f.read()
        image_base64 = base64.b64encode(img).decode('utf-8')
        ocr_client = CMSSEcloudOcrClient(accesskey, secretkey, url)
        response = ocr_client.request_ocr_service_base64(requestpath=requesturl,base64=image_base64)
        print(response.text)


def request_webimage_url():
    print("请求URL参数")
    requesturl = '/api/ocr/v1/webimage'
    imageurl = 'http://10.253.51.155:10086/wangluotupian.jpg'
    try:
        ocr_client = CMSSEcloudOcrClient(accesskey, secretkey, url)
        response = ocr_client.request_ocr_service_url(requesturl, imageurl)
        # print(type(response.))
        print(response.text)
    except ValueError as e:
        print(e)



def request_handwriting():
    requesturl = '/api/ocr/v1/handwriting'
    imagepath = './webimage.jpg'
    try:
        ocr_client = CMSSEcloudOcrClient(accesskey, secretkey, url)
        response = ocr_client.request_ocr_service_file(requestpath=requesturl, imagepath= imagepath)
        print(response.text)
    except ValueError as e:
        print(e)

def request_customverify():
    requesturl = '/api/ocr/v1/selfdefinition'
    imagepath = './shenfenzheng.jpg'
    options = {}
    options['TemplateId'] = '76542407608369152'
    try:
        ocr_client = CMSSEcloudOcrClient(accesskey, secretkey, url)
        response = ocr_client.request_ocr_service_file(requestpath=requesturl, imagepath= imagepath, options=options)
        print(response.text)
    except ValueError as e:
        print(e)



def Data_cleaning_api(text):
    text = text
    First = True
    pap = ""
    for word in text['body']['content']['prism_wordsInfo']:
        if First:
            pap = pap + word['word'] +","
            Frist = False
        else:
            pap = pap + "," + word['word']
        # pap = pap +","+ word['word']
    return pap

if __name__ == "__main__":
    #request_webimage_file()
    image_path = 'C:/software/OCRshibie/Python_SDK/test_code/2.jpg'
    text = request_smartstructure_file(image_path)
    # 调用API
    text = eval(text)
    # 转为字典
    pap = Data_cleaning_api(text)
    # 清洗API返回数据
    print(pap)


    # request_webimage_base64()
    #request_webimage_url()
    #request_handwriting()
    #request_customverify()

