# -*- coding: utf-8 -*-
# @Author : lcf
# @Time : 2023/7/10 15:37

from DB import Database
import os,re
import time
class Portrait():
    def __init__(self):
        self.connetion = Database().get_connention()
        self.cursor = self.connetion.cursor()

    def close(self):
        self.connetion.close()
        self.cursor.close()

    def portrait(self, resumeInfo):
        # print(resumeInfo[0])
        item_info = {}

        # 简历亮点
        highest_edu_per = resumeInfo[0][14]
        prof_skill_per = resumeInfo[0][20]
        courses = resumeInfo[0][27]
        awards_per = resumeInfo[0][22]
        school_level = resumeInfo[0][26]
        spot = ''
        First = True
        if highest_edu_per:
            if '博士' in highest_edu_per or '硕士' in highest_edu_per or '研究生' in highest_edu_per:
                First = False
                edu_spot = highest_edu_per
            else:
                edu_spot = ''
            if edu_spot:
                spot = '具有%s学位，属于高层次人才' % (edu_spot)
        if school_level:
            if First:
                if "985" in school_level:
                    school_spot = "就读于%s类型高校，具备优秀的学习能力" % ('985')
                elif "211" in school_level:
                    school_spot = "就读于%s类型高校，具备优秀的学习能力" % ('211')
                elif '港澳台院校' in school_level:
                    school_spot = "就读于%s，具备优秀的学习能力" % ('港澳台院校')
                elif "海外院校" in school_level:
                    school_spot = "就读于%s，具备优秀的学习能力，良好的外文沟通能力" % ('海外院校')
                else:
                    school_spot = ''
                if school_spot:
                    spot = school_spot
                    First = False
            else:
                if "985" in school_level:
                    school_spot = "就读于%s类型高校，具备优秀的学习能力" % ('985')
                elif "211" in school_level:
                    school_spot = "就读于%s类型高校，具备优秀的学习能力" % ('211')
                elif '港澳台院校' in school_level:
                    school_spot = "就读于%s，具备优秀的学习能力" % ('港澳台院校')
                elif "海外院校" in school_level:
                    school_spot = "就读于%s，具备优秀的学习能力，良好的外文沟通能力" % ('海外院校')
                else:
                    school_spot = ''
                if school_spot:
                    spot = spot + 'Ж' + school_spot
        if prof_skill_per:
            if First:
                prof_skill_per_list = prof_skill_per.split('Ж')
                if len(prof_skill_per_list) > 4 and prof_skill_per_list[-1] and prof_skill_per_list[-2] and \
                        prof_skill_per_list[-3] and prof_skill_per_list[-4] and prof_skill_per_list[-5]:
                    prof_skill_spot = '有丰富的专业技能，对%s、%s、%s、%s、%s等技能或工具有深入的理解' % (
                    prof_skill_per_list[-1], prof_skill_per_list[-2], prof_skill_per_list[-3], prof_skill_per_list[-4],
                    prof_skill_per_list[-5])
                elif len(prof_skill_per_list) > 3 and prof_skill_per_list[-1] and prof_skill_per_list[-2] and \
                        prof_skill_per_list[-3] and prof_skill_per_list[-4]:
                    prof_skill_spot = '有丰富的专业技能，对%s、%s、%s、%s等技能或工具有深入的理解' % (
                    prof_skill_per_list[-1], prof_skill_per_list[-2], prof_skill_per_list[-3], prof_skill_per_list[-4])
                elif len(prof_skill_per_list) > 2 and prof_skill_per_list[-1] and prof_skill_per_list[-2] and \
                        prof_skill_per_list[-3]:
                    prof_skill_spot = '有丰富的专业技能，对%s、%s、%s、%s等技能或工具有深入的理解' % (
                    prof_skill_per_list[-1], prof_skill_per_list[-2], prof_skill_per_list[-3])
                else:
                    prof_skill_spot = ''
                if prof_skill_spot:
                    spot = prof_skill_spot
                if spot:
                    First = False
            else:
                prof_skill_per_list = prof_skill_per.split('Ж')
                if len(prof_skill_per_list) > 5:
                    prof_skill_spot = '有丰富的专业技能，对%s、%s、%s、%s、%s等技能或工具有深入的理解' % (
                    prof_skill_per_list[-1], prof_skill_per_list[-2], prof_skill_per_list[-3], prof_skill_per_list[-4],
                    prof_skill_per_list[-5])
                elif len(prof_skill_per_list) > 3:
                    prof_skill_spot = '有丰富的专业技能，对%s、%s、%s、%s等技能或工具有深入的理解' % (
                    prof_skill_per_list[-1], prof_skill_per_list[-2], prof_skill_per_list[-3], prof_skill_per_list[-4])
                elif len(prof_skill_per_list) > 2:
                    prof_skill_spot = '有丰富的专业技能，对%s、%s、%s、%s等技能或工具有深入的理解' % (
                    prof_skill_per_list[-1], prof_skill_per_list[-2], prof_skill_per_list[-3])
                else:
                    prof_skill_spot = ''
                if prof_skill_spot:
                    spot = spot + 'Ж' + prof_skill_spot
        if courses:
            if First:
                courses_list = courses.split('Ж')
                if len(courses_list) > 2:
                    if courses_list[0]:
                        spot = courses_list[0]
                    elif courses_list[1]:
                        spot = courses_list[1]
                    elif courses_list[2]:
                        spot = courses_list[2]
                elif len(courses_list) > 0:
                    if courses_list[0]:
                        spot = courses_list[0]
                if spot:
                    First = False
            else:
                courses_list = courses.split('Ж')
                if len(courses_list) > 2:
                    if courses_list[0]:
                        courses_spot = courses_list[0]
                    elif courses_list[1]:
                        courses_spot = courses_list[1]
                    elif courses_list[2]:
                        courses_spot = courses_list[2]
                elif len(courses_list) > 0:
                    if courses_list[0]:
                        courses_spot = courses_list[0]
                if courses_spot:
                    spot = spot + 'Ж' + courses_spot
        if awards_per:
            if First:
                awards_per1 = awards_per.replace('\n', '、')
                spot = awards_per1
                First = False
            else:
                awards_per1 = awards_per.replace('\n', '、')
                spot = spot + 'Ж' + awards_per1
        spot_list = spot.replace(" ", '').split('Ж')
        is_spot_list_kong = 0 # 0表示列表所有元素都是空，就返回空列表
        for i in spot_list:
            if(i!=''):
                is_spot_list_kong = 1
        if(is_spot_list_kong == 0):
            spot_list = []
        item_info['highlights'] = spot_list

        # 预测薪资
        predicted_salary = resumeInfo[0][53]
        if(int(predicted_salary)<=5000):
            item_info['predicted_salary'] = '0-5000元/月'
        elif(int(predicted_salary)<=10000):
            item_info['predicted_salary'] = '5000-10000元/月'
        elif (int(predicted_salary) <= 15000):
            item_info['predicted_salary'] = '10000-15000元/月'
        elif (int(predicted_salary) <= 20000):
            item_info['predicted_salary'] = '15000-20000元/月'
        else:
            item_info['predicted_salary'] = '20000元/月以上'
        print(item_info)

        # 预测稳定性
        work_date = resumeInfo[0][31]
        item_info['predicted_stability'] = 0.9
        print(work_date)
        if(work_date!=''):
            if('Ж' in work_date):
                work_date_list = work_date.split('Ж')
                for date in work_date_list:
                    if("至今" not in date):
                        start_time = date.split('-')[0].replace(".", "-")
                        end_time = date.split('-')[1].replace(".", "-")
                        diff_time = time.mktime(time.strptime(end_time, '%Y-%m')) - time.mktime(time.strptime(start_time, '%Y-%m'))
                        if(diff_time<15552000): # 小于半年 就是不稳定
                            item_info['predicted_stability'] = 0.7
                            break
                    else:
                        start_time = date.replace("-", "").split('至今')[0].replace(".", "-")
                        end_time = time.time()
                        diff_time = end_time - time.mktime(time.strptime(str(start_time), '%Y-%m'))
                        if (diff_time < 15552000):  # 小于半年 就是不稳定
                            item_info['predicted_stability'] = 0.7
                            break
            else:
                if ("至今" not in work_date):
                    start_time = work_date.split('-')[0].replace(".", "-")
                    end_time = work_date.split('-')[1].replace(".", "-")
                    diff_time = time.mktime(time.strptime(end_time, '%Y-%m')) - time.mktime(
                        time.strptime(start_time, '%Y-%m'))
                    if (diff_time < 15552000):  # 小于半年 就是不稳定
                        item_info['predicted_stability'] = 0.7
                else:
                    start_time = work_date.replace("-", "").split('至今')[0].replace(".", "-")
                    end_time = time.time()
                    diff_time = end_time - time.mktime(time.strptime(str(start_time), '%Y-%m'))
                    if (diff_time < 15552000):  # 小于半年 就是不稳定
                        item_info['predicted_stability'] = 0.7
        else:
            item_info['predicted_stability'] = 0

        # 人物标签
        tags = {}

        # basic
        basic = []
        sex = resumeInfo[0][2]
        if(sex!= ''):
            basic.append({'tag':sex,"type":'性别'})
        age = resumeInfo[0][4]
        if(age!=''):
            if(int(age)<=10):
                basic.append({'tag': '0到10岁', "type": '年龄'})
            elif(10<int(age)<=15):
                basic.append({'tag': '10到15岁', "type": '年龄'})
            elif(15<int(age)<=20):
                basic.append({'tag': '15到20岁', "type": '年龄'})
            elif (20<int(age)<=25):
                basic.append({'tag': '20到25岁', "type": '年龄'})
            elif (25<int(age)<=30):
                basic.append({'tag': '25到30岁', "type": '年龄'})
            elif (25 < int(age) <= 30):
                basic.append({'tag': '25到30岁', "type": '年龄'})
            elif (30<int(age)<=35):
                basic.append({'tag': '30到35岁', "type": '年龄'})
            elif (35 < int(age) <= 40):
                basic.append({'tag': '35到40岁', "type": '年龄'})
            elif (40 < int(age) <= 45):
                basic.append({'tag': '40到45岁', "type": '年龄'})
            elif (45 < int(age) <= 50):
                basic.append({'tag': '45到50岁', "type": '年龄'})
            elif (50 < int(age) <= 55):
                basic.append({'tag': '50到55岁', "type": '年龄'})
            elif (55 < int(age) <= 60):
                basic.append({'tag': '55到60岁', "type": '年龄'})
            elif (60 < int(age) <= 65):
                basic.append({'tag': '60到65岁', "type": '年龄'})
            else:
                basic.append({'tag': '65岁以上', "type": '年龄'})
        else:
            basic.append({'tag': '', "type": '年龄'})

        if(predicted_salary!= ''):
            if(int(predicted_salary)<10000):
                basic.append({'tag':'初级', 'type':'等级'})
            elif(int(predicted_salary) < 20000):
                basic.append({'tag': '中级', 'type': '等级'})
            else:
                basic.append({'tag': '高级', 'type': '等级'})
        else:
            basic.append({'tag': '', 'type': '等级'})

        is_basic_tag_kong = 0   # 0表示所有的tag都为空
        for basic_tag in basic:
            if(basic_tag['tag']!=''):
                is_basic_tag_kong = 1
                break
        if(is_basic_tag_kong == 0):
            basic = []
        tags['basic'] = basic

        #教育标签
        education = []
        highest_edu = resumeInfo[0][14] # 学历
        if(highest_edu!=''):
            if("硕士" in highest_edu):
                education.append({'tag': '硕士学历', 'type':'学历'})
            elif("高中" in highest_edu):
                education.append({'tag': '高中学历', 'type': '学历'})
            elif ("大专" in highest_edu or "专科" in highest_edu):
                education.append({'tag': '专科学历', 'type': '学历'})
            elif ("本科" in highest_edu):
                education.append({'tag': '本科学历', 'type': '学历'})
            elif ("博士" in highest_edu):
                education.append({'tag': '博士学历', 'type': '学历'})
        else:
            education.append({'tag': '', 'type': '学历'})

        major_edu = resumeInfo[0][18]   # 专业
        if(major_edu != ''):
            if ('Ж' in major_edu):
                major_list = major_edu.split('Ж')
                for major in major_list:
                    education.append({'tag': major, 'type': '专业'})
            else:
                education.append({'tag': major_edu, 'type': '专业'})
        else:
            education.append({'tag': '', 'type': '专业'})
        is_edu_kong = 0
        for edu in education:
            if (edu['tag'] != ''):
                is_edu_kong = 1
                break
        if (is_edu_kong == 0):
            education = []
        tags['education'] = education

        # professional标签
        professional = []
        work_industry = resumeInfo[0][33]   #所处行业
        if(work_industry!=''):
            if('Ж' in work_industry):
                work_industry_list = work_industry.split('Ж')
                for hangye in work_industry_list:
                    professional.append({'tag': hangye, 'type': '行业'})
            else:
                professional.append({'tag': work_industry, 'type': '行业'})
        else:
            professional.append({'tag': '', 'type': '行业'})

        job_title = resumeInfo[0][29]   # 职位名称
        if(job_title!=''):
            if ('Ж' in job_title):
                job_title_list = job_title.split('Ж')
                for job in job_title_list:
                    professional.append({'tag': job, 'type': '职位'})
            else:
                professional.append({'tag': job_title, 'type': '职位'})
        else:
            professional.append({'tag': '', 'type': '职位'})
        is_pro_kong = 0
        for pro in professional:
            if (pro['tag'] != ''):
                is_pro_kong = 1
                break
        if (is_pro_kong == 0):
            professional = []
        tags['professional'] = professional

        # other标签
        other = []
        language = resumeInfo[0][19]
        if(language!=''):
            if(',' in language):
                lan_list = language.split(',')
                for lan in lan_list:
                    other.append({'tag': lan, 'type': '语言'})
            else:
                other.append({'tag': language, 'type': '语言'})
        else:
            other.append({'tag': '', 'type': '语言'})
        certificates = resumeInfo[0][23]
        if(certificates!=''):
            if('Ж' in certificates):
                certificates_list = certificates.split('Ж')
                for certificate in certificates_list:
                    other.append({'tag': certificate, 'type': '证书'})
            else:
                other.append({'tag': certificates, 'type': '证书'})
        else:
            other.append({'tag': '', 'type': '证书'})
        is_other_kong = 0
        for other_tag in other:
            if (other_tag['tag'] != ''):
                is_other_kong = 1
                break
        if (is_other_kong == 0):
            other = []
        tags['other'] = other

        # skills标签
        skills = []
        skillsInfo = resumeInfo[0][55]
        if(skillsInfo!=''):
            if('Ж' in skillsInfo):
                skills_list = skillsInfo.split('Ж')
                for skill in skills_list:
                    skill_tag = skill.split(':')[0]
                    skill_proficiency = round(float(skill.split(':')[1]),2)
                    if(skill_proficiency>1):
                        skill_proficiency = 1
                    skills.append({'tag':skill_tag, 'Proficiency':skill_proficiency})
            else:
                skill_tag = skillsInfo.split(':')[0]
                skill_proficiency = round(float(skillsInfo.split(':')[1]), 2)
                skills.append({'tag': skill_tag, 'Proficiency': skill_proficiency})
        else:
            skills.append({'tag': '', 'Proficiency': 0})
        is_skills_kong = 0
        for skill_tag in skills:
            if (skill_tag['tag'] != ''):
                is_skills_kong = 1
                break
        if (is_skills_kong == 0):
            skills = []
        tags['skills'] = skills

        is_tags_kong = 0 # 判断tags列表是否为空,0为空
        for tag in tags:
            if(tag!=[]):
                is_tags_kong = 1
                break
        if(is_tags_kong==0):
            tags = []
        item_info['tags'] = tags

        # 综合能力
        predicted_capability = {'语言': 79, '社交能力': 88, '领导能力': 60, '工作能力': 75, '教育经历': 60, '所获奖项': 82}
        item_info['predicted_capability'] = predicted_capability

        # 背景行业
        back1 = 55
        back2 = 25
        back3 = 20
        back4 = 30
        back5 = 40
        back6 = 50
        back7 = 60
        back8 = 68
        back9 = 61
        back10 = 53
        back11 = 48
        back12 = 50
        major_per = resumeInfo[0][18]
        highest_edu_per = resumeInfo[0][14]
        if ("建筑" in major_per or "房地产" in major_per):
            back1 = 86
        if ("咨询" in major_per or "法" in major_per or "公务员" in major_per):
            back2 = 88
        if ("生物" in major_per or "制药" in major_per or "医疗" in major_per or "护理" in major_per):
            back3 = 83
        if ("教育" in major_per or "翻译" in major_per or "服务" in major_per):
            back4 = 84
        if ("工程" in major_per):
            back6 = 86
        if ("运营" in major_per or "客服" in major_per or "销售" in major_per or "市场" in major_per or "高中" in highest_edu_per or "大专" in highest_edu_per or "专科" in highest_edu_per):
            back7 = 81
        if ("人事" in major_per or "行政" in major_per or "管理" in major_per):
            back8 = 84
        if ("生产" in major_per or "采购" in major_per or "物流" in major_per):
            back9 = 83
        if ("互联网" in major_per or "网络" in major_per or "软件" in major_per or "计算机" in major_per):
            back10 = 86
        if ("产品" in major_per):
            back11 = 84
        if ("金融" in major_per):
            back12 = 81
        predicted_industry = {'建筑/房地产': back1,'咨询/法律/公务员': back2,'生物/制药/医疗/护理': back3, '教育/翻译/服务业': back4,'其他': back5, '工程师': back6,'运营/客服/销售/市场': back7,'人事/行政/高级管理': back8, '生产/采购/物流': back9,
                              '互联网': back10,'产品': back11,'金融': back12}
        item_info['predicted_industry'] = predicted_industry
        print('item_info:', item_info)

        # 职位预测
        positions = []
        positionInfo = resumeInfo[0][54]
        if (positionInfo != ''):
            if ('Ж' in positionInfo):
                positions_list = positionInfo.split('Ж')
                for position in positions_list:
                    position_tag = position.split(':')[0]
                    position_proficiency = round(float(position.split(':')[1]), 2)
                    if (position_proficiency > 1):
                        position_proficiency = 1
                    positions.append({'tag': position_tag, 'Proficiency': position_proficiency})
            else:
                position_tag = positionInfo.split(':')[0]
                position_proficiency = round(float(positionInfo.split(':')[1]), 2)
                positions.append({'tag': position_tag, 'Proficiency': position_proficiency})
        else:
            positions.append({'tag': '', 'Proficiency': 0})
        is_positions_kong = 0
        for position_tag in positions:
            if (position_tag['tag'] != ''):
                is_positions_kong = 1
                break
        if (is_positions_kong == 0):
            positions = []
        tags['positions'] = positions

        return item_info
        # predicted_stability =