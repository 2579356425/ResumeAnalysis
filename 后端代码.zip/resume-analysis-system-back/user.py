# -*- coding: utf-8 -*-
# @Author : lcf
# @Time : 2023/7/1 21:44
import re
from DB import Database

class User():
    def __init__(self):
        self.connetion = Database().get_connention()
        self.cursor = self.connetion.cursor()

    def close(self):
        self.connetion.close()
        self.cursor.close()

    def register(self, args):
        sql = "insert into user(username, password, identity) values (%s,%s,%s)"
        try:
            self.cursor.execute(sql, args)
            self.connetion.commit()
            print('insert successfully')
            return True
        except Exception as err:
            print(err)
            result = re.search("Duplicate entry.*key.*PRIMARY", str(err))
            if (result == None):
                self.connetion.rollback()

    def login(self):
        sql = 'select * from user'
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            #print(result)
            return result
        except Exception as err:
            print(err)
