#调用数据分析必要的库
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import linear_model  #线性模型
#导入数据
many_variable = pd.read_csv(r"C:\software\csv_dct(1).csv")
# print(many_variable) #查看数据
# print(many_variable.shape)
print('是否存在缺失值',many_variable.isnull().any())  #是否存在缺失值
#数据处理
# print(many_variable)
# 学历
many_variable['highest_edu_per']=many_variable['highest_edu_per'].replace(['中专','研究生','本科学位','学士'],
                    ['高中','硕士','本科','本科'])
many_variable['highest_edu_per']=many_variable['highest_edu_per'].replace([np.nan,'高中','大专','本科','硕士','博士'],
                    ['1','2','3','4','5','6'])
# 地址
many_variable['address_per'] = many_variable['address_per'].replace(['湖北武汉','广东深圳','河南','湖南','浙江省','广东韶关','山东烟台'],
                    [np.nan,np.nan,np.nan,np.nan,np.nan,np.nan,'山东',])
many_variable['address_per']=many_variable['address_per'].replace([np.nan,'北京','上海','广州','山东'],
                    ['1','2','3','4','5'])
# 专业
many_variable['major_per'] = many_variable['major_per'].replace([np.nan],['1'])
for yy in range(200):
    if '计算机' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]),'6')
    elif '信息' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]),'6')
    elif '软件' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]),'6')
    # print(many_variable['major_per'][yy])
    elif '统计' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '2')
    elif '设计' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '3')
    elif '文艺' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '3')
    elif '音乐' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '3')
    elif '视觉' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '3')
    elif '营销' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '4')
    elif '会计' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '5')
    elif '新闻' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '7')
    elif '广告' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '7')
    elif '媒体' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '7')
    elif '摄影' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '7')
    elif '舞蹈学' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '7')
    elif '汉语言' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '8')
    elif '教育' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '8')
    elif '英语' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '8')
    elif '日语' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '8')
    elif '行政' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '9')
    elif '金融' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '10')
    elif '财务' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '10')
    elif '管理' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '10')
    elif '税务' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '10')
    elif '财经' in many_variable['major_per'][yy]:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '10')
    else:
        many_variable['major_per'][yy] = str(many_variable['major_per'][yy]).replace(str(many_variable['major_per'][yy]), '1')
# 专业 1nan 2统计学 3设计 4市场营销 5会计 6计算机 软件工程 7 新闻 广告摄影  8汉语言 9行政 10 金融 财务
# many_variable['work_year'] = many_variable['work_year'].replace([])
# 工作年限
for y in range(200):
    # print(many_variable['work_year'][y])
    if many_variable['work_year'][y]>8:
        many_variable['work_year'][y] = str(many_variable['work_year'][y]).replace(str(many_variable['work_year'][y]),'m')
    elif many_variable['work_year'][y]>0 and many_variable['work_year'][y]<=3:
        many_variable['work_year'][y] = str(many_variable['work_year'][y]).replace(str(many_variable['work_year'][y]),'y')
    elif many_variable['work_year'][y]>3 and many_variable['work_year'][y]<=5:
        many_variable['work_year'][y] = str(many_variable['work_year'][y]).replace(str(many_variable['work_year'][y]),'z')
    elif many_variable['work_year'][y]>5 and many_variable['work_year'][y]<=8:
        many_variable['work_year'][y] = str(many_variable['work_year'][y]).replace(str(many_variable['work_year'][y]),'y')
for yy in range(200):
    many_variable['work_year'][yy] = str(many_variable['work_year'][yy]).replace('nan', 'x')
many_variable['work_year']=many_variable['work_year'].replace(['x','y','z','n','m'],
                    ['1','2','3','4','5'])



# 学校水平
many_variable['school_level'] = many_variable['school_level'].replace([np.nan],['1'])
for yy in range(200):
    if '985' in many_variable['school_level'][yy]:
        many_variable['school_level'][yy] = str(many_variable['school_level'][yy]).replace(str(many_variable['school_level'][yy]), '2')
    elif '211' in many_variable['school_level'][yy]:
        many_variable['school_level'][yy] = str(many_variable['school_level'][yy]).replace(str(many_variable['school_level'][yy]), '3')
    elif '普通院校' in many_variable['school_level'][yy]:
        many_variable['school_level'][yy] = str(many_variable['school_level'][yy]).replace(str(many_variable['school_level'][yy]), '4')
    elif '职业' in many_variable['school_level'][yy]:
        many_variable['school_level'][yy] = str(many_variable['school_level'][yy]).replace(str(many_variable['school_level'][yy]), '4')
    elif '中学' in many_variable['school_level'][yy]:
        many_variable['school_level'][yy] = str(many_variable['school_level'][yy]).replace(str(many_variable['school_level'][yy]), '5')
    else:
        many_variable['school_level'][yy] = str(many_variable['school_level'][yy]).replace(
            str(many_variable['school_level'][yy]), '1')
# many_variable['school_level'] = many_variable['school_level'].replace([])
#查看数据
# print(many_variable)
#准备数据
x = np.array(many_variable[['work_year','highest_edu_per','address_per','major_per','school_level']])
y = np.array(many_variable['pred_salary'])
#切分数据集（训练集和测试集）
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test = train_test_split(x,y,test_size=0.1,random_state=1)
#调用线性回归模型
linear2 = linear_model.LinearRegression()
linear2.fit(X_train,y_train)
#查看截距和系数
print('#查看截距和系数',linear2.coef_ )
print('#查看截距和系数',linear2.intercept_)
#查看拟合效果得分
print('查看拟合效果得分',linear2.score(x,y))

#新数据预测
y_pred =list(linear2.predict(X_test))
print('新数据预测',y_pred)

#最终得出 y=1.35+1.1*work_length+5.19*education+5.92*title+0.09*city
