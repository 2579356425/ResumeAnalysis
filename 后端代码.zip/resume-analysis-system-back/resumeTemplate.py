# -*- coding: utf-8 -*-
# @Author : lcf
# @Time : 2023/6/23 14:41

from DB import Database
import os,re

class resumeTemplate():
    def __init__(self):
        self.connetion = Database().get_connention()
        self.cursor = self.connetion.cursor()

    def close(self):
        self.connetion.close()
        self.cursor.close()

    def getResumeTemplate_easy_business(self):
        sql = "select * from resume_template where template_type='商务简约'"
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            # print("result:", result)
            return result
        except Exception as err:
            print(err)

    def getResumeTemplates_exquisite_fashion(self):
        sql = "select * from resume_template where template_type='精美时尚'"
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            print("result:", result)
            return result
        except Exception as err:
            print(err)

    def getResumeTemplates_table(self):
        sql = "select * from resume_template where template_type='通用表格'"
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            print("result:", result)
            return result
        except Exception as err:
            print(err)

    def getResumeTemplates_steady_rigorous(self):
        sql = "select * from resume_template where template_type='沉稳严谨'"
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            print("result:", result)
            return result
        except Exception as err:
            print(err)

    def getResumeTemplates_individual_creativity(self):
        sql = "select * from resume_template where template_type='个性创意'"
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            print("result:", result)
            return result
        except Exception as err:
            print(err)

    def getResumeTemplates_graduate(self):
        sql = "select * from resume_template where template_type='毕业生'"
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            print("result:", result)
            return result
        except Exception as err:
            print(err)

    def uploadResumeTemplate(self, args):
        # print("args:", args)
        # 数据库中插入int类型仍然是%s
        sql = 'insert into resume_template(template_path, template_type) values (%s, %s)'
        # print("args:", args)
        try:
            self.cursor.execute(sql, args)
            self.connetion.commit()
            print('insert successfully')
            return True
        except Exception as err:
            print(err)
            result = re.search('Duplicate entry.*key.*PRIMARY', str(err))
            if (result == None):
                self.connetion.rollback()

    def deleteResumeTemplate(self, resumeTemplateUrl):
        sql = "delete from resume_template where template_path = '" + resumeTemplateUrl + "'"
        # print('sql:', sql)
        try:
            self.cursor.execute(sql)
            print('delete successfully')
            self.connetion.commit()
        except Exception as err:
            print(err)
            self.connetion.rollback()