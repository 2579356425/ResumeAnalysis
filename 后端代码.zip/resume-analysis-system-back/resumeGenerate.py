import os
import ttkbootstrap as tk
from docxtpl import DocxTemplate
from ttkbootstrap.constants import *
from ttkbootstrap.scrolled import ScrolledFrame
import resume_convert
from DB import Database
import re
from datetime import datetime


class resumeGenerate():
    def __init__(self):
        self.connetion = Database().get_connention()
        self.cursor = self.connetion.cursor()

    def close(self):
        self.connetion.close()
        self.cursor.close()

    def generateWord(self, context):
        # context是简历信息,字典形式
        if os.path.isfile(r"E:\研究生工作\十二届软件杯\resume-analysis-system-back\output\out.docx"):  # 判断是否存在
            os.remove(r"E:\研究生工作\十二届软件杯\resume-analysis-system-back\output\out.docx")  # 删除文件
        #     生成的简历地址
        if os.path.isfile(r'output\out.pdf'):
            os.remove(r'output\out.pdf')
        doc = DocxTemplate(r"E:\研究生工作\十二届软件杯\resume-analysis-system-back\resume_templates\001.docx")
    #     简历模板地址
    #     context1 = self.context
        # 获取简历信息
        doc.render(context)
    #     将信息写入模板中
        doc.save(r"F:\resume/" + context['name'] + ".docx")
    #     保存
        resume_convert.convert_to_pdf(context) # 生成pdf版本

        # 写入数据库
        generate_date = datetime.today().date() # 获取当前日期
        age = str(int(str(datetime.today().date())[:4]) - int(str(context['birthday'])[:4]))
        file_size = str(int(int(os.path.getsize(r"F:\resume/" + context['name'] + ".docx"))/1024))+'KB'
        file_path = r"F:\resume/" + context['name'] + ".docx"
        args = (context['name'], context['phone'], age, file_size, generate_date, file_path)
        sql = 'insert into resume_generate(name, phone, age, file_size, generate_date, file_path) ' \
              'values (%s, %s, %s, %s, %s, %s)'
        # print("args:", args)
        try:
            self.cursor.execute(sql, args)
            self.connetion.commit()
            print('insert successfully')
            return True
        except Exception as err:
            print(err)
            result = re.search('Duplicate entry.*key.*PRIMARY', str(err))
            if (result == None):
                self.connetion.rollback()

    def get_resumeGenerate(self):
        sql = "select * from resume_generate"
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            print("result:", result)
            return result
        except Exception as err:
            print(err)

if __name__=='__main__':
    context = {
            'name': "鲁超峰",
            'gender': "男",
            'birthday': "1999-10-19",
            'phone': "18254021559",
            'address': "山东省青岛市崂山区青岛科技大学",
            'certificate': "软件杯一等奖",
            'university': "青岛科技大学",
            'major': "计算机技术",
            'start_time1': "2021-9",
            'end_time1': "2024-6",
    }
    # toWord(context)
#     生产word简历文件
#     resume_convert.convert_to_pdf()
#     转为PDF