# pip安装
# pip install aliyun-python-sdk-alinlp==1.0.20
from paddlenlp import Taskflow
import json
import os
import re
from DB import Database
# 这里以分词为例，其它算法的API名称和参数请参考文档
from aliyunsdkalinlp.request.v20200629 import GetWsChGeneralRequest
import math
from aliyunsdkcore.client import AcsClient
from aliyunsdkcore.acs_exception.exceptions import ClientException
from aliyunsdkcore.acs_exception.exceptions import ServerException

class Position_match():
    def __init__(self):
        self.connetion = Database().get_connention()
        self.cursor = self.connetion.cursor()

    def close(self):
        self.connetion.close()
        self.cursor.close()

    # 以人推岗
    def personToPost(self, skills_tags, age_per, highest_edu_per, work_year, major_per, position_information, ie_default, position_list):
        # 工作年限向上取整
        if(work_year==''):
            work_year = 0
        work_year = str(math.ceil(float(work_year)))
        # print(work_year)
        for pos in position_information:
            info = '岗位名：'+pos['岗位名']+';'+pos['岗位信息']
            a = ie_default(info)
            position_name = pos['岗位名']
            skill_require = ''
            edu_require = ''
            major_require = ''
            age_require = ''
            year_require = ''
            for k, v in a[0].items():
                if k == '技术':
                    skill_require = v[0]['text']
                elif k == '学历':
                    edu_require = v[0]['text']
                elif k == '专业':
                    major_require = v[0]['text']
                elif k == '工作年限':
                    year_require = v[0]['text']
                elif k == '年龄':
                    age_require = v[0]['text']
            # skill match
            print("skills_tags:", skills_tags)
            # tag_text = Position_match.skill_text(skills_tags)
            tag_text = self.skill_text(skills_tags)
            # courses_list = skills_tags.split('Ж')
            # print("courses_list:", courses_list)
            # x = []
            # for n in courses_list:
            #     n_list = n.split(':')
            #     x.append(n_list[0])
            # tag = 'Ж'.join(x)
            # tag_text = tag
            fenxi_text = self.fenci(tag_text)
            result = json.loads(fenxi_text['Data'])
            skill_list = []
            for word in result['result']:
                skill_list.append(word['word'])
            skill_match = self.judge_skill(skill_list, skill_require, position_name)
            print(skill_match)

            # edu match
            edu_match = self.judge_edu(highest_edu_per, edu_require)
            print(edu_match)

            # major match
            major_list = major_per.split('Ж')
            # print(major_list)
            for st in major_list:
                if st == '':
                    major_list.remove(st)
            major_text = 'Ж'.join(major_list)
            major_fenxi_text = self.fenci(major_text)
            major_result = json.loads(major_fenxi_text['Data'])
            major_list1 = []
            for word in major_result['result']:
                major_list1.append(word['word'])
            for st1 in major_list1:
                if st1 == '':
                    major_list1.remove(st1)
            major_match = self.judge_major(major_list1, major_require)
            print(major_match)

            # # major age
            age_match = self.judge_age(age_per, age_require)
            print(age_match)

            # major year
            year_match = self.judge_year(work_year, year_require)
            print(year_match)
            if skill_match and edu_match and major_match and age_match and year_match:
                position_list.append(pos['岗位名'])
        # print(position_list)
        # return position_list

    def fenci(self,text):
        access_key_id = 'LTAI5t9FxzznGgydki6tUzLz'
        access_key_secret = '7rJOWfxtw9Lczzk3tx7esqwpuJb18N'

        # 创建AcsClient实例
        client = AcsClient(
            access_key_id,
            access_key_secret,
            "cn-hangzhou"
        )
        request = GetWsChGeneralRequest.GetWsChGeneralRequest()
        request.set_Text(text)
        request.set_OutType("1")
        request.set_ServiceCode("alinlp")
        request.set_TokenizerId("GENERAL_CHN")
        response = client.do_action_with_exception(request)
        resp_obj = json.loads(response)
        return resp_obj

    def skill_text(self, skill_tag):
        print("skill_tag:", skill_tag)
        courses_list = skill_tag.split('Ж')
        print("courses_list:", courses_list)
        x = []
        for n in courses_list:
            n_list = n.split(':')
            x.append(n_list[0])
        tag = 'Ж'.join(x)
        return tag

    def judge_skill(self, word_list,position_skill,position_name):
        if position_skill =='':
            return True
        for word in word_list:
            if word in position_skill:
                return True
            if word in position_name:
                return True
        return False
    def judge_major(self, major_list,major_require):
        if major_require =='':
            return True
        if len(major_list)==0 and major_require !='':
            return False
        for word in major_list:
            if word in major_require:
                return True
        return False

    def judge_edu(self, highest_edu_per,edu_require):
        if edu_require == '':
            return True
        if edu_require != '' and highest_edu_per == '':
            return False
        if highest_edu_per == '中专':
            highest_edu_per = '高中'
        elif highest_edu_per == '研究生':
            highest_edu_per = '硕士'
        elif highest_edu_per == '本科学位':
            highest_edu_per = '本科'
        elif highest_edu_per == '学士':
            highest_edu_per = '本科'
        # [np.nan,'高中','大专','本科','硕士','博士']/['1','2','3','4','5','6']
        if highest_edu_per == '':
            highest_edu_num = 1
        elif highest_edu_per == '高中':
            highest_edu_num = 2
        elif highest_edu_per == '大专':
            highest_edu_num = 3
        elif highest_edu_per == '本科':
            highest_edu_num = 4
        elif highest_edu_per == '硕士':
            highest_edu_num = 5
        elif highest_edu_per == '博士':
            highest_edu_num = 6
        if edu_require == '':
            require_num = 1
        elif '高中' in edu_require:
            require_num = 2
        elif '中专' in edu_require:
            require_num = 2
        elif '大专' in edu_require:
            require_num = 3
        elif '本科' in edu_require:
            require_num = 4
        elif '学士' in edu_require:
            require_num = 4
        elif '硕士' in edu_require:
            require_num = 5
        elif '研究生' in edu_require:
            require_num = 5
        elif '博士' in edu_require:
            require_num = 6
        if highest_edu_num>=require_num:
            return True
        else:
            return False

    def judge_age(self, age_per,age_require):
        if age_require =='':
            return True
        Chinese_year = {"一": '1', "两": '2', "二": '2', "三": '3', "四": '4', "五": '5', "六": '6', "七": '7', "八": '8',
                        "九": '9', "十": '10'}
        Chinese_year_key = ["一", "二", "两", "三", "四", "五", "六", "七", "八", "九", "十", '1', '2', '3', '4', '5', '6',
                            '7', '8', '9', '10']
        Chinese_year_key1 = '一二两三四五六七八九十'
        age_list = list(age_require)
        for i in range(len(age_list)):
            for k, v in Chinese_year.items():
                if i == 0:
                    if age_list[i] == '十' and age_list[i + 1] in Chinese_year_key:
                        age_list[i] = '1'
                    elif age_list[i] == k:
                        age_list[i] = v
                elif i == len(age_list) - 1:
                    # print(111)
                    if age_list[i] == '十' and age_list[i - 1] in Chinese_year_key:
                        age_list[i] = '0'
                    elif age_list[i] == k:
                        age_list[i] = v
                else:
                    # 3种情况 二十八 十八 八十
                    if age_list[i] == '十' and age_list[i - 1] in Chinese_year_key and age_list[i + 1] in Chinese_year_key:
                        age_list[i] = ''
                    elif age_list[i] == '十' and age_list[i - 1] in Chinese_year_key:
                        age_list[i] = '0'
                    elif age_list[i] == '十' and age_list[i + 1] in Chinese_year_key:
                        age_list[i] = '1'
                    elif age_list[i] == k:
                        age_list[i] = v

        print(age_list)
        for st2 in age_list:
            if st2 == '':
                age_list.remove(st2)
        age_text = ''.join(age_list)
        number = re.findall('\d+', age_text)
        num = 100000
        if len(number) > 1:
            for n in number:
                if int(n) < num:
                    num = int(n)
        elif len(number) == 1:
            num = int(number[0])
        else:
            num = 0
        if '上' in age_text:
            if age_per > num:
                return True
            else:
                return False
        elif '下' in age_text:
            if age_per <= num:
                return True
            else:
                return False
        else:
            if age_per > num:
                return True
            else:
                return False

    def judge_year(self, work_year,year_require):
        if year_require == '':
            return True
        Chinese_year = {"一": '1', "两": '2', "二": '2', "三": '3', "四": '4', "五": '5', "六": '6', "七": '7', "八": '8',
                        "九": '9', "十": '10'}
        Chinese_year_key = ["一", "二", "两", "三", "四", "五", "六", "七", "八", "九", "十", '1', '2', '3', '4', '5', '6',
                            '7', '8', '9', '10']
        Chinese_year_key1 = '一二两三四五六七八九十'
        year_list = list(year_require)
        for i in range(len(year_list)):
            for k, v in Chinese_year.items():
                if i == 0:
                    if year_list[i] == '十' and year_list[i + 1] in Chinese_year_key:
                        year_list[i] = '1'
                    elif year_list[i] == k:
                        year_list[i] = v
                elif i == len(year_list) - 1:
                    # print(111)
                    if year_list[i] == '十' and year_list[i - 1] in Chinese_year_key:
                        year_list[i] = '0'
                    elif year_list[i] == k:
                        year_list[i] = v
                else:
                    # 3种情况 二十八 十八 八十
                    if year_list[i] == '十' and year_list[i - 1] in Chinese_year_key and year_list[i + 1] in Chinese_year_key:
                        year_list[i] = ''
                    elif year_list[i] == '十' and year_list[i - 1] in Chinese_year_key:
                        year_list[i] = '0'
                    elif year_list[i] == '十' and year_list[i + 1] in Chinese_year_key:
                        year_list[i] = '1'
                    elif year_list[i] == k:
                        year_list[i] = v

        for st2 in year_list:
            if st2 == '':
                year_list.remove(st2)
        year_text = ''.join(year_list)
        number = re.findall('\d+', year_text)
        num = 100000
        if len(number) > 1:
            for n in number:
                if int(n) < num:
                    num = int(n)
        elif len(number) == 1:
            num = int(number[0])
        else:
            num = 0
        if '上' in year_text:
            if int(work_year) >= num:
                return True
            else:
                return False
        elif '下' in year_text:
            if int(work_year) < num:
                return True
            else:
                return False
        else:
            if int(work_year) > num:
                return True
            else:
                return False




# if __name__ == '__main__':
#
#     # 技能
#     skills_tags= "产品:0.5074710845947266Ж设计:0.5014553546905518Ж售后服务:0.4901031017303467Ж助理营销:0.4892154693603516Ж英语口语:0.45243420600891116"
#     # 年龄
#     age_per = 26
#     # 最高学历
#     highest_edu_per = '博士'
#     # 工作年限
#     work_year = '3.5'
#     # 向上取整
#     work_year = str(math.ceil(float(work_year)))
#     print(work_year)
#     # 专业
#     major_per = ''
#
#     position_list = []
#
#
#     ie_default = Taskflow("information_extraction", schema=['职位', '技术', '学历', '专业', '年龄', '工作年限'],
#                           task_path=r'C:\Users\82470\Desktop\23software\gangwei_check')
#     position_information = [{'岗位名':'产品运营',
#                              '岗位信息':'岗位职责 1.负责产品上线前后的线上、线下的运营方案和推广工作，协助项目负责人对接市场、产品开发等，完成个项目目标；2.负责产品运营中与线下的各种合作，配合完成商务推广，实施项目评估和监控，提升用户活跃度和忠诚度；3.负责研究行业竞争动态，定期拜访客户，维护重要客户关系发现客户的需求，引导客户的业务需求，根据自身产品制定产品营销策略，达成既定目标；4.负责分析和挖掘产品运营数据、用户行为数据等重要价值信息5.负责跟进和整理产品用户反馈，协同产品经理提出产品迭代方案。任职要求：1.2年及以上产品运营经验；2.主动性强，逻辑清晰，沟通能力强，能独立负责和落地运营项目能调动资源为运营目标服务；3.有较强数据分析能力、数据敏感性强。'},
#                             {
#                                 '岗位名': '平面设计师',
#                                 '岗位信息':'岗位职责：1.负责公司公众号的维护和内容推送；2.短视频相关内容的文案脚本策划，视频制作及编辑。并结合公司宣传计划，不断优化视频内容；3.协助其他平面设计、视频编辑等内容。任职要求：1.大专及以上学历，1-2年相关工作经验；2.熟悉平面设计软件及视频剪辑等，设计感好；3.工作责任心强，沟通及理解能力强。'
#                             }
#                             ]
#
#
#
#     # many_variable['highest_edu_per']=many_variable['highest_edu_per'].replace(['中专','研究生','本科学位','学士'],
#     #                     ['高中','硕士','本科','本科'])
#     # many_variable['highest_edu_per']=many_variable['highest_edu_per'].replace([np.nan,'高中','大专','本科','硕士','博士'],
#     #                     ['1','2','3','4','5','6'])
#
#     # skill match
#     # tag_text = skill_text(skills_tags)
#     # fenxi_text = fenci(tag_text)
#     # result = json.loads(fenxi_text['Data'])
#     # skill_list =[]
#     # for word in result['result']:
#     #     skill_list.append(word['word'])
#     # skill_match = judge_skill(skill_list,skill_require,position_name)
#     # print(skill_match)
#     #
#     # # edu match
#     # edu_match= judge_edu(highest_edu_per,edu_require)
#     # print(edu_match)
#     #
#     # # major match
#     # major_list = major_per.split('Ж')
#     # # print(major_list)
#     # for st in major_list:
#     #     if st == '':
#     #         major_list.remove(st)
#     # major_text = 'Ж'.join(major_list)
#     # major_fenxi_text = fenci(major_text)
#     # major_result = json.loads(major_fenxi_text['Data'])
#     # major_list1 =[]
#     # for word in major_result['result']:
#     #     major_list1.append(word['word'])
#     # for st1 in major_list1:
#     #     if st1 == '':
#     #         major_list1.remove(st1)
#     # major_match = judge_major(major_list1,major_require)
#     # print(major_match)
#     #
#     #
#     # # # major age
#     # age_match = judge_age(age_per,age_require)
#     # print(age_match)
#     #
#     # # major year
#     # year_match = judge_year(work_year, year_require)
#     # print(year_match)
#
#
#
#     # print(fenxi_text['Data'])