# -*- coding: utf-8 -*-
# @Author : lcf
# @Time : 2023/7/11 15:33
import time
import json
from DB import Database

class talentMyspic():
    def __init__(self):
        self.connetion = Database().get_connention()
        self.cursor = self.connetion.cursor()

    def close(self):
        self.connetion.close()
        self.cursor.close()

    def evaluate(self, name_per, sex_per, age_per, highest_edu_per, major_per, gra_school_per, work, skill_tags, political_status, address_per, pred_salary):
        # print(sex_per)
        # print(age_per)
        # print(highest_edu_per)
        # print(major_per)
        # print(gra_school_per)
        # print(work)
        # print('skill_tags:', type(skill_tags), skill_tags)
        # print(political_status)
        # print(address_per)

        famous_school = ['清华大学', '北京大学', '浙江大学', '上海交通大学', '复旦大学', '南京大学', '中国科学技术大学', '华中科技大学', '武汉大学', '西安交通大学',
                         '中山大学', '四川大学',
                         '哈尔滨工业大学', '北京航空航天大学', '东南大学', '北京理工大学', '同济大学', '中国人民大学', '北京师范大学', '南开大学', '天津大学', '山东大学',
                         '中南大学', '厦门大学',
                         '西北工业大学', '华南理工大学', '吉林大学', '电子科技大学', '湖南大学', '中国农业大学', '华东师范大学', '大连理工大学', '重庆大学', '上海财经大学',
                         '北京科技大学',
                         '南京理工大学', '南京航空航天大学', '东北大学', '西安电子科技大学', '兰州大学', '苏州大学', '华中农业大学', '北京交通大学', '华东理工大学', '郑州大学',
                         '中央财经大学', '华中师范大学',
                         '上海大学', '哈尔滨工程大学', '暨南大学', '中国政法大学', '对外经济贸易大学', '南京农业大学', '中国石油大学（北京）', '东北师范大学', '武汉理工大学',
                         '西南交通大学', '中国矿业大学',
                         '北京邮电大学', '南京师范大学', '中国地质大学（武汉）', '江南大学', '河海大学', '中国海洋大学', '北京工业大学', '北京化工大学', '西北大学',
                         '西南财经大学', '中国石油大学（华东）',
                         '陕西师范大学', '天津医科大学', '中南财经政法大学', '南昌大学', '中国地质大学（北京）', '西南大学', '福州大学', '西北农林科技大学', '华北电力大学',
                         '中国矿业大学（北京）', '东华大学',
                         '华南师范大学', '北京外国语大学', '云南大学', '北京林业大学', '中国传媒大学', '北京中医药大学', '合肥工业大学', '湖南师范大学', '长安大学', '广西大学',
                         '中国药科大学', '上海外国语大学',
                         '大连海事大学', '安徽大学', '中央民族大学', '河北工业大学', '太原理工大学', '贵州大学', '内蒙古大学', '东北林业大学', '海南大学', '东北农业大学',
                         '辽宁大学', '新疆大学', '石河子大学',
                         '四川农业大学', '宁夏大学', '延边大学', '青海大学', '北京体育大学', '西藏大学', '中国石油大学']
        # 985\211
        major1 = ['土木工程', '金融学', '会计学', '英语', '临床医学', '信息与计算科学', '法学', '教育技术学', '雕塑']
        major2 = ['机械设计制造及其自动化', '国际经济与贸易', '工商管理', '汉语言文学', '护理学', '数学与应用数学', '社会工作', '教育学', '数字媒体艺术']
        major3 = ['电气工程及其自动化', '经济学', '财务管理', '新闻学', '药学', '应用化学', '社会学', '学前教育', '美术学']
        major4 = ['电子信息工程', '财政学', '信息管理与信息系统', '广告学', '中医学', '生物技术', '政治学与行政学', '小学教育', '广播电视编导']
        major5 = ['计算机科学与技术', '金融工程', '市场营销', '日语', '口腔医学', '生物科学', '国际政治', '科学教育', '艺术设计学']
        major6 = ['通信工程', '投资学', '工程管理', '法语', '医学影像学', '应用物理学', '思想政治教育', '体育教育', '播音与主持艺术']
        major7 = ['自动化', '贸易经济', '人力资源管理', '传播学', '预防医学', '应用心理学', '侦查学', '艺术教育', '动画']
        major8 = ['建筑学', '经济统计学', '物流管理', '编辑出版学', '中西医临床医学', '统计学', '外交学', '特殊教育', '音乐学']
        major9 = ['车辆工程', '信用管理', '旅游管理', '德语', '麻醉学', '化学', '公安情报学', '人文教育', '绘画']
        major10 = ['软件工程', '国民经济管理', '公共事业管理', '翻译', '针灸推拿学', '物理学', '治安学', '运动人体科学', '戏剧影视文学']

        name = name_per
        sex = sex_per
        age = age_per
        high_edu = highest_edu_per
        major = major_per
        school = gra_school_per
        work = json.loads(work)
        skill_tags = skill_tags
        political_status = political_status
        address = address_per
        if (sex != '' and sex!='未知'):
            if sex == "女":
                sex_score = 90
            else:
                sex_score = 95
        else:
            sex_score = 0
        # 性别评分

        if(age!='' and age!='未知'):
            if int(age) >= 40:
                age_score = 70
            elif int(age) >= 30 and int(age) <= 40:
                age_score = 86
            else:
                age_score = 95
        else:
            age_score = 0
        # 年龄针对年龄段，大于40 30-40 小于30

        # 本科 大专 硕士 博士 中专 本科学历 学士学位 无
        if(high_edu!='' and high_edu!='未知'):
            if high_edu == "博士":
                high_edu_score = 100
            elif high_edu == "硕士" or high_edu == "研究生":
                high_edu_score = 90
            elif high_edu == "本科" or high_edu == "本科学历" or high_edu == "学士学位":
                high_edu_score = 80
            elif high_edu == "大专":
                high_edu_score = 70
            else:
                high_edu_score = 60
        else:
            high_edu_score = 0
        # 学历分段打分

        diff_time = 0
        if(len(work)>0):
            # print("work:", work)
            for workInfo in work:
                # print("workInfo:", type(workInfo), workInfo)
                if(workInfo!=''):
                    date = workInfo['work_date']
                    if ("至今" not in date):
                        start_time = date.split('-')[0].replace(".", "-")
                        end_time = date.split('-')[1].replace(".", "-")
                        diff_time = diff_time + time.mktime(time.strptime(end_time, '%Y-%m')) - time.mktime(time.strptime(start_time, '%Y-%m'))
                    else:
                        start_time = date.replace("-", "").split('至今')[0].replace(".", "-")
                        end_time = time.time()
                        diff_time = diff_time + end_time - time.mktime(time.strptime(str(start_time), '%Y-%m'))

        if(diff_time == 0):
            work_time = ""
            working_time_score = 0
        elif (diff_time < 7776000):  # 小于3个月
            work_time = "3个月"
            working_time_score = 40
        elif (diff_time < 15552000):    #小于半年
            work_time = "半年"
            working_time_score = 50
        elif (diff_time < 31104000):    #小于一年
            work_time = "一年"
            working_time_score = 60
        elif (diff_time < 62208000):  # 小于两年
            work_time = "两年"
            working_time_score = 70
        elif (diff_time < 124416000):  # 小于四年
            work_time = "四年"
            working_time_score = 80
        elif (diff_time < 155520000):  # 小于五年
            work_time = "五年"
            working_time_score = 90
        else:   #五年以上
            work_time = "五年以上"
            working_time_score = 100
        # 工作时间评分

        company_name_score = 0
        if (len(work) > 0):
            for workInfo in work:
                if(workInfo['company_name']!=''):
                    company_return = workInfo['company_name']
                    company_name_score = 76
                    break
        else:
            company_return = ""

        if(skill_tags!='' and skill_tags!='未知'):
            skill_tags_list = skill_tags.split(',')
            if(len(skill_tags_list)<5):

                prof_skill_per_score = 60
            elif(len(skill_tags_list)<10):
                prof_skill_per_score = 70
            elif (len(skill_tags_list) < 15):
                prof_skill_per_score = 80
            elif (len(skill_tags_list) < 20):
                prof_skill_per_score = 90
            else:
                prof_skill_per_score = 100
            skill_return = "掌握技能数" + str(len(skill_tags_list))
        else:
            skill_return = ""
            prof_skill_per_score = 0

        # 政治面貌评分 中共党员、中共预备党员、共青团员、民革党员、民盟盟员、民建会员、民进会员、农工党党员、致公党党员、九三学社社员、台盟盟员、无党派人士以及群众
        if(political_status!='' and political_status!='未知'):
            if '中共党员' in political_status:
                political_status_score = 100
            elif '中共预备党员' in political_status:
                political_status_score = 98
            elif '民革党员' in political_status or '民盟盟员' in political_status or '民建会员' in political_status or '民进会员' in political_status \
                    or '农工党党员' in political_status or '致公党党员' in political_status or '九三学社社员' in political_status or '台盟盟员' in political_status:
                political_status_score = 95
            elif '共青团员' in political_status:
                political_status_score = 93
            elif '群众' in political_status:
                political_status_score = 92
            else:
                political_status_score = 90
        else:
            political_status_score = 0

        # 籍贯或地址评分
        if(address!='' and address!='未知'):
            if "北京" in address or '上海' in address or '广州' in address or '深圳' in address or '香港' in address:
                print(address)
                address_score = 98
            elif '成都' in address or '重庆' in address or '杭州' in address or '西安' in address or '武汉' in address or '苏州' in address \
                    or '郑州' in address or '南京' in address or '天津' in address or '长沙' in address or '东莞' in address \
                    or '宁波' in address or '佛山' in address or '合肥' in address or '青岛' in address or '山东' in address:
                address_score = 92
            else:
                address_score = 86
        else:
            address_score = 0


        # 学校评分
        school_score = 0
        if(school!='' and school!='未知'):
            if(',' in school):
                school_list = school.split(',')
                for school_name in school_list:
                    school_return = school_name
                    if school_name in famous_school:
                        if(school_score<100):
                            school_score = 100
                    elif "大学" in school_name:
                        if(school_score<89):
                            school_score = 89
                    elif "学院" in school_name:
                        if(school_score<85):
                            school_score = 85
                    else:
                        if(school_name!='' and school_score<80):
                            school_score = 80
            else:
                school_return = school
                if school in famous_school:
                    if (school_score < 100):
                        school_score = 100
                elif "大学" in school:
                    if (school_score < 89):
                        school_score = 89
                elif "学院" in school:
                    if (school_score < 85):
                        school_score = 85
                else:
                    if (school != '' and school_score < 80):
                        school_score = 80
        else:
            school_return = ""
            school_score = 0

        # 专业评分
        major_score = 0
        if(major!='' and major!='未知'):
            if(',' in major):
                major_list = major.split(',')
                for major_name in major_list:
                    major_return = major_name
                    if major_name in major1:
                        if(major_score<95):
                            major_score = 95
                    elif major_name in major2:
                        if (major_score < 92):
                            major_score = 92
                    elif major_name in major3:
                        if (major_score < 89):
                            major_score = 89
                    elif major_name in major4:
                        if (major_score < 87):
                            major_score = 87
                    elif major_name in major5:
                        if (major_score < 84):
                            major_score = 84
                    elif major_name in major6:
                        if (major_score < 81):
                            major_score = 81
                    elif major_name in major7:
                        if (major_score < 78):
                            major_score = 78
                    elif major_name in major8:
                        if (major_score < 75):
                            major_score = 75
                    elif major_name in major9:
                        if (major_score < 72):
                            major_score = 72
                    elif major_name in major10:
                        if (major_score < 69):
                            major_score = 69
                    else:
                        if (major_score < 66):
                            major_score = 66
            else:
                major_return = major
                if major in major1:
                    if (major_score < 95):
                        major_score = 95
                elif major in major2:
                    if (major_score < 92):
                        major_score = 92
                elif major in major3:
                    if (major_score < 89):
                        major_score = 89
                elif major in major4:
                    if (major_score < 87):
                        major_score = 87
                elif major in major5:
                    if (major_score < 84):
                        major_score = 84
                elif major in major6:
                    if (major_score < 81):
                        major_score = 81
                elif major in major7:
                    if (major_score < 78):
                        major_score = 78
                elif major in major8:
                    if (major_score < 75):
                        major_score = 75
                elif major in major9:
                    if (major_score < 72):
                        major_score = 72
                elif major in major10:
                    if (major_score < 69):
                        major_score = 69
                else:
                    if (major_score < 66):
                        major_score = 66
        else:
            major_return = ""
            major_score = 0

        # 综合分，加权
        score = int(sex_score*0.05 + age_score*0.05 + high_edu_score*0.2 + major_score*0.1 + school_score*0.2 + working_time_score*0.05 + \
                company_name_score*0.05 + prof_skill_per_score*0.2 + political_status_score*0.05 + address_score*0.05)
        if(score < 60):
            score = 62
        if(pred_salary!='' and pred_salary!='未知'):
            if(int(pred_salary)<=5000):
                pred_salary = '0-5000元/月'
            elif(int(pred_salary)<=10000):
                pred_salary = '5000-10000元/月'
            elif (int(pred_salary) <= 15000):
                pred_salary = '10000-15000元/月'
            elif (int(pred_salary) <= 20000):
                pred_salary = '15000-20000元/月'
            else:
                pred_salary = '20000元/月以上'
        else:
            pred_salary = ''

        return {"性别分数": sex_score, "年龄分数": age_score, "学历分数": high_edu_score, "专业分数": major_score, "学校分数": school_score,
                "工作时长分数": working_time_score, "公司分数": company_name_score, "专业技能分数": prof_skill_per_score,
                "政治面貌分数": political_status_score, "籍贯或地址分数": address_score, "综合分": score, "预估薪资": pred_salary,
                "性别": sex_per, "年龄": age_per, "学历":highest_edu_per, "专业": major_return, "学校": school_return, "工作时长":work_time,
                "公司":company_return, "技能":skill_return, "政治面貌":political_status, "地点":address_per}
