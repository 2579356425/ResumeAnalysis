# coding=gbk
# @Author : lcf
# @Time : 2023/7/2 21:22
from pymysql import NULL

from DB import Database
import re
import os,sys
import base64
import requests
import json
import csv
import pandas as pd

class resumeAnalysis():
    def __init__(self):
        self.connetion = Database().get_connention()
        self.cursor = self.connetion.cursor()

    def close(self):
        self.connetion.close()
        self.cursor.close()

    def selectAllResume(self):
        sql = "select * from resume"
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            print("result:", result)
            return result
        except Exception as err:
            print(err)

    def selectUserResume(self, user):
        sql = "select * from resume where name_per = %s" %user
        try:
            self.cursor.execute(sql)
            result = self.cursor.fetchall()
            print("result:", result)
            return result
        except Exception as err:
            print(err)

    # url��apiUrl
    # fpath���ļ�·�������ļ�����
    # fname���ļ���
    def analysis(self, url, fpath, fname):
        project_path = os.path.dirname(os.path.abspath(__file__))  # ��ȡ��ǰ�ļ�·������һ��Ŀ¼
        # print("project_path:", project_path)
        # with open(project_path+"/ieResult/" + fname.split(".")[0] + ".txt", 'a', encoding="utf-8") as w:
        #     # w.write(str(json.dumps(res_js, indent=4, ensure_ascii=False)))
        #     w.write("")
        # w.close()
        # ��ȡ�ļ�����
        cont = open(fpath, 'rb').read()
        # base_cont = base64.b64encode(cont)  # python2
        base_cont = base64.b64encode(cont).decode('utf8')  # python3

        # ����json����
        data = {
            'file_name': fpath,  # �����ļ������������ȷ�ĺ�׺����
            'file_cont': base_cont,  # �������ݣ�base64����ļ������ݣ�
            'need_avatar': 1,  # �Ƿ���Ҫ��ȡͷ��ͼƬ
            'ocr_type': 1,  # 1Ϊ�߼�ocr
        }

        appcode = '08eb52fb4e8f473b84bda3543c4e4ad3'
        headers = {'Authorization': 'APPCODE ' + appcode,
                   'Content-Type': 'application/json; charset=UTF-8',
                   }
        # ��������
        data_js = json.dumps(data)
        res = requests.post(url=url, data=data_js, headers=headers)

        # �������
        res_js = json.loads(res.text)

        print(json.dumps(res_js, indent=4, ensure_ascii=False))  # ��ӡȫ�����
        with open(project_path+"/ieResult/" + fname.split(".")[0] + ".txt", 'a', encoding="utf-8") as w:
            w.write(str(json.dumps(res_js, indent=4, ensure_ascii=False)))
        w.close()
        return res_js

    # ����code:�ֵ�����ȡ����result.avatar_data��,����Ĳ���
    # ����imgname:�����ͼƬ��
    def decode(self, code, imgname):
        with open(imgname, 'wb') as file:
            jiema = base64.b64decode(code)
            file.write(jiema)

    # ������������������ݿ��ʽ
    def handleInfo(self, a, username, resumeUrl, resumeName):
        project_path = os.path.dirname(os.path.abspath(__file__))  # ��ȡ��ǰ�ļ�·������һ��Ŀ¼
        content = {}
        # ����
        if (a['result'].__contains__('name') != False):
            content['name_per'] = a['result']['name']
        else:
            content['name_per'] = ''
        # �Ա�
        if (a['result'].__contains__('gender') != False):
            content['sex_per'] = a['result']['gender']
        else:
            content['sex_per'] = ''
        # ����
        if (a['result'].__contains__('email') != False):
            content['email_per'] = a['result']['email']
        else:
            content['email_per'] = ''
        # ����
        if (a['result'].__contains__('age') != False):
            content['age_per'] = a['result']['age']
        else:
            content['age_per'] = -1
        # �绰
        if (a['result'].__contains__('phone') != False):
            content['phone_per'] = a['result']['phone']
        else:
            content['phone_per'] = ''
        # QQ
        if (a['result'].__contains__('qq') != False):
            content['qq'] = a['result']['qq']
        else:
            content['qq'] = ''
        # ΢��
        if (a['result'].__contains__('weixin') != False):
            content['weixin'] = a['result']['weixin']
        else:
            content['weixin'] = ''
        # ����
        if (a['result'].__contains__('hometown_address') != False):
            content['address_per'] = a['result']['hometown_address']
        else:
            content['address_per'] = ''
        # ����
        if (a['result'].__contains__('height') != False):
            content['height'] = a['result']['height']
        else:
            content['height'] = ''
        # ����
        if (a['result'].__contains__('weight') != False):
            content['weight'] = a['result']['weight']
        else:
            content['weight'] = ''
        # ����
        if (a['result'].__contains__('race') != False):
            content['race'] = a['result']['race']
        else:
            content['race'] = ''
        # ����
        if (a['result'].__contains__('nationality') != False):
            content['nationality'] = a['result']['nationality']
        else:
            content['nationality'] = ''
        # ����״̬
        if (a['result'].__contains__('marital_status') != False):
            content['marital_status'] = a['result']['marital_status']
        else:
            content['marital_status'] = ''
        # ���ѧ��
        if (a['result'].__contains__('degree') != False):
            content['highest_edu_per'] = a['result']['degree']
        else:
            content['highest_edu_per'] = ''
        # ��������
        if (a['result'].__contains__('education_objs') != False):
            if(len(a['result']['education_objs'])==0):
                content['adm_date'] = ''
                content['gra_date'] = ''
                content['gra_school_per'] = ''
                content['major_per'] = ''
                content['courses'] = ''
                content['edu_gpa'] = ''
                content['school_level'] = ''
            else:
                First = True
                for edu_list in a['result']['education_objs']:
                    if First:
                        # ��ѧʱ��
                        if (edu_list.__contains__('start_date') != False):
                            content['adm_date'] = edu_list['start_date']
                        else:
                            content['adm_date'] = ''
                        # ��ҵʱ��
                        if (edu_list.__contains__('end_date') != False):
                            content['gra_date'] = edu_list['end_date']
                        else:
                            content['gra_date'] = ''
                        # ��ҵԺУ
                        if (edu_list.__contains__('edu_college') != False):
                            content['gra_school_per'] = edu_list['edu_college']
                        else:
                            content['gra_school_per'] = ''
                        # רҵ
                        if (edu_list.__contains__('edu_major') != False):
                            content['major_per'] = edu_list['edu_major']
                        else:
                            content['major_per'] = ''
                        # ��ѧ�γ�
                        if (edu_list.__contains__('edu_content') != False):
                            content['courses'] = edu_list['edu_content']
                        else:
                            content['courses'] = ''
                        # GPA
                        if (edu_list.__contains__('edu_gpa') != False):
                            content['edu_gpa'] = edu_list['edu_gpa']
                        else:
                            content['edu_gpa'] = ''
                        # ѧУˮƽ
                        if (edu_list.__contains__('edu_college_type') != False):
                            if edu_list['edu_college_type'] == '0':
                                content['school_level'] = '��ͨԺУ'
                            elif edu_list['edu_college_type'] == '1':
                                content['school_level'] = '985'
                            elif edu_list['edu_college_type'] == '2':
                                content['school_level'] = '211'
                            elif edu_list['edu_college_type'] == '3':
                                content['school_level'] = '�۰�̨ԺУ'
                            elif edu_list['edu_college_type'] == '4':
                                content['school_level'] = '����ԺУ'
                            elif edu_list['edu_college_type'] == '5':
                                content['school_level'] = '��ѧ'
                            elif edu_list['edu_college_type'] == '6':
                                content['school_level'] = 'ְҵ����'
                            elif edu_list['edu_college_type'] == '7':
                                content['school_level'] = '��ѵ����'
                            else:
                                content['school_level'] = ''
                        else:
                            content['school_level'] = ''
                        First = False
                    else:
                        if (edu_list.__contains__('start_date') != False):
                            content['adm_date'] = content['adm_date'] + '��' + edu_list['start_date']
                        else:
                            content['adm_date'] = content['adm_date'] + '��' + ''
                        if (edu_list.__contains__('end_date') != False):
                            content['gra_date'] = content['gra_date'] + '��' + edu_list['end_date']
                        else:
                            content['gra_date'] = content['gra_date'] + '��' + ''
                        if (edu_list.__contains__('edu_college') != False):
                            content['gra_school_per'] = content['gra_school_per'] + '��' + edu_list['edu_college']
                        else:
                            content['gra_school_per'] = content['gra_school_per'] + '��' + ''
                        if (edu_list.__contains__('edu_major') != False):
                            content['major_per'] = content['major_per'] + '��' + edu_list['edu_major']
                        else:
                            content['major_per'] = content['major_per'] + '��' + ''
                        if (edu_list.__contains__('edu_content') != False):
                            content['courses'] = content['courses'] + '��' + edu_list['edu_content']
                        else:
                            content['courses'] = content['courses'] + '��' + ''
                        if (edu_list.__contains__('edu_gpa') != False):
                            content['edu_gpa'] = content['edu_gpa'] + '��' + edu_list['edu_gpa']
                        else:
                            content['edu_gpa'] = content['edu_gpa'] + '��' + ''
                        if (edu_list.__contains__('edu_college_type') != False):
                            if edu_list['edu_college_type'] == '0':
                                x = '��ͨԺУ'
                            elif edu_list['edu_college_type'] == '1':
                                x = '985'
                            elif edu_list['edu_college_type'] == '2':
                                x = '211'
                            elif edu_list['edu_college_type'] == '3':
                                x = '�۰�̨ԺУ'
                            elif edu_list['edu_college_type'] == '4':
                                x = '����ԺУ'
                            elif edu_list['edu_college_type'] == '5':
                                x = '��ѧ'
                            elif edu_list['edu_college_type'] == '6':
                                x = 'ְҵ����'
                            elif edu_list['edu_college_type'] == '7':
                                x = '��ѵ����'
                            else:
                                x = ''
                            content['school_level'] = content['school_level'] + '��' + x
                        else:
                            content['school_level'] = content['school_level'] + '��' + ''
        else:
            content['adm_date'] = ''
            content['gra_date'] = ''
            content['gra_school_per'] = ''
            content['major_per'] = ''
            content['courses'] = ''
            content['edu_gpa'] = ''
            content['school_level'] = ''


        # ���Լ���
        if (a['result'].__contains__('languages') != False):
            content['lan_skill_per'] = a['result']['languages']
        else:
            content['lan_skill_per'] = ''
        if (a['result'].__contains__('english_level') != False):
            content['lan_skill_per'] = a['result']['english_level']
        # רҵ����
        if (a['result'].__contains__('skills_objs') != False):
            if(len(a['result']['skills_objs'])==0):
                content['prof_skill_per'] = ''
            else:
                First1 = True
                for skills_list in a['result']['skills_objs']:
                    if First1:
                        if (skills_list.__contains__('skills_name') != False):
                            content['prof_skill_per'] = skills_list['skills_name']
                        else:
                            content['prof_skill_per'] = ''
                        # if (skills_list.__contains__('skills_level') != False):
                        #     content['prof_skill_per'] =content['prof_skill_per']+ ':'+skills_list['skills_level']
                        # else:
                        #     x = ['�˽�','��Ϥ','����','��ͨ']
                        #     a = random.randint(0, 3)
                        #     content['prof_skill_per'] =content['prof_skill_per']+ ':'+x[a]
    
                        First1 = False
                    else:
                        if (skills_list.__contains__('skills_name') != False):
                            content['prof_skill_per'] = content['prof_skill_per'] + '��' + skills_list['skills_name']
                        else:
                            content['prof_skill_per'] = content['prof_skill_per'] + '��' + ''
                        # if (skills_list.__contains__('skills_level') != False):
                        #     content['prof_skill_per'] =content['prof_skill_per']+ ':'+skills_list['skills_level']
                        # else:
                        #     x = ['�˽�','��Ϥ','����','��ͨ']
                        #     a = random.randint(0, 3)
                        #     content['prof_skill_per'] =content['prof_skill_per']+ ':'+x[a]
        else:
            content['prof_skill_per'] = ''
        # �칫����
        content['office_skill_per'] = ''
        if 'office' in a['result']['raw_text']:
            content['office_skill_per'] = content['office_skill_per'] + 'office' + ';'
        if 'word' in a['result']['raw_text']:
            content['office_skill_per'] = content['office_skill_per'] + 'word' + ';'
        if 'excel' in a['result']['raw_text']:
            content['office_skill_per'] = content['office_skill_per'] + 'excel' + ';'
        if 'ppt' in a['result']['raw_text']:
            content['office_skill_per'] = content['office_skill_per'] + 'ppt' + ';'

        # ֤��
        if (a['result'].__contains__('all_cert_objs') != False):
            if(len(a['result']['all_cert_objs'])==0):
                content['certificates'] = ''
            else:
                First2 = True
                for awards_list in a['result']['all_cert_objs']:
                    if First2:
                        if (awards_list.__contains__('cert_name') != False):
                            content['certificates'] = awards_list['cert_name']
                        else:
                            content['certificates'] = ''
                        First2 = False
                    else:
                        if (awards_list.__contains__('cert_name') != False):
                            content['certificates'] = content['certificates'] + '��' + awards_list['cert_name']
                        else:
                            content['certificates'] = content['certificates'] + '��' + ''
        else:
            content['certificates'] = ''
        # ����
        if (a['result'].__contains__('cont_award') != False):
            content['awards_per'] = a['result']['cont_award']
        else:
            content['awards_per'] = ''
        # ������ò
        if (a['result'].__contains__('polit_status') != False):
            content['political_status'] = a['result']['polit_status']
        else:
            content['political_status'] = ''
        # �ʱ�
        if (a['result'].__contains__('postal_code') != False):
            content['postal_code'] = a['result']['postal_code']
        else:
            content['postal_code'] = ''
        # ��������
        if (a['result'].__contains__('job_exp_objs') != False):
            if(len(a['result']['job_exp_objs'])==0):
                content['job_title'] = ''
                content['company_name'] = ''
                content['work_date'] = ''
                content['work_description'] = ''
            else:
                First3 = True
                for job_list in a['result']['job_exp_objs']:
                    if First3:
                        # ְλ��
                        if (job_list.__contains__('job_position') != False):
                            content['job_title'] = job_list['job_position']
                        else:
                            content['job_title'] = ''
                        #     ��˾��
                        if (job_list.__contains__('job_cpy') != False):
                            content['company_name'] = job_list['job_cpy']
                        else:
                            content['company_name'] = ''
                        # ����ʱ��
                        if (job_list.__contains__('start_date') != False) and (job_list.__contains__('end_date') != False):
                            content['work_date'] = job_list['start_date'] + '-' + job_list['end_date']
                        else:
                            content['work_date'] = ''
                        # ��������
                        if (job_list.__contains__('job_content') != False):
                            content['work_description'] = job_list['job_content']
                        else:
                            content['work_description'] = ''
                        First3 = False
                    else:
                        if (job_list.__contains__('job_position') != False):
                            content['job_title'] = content['job_title'] + '��' + job_list['job_position']
                        else:
                            content['job_title'] = content['job_title'] + '��' + ''
                        if (job_list.__contains__('job_cpy') != False):
                            content['company_name'] = content['company_name'] + '��' + job_list['job_cpy']
                        else:
                            content['company_name'] = content['company_name'] + '��' + ''
                        if (job_list.__contains__('start_date') != False) and (job_list.__contains__('end_date') != False):
                            content['work_date'] = content['work_date'] + '��' + job_list['start_date'] + '-' + job_list[
                                'end_date']
                        else:
                            content['work_date'] = content['work_date'] + '��' + ''
                        if (job_list.__contains__('job_content') != False):
                            content['work_description'] = content['work_description'] + '��' + job_list['job_content']
                        else:
                            content['work_description'] = content['work_description'] + '��' + ''
        else:
            content['job_title'] = ''
            content['company_name'] = ''
            content['work_date'] = ''
            content['work_description'] = ''

        # ������ҵ
        if (a['result'].__contains__('work_industry') != False):
            content['work_industry'] = a['result']['work_industry']
        else:
            content['work_industry'] = ''
        # ��������
        if (a['result'].__contains__('work_year_norm') != False):
            content['work_year'] = a['result']['work_year_norm']
        else:
            content['work_year'] = ''
        # ��Ŀ����
        if (a['result'].__contains__('proj_exp_objs') != False):
            if(len(a['result']['proj_exp_objs'])==0):
                content['project_date'] = ''
                content['project_name'] = ''
                content['project_position'] = ''
                content['project_description'] = ''
            else:
                First4 = True
                for projects_list in a['result']['proj_exp_objs']:
                    if First4:
                        # ��Ŀʱ��
                        if (projects_list.__contains__('start_date') != False) and (
                                projects_list.__contains__('end_date') != False):
                            content['project_date'] = projects_list['start_date'] + '-' + projects_list['end_date']
                        else:
                            content['project_date'] = ''
                        # ��Ŀ����
                        if (projects_list.__contains__('proj_name') != False):
                            content['project_name'] = projects_list['proj_name']
                        else:
                            content['project_name'] = ''
                        # ��Ŀְλ
                        if (projects_list.__contains__('proj_position') != False):
                            content['project_position'] = projects_list['proj_position']
                        else:
                            content['project_position'] = ''
                        # ��Ŀ����
                        if (projects_list.__contains__('proj_content') != False):
                            content['project_description'] = projects_list['proj_content']
                        else:
                            content['project_description'] = ''
                        First4 = False
                    else:
                        if (projects_list.__contains__('start_date') != False) and (
                                projects_list.__contains__('end_date') != False):
                            content['project_date'] = content['project_date'] + '��' + projects_list['start_date'] + '-' + \
                                                      projects_list['end_date']
                        else:
                            content['project_date'] = content['project_date'] + '��' + ''
                        if (projects_list.__contains__('proj_name') != False):
                            content['project_name'] = content['project_name'] + '��' + projects_list['proj_name']
                        else:
                            content['project_name'] = content['project_name'] + '��' + ''
                        # ��Ŀְλ
                        if (projects_list.__contains__('proj_position') != False):
                            content['project_position'] = content['project_position'] + '��' + projects_list['proj_position']
                        else:
                            content['project_position'] = content['project_position'] + '��' + ''
                        if (projects_list.__contains__('proj_content') != False):
                            content['project_description'] = content['project_description'] + '��' + projects_list[
                                'proj_content']
                        else:
                            content['project_description'] = content['project_description'] + '��' + ''
        else:
            content['project_date'] = ''
            content['project_name'] = ''
            content['project_position'] = ''
            content['project_description'] = ''

        # ��ᾭ��
        if (a['result'].__contains__('social_exp_objs') != False):
            if(len(a['result']['social_exp_objs'])==0):
                content['social_date'] = ''
                content['social_cpy'] = ''
                content['social_description'] = ''
                content['social_pos'] = ''
            else:
                First5 = True
                for social_list in a['result']['social_exp_objs']:
                    if First5:
                        # ���ʱ��
                        if (social_list.__contains__('start_date') != False) and (
                                social_list.__contains__('end_date') != False):
                            content['social_date'] = social_list['start_date'] + '-' + social_list['end_date']
                        else:
                            content['social_date'] = ''
                        # ��ᵥλ
                        if (social_list.__contains__('job_cpy') != False):
                            content['social_cpy'] = social_list['job_cpy']
                        else:
                            content['social_cpy'] = ''
                        # �������
                        if (social_list.__contains__('job_content') != False):
                            content['social_description'] = social_list['job_content']
                        else:
                            content['social_description'] = ''
                        # ���ְλ
                        if (social_list.__contains__('job_position') != False):
                            # content['social_pos'] = social_list['job_position']
                            content['social_pos'] = ''
                        else:
                            content['social_pos'] = ''
                        First5 = False
                    else:
                        # ���ʱ��
                        if (social_list.__contains__('start_date') != False) and (
                                social_list.__contains__('end_date') != False):
                            content['social_date'] = content['social_date'] + '��' + social_list['start_date'] + '-' + \
                                                     social_list['end_date']
                        else:
                            content['social_date'] = content['social_date'] + '��' + ''
                        # ��ᵥλ
                        if (social_list.__contains__('job_cpy') != False):
                            content['social_cpy'] = content['social_cpy'] + '��' + social_list['job_cpy']
                        else:
                            content['social_cpy'] = content['social_cpy'] + '��' + ''
                        # �������
                        if (social_list.__contains__('job_content') != False):
                            content['social_description'] = content['social_description'] + '��' + social_list['job_content']
                        else:
                            content['social_description'] = content['social_description'] + '��' + ''
                        #     ���ְλ
                        if (social_list.__contains__('job_position') != False):
                            content['social_pos'] = content['social_pos'] + '��' + social_list['job_position']
                        else:
                            content['social_pos'] = content['social_pos'] + '��' + ''
        else:
            content['social_date'] = ''
            content['social_cpy'] = ''
            content['social_description'] = ''
            content['social_pos'] = ''


        # ��ѵ����
        if (a['result'].__contains__('training_objs') != False):
            if(len(a['result']['training_objs'])== 0):
                content['train_date'] = ''
                content['train_org'] = ''
                content['training_description'] = ''
            else:
                First6 = True
                for training_list in a['result']['training_objs']:
                    if First6:
                        # ��ѵʱ��
                        if (training_list.__contains__('start_date') != False) and (
                                training_list.__contains__('end_date') != False):
                            content['train_date'] = training_list['start_date'] + '-' + training_list['end_date']
                        else:
                            content['train_date'] = ''
                        # ��ѵ��λ
                        if (training_list.__contains__('train_org') != False):
                            content['train_org'] = training_list['train_org']
                        else:
                            content['train_org'] = ''
                        # ��ѵ����
                        if (training_list.__contains__('train_cont') != False):
                            content['training_description'] = training_list['train_cont']
                        else:
                            content['training_description'] = ''
                        First6 = False
                    else:
                        # ��ѵʱ��
                        if (training_list.__contains__('start_date') != False) and (
                                training_list.__contains__('end_date') != False):
                            content['train_date'] = content['train_date'] + '��' + training_list['start_date'] + '-' + \
                                                    training_list['end_date']
                        else:
                            content['train_date'] = content['train_date'] + '��' + ''
                        # ��ѵ��λ
                        if (training_list.__contains__('train_org') != False):
                            content['train_org'] = content['train_org'] + '��' + training_list['train_org']
                        else:
                            content['train_org'] = content['train_org'] + '��' + ''
                        # ��ѵ����
                        if (training_list.__contains__('train_cont') != False):
                            content['training_description'] = content['training_description'] + '��' + training_list[
                                'train_cont']
                        else:
                            content['training_description'] = content['training_description'] + '��' + ''
        else:
            content['train_date'] = ''
            content['train_org'] = ''
            content['training_description'] = ''
        # ��������
        if (a['result'].__contains__('cont_my_desc') != False):
            content['self_evaluation'] = a['result']['cont_my_desc']
        else:
            content['self_evaluation'] = ''
        # Ͷ��ְλ��
        if (a['result'].__contains__('apply_job') != False):
            content['candidate_job_title'] = a['result']['apply_job']
        else:
            content['candidate_job_title'] = ''
        # ��������ʱ��
        if (a['result'].__contains__('resume_parse_time') != False):
            content['parsing_time'] = a['result']['resume_parse_time']
        else:
            content['parsing_time'] = ''
        # ��������
        if (a['result'].__contains__('resume_type') != False):
            if a['result']['resume_type'] == '0':
                content['resume_type'] = '����'
            elif a['result']['resume_type'] == '1':
                content['resume_type'] = 'Ӣ��'
            else:
                content['resume_type'] = '����'
        else:
            content['resume_type'] = ''
        # �����ļ���
        # if (a['result'].__contains__('resume_name') != False):
        #     content['resume_name'] = a['result']['resume_name']
        # else:
        #     content['resume_name'] = ''

        content['resume_name'] = resumeName

        # �����洢·��
        # if (a['result'].__contains__('resume_name') != False):
        #     content['path_resume'] = a['result']['resume_name']
        content['path_resume'] = resumeUrl
        # # ����ͷ��ͼƬurl
        # ��������ͼƬ���浽imgPath�У�����·��
        if (a['result'].__contains__('avatar_data') != False):
            imgname = content['resume_name'].split('.')[0] + ".png"
            with open(project_path+"/imgPath/"+imgname, 'wb') as file:
                print(a['result']['avatar_data'])
                print(a['result']['avatar_data'].split(', '))
                print(a['result']['avatar_data'].split(', ')[1])
                jiema = base64.b64decode(a['result']['avatar_data'].split(', ')[1])
                file.write(jiema)
            content['avatar_url'] = project_path+"/imgPath/"+imgname
        else:
            content['avatar_url']=''

        # Ԥ��н��
        if (a['eval'].__contains__('salary') != False):
            content['pred_salary'] = a['eval']['salary']
        else:
            content['pred_salary'] = ''
        # ��λ��ǩ
        if (a['tags'].__contains__('pos_tags') != False):
            if(len(a['tags']['pos_tags'])==0):
                content['pos_tags'] = ''
            else:
                First7 = True
                for pos_tags_list in a['tags']['pos_tags']:
                    if First7:
                        content['pos_tags'] = pos_tags_list['tag_name'] + ':' + str(pos_tags_list['tag_weight'])
                        First7 = False
                    else:
                        content['pos_tags'] = content['pos_tags'] + '��' + pos_tags_list['tag_name'] + ':' + str(
                            pos_tags_list['tag_weight'])
        else:
            content['pos_tags'] = ''
        # ���ܱ�ǩ
        if (a['tags'].__contains__('skills_tags') != False):
            if(len(a['tags']['skills_tags'])==0):
                content['skills_tags'] = ''
            else:
                First8 = True
                for skills_tags_list in a['tags']['skills_tags']:
                    if First8:
                        content['skills_tags'] = skills_tags_list['tag_name'] + ':' + str(skills_tags_list['tag_weight'])
                        First8 = False
                    else:
                        content['skills_tags'] = content['skills_tags'] + '��' + skills_tags_list['tag_name'] + ':' + str(
                            skills_tags_list['tag_weight'])
        else:
            content['skills_tags']= ''

        # print('content:', content)
        labels = ['name_per', 'sex_per', 'email_per', 'age_per', 'phone_per', 'qq', 'weixin', 'address_per', 'height',
                  'weight',
                  'race', 'nationality', 'marital_status', 'highest_edu_per', 'adm_date', 'gra_date', 'gra_school_per',
                  'major_per', 'lan_skill_per', 'prof_skill_per',
                  'office_skill_per', 'awards_per', 'certificates', 'political_status', 'postal_code', 'school_level',
                  'courses', 'edu_gpa', 'job_title',
                  'company_name', 'work_date', 'work_description', 'work_industry', 'work_year', 'project_name',
                  'project_position', 'project_date', 'project_description',
                  'social_pos', 'social_description', 'social_cpy', 'social_date', 'train_org', 'training_description',
                  'train_date', 'self_evaluation', 'candidate_job_title',
                  'parsing_time', 'resume_type', 'resume_name', 'path_resume', 'avatar_url', 'pred_salary', 'pos_tags',
                  'skills_tags','username']

        #ʶ����д��csv
        # with open(r"E:\�о�������\ʮ����������\resume-analysis-system-back/ieResult/csv_dct.csv", 'a', encoding='utf-8') as f:
        #     writer = csv.DictWriter(f, fieldnames=labels)
        #     # writer.writeheader()
        #     # for elem in dct_arr:
        #     writer.writerow(content)
        # f.close()

        data = (content['name_per'], content['sex_per'], content['email_per'], content['age_per'], content['phone_per'], content['qq'], content['weixin'], content['address_per'],
                content['height'], content['weight'], content['race'], content['nationality'], content['marital_status'], content['highest_edu_per'], content['adm_date'],
                content['gra_date'], content['gra_school_per'], content['major_per'], content['lan_skill_per'], content['prof_skill_per'], content['office_skill_per'],
                content['awards_per'], content['certificates'], content['political_status'], content['postal_code'], content['school_level'], content['courses'], content['edu_gpa'],
                content['job_title'], content['company_name'], content['work_date'], content['work_description'], content['work_industry'], content['work_year'], content['project_name'],
                content['project_position'], content['project_date'], content['project_description'], content['social_pos'], content['social_description'], content['social_cpy'],
                content['social_date'], content['train_org'], content['training_description'], content['train_date'], content['self_evaluation'], content['candidate_job_title'],
                content['parsing_time'], content['resume_type'], content['resume_name'], content['path_resume'], content['avatar_url'], content['pred_salary'], content['pos_tags'],
                content['skills_tags'], username)
        return data

