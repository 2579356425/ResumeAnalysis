import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'

/* Router Modules */
import componentsRouter from './modules/components'
import chartsRouter from './modules/charts'
import tableRouter from './modules/table'
import nestedRouter from './modules/nested'

/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    roles: ['admin','editor']    control the page roles (you can set multiple roles)
    title: 'title'               the name show in sidebar and breadcrumb (recommend set)
    icon: 'svg-name'/'el-icon-x' the icon show in the sidebar
    noCache: true                if set true, the page will no be cached(default is false)
    affix: true                  if set true, the tag will affix in the tags-view
    breadcrumb: false            if set false, the item will hidden in breadcrumb(default is true)
    activeMenu: '/example/list'  if set path, the sidebar will highlight the path you set
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
export const constantRoutes = [
  {
    path: '/redirect',
    component: Layout,
    hidden: true,
    children: [
      {
        path: '/redirect/:path(.*)',
        component: () => import('@/views/redirect/index')
      }
    ]
  },
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },
  {
    path: '/auth-redirect',
    component: () => import('@/views/login/auth-redirect'),
    hidden: true
  },
  {
    path: '/404',
    component: () => import('@/views/error-page/404'),
    hidden: true
  },
  {
    path: '/401',
    component: () => import('@/views/error-page/401'),
    hidden: true
  },
  {
    path: '/',
    component: Layout,
    redirect: '/dashboard',
    children: [
      {
        path: 'dashboard',
        component: () => import('@/views/dashboard/index'),
        name: 'Dashboard',
        meta: { title: '数据统计与分析', icon: 'dashboard', affix: true }
      }
    ]
  },
  {
    path: '/',
    component: Layout,
    redirect: '/resumeDataManage',
    name: '简历制作&管理',
    meta: {
	    title: '简历制作&管理',
	    icon: 'resume'
	  },
    children: [
      {
        // 简历制作
			  path: 'resumeGenerate',
			  component: () => import('@/views/resumeDataManage/resumeGenerate/index'),
			  name: 'resumeGenerate',
			  meta: {
			    title: '简历制作',
			    icon: 'write'
			  }
			},
      {
        path: 'dataManage',
        component: () => import('@/views/resumeDataManage/dataManage/index'),
        name: 'dataManage',
        meta: { title: '简历库管理', icon: 'manage', affix: true }
      }
    ]
  },

  {
    path: '/',
    component: Layout,
    redirect: '/positionManage',
    children: [
      {
        path: 'positionManage',
        component: () => import('@/views/positionManage/index'),
        name: 'positionManage',
        meta: { title: '岗位管理', icon: '手提箱', affix: true }
      }
    ]
  },
  {
	  path: '/',
	  component: Layout,
	  redirect: '/resumeAnalysis/resumeGenerate',
	  children: [
			{
        // 简历分析
	      path: 'resumeAnalysis',
	      component: () => import('@/views/resumeAnalysis/index'),
	      name: 'resumeAnalysis',
	      meta: {
	        title: '简历解析',
	        icon: 'analysis'
	      }
	    }
	  ]
	},
  {
    path: '/',
    component: Layout,
    redirect: '/talentPortrait',
    children: [
      {
        path: 'talentPortrait',
        component: () => import('@/views/talentPortrait/index'),
        name: 'talentPortrait',
        meta: { title: '人才画像构建', icon: '候选人', affix: true }
      }
    ]
  },
  {
    path: '/1',
    component: Layout,
    redirect: '/person-post',
    name: '人岗匹配',
    meta: {
	    title: '人岗匹配',
	    icon: 'kg1'
	  },
    children: [
      {
        // 简历制作
			  path: 'person-post',
			  component: () => import('@/views/person-post/index'),
			  name: 'person-post',
			  meta: {
			    title: '以人推岗',
			    icon: 'kg1'
			  }
			},
      {
        path: 'post-person',
        component: () => import('@/views/post-person/index'),
        name: 'post-person',
        meta: { title: '以岗推人', icon: 'kg1'}
      }
    ]
  },
  // {
  //   path: '/',
  //   component: Layout,
  //   redirect: '/person-post',
  //   children: [
  //     {
  //       path: 'person-post',
  //       component: () => import('@/views/person-post/index'),
  //       name: 'person-post',
  //       meta: { title: '人岗匹配', icon: 'kg1', affix: true }
  //     }
  //   ]
  // },
	// {
	//   path: '/form',
	//   component: Layout,
	//   children: [{
	//     path: 'table',
	//     name: 'Table',
	//     component: () => import('@/views/table/index'),
	//     meta: {
	//       title: '历史记录',
	//       icon: 'list'
	//     }
	//   }]
	// },
	{
	  path: '/sysinfo',
	  component: Layout,
	  children: [{
	    path: 'sysinfo',
	    name: 'sysinfo',
	    component: () => import('@/views/sysinfo/index'),
	    meta: {
	      title: '关于我们',
	      icon: 'link'
	    }
	  }]
	},
]

/**
 * asyncRoutes
 * the routes that need to be dynamically loaded based on user roles
 */
export const asyncRoutes = [

  // 404 page must be placed at the end !!!
  { path: '*', redirect: '/404', hidden: true }
]

const createRouter = () => new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
