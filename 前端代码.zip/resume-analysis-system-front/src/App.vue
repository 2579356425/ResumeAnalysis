<template>
  <div id="app">
    <router-view v-if="isRouterAlive"></router-view>
    <!-- <router-view></router-view> -->
  </div>
</template>

<script>
// import * as echarts from 'echarts';
// import { provide } from 'vue';
// // echarts
// provide('echarts', echarts);
export default {
  name: 'App',
  // 通过声明reload方法，控制router-view的显示或隐藏，从而控制页面的再次加载，这边定义了isRouterAlive，用true or false 来控制
  // 参考https://blog.csdn.net/yaxuan88521/article/details/123307992 第三种方法
  provide (){
    return{
      reload: this.reload
    }
  },
  data (){
    return{
      isRouterAlive: true
    }
  },
  methods: {
    reload (){
      this.isRouterAlive = false
      this.$nextTick(function(){
        this.isRouterAlive = true
      })
    }
  }
}
</script>
