<script>
export default {
  name: 'Global',
  data() {
    return {
      // conn: 'http://localhost:5000',
      conn: 'http://81.68.169.78:5000',
      username: 'admin'
    }
  }
}
</script>
