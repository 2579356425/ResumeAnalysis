<template>
    <div align="center">
      <div style="padding-bottom: 40px;">
        <a style="color: #00aaff;"><h2>数据集管理</h2></a>
        <el-col :span="16" :offset="4">
            <!-- <el-upload
            class="upload-demo"
            action="http://10.9.21.97:59999/workspace/whj/flask/images/"
            :headers="upHeaders"
            :show-file-list="false"
            :on-success="handleSuccess"
            :on-error="handleError"
            :limit="1"
            >
            </el-upload> -->
            <el-button size="small" type="primary" style="margin-left:10px;margin-top:1px;height: 34px;" @click="dialogTableVisible = true"><i class="el-icon-upload" />上传数据集</el-button>
            <el-dialog title="上传数据集" :visible.sync="dialogTableVisible">
                <el-form :model="dataset">
                    <div style="margin-left: 10px;margin-bottom: 5px; margin-top: -5px; text-align: left;">
                        <span style="color: red; margin-left: 20px;align: left">*</span>
                        <span style="text-align:left; font-size: 15px;color: black;font-weight: bold;">数据集名称</span>
                    </div>
                    <el-form-item >
                        <el-input v-model="datasetName" autocomplete="off" style="margin-left: 0px;"></el-input>
                    </el-form-item>
                    <div style="margin-left: 10px;margin-bottom: 5px; margin-top: -10px; text-align: left;">
                        <span style="color: red; margin-left: 20px;align: left">*</span>
                        <span style="text-align:left; font-size: 15px;color: black;font-weight: bold;">数据集获取日期</span>
                        <div style="margin-top: 5px;">
                          <el-date-picker
                            v-model="getDate"
                            type="date"
                            placeholder="选择数据集获取日期"
                            format="yyyy-MM-dd"
                            value-format="yyyy-MM-dd"
                            style="margin-left: 20px;width: 88%;"
                          />
                        </div>
                    </div>
                    <div style="margin-left: 10px;margin-bottom: 5px; margin-top: 10px; text-align: left;">
                        <span style="color: red; margin-left: 20px;align: left">*</span>
                        <span style="text-align:left; font-size: 15px;color: black;font-weight: bold;">数据集类型</span>
                        <el-cascader size="small" v-model="datasetType" :options="options2" placeholder="请选择数据集类型" style="width: 99%; margin: 8px 0 0 20px;" popper-class="pc-sel-area-cascader">
                        </el-cascader>
                    </div>

                    <div style="margin-left: 10px;margin-bottom: 5px; margin-top: 5px; text-align: left;">
                        <span style="color: red; margin-left: 20px;align: left">*</span>
                        <span style="text-align:left; font-size: 15px;color: black;font-weight: bold;">数据集文件</span>
                    </div>
                    <el-upload
                        class="upload-demo"
                        drag
                        action="https://jsonplaceholder.typicode.com/posts/"
                        multiple>
                        <i class="el-icon-upload" style="margin-top: 25px;"></i>
                        <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
                        <div style="margin-top: 5px;"></div>
                        <div class="el-upload__text">只能上传zip文件，文件格式如下：</div>
                        <div style="margin-top: 5px;"></div>
                        <div class="el-upload__text_left">·image文件夹（存放png或jpg格式的图片）</div>
                        <div style="margin-top: 5px;"></div>
                        <div class="el-upload__text_left">·label文件夹（存放带标签的图像）</div>
                    </el-upload>
                    <div style="margin-top: 8px;"></div>
                    <div style="margin-left: 10px;margin-bottom: 5px; text-align: left;">
                        <span style="color: red; margin-left: 20px;align: left">*</span>
                        <span style="text-align:left;font-size: 15px;color: black;font-weight: bold;">所属区域</span>
                    </div>
                    <el-form-item style="margin-left: 20px;">
                    <el-cascader
                        v-model="imageArea"
                        :options="options"
                        :props="{ expandTrigger: 'hover' }"
                        @change="handleChange"
                        popper-class="pc-sel-area-cascader"
                        style="margin: 0 0 0 -15px;">
                    </el-cascader>
                    </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer">
                    <el-button @click="dialogFormVisible = false">取 消</el-button>
                    <el-button type="primary" @click="dialogFormVisible = false;uploadDataset()">确 定</el-button>
                </div>
            </el-dialog>
        </el-col>
      </div>

      <div style="width: 100%;padding: 20px 40px 40px 40px;">
        <el-row :gutter="20" type="flex">
            <el-col :span="6" v-for="(o, index) in dataset.slice((currentPage-1)*PageSize,currentPage*PageSize)" :key="index">
              <el-card :body-style="{ padding: '15px 15px 10px 15px' }" >
                <el-image :src="dataset[index][3]" class="image" />
                <div style="padding: 10px 10px 0 10px;">
                  <div style="text-align: left;width: 100%;">
                    <span style="font-size: 16px;font-weight: 600;">数据集名称:</span>
                    <span style="font-size: 16px;font-weight: 600;">{{dataset[index][1]}}</span>
                  </div>
                  <div style="text-align: left;width: 100%;margin-top: 5px;">
                    <span style="font-size: 16px;font-weight: 600;">数据集获取日期:</span>
                    <span style="font-size: 16px;font-weight: 600;">{{dataset[index][5]}}</span>
                  </div>
                  <div style="text-align: left;width: 100%;margin-top: 5px;">
                    <span style="font-size: 16px;font-weight: 600;">数据集类型:</span>
                    <span style="font-size: 16px;font-weight: 600;">{{dataset[index][6]}}</span>
                  </div>
                  <div class="bottom clearfix">
                    <!-- <time class="time">{{ currentDate }}</time> -->
                    <el-button size="medium"  type="danger" class="button" @click="deleteDataset(index)"><i class="el-icon-delete" />删除</el-button>
                    
                    <el-button size="medium"  type="primary" class="button" @click="downloadDataset(index)"><i class="el-icon-download"></i>下载</el-button>
                    </div>
                </div>
              </el-card>
            </el-col>
        </el-row>
      </div>
      <div class="block" align="center" style="margin-top: 10px; margin-bottom: 10px;">
        <el-pagination
          :current-page="currentPage"
          :page-sizes="pageSizes"
          :page-size="PageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>
</template>
<script>
    import { regionDataPlus } from 'element-china-area-data'
    import axios from 'axios'
    import Vue from 'vue'
    export default {
        inject: ['reload'], // 注入刷新页面的依赖
        data() {
            return{
                dialogTableVisible: false,
                datasetName: '',
                getDate: '',
                datasetType: '',
                imageArea: '',
                dataset: [],
                currentPage: 1,
                total: 0,
                pageSizes: [4, 8, 12],
                PageSize: 4,
                options: regionDataPlus ,
                currentDate: new Date(),
                options2  : [{
                    value: '目标提取',
                    label: '目标提取',
                    }, {
                    value: '变化检测',
                    label: '变化检测',
                    }, {
                    value: '目标检测',
                    label: '目标检测',
                    children:[{
                      value: '操场',
                      label: '操场'
                    },{
                      value: '油罐',
                      label: '油罐'
                    },{
                      value: '天桥',
                      label: '天桥'
                    },{
                      value: '飞机',
                      label: '飞机'
                    }]}, {
                    value: '地物分类',
                    label: '地物分类',
                    }],
            }
        },
         created() {
            this.getDatasetInfo()
        },
        methods: {
            uploadDataset(file) {
                  const config = {
                    headers: {
                      'Content-Type': 'multipart/form-data'
                    }
                  }
                  const formData = new FormData()
                  formData.append('datasetName', this.datasetName)
                  formData.append('imageArea', this.imageArea)
                  formData.append('getDate', this.getDate)
                  formData.append('datasetType', this.datasetType)
                  var that = this
                  axios.post('http://10.9.21.97:5000/datasetUpload', formData, file, config).then(function(response) {
                    if (response.status == 200) {
                      that.$notify({
                        title: '成功',
                        message: '数据集上传成功！',
                        type: 'success'
                      })
                      that.reload()
                    }
                  }).catch(err => {
                    this.$message.error(err.message)
                    console.log(err)
                  })
            },
            // 上传失败钩子
            handleError(err, file, fileList) {
                this.$message.error(err.errormsg)
            },
            // 上传成功钩子(在这里可以处理上传成功后端返回的数据)
            handleSuccess(rep, file, fileList) {
                console.log(req)
            },
            getDatasetInfo(){
              const path = 'http://10.9.21.97:5000/getDataset'
              var that = this
              axios.get(path).then(res => {
                console.log(res.data)
                that.dataset = res.data
                that.total = that.dataset.length
              }).catch(error => {
                console.error(error)
              })
            },
            downloadDataset(index){
              console.log(this.dataset[index][0])
              const formData = new FormData()
              formData.append('datasetId', this.dataset[index][0])
              const config = {
                headers: {
                  'Content-Type': 'multipart/form-data'
                }
              }
              var that = this
              axios.post('http://10.9.21.97:5000/downloadDataset', formData, config).then(function(response) {
                if (response.status === 200) {
                  console.log(response.data)
                  window.open(response.data + '?response-content-type=application/octet-stream')
                  that.$notify({
                    title: '成功',
                    message: '数据集下载成功！',
                    type: 'success'
                  })
                }
              }).catch(err => {
                this.$message.error(err.message)
                console.log(err)
              })
              this.reload()
            },
            deleteDataset(index){
              this.$confirm('此操作将永久删除该数据集, 是否继续?', '提示', {
              		confirmButtonText: '确定',
              		cancelButtonText: '取消',
              		type: 'warning'
              	}).then(() => {
                  const formData = new FormData()
                  formData.append('datasetId', this.dataset[index][0])
                  const config = {
                    headers: {
                      'Content-Type': 'multipart/form-data'
                    }
                  }
                  var that = this
                  axios.post('http://10.9.21.97:5000/deleteDataset', formData, config).then(function(response) {
                    if (response.status === 200) {
                      that.$notify({
                        title: '成功',
                        message: '数据集删除成功！',
                        type: 'success'
                      })
                    }
                  }).catch(err => {
                    this.$message.error(err.message)
                    console.log(err)
                  })
                  this.reload()
                })
            },
            handleSizeChange(val) {
              this.PageSize = val
              this.currentPage = 1
              console.log(`每页 ${val} 条`)
            },
            handleCurrentChange(val) {
              this.currentPage = val
              console.log(`当前页: ${val}`)
            },
        }
    }
</script>
<style>
    .el-dialog {
        width: 30%;
    }
    .el-form .el-input {
        width: 86%;
    }
    .el-input.el-input--medium.el-input--suffix {
        width: 357px;
        margin-left: -15px;
    }
    .dialog-footer {
        margin-right: 30px;
    }
    .el-upload__text_left {
        text-align: left;
        margin-left: 65px;
    }
    .el-cascader .el-input .el-input__inner {
      background-color: white;
      width: 103%;
    }
    .el-cascader-menu__list {
      background-color: white;
    }
    .el-cascader-node__label {
      color: black;
    }
    .el-button.button.el-button--danger.el-button--medium {
      width: 60px;
      height: 30px;
    }
    .el-button.button.el-button--primary.el-button--medium {
      width: 60px;
      height: 30px;
    }
</style>
<style>
  .time {
    font-size: 13px;
    color: #999;
  }

  .bottom {
    margin-top: 13px;
    line-height: 12px;
  }

  .button {
    margin-left: 10px;
    padding: 0;
    float: right;
  }

  .image {
    width: 100%;
    display: block;
  }

  .clearfix:before,
  .clearfix:after {
      display: table;
      content: "";
  }

  .clearfix:after {
      clear: both
  }
</style>
