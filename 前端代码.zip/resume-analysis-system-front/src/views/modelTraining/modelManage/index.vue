<template>
    <div align="center">
      <div style="padding-bottom: 40px;">
        <a style="color: #00aaff;"><h2>模型管理</h2></a>
        <div style="width: 100%;height: 30px;margin-top: 40px;">
          <!-- <span style="text-align:left; font-size: 15px;color: black;font-weight: bold;">数据集名称</span> -->
          <div style="width: 20%;height: 20px;float:left;margin-left: 60px;">
            <span style="margin-left: 10px;font-size: 16px;font-weight: bold;">模型名称</span>
            <el-input size="small" style="width: 150px;margin-left: 15px;" v-model="modelName" placeholder="请输入模型名称" >
              <el-button slot="suffix" icon="el-icon-search" type="text"></el-button>
            </el-input>
          </div>
          <div style="width: 20%;height: 20px;float:left;">
            <span style="margin-left: 10px;font-size: 16px;font-weight: bold;">模型类型</span>
            <el-cascader
                size="small"
                v-model="modelType"
                placeholder="请选择模型类型"
                :options="options1"
                :props="{ expandTrigger: 'hover' }"
                @change="handleChange"
                popper-class="pc-sel-area-cascader"
                style="margin: 0 0 0 -15px;">
            </el-cascader>
          </div>
          <div style="width: 22%;height: 20px;float:left;">
            <span style="margin-left: 10px;font-size: 16px;font-weight: bold;">创建日期</span>
            <el-date-picker
              size="small"
              v-model="buildDate"
              type="date"
              placeholder="请选择模型创建日期"
              format="yyyy-MM-dd"
              value-format="yyyy-MM-dd"
              style="margin-left: 20px;width: 190px;"
            />
          </div>
          <div >
            <el-button size="medium" type="primary" style="margin-left:10px;margin-top:1px;height: 34px;" @click="dialogTableVisible = true;"><i class="el-icon-thumb"></i>新建模型训练</el-button>
          </div>
        </div>
        <div style="width: 100%;height: 30px;margin-top: 30px;margin-bottom: 20px;margin-left: 60px;">
          <div style="width: 20%;height: 20px;float:left;">
            <span style="margin-left: 10px;font-size: 16px;font-weight: bold;">模型状态</span>
            <el-cascader
                size="small"
                v-model="modelState"
                placeholder="请选择模型状态"
                :options="options2"
                :props="{ expandTrigger: 'hover' }"
                @change="handleChange"
                popper-class="pc-sel-area-cascader"
                style="margin: 0 0 0 -15px;">
            </el-cascader>
          </div>
          <div style="width: 20%;height: 20px;float:left;">
            <span style="margin-left: 10px;font-size: 16px;font-weight: bold;">网络结构</span>
            <el-cascader
                size="small"
                v-model="netName"
                placeholder="请选择网络结构"
                :options="options3"
                :props="{ expandTrigger: 'hover' }"
                @change="handleChange"
                popper-class="pc-sel-area-cascader"
                style="margin: 0 0 0 -15px;">
            </el-cascader>
          </div>
          <div style="width: 22%;height: 20px;float:left;">
            <span style="margin-left: 10px;font-size: 16px;font-weight: bold;">主干网络</span>
            <el-select
                size="small"
                v-model="backbone"
                placeholder="请选择主干网络"
                :props="{ expandTrigger: 'hover' }"
                @change="handleChange"
                popper-class="pc-sel-area-cascader"
                style="margin: 0 0 0 20px;width: 190px;">
                <el-option
                v-for="item in options4"
                :key="item.key"
                :label="item.label"
                :value="item.value">
                </el-option>
            </el-select>
          </div>
        </div>

        <el-dialog title="新建模型训练" :visible.sync="dialogTableVisible">
            <el-form>
                <div style="margin-left: 10px;margin-bottom: 5px; margin-top: -5px; text-align: left;">
                    <span style="color: red; margin-left: 20px;align: left">*</span>
                    <span style="text-align:left; font-size: 15px;color: black;font-weight: bold;">模型名称</span>
                </div>
                <el-form-item >
                    <el-input v-model="modelName1" autocomplete="off" style="margin-left: 0px; width:150px;"></el-input>
                </el-form-item>
                <div style="margin-left: 10px;margin-bottom: 5px; margin-top: -10px; text-align: left;">
                    <span style="color: red; margin-left: 20px;align: left">*</span>
                    <span style="text-align:left; font-size: 15px;color: black;font-weight: bold;">数据集名称</span>
                </div>
                <el-select
                    size="medium"
                    v-model="datasetName"
                    placeholder="请选择数据集名称"
                    :props="{ expandTrigger: 'hover' }"
                    @change="handleChange"
                    popper-class="pc-sel-area-cascader"
                    style="margin: 0 0 0 40px;width: 190px;">
                    <el-option
                    v-for="item in options5"
                    :key="item.key"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
                <div style="margin-left: 10px;margin-bottom: 5px; margin-top: 10px; text-align: left;">
                    <span style="color: red; margin-left: 20px;align: left">*</span>
                    <span style="text-align:left; font-size: 15px;color: black;font-weight: bold;">模型类型</span>
                </div>
                <el-select
                    size="medium"
                    v-model="modelType1"
                    placeholder="请选择模型类型"
                    :props="{ expandTrigger: 'hover' }"
                    @change="handleChange"
                    popper-class="pc-sel-area-cascader"
                    style="margin: 0 0 0 40px;width: 190px;">
                    <el-option
                    v-for="item in options1"
                    :key="item.key"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
                <div style="margin-left: 10px;margin-bottom: 5px; margin-top: 10px; text-align: left;">
                    <span style="color: red; margin-left: 20px;align: left">*</span>
                    <span style="text-align:left; font-size: 15px;color: black;font-weight: bold;">网络结构</span>
                </div>
                <el-select
                    size="medium"
                    v-model="netName1"
                    placeholder="请选择网络结构"
                    :props="{ expandTrigger: 'hover' }"
                    @change="handleChange"
                    popper-class="pc-sel-area-cascader"
                    style="margin: 0 0 0 40px;width: 190px;">
                    <el-option
                    v-for="item in options3"
                    :key="item.key"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
                <div style="margin-left: 10px;margin-bottom: 5px; margin-top: 10px; text-align: left;">
                    <span style="color: red; margin-left: 20px;align: left">*</span>
                    <span style="text-align:left; font-size: 15px;color: black;font-weight: bold;">主干网络</span>
                </div>
                <el-select
                    size="medium"
                    v-model="backbone1"
                    placeholder="请选择主干网络"
                    :props="{ expandTrigger: 'hover' }"
                    @change="handleChange"
                    popper-class="pc-sel-area-cascader"
                    style="margin: 0 0 0 40px;width: 190px;">
                    <el-option
                    v-for="item in options4"
                    :key="item.key"
                    :label="item.label"
                    :value="item.value">
                    </el-option>
                </el-select>
            </el-form>
            <div slot="footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" style="margin-right: 30px;" @click="dialogFormVisible = false;  modelTraining()">确 定</el-button>
            </div>
        </el-dialog>

      </div>

      <div style="width: 100%;padding: 20px 40px 40px 40px;">
        <el-table
          id="extract"
          :data="modelData.slice((currentPage-1)*PageSize,currentPage*PageSize).filter(data => !modelType || data[2].toLowerCase().includes(modelType[0].toLowerCase()))"
          border
          style="width: 95%;"
          :header-cell-style="{'text-align':'center'}"
          :cell-style="{'text-align':'center'}"
        >
          <el-table-column type="index" :index="indexMethod" label="序号" />
          <el-table-column prop="1" label="模型名称" />
          <el-table-column prop="2" label="模型类型" />
          <el-table-column prop="3" label="创建日期" />
          <el-table-column prop="4" label="模型状态" >
          <!--  <template slot-scope="scope">
              <el-progress :text-inside="true" :stroke-width="26" :percentage="progressUp" v-if="scope.row.modelState==训练中"></el-progress>
            </template> -->
          </el-table-column>
          <el-table-column prop="5" label="网络结构" />
          <el-table-column prop="6" label="主干网络" />
          <el-table-column  align="right" label="模型管理">
   <!--         <template slot="header" slot-scope="scope">
            	<el-input v-model="modelType" size="mini" placeholder="输入解译名称或解译类型搜索" />
            </template> -->
            <template slot-scope="scope">
              <el-button type="primary" size="mini" @click="drawer = true;"><i class="el-icon-search" />详情</el-button>
              <el-button type="danger" size="mini" @click="deleteModel(scope.$index, scope.row)"><i class="el-icon-delete" />删除</el-button>
              <el-drawer
                title="模型信息详情"
                :visible.sync="drawer"
                direction="rtl"
                size="25%">
                <div style="height: 30px;">
                  <span style="color: black;float: left;margin-left: 50px;font-size: 18px;">模型名称</span>
                  <span style="color: black;float: left;margin-left: 150px;font-size: 18px;">模型类型</span>
                </div>
                <div style="height: 30px;">
                  <span style="color: black;float: left;margin-left: 50px;font-size: 16px;">{{scope.row[1]}}</span>
                  <span style="color: black;float: left;margin-left: 150px;font-size: 16px;">{{scope.row[2]}}</span>
                </div>

                <div style="height: 30px;margin-top: 20px;">
                  <div style="margin-left: 10px;">
                    <span style="color: black;float: left;margin-left: 40px;font-size: 18px;">网络结构</span>
                    <el-popover
                        placement="top-start"
                        trigger="hover"
                        content="深度学习模型训练基于的网络结构"
                        popper-class="el_popover_class1"
                        style="margin-left: -30px;">
                      <el-button size="medium" slot="reference" type="goon" icon="el-icon-question" circle></el-button>
                    </el-popover>
                    <span style="color: black; margin-left: 130px;font-size: 18px;">Backbone</span>
                    <el-popover
                        placement="top-start"
                        trigger="hover"
                        content="模型训练中用于特征提取的主干网络"
                        popper-class="el_popover_class2">
                      <el-button size="medium" slot="reference" type="goon" icon="el-icon-question" circle></el-button>
                    </el-popover>
                  </div>

                </div>

                <div style="height: 30px;">
                  <span style="color: black;float: left;margin-left: 50px;font-size: 16px;">{{scope.row[5]}}</span>
                  <span style="color: black;position: absolute;left: 270px;top: 185px;font-size: 16px;">{{scope.row[6]}}</span>
                </div>

                <div style="height: 30px;margin-top: 20px;">
                  <span style="color: black;float: left;margin-left: 50px;font-size: 18px;">模型状态</span>
                </div>
                <div>
                    <div style="width: 400px;">
                      <div style="width: 150px;margin-left: 20px;" v-if='scope.row[4]=="训练中"'>
                        <span style="color: black;float: left;margin-left: 50px;font-size: 16px;">{{scope.row[4]}}</span>
                        <el-progress :percentage="48.7" :stroke-width="12"></el-progress>
                        <el-button style="position: absolute;left: 240px;top: 280px; width:140px;" type="danger" size="medium" @click="cancelModelTraining(scope.$index, scope.row)"><i class="el-icon-delete" />终止训练</el-button>
                      </div>
                      <div style="width: 400px;" v-if='scope.row[4]!="训练中"'>
                        <span style="color: black;float: left;margin-left: 50px;font-size: 16px;">{{scope.row[4]}}</span>
                      </div>
                      <div style="margin-left: 20px;width: 50px;">
                        <el-button style="position: absolute;left: 240px;top: 240px;" type="primary" size="medium" @click="changeModelState(scope.$index, scope.row)"><i class="el-icon-edit" />更新模型状态</el-button>
                      </div>
                    </div>
                </div>
                <div  v-if='scope.row[4]!="训练中"'>
                  <div style="height: 20px;margin-top: 40px;">
                    <span style="color: black;float: left;margin-left: 50px;font-size: 18px;">检测样例</span>
                  </div>
                  <div style="height: 150px;margin-top: 20px;margin-left: -150px;">
                    <span style="position: absolute;left: 80px;top: 500px;">(待检测图像)</span>
                    <img src='http://10.9.21.97:59999/workspace/whj/flask/images/img-1.png' draggable="false" width="150px">
                  </div>
                  <div style="height: 150px;margin-top: 30px;margin-left: -150px;">
                    <span style="position: absolute;left: 90px;top: 690px;">(检测结果)</span>
                    <img src='http://10.9.21.97:59999/workspace/whj/flask/results/tiqu/目标提取示例.png' draggable="false" width="150px">
                  </div>
                </div>
                <div  v-if='scope.row[4]=="训练中"'>
                  <div style="height: 20px;margin-top: 20px;">
                    <span style="color: black;float: left;margin-left: 50px;font-size: 18px;">检测样例</span>
                  </div>
                  <div style="height: 150px;margin-top: 20px;margin-left: -150px;">
                    <span style="position: absolute;left: 80px;top: 532px;">(待检测图像)</span>
                    <img src='http://10.9.21.97:59999/workspace/whj/flask/images/img-1.png' draggable="false" width="150px">
                  </div>
                  <div style="height: 150px;margin-top: 30px;margin-left: -150px;">
                    <span style="position: absolute;left: 90px;top: 722px;">(检测结果)</span>
                    <img src='http://10.9.21.97:59999/workspace/whj/flask/results/tiqu/目标提取示例.png' draggable="false" width="150px">
                  </div>
                </div>
              </el-drawer>
            </template>

          </el-table-column>
        </el-table>

      </div>

      <div class="block" align="center" style="margin-top: 10px; margin-bottom: 10px;">
        <el-pagination
          :current-page="currentPage"
          :page-sizes="pageSizes"
          :page-size="PageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>
</template>
<script>
    import { regionDataPlus } from 'element-china-area-data'
    import axios from 'axios'
    import Vue from 'vue'
    export default {
        inject: ['reload'], // 注入刷新页面的依赖
        data() {
            return{
                dialogTableVisible: false,
                modelName: '',
                buildDate: '',
                modelType: '',
                modelState: '',
                netName: '',
                backbone: '',
                modelName1: '',
                buildDate1: '',
                modelType1: '',
                modelState1: '',
                netName1: '',
                backbone1: '',
                progressUp: 67,
                datasetName: '',
                drawer: false,
                modelData: [],
                currentPage: 1,
                total: 0,
                pageSizes: [5, 10, 15],
                PageSize: 5,
                options: regionDataPlus ,
                currentDate: new Date(),
                options1  : [{
                    value: '目标提取',
                    label: '目标提取',
                    }, {
                    value: '变化检测',
                    label: '变化检测',
                    }, {
                    value: '目标检测',
                    label: '目标检测',
                    }, {
                    value: '地物分类',
                    label: '地物分类',
                    }],
                options2:[{
                    value: '训练中',
                    label: '训练中',
                    }, {
                    value: '待部署',
                    label: '待部署',
                    }, {
                    value: '已部署',
                    label: '已部署',
                    }],
                options3: [{
                    value: 'DeepLabV3Plus',
                    label: 'DeepLabV3Plus',
                },{
                    value: 'PSPNet',
                    label: 'PSPNet',
                },{
                    value: 'fcn',
                    label: 'fcn',
                }],
                options4: [{
                    value: 'resnet18',
                    label: 'resnet18',
                },{
                    value: 'resnet34',
                    label: 'resnet34',
                },{
                    value: 'resnet50',
                    label: 'resnet50',
                },{
                    value: 'resnet101',
                    label: 'resnet101',
                }],
                options5: [{
                      value: '目标提取7.20',
                      label: '目标提取7.20',
                  },{
                      value: '变化检测7.20',
                      label: '变化检测7.20',
                  },{
                      value: '操场检测7.20',
                      label: '操场检测7.20',
                  },{
                      value: '地物分类7.20',
                      label: '地物分类7.20',
                  }],
            }
        },
         created() {
            this.getModel()
        },
        watch:{
          backbone: function(){
            console.log(this.backbone)
          },
          modelType: function(){
            console.log(this.modelType)
          },
          netName: function(){
            console.log(this.netName)
          }
        },
        methods: {
            modelTraining(file) {
                  const config = {
                    headers: {
                      'Content-Type': 'multipart/form-data'
                    }
                  }
                  var Date1 = new Date().getTime() // 中国标准时间
                  var date = new Date(Date1)
                  var y = date.getFullYear() // 年
                  var m = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) // 月
                  var d = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()) // 日
                  this.buildDate1 = y + '-' + m + '-' + d
                  this.modelState1 = "训练中"
                  const formData = new FormData()
                  formData.append('modelName', this.modelName1)
                  formData.append('buildDate', this.buildDate1)
                  formData.append('modelType', this.modelType1)
                  formData.append('modelState', this.modelState1)
                  formData.append('netName', this.netName1)
                  formData.append('backbone', this.backbone1)
                  formData.append('datasetName', this.datasetName)
                  var that = this
                  axios.post('http://10.9.21.97:5000/modelTraining', formData, file, config).then(function(response) {
                    if (response.status == 200) {
                      that.$notify({
                        title: '成功',
                        message: '模型已经开始训练！',
                        type: 'success'
                      })
                      that.reload()
                    }
                  }).catch(err => {
                    this.$message.error(err.message)
                    console.log(err)
                  })
            },
            // 上传失败钩子
            handleError(err, file, fileList) {
                this.$message.error(err.errormsg)
            },
            // 上传成功钩子(在这里可以处理上传成功后端返回的数据)
            handleSuccess(rep, file, fileList) {
                console.log(req)
            },
            handleClose(done) {
                    this.$confirm('确认关闭？')
                      .then(_ => {
                        done();
                      })
                      .catch(_ => {});
            },
            getModel(){
              const path = 'http://10.9.21.97:5000/getModel'
              var that = this
              axios.get(path).then(res => {
                console.log(res.data)
                that.modelData = res.data
                that.total = that.modelData.length
              }).catch(error => {
                console.error(error)
              })
            },
            downloadDataset(index){
              const formData = new FormData()
              formData.append('datasetId', this.dataset[index][0])
              const config = {
                headers: {
                  'Content-Type': 'multipart/form-data'
                }
              }
              var that = this
              axios.post('http://10.9.21.97:5000/downloadDataset', formData, config).then(function(response) {
                if (response.status === 200) {
                  window.open(response.data + '?response-content-type=application/octet-stream')
                  that.$notify({
                    title: '成功',
                    message: '数据集下载成功！',
                    type: 'success'
                  })
                }
              }).catch(err => {
                this.$message.error(err.message)
                console.log(err)
              })
              this.reload()
            },
            deleteModel(index, row){
              this.$confirm('此操作将永久删除该模型, 是否继续?', '提示', {
              		confirmButtonText: '确定',
              		cancelButtonText: '取消',
              		type: 'warning'
              	}).then(() => {
                  console.log(row[0])
                  const formData = new FormData()
                  formData.append('model_id', row[0])
                  console.log(formData)
                  var that =
                      this // 在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
                  axios.post('http://10.9.21.97:5000/deleteModel', formData).then(function(response) {
                    if (response.data === 'success') {
                      that.getTemplate()
                      that.$notify({
                        title: '成功',
                        message: filename + ' 删除成功!',
                        type: 'success'
                      })
                    }
                  }).catch(err => {
                    this.$message.error(err.message)
                    console.log(err)
                  })
                  this.reload()
                }).catch(() => {
                  this.$message({
                    type: 'info',
                    message: '已取消删除'
                  });
                });
            },
            cancelModelTraining(index, row){
              this.$confirm('是否确定终止训练此模型?', '提示', {
              		confirmButtonText: '确定',
              		cancelButtonText: '取消',
              		type: 'warning'
              	}).then(() => {
                  console.log(row[0])
                  const formData = new FormData()
                  formData.append('model_id', row[0])
                  console.log(formData)
                  var that =
                      this // 在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
                  axios.post('http://10.9.21.97:5000/deleteModel', formData).then(function(response) {
                    if (response.data === 'success') {
                      that.getTemplate()
                      that.$notify({
                        title: '成功',
                        message: filename + ' 成功终止训练!',
                        type: 'success'
                      })
                    }
                  }).catch(err => {
                    this.$message.error(err.message)
                    console.log(err)
                  })
                  this.reload()
                }).catch(() => {
                  this.$message({
                    type: 'info',
                    message: '已取消终止'
                  });
                });
            },
            changeModelState(index, row){
              this.$confirm('是否确定更改模型状态?', '提示', {
              		confirmButtonText: '确定',
              		cancelButtonText: '取消',
              		type: 'warning'
              	}).then(() => {
                const formData = new FormData()
                formData.append('model_id', row[0])
                if(row[4] == "训练中"){
                  this.modelState1 = "待部署"
                  formData.append('modelState', "待部署")
                }
                else if(row[4] == "待部署"){
                  this.modelState1 == "已部署"
                  formData.append('modelState', "已部署")
                }
                else{
                  formData.append('modelState', "已部署")
                }
                console.log(formData.get("modelState"))
                // formData.append('modelState', this.modelState1)
                const config = {
                  headers: {
                    'Content-Type': 'multipart/form-data'
                  }
                }
                var that = this
                axios.post('http://10.9.21.97:5000/updateModelState', formData, config).then(function(response) {
                  if (response.status === 200) {
                    that.$notify({
                      title: '成功',
                      message: '模型状态修改成功！',
                      type: 'success'
                    })
                  }
                }).catch(err => {
                  this.$message.error(err.message)
                  console.log(err)
                })
                this.$nextTick(() => {
                    this.reload()
                })
                }).catch(() => {
                  this.$message({
                    type: 'info',
                    message: '已取消更改'
                  });
                });
            },
            handleSizeChange(val) {
              this.PageSize = val
              this.currentPage = 1
              console.log(`每页 ${val} 条`)
            },
            handleCurrentChange(val) {
              this.currentPage = val
              console.log(`当前页: ${val}`)
            },
        }
    }
</script>
<style>
  .el-input__suffix {
    margin-top: -2px;
    margin-right: 4px;
  }
  .el-cascader .el-input .el-input__inner {
    width: 150px;
    margin-left: 30px;
  }
  .el-dialog {
    width: 400px;
  }
  .el-input--medium .el-input__inner {
    width: 300px;
    margin-left: -75px;
  }

  .el-cascader.el-cascader--medium.el-input.el-input--medium.el-input__inner{
    width: 300px;
  }
  .el-input.el-input--medium .el-input__inner {
    width: 300px;
  }
 .el-input.el-input--medium .el-icon-arrow-down {
    margin-right: -45px;
    margin-top: 3px;
  }
  .el-pagination__editor.el-input .el-input__inner{
    width: 40px;
  }
/*  .el-icon-arrow-down:before {
    margin-right: -20px;
  } */
  .el-input--medium .el-input__icon {
    margin-right: -40px;
  }
  .el-select .el-input .el-select__caret {
    margin-top: 2px;
  }
  .el-cascader .el-input .el-icon-arrow-down {
    margin-top: 2px;
  }
  .el-drawer__header {
      color: black;
      font-size: 22px;
    }
  .el-button.el-button--goon.el-button--medium.is-circle.el-popover__reference{
      width: 15px;
      height: 15px;
      padding: 0;
      margin-left: 10px;
    }
/* .el-popover.el_popover_class1{
    margin-left: -100px;
  } */
</style>
