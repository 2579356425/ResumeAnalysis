<template>
  <div>
    <div v-if="active==0" class="big">
      <div align="center">
        <a style="color: #00aaff;"><h2>岗位&公司管理</h2></a>
        <div style="width: 80%;margin: 20px auto;">
          <el-input v-model="txt" size="small" style="width: 150px;margin-left: 15px;" placeholder="请输入关键词" />
          <el-button size="medium" type="primary" style="margin-left:10px;margin-top:1px;height: 34px;" @click="sousuo_mohuchaxun()"><i class="el-icon-thumb" />搜索</el-button>
          <el-button size="medium" type="primary" style="margin-left:10px;margin-top:1px;height: 34px;" @click="drawer = true"><i class="el-icon-menu" />筛选</el-button>
          <el-button type="primary" icon="el-icon-document-add" style="float: right" class="sousuo" @click="dialogFormVisible1 = true">新增</el-button>
        </div>
        <el-table
          id="extract"
          :data="job_info"
          border
          style="width: 95%;"
          :header-cell-style="{'text-align':'center'}"
          :cell-style="{'text-align':'center'}"
        >
          <el-table-column type="index" :index="indexMethod" label="序号" />
          <el-table-column prop="job_name" label="岗位名称"/>
          <el-table-column prop="company_name" label="公司名称"/>
          <el-table-column prop="address" label="工作地点"/>
          <el-table-column prop="salary" label="薪资水平"/>
          <el-table-column prop="publish_time" label="更新时间"/>
          <el-table-column align="right" label="岗位信息管理">
            <template slot-scope="scope">
              <el-button type="primary" size="mini" @click="moveToDetail(scope.row)"><i class="el-icon-edit" />查看</el-button>
              <el-button type="danger" size="mini" @click="Delete( scope.row)"><i class="el-icon-delete" />删除</el-button>
            </template>
          </el-table-column>
        </el-table>
        <div class="block" align="center" style="margin-top: 10px; margin-bottom: 10px;">
          <el-pagination
            :current-page="currentPage"
            :page-sizes="pageSizes"
            :page-size="PageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
          />
        </div>
      </div>
<!--      <div style="text-align: left">-->
<!--        <el-dialog title="重要提示" :visible.sync="isdel">-->
<!--          <div style="color: red">是否确定要删除这个岗位？</div>-->
<!--          <div slot="footer" class="dialog-footer">-->
<!--            <el-button @click="isdel = false">取 消</el-button>-->
<!--            <el-button type="primary" @click="del()">确 定</el-button>-->
<!--          </div>-->
<!--        </el-dialog>-->
<!--      </div>-->
      <el-dialog
        title="提示"
        :visible.sync="centerDialogVisible"
        width="30%"
        center>
        <span>当前查询条件是否提交？</span>
        <span slot="footer" class="dialog-footer">
          <el-button @click="centerDialogVisible = false;drawer = false">取 消</el-button>
          <el-button type="primary" @click="sousuo_tiaojianchaxun">提 交</el-button>
        </span>
      </el-dialog>
      <div class="dia11" style="width: 80%;">
        <el-drawer
          :size="200+''"
          title="筛选条件"
          :with-header="false"
          :visible.sync="drawer"
          :direction="direction"
          :before-close="handleClose">
          <div style="width: 100%;">
            <form ref="" action="">
              <div style="margin-top: 50px" align="center"><a style="color: #1a91ff;"><h2>筛选条件</h2></a></div>
<!--              <a @click="clean_()" style="font-size: small;color: #979797;position: relative;left: 300px">清除条件</a>-->
              <div class="xiangdui">
                <div class="hangye">岗位行业</div>
                <div class="fuxuankuang">
                 <div>
                    <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选</el-checkbox>
                    <el-checkbox-group v-model="selected_industry" @change="handleCheckedCitiesChange">
                      <el-checkbox v-for="industry in select_industry" :label="industry" :key="industry">{{industry}}</el-checkbox>
                    </el-checkbox-group>
                  </div>
                </div>
              </div>

              <div class="xiangdui">
                <div class="didian">工作地点</div>
                <div class="xuanze">
                  <div id="app" style="width: 150px;">
                    <el-cascader
                      size="large"
                      :options="options"
                      :props="{ expandTrigger: 'hover' }"
                      v-model="selectedOptions"
                      @change="handleChange">
                    </el-cascader>
                  </div>
                </div>
              </div>
              <div class="xiangdui">
                <div class="shijian">时间范围</div>
                <div class="danxuankuang">
                  <div style="text-align: left"><el-radio v-model="time_frame" label="7日内">7日内</el-radio></div>
                  <div><el-radio v-model="time_frame" label="1个月内">1个月内</el-radio></div>
                  <div><el-radio v-model="time_frame" label="3个月内">3个月内</el-radio></div>
                </div>
              </div>
            </form>
            <div slot="footer" class="dialog-footer" style="text-align: center;">
              <el-button class="elbtn" @click="clean_()">清除数据</el-button>
<!--              <el-button class="elbtn" @click="drawer = false">取 消</el-button>-->
              <el-button class="elbtn" type="primary" @click="sousuo_tiaojianchaxun()">提 交</el-button>
            </div>
          </div>
        </el-drawer>
      </div>
      <div class="dia" style="width: 80%;">
        <el-dialog title="新增岗位" :visible.sync="dialogFormVisible1">
          <form ref="form_new" action="">
            <div>
              <lable id="job_name"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>岗位名称</lable>
              <span><input v-model="form_new.job_name" type="text" placeholder="请输入岗位名称"></span>
            </div>
            <div>
              <lable id="job_function">工作职能</lable>
              <span><input v-model="form_new.job_function" type="text" placeholder="请输入工作职能"></span>
            </div>
            <div>
              <lable id="job_requirement">岗位要求</lable>
              <span><input v-model="form_new.job_requirement" type="text" placeholder="请输入岗位要求"></span>
            </div>
            <div>
              <lable id="num_hire">招聘人数</lable>
              <span><input v-model="form_new.num_hire" type="text" placeholder="请输入招聘人数"></span>
            </div>
            <div>
              <lable id="company_name">公司名称</lable>
              <span><input v-model="form_new.company_name" type="text" placeholder="请输入公司名称"></span>
            </div>
            <div>
              <lable id="company_industry">公司行业</lable>
              <span><input v-model="form_new.company_industry" type="text" placeholder="请输入公司行业"></span>
            </div>
            <div>
              <lable id="department">招聘部门</lable>
              <span><input v-model="form_new.department" type="text" placeholder="请输入招聘部门"></span>
            </div>
            <div>
              <lable id="address">公司位置</lable>
              <span><input v-model="form_new.address" type="text" placeholder="请输入公司位置"></span>
            </div>
            <div>
              <lable id="phone">联系电话</lable>
              <span><input v-model="form_new.phone" type="text" placeholder="请输入联系电话"></span>
            </div>
            <div>
              <lable id="email">联系邮箱</lable>
              <span><input v-model="form_new.email" type="text" placeholder="请输入联系邮箱"></span>
            </div>
            <div>
              <lable id="salary">工资水平</lable>
              <span><input v-model="form_new.salary" type="text" placeholder="请输入工资水平"></span>
            </div>
            <div>
              <lable id="benefit">福利待遇</lable>
              <span><input v-model="form_new.benefit" type="text" placeholder="请输入福利待遇"></span>
            </div>
            <div>
              <lable id="company_intro">公司描述</lable>
              <span><input v-model="form_new.company_intro" type="text" placeholder="请输入公司描述"></span>
            </div>
            <div>
              <lable id="experience_post">工作经验</lable>
              <span><input v-model="form_new.experience_post" type="text" placeholder="请输入工作经验"></span>
            </div>
            <div>
              <lable id="gender">性别要求</lable>
              <span><input v-model="form_new.gender" type="text" placeholder="请输入性别要求"></span>
            </div>
            <div>
              <lable id="age">年龄要求</lable>
              <span><input v-model="form_new.age" type="text" placeholder="请输入年龄要求"></span>
            </div>
            <div>
              <lable id="major_post">专业要求</lable>
              <span><input v-model="form_new.major_post" type="text" placeholder="请输入专业要求"></span>
            </div>
            <div>
              <lable id="edu_require_post">学位要求</lable>
              <span><input v-model="form_new.edu_require_post" type="text" placeholder="请输入学位要求"></span>
            </div>
            <div>
              <lable id="school_level">学校等级要求</lable>
              <span><input v-model="form_new.school_level" type="text" placeholder="请输入学校等级要求"></span>
            </div>
            <div>
              <lable id="language_post">语言技能要求</lable>
              <span><input v-model="form_new.language_post" type="text" placeholder="请输入语言技能要求"></span>
            </div>
            <div>
              <lable id="prof_skill_post">专业技能要求</lable>
              <span><input v-model="form_new.prof_skill_post" type="text" placeholder="请输入专业技能要求"></span>
            </div>
            <div>
              <lable id="soft_post">软性技能要求</lable>
              <span><input v-model="form_new.soft_post" type="text" placeholder="请输入软性技能要求"></span>
            </div>
            <div>
              <lable id="management_requirement">管理能力要求</lable>
              <span><input v-model="form_new.management_requirement" type="text" placeholder="请输入管理能力要求"></span>
            </div>
            <div>
              <lable id="professional_requirement">职能经验要求</lable>
              <span><input v-model="form_new.professional_requirement" type="text" placeholder="请输入职能经验要求"></span>
            </div>
            <div>
              <lable id="industry_requirement">行业经验要求</lable>
              <span><input v-model="form_new.industry_requirement" type="text" placeholder="请输入行业经验要求"></span>
            </div>
            <div>
              <lable id="certificates">证书要求</lable>
              <span><input v-model="form_new.certificates" type="text" placeholder="请输入证书要求"></span>
            </div>

          </form>
          <div slot="footer" class="dialog-footer">
            <el-button class="elbtn" @click="dialogFormVisible1 = false">取 消</el-button>

            <el-button class="elbtn" type="primary" @click="submit_new()">提 交</el-button>
<!--            <el-button class="elbtn" :plain="true" type="primary" @click="submit_new()">提 交</el-button>-->
          </div>
        </el-dialog>
      </div>
    </div>
    <div v-if="active==1" class="big1">
<!--      <i class="el-icon-back" style="display: inline-block;font-size: 40px;float:left;margin-top: 20px;margin-left: 20px" @click="go_back()" />-->
      <i class="el-icon-back" style="display: inline-block;font-size: 40px;float:left;margin-top: 40px;margin-left: 80px" @click="go_back()" />
      <div class="info">
        <div class="one">
<!--          <div class="zhongwenjianli">岗位信息</div>-->
        </div>
        <div class="two">
          <div class="sinfo">
            <div v-if="item.job_name.length>11" class="name">{{ item.job_name.slice(0,8) }}...</div>
            <div v-if="item.job_name.length<=11" class="name">{{ item.job_name }}</div>
            <div  class="salary">{{ item.salary }}</div>
            <div class="sinfos">
              <i v-if="item.major_post.length>0" class="mar_left el-icon-star-on" /><span>{{ item.major_post }}</span>
              <i v-if="item.edu_require_post.length>0" class="mar_left el-icon-s-cooperation" /><span>{{ item.edu_require_post }}</span>
              <i v-if="item.gender.length>0" class="mar_left el-icon-s-tools" /><span>{{ item.gender }}</span>
              <i v-if="item.age.length>0" class="mar_left el-icon-s-opportunity" /><span>{{ item.age }}</span>
              <i v-if="item.address.length>0" class="el-icon-location" /><span>{{ item.address }}</span>
            </div>
          </div>
        </div>
        <hr class="fenjiexian">
        <div v-if="item.num_hire.toString().length>0 || item.job_function.length>0 || item.job_name.length>0" class="title_box">
          <div class="_title "> <img style="height: 35px;" src="../positionManage/ico/33.png"> 岗位描述</div>
          <div class="_title_down" />
        </div>
        <div class="thr">
          <ul>
            <li style="position: relative"  v-if="item.job_name.length>0"><span style="position: absolute"  class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px"> 岗位名称：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;"><span style="display: block" >{{ item.job_name }}</span></div></li>
            <li style="position: relative"  v-if="item.job_function.length>0"><span style="position: absolute"  class="dian">●</span><span style="color: #9198a5;position: absolute;left: 18px"> 工作职能：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;"><span style="display: block;margin-bottom: 10px" v-for="i in item.job_function">{{ i }}</span></div></li>
            <li v-if="item.num_hire.toString().length>0"><span class="dian">●</span> 招聘人数：<span>{{ item.num_hire }}</span></li>
          </ul>
        </div>
        <div v-if="item.gender.length>0 || item.age.length>0 || item.school_level.length>0 || item.major_post.length>0 ||
         item.edu_require_post.length>0 || item.language_post.length>0 || item.prof_skill_post.length>0 ||
         item.soft_post.length>0 || item.management_requirement.length>0 || item.professional_requirement.length>0 ||
         item.industry_requirement.length>0 || item.certificates.length>0 || item.experience_post.length>0 || item.job_requirement.length>0" class="title_box">
          <div class="_title "> <img style="height: 35px;" src="../positionManage/ico/22.png"> 岗位要求</div>
          <div class="_title_down" />
        </div>
        <div class="four">
            <ul>
              <li v-if="item.gender.length>0"><span class="dian">●</span> 性别要求：<span>{{ item.gender }}</span></li>
              <li v-if="item.age.length>0"><span class="dian">●</span> 年龄要求：<span>{{ item.age }}</span></li>
              <li v-if="item.school_level.length>0"><span class="dian">●</span> 学校等级要求：<span>{{ item.school_level }}</span></li>
            </ul>
            <ul>
              <li v-if="item.major_post.length>0"><span class="dian">●</span> 专业要求：<span>{{ item.major_post }}</span></li>
              <li v-if="item.edu_require_post.length>0"><span class="dian">●</span> 学位要求：<span>{{ item.edu_require_post }}</span></li>
              <li v-if="item.language_post.length>0"><span class="dian">●</span> 语言技能要求：<span>{{ item.language_post }}</span></li>
            </ul>
          <ul>
            <li style="position: relative" v-if="item.prof_skill_post.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">专业技能要求：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 140px">{{ item.prof_skill_post }}</div></li>
            <li style="position: relative" v-if="item.soft_post.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">软性技能要求：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 140px">{{ item.soft_post }}</div></li>
            <li style="position: relative" v-if="item.management_requirement.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">管理能力要求：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 140px">{{ item.management_requirement }}</div></li>
            <li style="position: relative" v-if="item.professional_requirement.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">职能经验要求：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 140px">{{ item.professional_requirement }}</div></li>
            <li style="position: relative" v-if="item.industry_requirement.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">行业经验要求：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 140px">{{ item.industry_requirement }}</div></li>
            <li style="position: relative" v-if="item.certificates.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">证书要求：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px">{{ item.certificates }}</div></li>
            <li style="position: relative" v-if="item.experience_post.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">工作经验要求：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 140px">{{ item.experience_post }}</div></li>
            <li style="position: relative" v-if="item.job_requirement.length>0"><span style="position: absolute" class="dian">●</span>  <span style="color: #9198a5;position: absolute;left: 18px">工作需求：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;"><span style="display: block;margin-bottom: 10px"  v-for="i in item.job_requirement">{{ i }}</span></div></li>
          </ul>
        </div>
        <div v-if="item.salary.length>0 || item.benefit.length>0" class="title_box">
          <div class="_title"><img style="height: 30px;" src="../positionManage/ico/11.png"> 福利待遇</div>
          <div class="_title_down" />
        </div>
        <div class="five">
          <ul>
            <li style="position: relative" v-if="item.salary.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">工资：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 70px">{{ item.salary }}</div></li>
            <li style="position: relative" v-if="item.benefit.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">福利待遇：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px">{{ item.benefit }}</div></li>
          </ul>
        </div>
        <div v-if="item.company_name.length>0 || item.company_industry.length>0 || item.department.length>0 || item.address.length>0 || item.phone.length>0 || item.email.length>0 || item.company_intro.length>0" class="title_box">
          <div class="_title "><img style="height: 30px;" src="../positionManage/ico/会议.png"> 公司介绍</div>
          <div class="_title_down" />
        </div>
        <div class="six">
          <ul>
            <li style="position: relative" v-if="item.company_name.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">公司名称：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px">{{ item.company_name }}</div></li>
            <li style="position: relative" v-if="item.company_industry.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">公司行业：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px">{{ item.company_industry }}</div></li>
            <li style="position: relative" v-if="item.department.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">招聘部门：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px">{{ item.department }}</div></li>
            <li style="position: relative" v-if="item.address.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">公司位置：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px">{{ item.address }}</div></li>
            <li style="position: relative" v-if="item.phone.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">联系电话：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px">{{ item.phone }}</div></li>
            <li style="position: relative" v-if="item.email.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">联系邮箱：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px">{{ item.email }}</div></li>
            <li style="position: relative" v-if="item.company_intro.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">公司描述：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px">{{ item.company_intro }}</div></li>
          </ul>
        </div>
        <div class="teil" style="text-align: right">
          <el-button type="primary" size="mini" @click="mod_btn()"><i class="el-icon-edit" />修改</el-button>
          <el-button type="danger" size="mini" @click="del()"><i class="el-icon-delete" />删除</el-button>

        </div>
      </div>
<!--      <div style="text-align: left">-->
<!--        <el-dialog title="重要提示" :visible.sync="isdel">-->
<!--          <div style="color: red">是否确定要删除这个岗位？</div>-->
<!--          <div slot="footer" class="dialog-footer">-->
<!--            <el-button @click="isdel = false">取 消</el-button>-->
<!--            <el-button type="primary" @click="del()">确 定</el-button>-->
<!--          </div>-->
<!--        </el-dialog>-->
<!--      </div>-->
      <div class="xiugai" style="width: 80%;">
        <el-dialog title="修改信息" :visible.sync="big1_dialogFormVisible">
          <form ref="item_mod" action="">
            <div style="text-align: center">
<!--              看这里  岗位修改和新增的id是一样的  为什么么有报错   不重要，能跑就行   -->
              <div>
                <lable id="job_name"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>岗位名称</lable>
                <span><input v-model="item_mod.job_name" type="text" placeholder="请输入岗位名称"></span>
              </div>
              <div>
                <lable id="job_function">工作职能</lable>
                <span><input v-model="item_mod.job_function" type="text" placeholder="请输入工作职能"></span>
              </div>
              <div>
                <lable id="job_requirement">岗位要求</lable>
                <span><input v-model="item_mod.job_requirement" type="text" placeholder="请输入岗位要求"></span>
              </div>
              <div>
                <lable id="num_hire">招聘人数</lable>
                <span><input v-model="item_mod.num_hire" type="text" placeholder="请输入招聘人数"></span>
              </div>
              <div>
                <lable id="company_name">公司名称</lable>
                <span><input v-model="item_mod.company_name" type="text" placeholder="请输入公司名称"></span>
              </div>
              <div>
                <lable id="company_industry">公司行业</lable>
                <span><input v-model="item_mod.company_industry" type="text" placeholder="请输入公司行业"></span>
              </div>
              <div>
                <lable id="department">招聘部门</lable>
                <span><input v-model="item_mod.department" type="text" placeholder="请输入招聘部门"></span>
              </div>
              <div>
                <lable id="address">公司位置</lable>
                <span><input v-model="item_mod.address" type="text" placeholder="请输入公司位置"></span>
              </div>
              <div>
                <lable id="phone">联系电话</lable>
                <span><input v-model="item_mod.phone" type="text" placeholder="请输入联系电话"></span>
              </div>
              <div>
                <lable id="email">联系邮箱</lable>
                <span><input v-model="item_mod.email" type="text" placeholder="请输入联系邮箱"></span>
              </div>
              <div>
                <lable id="salary">工资水平</lable>
                <span><input v-model="item_mod.salary" type="text" placeholder="请输入工资水平"></span>
              </div>
              <div>
                <lable id="benefit">福利待遇</lable>
                <span><input v-model="item_mod.benefit" type="text" placeholder="请输入福利待遇"></span>
              </div>
              <div>
                <lable id="company_intro">公司描述</lable>
                <span><input v-model="item_mod.company_intro" type="text" placeholder="请输入公司描述"></span>
              </div>
              <div>
                <lable id="experience_post">工作经验</lable>
                <span><input v-model="item_mod.experience_post" type="text" placeholder="请输入工作经验"></span>
              </div>
              <div>
                <lable id="gender">性别要求</lable>
                <span><input v-model="item_mod.gender" type="text" placeholder="请输入性别要求"></span>
              </div>
              <div>
                <lable id="age">年龄要求</lable>
                <span><input v-model="item_mod.age" type="text" placeholder="请输入年龄要求"></span>
              </div>
              <div>
                <lable id="major_post">专业要求</lable>
                <span><input v-model="item_mod.major_post" type="text" placeholder="请输入专业要求"></span>
              </div>
              <div>
                <lable id="edu_require_post">学位要求</lable>
                <span><input v-model="item_mod.edu_require_post" type="text" placeholder="请输入学位要求"></span>
              </div>
              <div>
                <lable id="school_level">学校等级要求</lable>
                <span><input v-model="item_mod.school_level" type="text" placeholder="请输入学校等级要求"></span>
              </div>
              <div>
                <lable id="language_post">语言技能要求</lable>
                <span><input v-model="item_mod.language_post" type="text" placeholder="请输入语言技能要求"></span>
              </div>
              <div>
                <lable id="prof_skill_post">专业技能要求</lable>
                <span><input v-model="item_mod.prof_skill_post" type="text" placeholder="请输入专业技能要求"></span>
              </div>
              <div>
                <lable id="soft_post">软性技能要求</lable>
                <span><input v-model="item_mod.soft_post" type="text" placeholder="请输入软性技能要求"></span>
              </div>
              <div>
                <lable id="management_requirement">管理能力要求</lable>
                <span><input v-model="item_mod.management_requirement" type="text" placeholder="请输入管理能力要求"></span>
              </div>
              <div>
                <lable id="professional_requirement">职能经验要求</lable>
                <span><input v-model="item_mod.professional_requirement" type="text" placeholder="请输入职能经验要求"></span>
              </div>
              <div>
                <lable id="industry_requirement">行业经验要求</lable>
                <span><input v-model="item_mod.industry_requirement" type="text" placeholder="请输入行业经验要求"></span>
              </div>
              <div>
                <lable id="certificates">证书要求</lable>
                <span><input v-model="item_mod.certificates" type="text" placeholder="请输入证书要求"></span>
              </div>
            </div>
          </form>
          <div slot="footer" class="dialog-footer">
            <el-button type="danger" size="mini" icon="el-icon-close" @click="big1_dialogFormVisible = false">取消</el-button>
            <el-button type="primary" size="mini" icon="el-icon-check" @click="submit_mod()">提交</el-button>
          </div>
        </el-dialog>
      </div>
    </div>
  </div>
</template>

<style scoped>
#dr {
  /*width: 200px !important;*/
}
.xiangdui .xuanze {
  /*text-align: left !important;*/
  position: relative;
  left: 30px;
  top: 15px;
  display: inline-block;
  /*background-color: #ffe4e4;*/
}
.xiangdui .fuxuankuang{
  text-align: left !important;
  position: relative;
  left: 35px;
  top: 20px;
  display: inline-block;
  /*background-color: #ffe4e4;*/
}
.xiangdui .danxuankuang {
  text-align: left !important;
  position: relative;
  left: 10px;
  /*top: 20px;*/
  display: inline-block;
  /*background-color: #ffe4e4;*/
}
.fuxuankuang div  {
  width: 200px;
  /*background-color: #ec0a0a;*/
  text-align: left !important;
  position: relative;
  left: 20px;
  /*margin-top: 5px;*/
  margin-bottom: 0px !important;
}
.xiangdui .hangye{
  display: inline-block;
  position: absolute;
  top: 20px;
  left: 60px;
  /*background-color: #ffd5d5;*/
}
.xiangdui .didian{
  display: inline-block;
  position: absolute;
  top: 20px;
  left: 60px;
  /*background-color: #ffd5d5;*/
}
.xiangdui .shijian{
   display: inline-block;
   position: absolute;
   left: 62px;
   /*background-color: #ffd5d5;*/
 }
.xiangdui {
  font-size: large;
  position: relative;
  width: 400px;
  margin: 0px auto;
  /*height: 100px;*/
  /*background-color: #cae7fc;*/

}
.big1 lable{
  /*background-color: #c25959;*/
  font-size: inherit;
  width:90px;
  display: inline-block;
  text-align: right;
  margin: 10px 20px;
}
.big1 .xiugai {
  width: 80%;
}
.big1 .xiugai span input{
  font-size: small;
  width: 100%;
  height: 32px;
  line-height: 30px;
  color: gray;
}
.big1 .xiugai span{
  /*background-color: #aa1111;*/
  width: 60%;
  /*font-size: 27px;*/
  display: inline-block;
}
.big1 .xiugai .elbtn{
  width: 70px;
  height: 40px;
  font-size: small;
}
.big1 .teil .mod{
  text-align: center;
  line-height: 50px;
  font-style: italic;
  font-size: small;
  float: right;
  width: 100px;
  height: 50px;
  /*background-color: #ffb8b8;*/
  display: inline-block;
}
.big1 .teil .del{
  text-align: center;
  line-height: 50px;
  font-style: italic;
  font-size: small;
  float: right;
  width: 100px;
  height: 50px;
  /*background-color: #cb3535;*/
  display: inline-block;
}
.big1 .teil{
  width: 90%;
  height: 100px;
  margin: 30px auto;
  /*background-color: #6366ff;*/
}
.big1 .six{
  width: 90%;
  /*height: 330px;*/
  margin: 30px auto;
  margin-top: 20px;
  /*background-color: #6366ff;*/
}
.big1 .five{
  width: 90%;
  /*height: 250px;*/
  margin: 0px auto;
  margin-top: 20px;
  /*background-color: #efff63;*/
}
.big1 .four{
  width: 90%;
  margin: 0px auto;
  margin-top: 20px;
  /*margin-bottom: 90px;*/
  /*background-color: #ffac63;*/
}
.big1 .thr{
  width: 90%;
  margin: 0px auto;
  margin-top: 10px;
  /*background-color: #f88eff;*/
}
.big1 .title_box{
  position: relative;
  margin-top: 10px;
  width: 100%;
  height: 70px;
  /*background-color: #af3f3f;*/
}
.big1 ._title_down{
  /*底色  设置长、宽、背景色*/
  width: 150px;
  height: 40px;
  /*background-color: #e7ecfb;*/
  position: absolute;
  left: 60px;
  top: 25px;
}
.big1 ._title{
  /*文字  设置长、宽、字号、粗细、最上方显示*/
  z-index: 999;
  width: 200px;
  height: 60px;
  font-size: xx-large;
  font-weight: normal;
  position: absolute;
  left: 40px;
  top: 10px;
}

.big1 ul{
  /*margin: 130px 30px;*/
  list-style-type: none;
}
.big1 ul li{
  font-size: large;
  margin-top: 25px;
  color: #9198a5;
}
.big1 li .dian{
  color: #6873e5;
}
.big1 li span{
  color: #494949;
}
.big1 div .left{
  width: 50%;
  /*height: 100%;*/
  display: inline-block;
  float: left;
  /*background-color: #ff8b8b;*/
}
.big1 div .right{
  width: 50%;
  /*height: 100%;*/
  display: inline-block;
  float: right;
  /*background-color: #e5d98c;*/
}
.big1 .fenjiexian {
  border: black;
  padding: 3px;
  background: repeating-linear-gradient(135deg, #d0d0d0 0px, #09090a 1px, transparent 1px, transparent 6px);
}
.big1 .two{
  width: 90%;
  height: 130px;
  margin: 20px auto;
  /*background-color: #8aff63;*/
}
.big1 .two .sinfo{
  width: 95%;
  height: 100%;
  margin: 0px auto;
  /*background-color: #e27070;*/
}
.big1 .two .salary{
  display: inline-block;
  height: 70px;
  width: 30%;
  /*margin-top: 30px;*/
  font-size: xx-large;
  font-weight: bold;
  line-height: 70px;
  text-align: left;
  color: #f26e4a;
  /*background-color: #b38787;*/
  float: right;
  /*margin-right: 19%;*/
}
.big1 .two .name{
  width: 50%;
  display: inline-block;
  height: 70px;
  /*margin-top: 30px;*/
  /*margin-right: 50px;*/
  font-size: 35px;
  font-weight: bolder;
  line-height: 70px;
  text-align: left;
  overflow:hidden;
  /*background-color: #ea5454;*/
  float: left;
}
.big1 .two .sinfos{
  padding-top: 80px;
  /*margin-top: 120px;*/
  height: 50px;
  font-size: larger;
  color: #8a919f;
  /*background-color: #ffefef;*/
}
.big1 i {
  margin-right: 10px;
}
.big1 .mar_left{
  margin-left: 20px;
}
.big1 .one{
  width: 90%;
  height: 40px;
  margin: 0px auto;
  margin-top: 30px;
  /*background-color: #e3e3e3;*/
}
.big1 .one .zhongwenjianli{
  width: 70px;
  height: 40px;
  line-height: 35px;
  text-align: center;
  color: #3155eb;
  border-style: solid;
  border-width: medium;
  border-color: #aec6ff;
  border-radius: 10px;
  font-size: small;
  /*background-color: #f0f5ff;*/
}
/*.big1 .info{*/
/*  width: 80%;*/
/*  height: 95%;*/
/*  overflow: auto;*/
/*  position: absolute;*/
/*  left: 10%;*/
/*  background-color: #ffffff;*/
/*  margin-top: 20px;*/
/*  -webkit-box-shadow: #666 0px 0px 50px;*/
/*  -moz-box-shadow: #666 0px 0px 50px;*/
/*  box-shadow: #666 0px 0px 20px;*/
/*}*/

.big1 .info{
  width: 60%;
  height: 95%;
  overflow: auto;
  position: absolute;
  top: 0;left:0;right:0;bottom:0;
  margin: auto;
  background-color: #ffffff;
  -webkit-box-shadow: #666 0px 0px 50px;
  -moz-box-shadow: #666 0px 0px 50px;
  box-shadow: #666 0px 0px 20px;
}


.big form div{
  margin-bottom: 10px;
  text-align: center;
}
.big lable span{
  margin-right: 5px !important;
}
.big lable{
  /*background-color: #c25959;*/
  font-size: inherit;
  width: 100px;
  display: inline-block;
  text-align: right;
  margin-right: 10px;
  /*margin: 10px 20px;*/
}
.big .dia {
  width: 80%;
}
.big .dia span input{
  font-size: small;
  width: 100%;
  height: 32px;
  line-height: 30px;
  color: gray;
}
.big .dia span{
  /*background-color: #aa1111;*/
  width: 60%;
  /*font-size: 27px;*/
  display: inline-block;
}
.big .dia .elbtn{
  padding: 0!important;
  width: 70px;
  height: 40px;
  text-align: center;
  font-size: small;
}
.big #extract {
  border-radius: 5px;
  box-shadow: 0 2px 6px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
}

</style>

<script>
import axios from 'axios'
import Global from '../../global/global'
import { CodeToText, provinceAndCityDataPlus } from 'element-china-area-data'
var industry_options = ['医学', '互联网', '销售', '金融', '管理', '设计', '教育', '其他']
export default {
  inject: ['reload'], // 注入刷新页面的依赖
  data() {
    return {
      chars:',.;:，。；：、',
      // 时间范围
      time_frame: '',
      // 所有地点信息
      options: provinceAndCityDataPlus,
      // 选择的地点信息
      selectedOptions: '',
      // 行业复选框
      checkAll: false,
      // 选择的复选框内容
      selected_industry: [],
      // 所有的行业
      select_industry: industry_options,
      // 不知道是什么属性
      isIndeterminate: true,
      // 抽屉取消提示的可见性
      centerDialogVisible: false,
      // 抽屉的可见性
      drawer: false,
      // 抽屉的方向
      direction: 'rtl',
      conn: Global.data().conn,
      // 确认删除的可见性
      isdel: false,
      active: 0,
      // 修改新的弹窗的可见性
      big1_dialogFormVisible: false,
      dialogFormVisible: false,
      dialogFormVisible1: false,
      txt: '',
      // 详情界面显示的信息
      item: {
        id: 200,
        job_name: '软件工程师（配合前端进行调试软件）',
        job_function: '1.负责产品上线前后的线上、线下的运营方案和推广工作，协助项目负责人对接市场、产品开发等，完成个项目目标；2.负责产品运营中与线下的各种合作，配合完成商务推广，实施项目评估和监控，提升用户活跃度和忠诚度；3.负责研究行业竞争动态，定期拜访客户，维护重要客户关系发现客户的需求，引导客户的业务需求，根据自身产品制定产品营销策略，达成既定目标；4.负责分析和挖掘产品运营数据、用户行为数据等重要价值信息5.负责跟进和整理产品用户反馈，协同产品经理提出产品迭代方案。',
        company_name: '未知的王妃科技有限公司',
        company_intro: '专门负责外包项目的一个公司，帮别的公司做项目。做好事不留名，足足有一百年的历史了，是个家族企业。全部的ceo都是活雷锋',
        company_industry: '互联网',
        department: '技术部',
        num_hire: '100',
        address: '山东青岛',
        major_post: '计算机相关专业',
        edu_require_post: '大专及以上',
        language_post: '中文、英语',
        soft_post: '唱歌跳舞',
        experience_post: '最好有相关经验',
        prof_skill_post:'java',
        school_level: '学校即可，无特殊要求',
        certificates: '英语四级',
        gender: '无性别要求',
        age: '18岁以上，45岁以下',
        management_requirement: '最好有相关经验',
        professional_requirement: '最好有项目经验',
        industry_requirement: '近三年最好从事相关行业',
        salary: '工资面议',
        benefit: '五险一金',
        email: '1225444444@qq.com',
        phone: '17860355555',
        publish_time: '2023.6.6',
        job_requirement: '1、需要具备良好的身体条件；2、有良好的心理承受能力；3、能接受加班；能接受调休'

      },
      // 修改的对象
      item_mod: {},
      // 新增的对象
      form_new: {
        id: '',
        job_name: '',
        job_function: '',
        company_name: '',
        company_intro: '',
        company_industry: '',
        department: '',
        num_hire: '',
        address: '',
        major_post: '',
        edu_require_post: '',
        language_post: '',
        soft_post: '',
        experience_post: '',
        prof_skill_post: '',
        school_level: '',
        certificates: '',
        gender: '',
        age: '',
        management_requirement: '',
        professional_requirement: '',
        industry_requirement: '',
        salary: '',
        benefit: '',
        email: '',
        phone: '',
        publish_time: '',
        job_requirement: ''
      },
      mod_justnow: false,
      // 当前界面显示的全部岗位信息
      job_info: [],
      // 从狗端获得的全部信息
      all_job_info: [],
      // 当前界面页数
      currentPage: 1,
      // 总页数
      total: 0,
      // 页面条数的选择
      pageSizes: [5, 10, 20],
      // 当前界面条数
      PageSize: 5,
      // 地点信息变成中文字符串
      big_city: '',
      small_city: ''
    }
  },
  created() {
    // this.chuli_job_function()
    // this.chuli_job_requirement()
    // // this.item.job_function = this.item.job_function==''? '': this.item.job_function.split('；')
    // // this.item.job_requirement = this.item.job_requirement.split('；')
    this.getInfo()
  },
  methods: {
    // 添加一个分号
    add_fenhao(str){
      console.log('；；；添加分号接受到的字符串是：：',str)
      var char = str.substring(str.length-1)
      if (this.chars.indexOf(char)==-1){
        // 最后一个字符不是 标点符号    -----  添加一个分号
        str = str+'；'
      }else {
        //  最后一个字符是标点符号
        str = str.substring(0,str.length-1)
        str = str+'；'
      }
      console.log('添加完变成了：：',str)
      return str
    },
    // 添加一个分号
    add_juhao(str){
      console.log('。。。添加句号接受到的字符串是：：',str)
      var char = str.substring(str.length-1)
      if (this.chars.indexOf(char)==-1){
        // 最后一个字符不是 标点符号    -----  添加一个分号
        str = str+'。'
      }else {
        //  最后一个字符是标点符号
        str = str.substring(0,str.length-1)
        str = str+'。'
      }
      console.log('添加完变成了：：',str)
      return str
    },
    // 将job_functioc处理成列表
    chuli_str_to_list(str){
      var jieguo = []
      var temp = []
      if (str==''){
        console.log("是空字符串，不用处理,,fanhuizhiwei ",jieguo)
      }else {
        console.log('一开始的字符串为：：',str)
        for (var i = 2; i <= 20 ; i++) {
          if (str.indexOf(','+i)!=-1){
            temp =  str.split(','+i)
          }else if (str.indexOf('。'+i)!=-1){
            temp =  str.split('。'+i)
          }else if (str.indexOf('；'+i)!=-1){
            temp =  str.split('；'+i)
          }else if (str.indexOf(';'+i)!=-1){
            temp =  str.split(';'+i)
          }else if (str.indexOf(i+'.')!=-1){
            temp =  str.split(i+'.')
            temp[1] = '.'+temp[1]
          }else if (str.indexOf(i+'、')!=-1){
            temp =  str.split(i+'、')
            temp[1] = '、'+temp[1]
          }else {
            temp =  str.split(i)
          }

          // console.log(temp)
          if (temp.length==2){
            //  正好被分成两个
            jieguo.push(this.add_fenhao(temp[0]))
            str = i + temp[1]
          }else if (temp.length==1){
            str = temp[0]
          }
          if (i==20){
            jieguo.push(this.add_juhao(temp[0]))
          }
        }
        console.log(jieguo)
      }
      return jieguo
    },
    // // 将job_functioc处理成列表
    // chuli_job_function(){
    //   if (this.item.job_function==''){
    //     console.log("job_function是空字符串，不用处理")
    //   }else {
    //     var str = this.item.job_function
    //     console.log('一开始的字符串为：：',str)
    //     var jieguo = []
    //     for (var i = 2; i <= 20 ; i++) {
    //       var temp = []
    //       if (str.indexOf(','+i)!=-1){
    //         temp =  str.split(','+i)
    //       }else if (str.indexOf('。'+i)!=-1){
    //         temp =  str.split('。'+i)
    //       }else if (str.indexOf('；'+i)!=-1){
    //         temp =  str.split('；'+i)
    //       }else if (str.indexOf(';'+i)!=-1){
    //         temp =  str.split(';'+i)
    //       }else if (str.indexOf(i+'.')!=-1){
    //         temp =  str.split(i+'.')
    //         temp[1] = '.'+temp[1]
    //       }else if (str.indexOf(i+'、')!=-1){
    //         temp =  str.split(i+'、')
    //         temp[1] = '、'+temp[1]
    //       }else {
    //         temp =  str.split(i)
    //       }
    //
    //       // console.log(temp)
    //       if (temp.length==2){
    //         //  正好被分成两个
    //         jieguo.push(this.add_fenhao(temp[0]))
    //         // jieguo.push(temp[0])
    //         str = i + temp[1]
    //       }else if (temp.length==1){
    //         str = temp[0]
    //       }
    //       if (i==20){
    //         jieguo.push(this.add_juhao(temp[0]))
    //       }
    //     }
    //     console.log(jieguo)
    //     this.item.job_function = jieguo
    //   }
    // },



    // 将job_requirement处理成列表
    // chuli_job_requirement(){
    //   if (this.item.job_requirement==''){
    //     console.log("job_requirement是空字符串，不用处理")
    //   }else {
    //     var str = this.item.job_requirement
    //     console.log('一开始的字符串为：：',str)
    //     var jieguo = []
    //     for (var i = 2; i <= 20 ; i++) {
    //       var temp = []
    //       if (str.indexOf(','+i)!=-1){
    //         temp =  str.split(','+i)
    //       }else if (str.indexOf('。'+i)!=-1){
    //         temp =  str.split('。'+i)
    //       }else if (str.indexOf('；'+i)!=-1){
    //         temp =  str.split('；'+i)
    //       }else if (str.indexOf(';'+i)!=-1){
    //         temp =  str.split(';'+i)
    //       }else if (str.indexOf(i+'.')!=-1){
    //         temp =  str.split(i+'.')
    //         temp[1] = '.'+temp[1]
    //       }else if (str.indexOf(i+'、')!=-1){
    //         temp =  str.split(i+'、')
    //         temp[1] = '、'+temp[1]
    //       }else {
    //         temp =  str.split(i)
    //       }
    //
    //       // console.log(temp)
    //       if (temp.length==2){
    //         //  正好被分成两个
    //         jieguo.push(this.add_fenhao(temp[0]))
    //         // jieguo.push(temp[0])
    //         str = i + temp[1]
    //       }else if (temp.length==1){
    //         str = temp[0]
    //       }
    //       if (i==20){
    //         jieguo.push(this.add_juhao(temp[0]))
    //       }
    //     }
    //     console.log(jieguo)
    //     this.item.job_requirement = jieguo
    //   }
    // },



    // 清除新增界面的全部信息
    clean_form_new() {
      console.log('现在将新增的对象信息置为空')
      this.form_new.id = ''
      this.form_new.job_name = ''
      this.form_new.job_function = ''
      this.form_new.company_name = ''
      this.form_new.company_intro = ''
      this.form_new.company_industry = ''
      this.form_new.department = ''
      this.form_new.num_hire = ''
      this.form_new.address = ''
      this.form_new.major_post = ''
      this.form_new.edu_require_post = ''
      this.form_new.language_post = ''
      this.form_new.soft_post = ''
      this.form_new.experience_post = ''
      this.form_new.prof_skill_post = ''
      this.form_new.school_level = ''
      this.form_new.certificates = ''
      this.form_new.gender = ''
      this.form_new.age = ''
      this.form_new.management_requirement = ''
      this.form_new.professional_requirement = ''
      this.form_new.industry_requirement = ''
      this.form_new.salary = ''
      this.form_new.benefit = ''
      this.form_new.email = ''
      this.form_new.phone = ''
      this.form_new.publish_time = ''
      this.form_new.job_requirement = ''
    },
    // 清除筛选界面的全部信息
    clean_() {
      console.log('现在将筛选信息置为空')
      this.selected_industry = []
      this.selectedOptions = ''
      this.big_city = ''
      this.small_city = ''
      this.time_frame = ''
      this.checkAll = false
      this.isIndeterminate = true
    },
    // 全选的方法
    handleCheckAllChange(val) {
      this.selected_industry = val ? industry_options : []
      this.isIndeterminate = false
    },
    handleCheckedCitiesChange(value) {
      // console.log(value)
      var checkedCount = value.length
      this.checkAll = checkedCount === this.select_industry.length
      this.isIndeterminate = checkedCount > 0 && checkedCount < this.select_industry.length
    },
    // 选择地点
    handleChange(value) {
      this.big_city = CodeToText[value[0]]
      this.small_city = CodeToText[value[1]] ? CodeToText[value[1]] : ''
      // console.log(this.small_city.slice(this.small_city.length - 1, this.small_city.length))
      if (this.small_city.length > 1 && this.small_city.slice(this.small_city.length - 1, this.small_city.length) === '市') {
        this.small_city = this.small_city.substring(0, this.small_city.length - 1)
      }
      if (this.big_city.length > 1 && this.big_city.slice(this.big_city.length - 1, this.big_city.length) === '市') {
        this.big_city = this.big_city.substring(0, this.big_city.length - 1)
      }
      if (this.big_city.length > 1 && this.big_city.slice(this.big_city.length - 1, this.big_city.length) === '省') {
        this.big_city = this.big_city.substring(0, this.big_city.length - 1)
      }
      // console.log(this.big_city.slice(this.big_city.length - 5, this.big_city.length))
      if (this.big_city.length > 4 && this.big_city.slice(this.big_city.length - 3, this.big_city.length) === '自治区') {
        this.big_city = this.big_city.substring(0, this.big_city.length - 3)
      }
      if (this.big_city.length > 6 && this.big_city.slice(this.big_city.length - 5, this.big_city.length) === '特别行政区') {
        this.big_city = this.big_city.substring(0, this.big_city.length - 5)
      }
    },
    // 抽屉关闭提示
    handleClose() {
      this.centerDialogVisible = true
    },
    re_get_data() {
      console.log('一个神奇的函数')
      console.log('当前全部的对象的id列表为：')
      console.log(this.id_list)
      var data = new FormData()
      var that = this
      var table = []
      data.append('ids', this.id_list)
      axios.post(this.conn + '/reload_job', data).then(function(res) {
        console.log('修改信息之后重新获取信息的返回值为：')
        console.log(res)
        if (res.data === null){
          that.allData=[]
          that.total = 0
          that.fenye()
          console.log('返回值为null')
          that.$message.error('当前用户没有可用信息！')
          return
        }
        if (res.status === 200) {
          for (var i = 0; i < res.data.length; i++) {
            for (var j = 0; j < res.data[i].length; j++) {
              if (res.data[i][j] == null || res.data[i][j] === 'undefined') {
                res.data[i][j] = ''
              }
            }
            var this_data = new Date(res.data[i][26])
            var year = this_data.getFullYear()
            var mon = this_data.getMonth() + 1
            var day = this_data.getDate()
            var str = year + '-' + mon + '-' + day
            table.push({
              id: res.data[i][0],
              job_name: res.data[i][1],
              job_function: res.data[i][2],
              company_name: res.data[i][3].length>0? res.data[i][3] : '未知',
              company_intro: res.data[i][4],
              company_industry: res.data[i][5],
              department: res.data[i][6],
              num_hire: res.data[i][7],
              address: res.data[i][8].length>0 ? res.data[i][8] : '未知',
              major_post: res.data[i][9],
              edu_require_post: res.data[i][10],
              language_post: res.data[i][11],
              soft_post: res.data[i][12],
              experience_post: res.data[i][13],
              prof_skill_post: res.data[i][14],
              school_level: res.data[i][15],
              certificates: res.data[i][16],
              gender: res.data[i][17],
              age: res.data[i][18],
              management_requirement: res.data[i][19],
              professional_requirement: res.data[i][20],
              industry_requirement: res.data[i][21],
              salary: res.data[i][22].length>0 ? res.data[i][22] : '薪资面议',
              benefit: res.data[i][23],
              email: res.data[i][24],
              phone: res.data[i][25],
              publish_time: str,
              job_requirement: res.data[i][27]
            })
          }
          that.all_job_info = table
          that.total = table.length
          // if (that.total < that.PageSize) {
          //   that.PageSize = that.total
          // }
          // that.currentPage = 1
          that.fenye()
        }
      })
    },
    go_back() {
      // if (this.mod_justnow === true) {
      //   // 刚刚进行了修改操作，现在需要将原来的信息的id传到后端进行查询，然后显示最新的信息
      //   this.re_get_data()
      //   this.mod_justnow = false
      // }
      // 不管有没有修改，都重新获取数据   ---  当前页不变
      this.re_get_data()
      this.active = 0
    },
    mod_btn() {
      this.item_mod = JSON.parse(JSON.stringify(this.item))
      // for (var i in this.item) {
      //   var con = this.item[i]
      //   this.item_mod[i] = con
      // }
      if (typeof this.item_mod.job_function ==='object'){
        this.item_mod.job_function = this.item_mod.job_function.join('')
      }
      if (typeof this.item_mod.job_requirement ==='object'){
        this.item_mod.job_requirement = this.item_mod.job_requirement.join('')
      }
      this.big1_dialogFormVisible = true
    },
    // 修改信息
    // 参数: 当前对象的全部属性值
    // 返回值: 200
    // 操作: 判断成功之后将当前信息修改成新的信息
    submit_mod() {
      console.log('点击修改')
      var flag = true
      for (var i in this.item_mod) {
        if (this.item_mod[i].length === 0) {
          if (i === 'job_name') {
            flag = false
            var res = document.getElementById(i).innerText
            alert('请输入' + res)
            break
          } else {
            continue
          }
        }
      }
      if (flag) {
        // 表示所有必填选项都已经填了，可以上传信息
        var data = new FormData()
        console.log(typeof this.item_mod.job_function )
        console.log('提交的修改信息为',this.item_mod)
        var that = this
        data.append('id', this.item_mod.id)
        data.append('job_name', this.item_mod.job_name)
        data.append('job_function', this.item_mod.job_function)
        data.append('company_name', this.item_mod.company_name)
        data.append('company_intro', this.item_mod.company_intro)
        data.append('company_industry', this.item_mod.company_industry)
        data.append('department', this.item_mod.department)
        data.append('num_hire', this.item_mod.num_hire)
        data.append('address', this.item_mod.address)
        data.append('major_post', this.item_mod.major_post)
        data.append('edu_require_post', this.item_mod.edu_require_post)
        data.append('language_post', this.item_mod.language_post)
        data.append('soft_post', this.item_mod.soft_post)
        data.append('experience_post', this.item_mod.experience_post)
        data.append('prof_skill_post', this.item_mod.prof_skill_post)
        data.append('school_level', this.item_mod.school_level)
        data.append('certificates', this.item_mod.certificates)
        data.append('gender', this.item_mod.gender)
        data.append('age', this.item_mod.age)
        data.append('management_requirement', this.item_mod.management_requirement)
        data.append('professional_requirement', this.item_mod.professional_requirement)
        data.append('industry_requirement', this.item_mod.industry_requirement)
        data.append('salary', this.item_mod.salary)
        data.append('benefit', this.item_mod.benefit)
        data.append('email', this.item_mod.email)
        data.append('phone', this.item_mod.phone)
        data.append('publish_time', this.getNowDate())
        data.append('job_requirement', this.item_mod.job_requirement)
        axios.post(this.conn + '/jobUpdate', data).then(function(res) {
          console.log('修改的返回值为：')
          console.log(res)
          if (res.data === null){
            that.allData=[]
            that.total = 0
            that.fenye()
            console.log('返回值为null')
            that.$message.error('当前用户没有可用信息！')
            return
          }
          if (res.status === 200) {
            // 修改信息之后点击返回，刷新当前界面
            that.mod_justnow = true
            that.$message({
              message: '岗位修改成功！',
              type: 'success'
            })
            that.big1_dialogFormVisible = false
            that.item = that.item_mod
          //   这里调用处理数据的方法
            that.item.job_function = that.chuli_str_to_list(that.item.job_function)
            that.item.job_requirement = that.chuli_str_to_list(that.item.job_requirement)
          }
        }).catch(err => {
          that.big1_dialogFormVisible = false
          this.$message.error(err.message)
          console.log(err)
        })
      }
    },
    getNowDate() {
      const timeOne = new Date()
      const year = timeOne.getFullYear()
      let month = timeOne.getMonth() + 1
      let day = timeOne.getDate()
      month = month < 10 ? '0' + month : month
      day = day < 10 ? '0' + day : day
      const NOW_MONTHS_AGO = `${year}-${month}-${day}`
      return NOW_MONTHS_AGO
    },
    // 新增岗位信息
    // 参数: 新增信息的全部属性值
    // 返回值: 200
    // 操作: 判断新增成功刷新界面
    submit_new() {
      console.log('点击了新增表单的提交，当前提交的信息为：')
      console.log(this.form_new)
      var flag = true
      // 判断必选是不是非空
      for (var i in this.form_new) {
        // if (this.form_new[i].length === 0) {
        //   if (i === 'job_name' || i === 'job_function' || i === 'num_hire' || i === 'company_name' || i === 'company_industry' || i === 'department' || i === 'address' || i === 'phone' || i === 'email' || i === 'salary') {
        //     flag = false
        //     var res = document.getElementById(i).innerText
        //     alert('请输入' + res)
        //     break
        //   } else {
        //     continue
        //   }
        // }
        if (this.form_new[i].length === 0) {
          console.log(i)
          if (i === 'job_name') {
            flag = false
            // var res = document.getElementById(i).innerText
            alert('请输入岗位名称')
            break
          } else {
            continue
          }
        }
      }
      if (flag) {
        // 表示所有必填选项都已经填了，可以上传信息
        var data = new FormData()
        var that = this
        data.append('id', this.form_new.id)
        data.append('job_name', this.form_new.job_name)
        data.append('job_function', this.form_new.job_function)
        data.append('company_name', this.form_new.company_name)
        data.append('company_intro', this.form_new.company_intro)
        data.append('company_industry', this.form_new.company_industry)
        data.append('department', this.form_new.department)
        data.append('num_hire', this.form_new.num_hire)
        data.append('address', this.form_new.address)
        data.append('major_post', this.form_new.major_post)
        data.append('edu_require_post', this.form_new.edu_require_post)
        data.append('language_post', this.form_new.language_post)
        data.append('soft_post', this.form_new.soft_post)
        data.append('experience_post', this.form_new.experience_post)
        data.append('prof_skill_post', this.form_new.prof_skill_post)
        data.append('school_level', this.form_new.school_level)
        data.append('certificates', this.form_new.certificates)
        data.append('gender', this.form_new.gender)
        data.append('age', this.form_new.age)
        data.append('management_requirement', this.form_new.management_requirement)
        data.append('professional_requirement', this.form_new.professional_requirement)
        data.append('industry_requirement', this.form_new.industry_requirement)
        data.append('salary', this.form_new.salary)
        data.append('benefit', this.form_new.benefit)
        data.append('email', this.form_new.email)
        data.append('phone', this.form_new.phone)
        data.append('job_requirement', this.form_new.job_requirement)
        data.append('publish_time', this.getNowDate())
        axios.post(this.conn + '/save_job', data).then(function(res) {
          console.log('新增的返回值为：')
          console.log(res)
          if (res.data === null){
            that.allData=[]
            that.total = 0
            that.fenye()
            console.log('返回值为null')
            that.$message.error('当前用户没有可用信息！')
            return
          }
          if (res.status === 200) {
            that.clean_form_new()
            that.$message({
              message: '岗位新增成功！',
              type: 'success'
            })
            that.dialogFormVisible1 = false
            that.reload()
          }
        })
      }
    },
    // 按照筛选条件进行查询
    // 参数: 三个查询条件,如果不查就是空的
    // 返回值: 多条sql结果
    // 操作: 需要遍历每一条，按顺序将变量放在对象当中（获取所有数据）
    // 总条数等于alldata长度，当前显示第一页, 调用分页函数进行切分表格显示
    sousuo_tiaojianchaxun() {
      this.selected_industry = this.selected_industry.join('/')
      var data = new FormData()
      data.append('company_industry', this.selected_industry)
      data.append('big_city', this.big_city)
      data.append('small_city', this.small_city)
      data.append('publish_time', this.time_frame)
      console.log('当前提交的信息为：：')
      console.log(this.selected_industry)
      console.log(this.big_city)
      console.log(this.small_city)
      console.log(this.time_frame)
      var that = this
      var table = []
      axios.post(this.conn + '/getJobInfoBySelect', data).then(function(res) {
        console.log('筛选的返回值为：：')
        console.log(res)
        if (res.data === null){
          that.allData=[]
          that.total = 0
          that.fenye()
          console.log('返回值为null')
          that.$message.error('当前用户没有可用信息！')
          return
        }
        if (res.status === 200) {
          // 清除之前的条件
          that.clean_()
          that.pageSize = 3
          for (var i = 0; i < res.data.length; i++) {
            // 把接收到的null都变成字符串
            for (var j = 0; j < res.data[i].length; j++) {
              if (res.data[i][j] == null || res.data[i][j] === 'undefined') {
                res.data[i][j] = ''
              }
            }
            var this_data = new Date(res.data[i][26])
            var year = this_data.getFullYear()
            var mon = this_data.getMonth() + 1
            var day = this_data.getDate()
            var str = year + '-' + mon + '-' + day
            table.push({
              id: res.data[i][0],
              job_name: res.data[i][1],
              job_function: res.data[i][2],
              company_name: res.data[i][3].length>0? res.data[i][3] : '未知',
              company_intro: res.data[i][4],
              company_industry: res.data[i][5],
              department: res.data[i][6],
              num_hire: res.data[i][7],
              address: res.data[i][8].length>0 ? res.data[i][8] : '未知',
              major_post: res.data[i][9],
              edu_require_post: res.data[i][10],
              language_post: res.data[i][11],
              soft_post: res.data[i][12],
              experience_post: res.data[i][13],
              prof_skill_post: res.data[i][14],
              school_level: res.data[i][15],
              certificates: res.data[i][16],
              gender: res.data[i][17],
              age: res.data[i][18],
              management_requirement: res.data[i][19],
              professional_requirement: res.data[i][20],
              industry_requirement: res.data[i][21],
              salary: res.data[i][22].length>0 ? res.data[i][22] : '薪资面议',
              benefit: res.data[i][23],
              email: res.data[i][24],
              phone: res.data[i][25],
              publish_time: str,
              job_requirement: res.data[i][27]
            })
          }
          that.centerDialogVisible = false
          that.drawer = false
          that.all_job_info = table
          that.total = table.length
          // if (that.total < that.PageSize) {
          //   that.PageSize = that.total
          // }
          that.currentPage = 1
          that.fenye()
        }
      })
    },
    // 按照关键词进行查询
    // 参数: 用户输入的关键词
    // 返回值: 多条sql结果
    // 操作: 需要遍历每一条，按顺序将变量放在对象当中（获取所有数据）
    // 总条数等于alldata长度，当前显示第一页, 调用分页函数进行切分表格显示
    sousuo_mohuchaxun() {
      console.log('当前正在进行关键词查询，关键词为：')
      console.log(this.txt)
      var data = new FormData()
      data.append('keyword', this.txt)
      var that = this
      var table = []
      // 地址  根据关键词查询
      axios.post(this.conn + '/getJobInfoByKeyword', data).then(function(res) {
        console.log('关键词查询的返回值为：：')
        console.log(res)
        if (res.data === null){
          that.allData=[]
          that.total = 0
          that.fenye()
          console.log('返回值为null')
          that.$message.error('当前用户没有可用信息！')
          return
        }
        if (res.status === 200) {
          that.pageSize = 3
          for (var i = 0; i < res.data.length; i++) {
            for (var j = 0; j < res.data[i].length; j++) {
              if (res.data[i][j] == null || res.data[i][j] === 'undefined') {
                res.data[i][j] = ''
              }
            }
            var this_data = new Date(res.data[i][26])
            var year = this_data.getFullYear()
            var mon = this_data.getMonth() + 1
            var day = this_data.getDate()
            var str = year + '-' + mon + '-' + day
            table.push({
              id: res.data[i][0],
              job_name: res.data[i][1],
              job_function: res.data[i][2],
              company_name: res.data[i][3].length>0? res.data[i][3] : '未知',
              company_intro: res.data[i][4],
              company_industry: res.data[i][5],
              department: res.data[i][6],
              num_hire: res.data[i][7],
              address: res.data[i][8].length>0 ? res.data[i][8] : '未知',
              major_post: res.data[i][9],
              edu_require_post: res.data[i][10],
              language_post: res.data[i][11],
              soft_post: res.data[i][12],
              experience_post: res.data[i][13],
              prof_skill_post: res.data[i][14],
              school_level: res.data[i][15],
              certificates: res.data[i][16],
              gender: res.data[i][17],
              age: res.data[i][18],
              management_requirement: res.data[i][19],
              professional_requirement: res.data[i][20],
              industry_requirement: res.data[i][21],
              salary: res.data[i][22].length>0 ? res.data[i][22] : '薪资面议',
              benefit: res.data[i][23],
              email: res.data[i][24],
              phone: res.data[i][25],
              publish_time: str,
              job_requirement: res.data[i][27]
            })
          }
          that.all_job_info = table
          that.total = table.length
          // if (that.total < that.PageSize) {
          //   that.PageSize = that.total
          // }
          that.currentPage = 1
          that.fenye()
        }
      })
    },
    // 在表格上点击删除
    // 操作: 将当前行的信息保存到item中,显示删除提示
    Delete(item) {
      this.item = item
      this.del()
    },
    // 点击删除提示中的删除按钮,删除信息
    // 参数: id:id
    // 返回值: 200
    // 操作: 判断成功之后,显示删除成功,刷新界面
    del() {
      this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        console.log('点击了确认删除，当前删除的id和岗位名为：：')
        console.log(this.item.id)
        console.log(this.item.job_name)
        var data = new FormData()
        data.append('id', this.item.id)
        var that = this
        // 提示是否删除
        axios.post(this.conn + '/jobDelete', data).then(function(res) {
          console.log('删除的返回值为：：')
          console.log(res)
          if (res.status === 200) {
            that.isdel = false
            that.$message({
              message: '删除成功',
              type: 'success'
            })
            that.reload()
          }
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });
      });

    },
    moveToDetail(item) {
      this.id_list = []
      console.log('点击了查看')
      for (var j in this.all_job_info) {
        this.id_list.push(this.all_job_info[j].id)
      }
      console.log(this.id_list)
      // 先赋值，再修改信息，看看会不会再出现刷新不及时的情况
      for (var i in item) {
        var str = item[i]+''
        str = str.replaceAll("\n",'')
        this.item[i] = str
        if (this.item[i] === null || this.item[i] === 'undefined' || this.item[i] === '未知'){
          this.item[i] = ''
        }
      }
      console.log(this.item.job_requirement)
      console.log(this.chuli_str_to_list(this.item.job_requirement))
      this.item.job_requirement = this.chuli_str_to_list(this.item.job_requirement)
      this.item.job_function = this.chuli_str_to_list(this.item.job_function)
      console.log(this.item)
      this.active = 1
    },
    indexMethod(index) {
      return index + ((this.currentPage - 1) * this.PageSize) + 1
    },
    handleSizeChange(val) {
      this.PageSize = val
      this.currentPage = 1
      this.fenye()
    },
    handleCurrentChange(val) {
      this.currentPage = val
      this.fenye()
    },
    // 查询全部信息
    // 参数： 无
    // 返回值： 多条sql结果，
    // 操作： 需要遍历每一条，按顺序将变量放在对象当中（获取所有数据）
    // 总条数等于alldata长度，调用分页函数进行切分表格显示
    getInfo() {
      // 查询全部信息
      var that = this
      var table = []
      axios.get(this.conn + '/getJobInfo').then(res => {
        console.log('查看全部信息的返回值为：：：')
        console.log(res)
        if (res.data === null){
          that.allData=[]
          that.total = 0
          that.fenye()
          console.log('返回值为null')
          that.$message.error('当前用户没有可用信息！')
          return
        }
        if (res.status === 200) {
          that.pageSize = 3
          for (var i = 0; i < res.data.length; i++) {
            for (var j = 0; j < res.data[i].length; j++) {
              if (res.data[i][j] == null || res.data[i][j] === 'undefined') {
                res.data[i][j] = ''
              }
            }
            var this_data = new Date(res.data[i][26])
            var year = this_data.getFullYear()
            var mon = this_data.getMonth() + 1
            var day = this_data.getDate()
            var str = year + '-' + mon + '-' + day
            table.push({
              id: res.data[i][0],
              job_name: res.data[i][1],
              job_function: res.data[i][2],
              company_name: res.data[i][3].length>0? res.data[i][3] : '未知',
              company_intro: res.data[i][4],
              company_industry: res.data[i][5],
              department: res.data[i][6],
              num_hire: res.data[i][7],
              address: res.data[i][8].length>0 ? res.data[i][8] : '未知',
              major_post: res.data[i][9],
              edu_require_post: res.data[i][10],
              language_post: res.data[i][11],
              soft_post: res.data[i][12],
              experience_post: res.data[i][13],
              prof_skill_post: res.data[i][14],
              school_level: res.data[i][15],
              certificates: res.data[i][16],
              gender: res.data[i][17],
              age: res.data[i][18],
              management_requirement: res.data[i][19],
              professional_requirement: res.data[i][20],
              industry_requirement: res.data[i][21],
              salary: res.data[i][22].length>0 ? res.data[i][22] : '薪资面议',
              benefit: res.data[i][23],
              email: res.data[i][24],
              phone: res.data[i][25],
              publish_time: str,
              job_requirement: res.data[i][27]
            })
          }
          that.all_job_info = table
          that.total = table.length
          // if (that.total < that.PageSize) {
          //   that.PageSize = that.total
          // }
          that.currentPage = 1
          that.fenye()
        }
      }).catch(error => {
        console.error(error)
      })
    },
    fenye() {
      console.log('进行分页')
      this.job_info = []
      for (var i in this.all_job_info) {
        this.job_info[i] = this.all_job_info[i]
      }
      this.job_info = this.job_info.splice((this.currentPage - 1) * this.PageSize, this.PageSize)
    }
  }
}
</script>

