<template>
  <div class="big">
    <div class="info">
      <div class="one">
        <div class="zhongwenjianli">岗位信息</div>
      </div>
      <div class="two">
        <div class="sinfo">
          <div class="name" v-if="item.job_name.length>7">{{item.job_name.slice(0,6)}}...</div>
          <div class="name" v-if="item.job_name.length<=7">{{item.job_name}}</div>
          <div class="salary">{{item.salary}}</div>
          <div class="sinfos">
            <i class="mar_left el-icon-star-on"></i>{{item.major_post}}
            <i class="mar_left el-icon-s-cooperation"></i>{{item.edu_require_post}}
            <i class="mar_left el-icon-s-tools"></i>{{item.gender}}
            <i class="mar_left el-icon-s-opportunity"></i>{{item.age}}
            <i class="el-icon-location"></i>{{item.address}}
          </div>
        </div>
      </div>
      <hr class="fenjiexian">
      <div class="title_box">
        <div class="_title">岗位描述</div>
        <div class="_title_down"></div>
      </div>
      <div class="thr">
        <ul>
          <li><span class="dian">●</span> 岗位名称：<span>{{item.job_name}}</span></li>
          <li><span class="dian">●</span> 工作职能：<span>{{item.job_function}}</span></li>
          <li><span class="dian">●</span> 招聘人数：<span>{{item.num_hire}}</span></li>
        </ul>
<!--        <div class="left">-->
<!--          -->
<!--        </div>-->
<!--        <div class="right">-->
<!--          <ul>-->

<!--          </ul>-->
<!--        </div>-->
      </div>
      <div class="title_box">
        <div class="_title">岗位要求</div>
        <div class="_title_down"></div>
      </div>
      <div class="four">
        <div class="left">
          <ul>
            <li><span class="dian">●</span> 性别要求：<span>{{item.gender}}</span></li>
            <li><span class="dian">●</span> 年龄要求：<span>{{item.age}}</span></li>
            <li><span class="dian">●</span> 学校等级要求：<span>{{item.school_level}}</span></li>
          </ul>
        </div>
        <div class="right">
          <ul>
            <li><span class="dian">●</span> 专业要求：<span>{{item.major_post}}</span></li>
            <li><span class="dian">●</span> 学位要求：<span>{{item.edu_require_post}}</span></li>
            <li><span class="dian">●</span> 语言技能要求：<span>{{item.language_post}}</span></li>

          </ul>
        </div>
        <ul>
          <li><span class="dian">●</span> 专业技能要求：<span>{{item.prof_skill_post}}</span></li>
          <li><span class="dian">●</span> 软性技能要求：<span>{{item.soft_post}}</span></li>
          <li><span class="dian">●</span> 管理能力要求：<span>{{item.management_requirement}}</span></li>
          <li><span class="dian">●</span> 职能经验要求：<span>{{item.professional_requirement}}</span></li>
          <li><span class="dian">●</span> 行业经验要求：<span>{{item.industry_requirement}}</span></li>
          <li><span class="dian">●</span> 证书要求：<span>{{item.certificates}}</span></li>
<!--          <li><span class="dian">●</span> 工作经验要求：<span>{{item.experience_post}}</span></li>-->
          <li ><span class="dian" style="display: inline-block">●</span> 工作经历： <div style="color: #494949;display: inline-block;width: 86%;float: right">{{item.experience_post}}</div></li>

        </ul>
      </div>
      <div class="title_box">
        <div class="_title">福利待遇</div>
        <div class="_title_down"></div>
      </div>
      <div class="five">
        <ul>
          <li><span class="dian">●</span> 工资：<span>{{item.salary}}</span></li>
          <li><span class="dian">●</span> 福利待遇：<span>{{item.benefit}}</span></li>
        </ul>
      </div>
      <div class="title_box">
        <div class="_title">公司介绍</div>
        <div class="_title_down"></div>
      </div>
      <div class="six">
        <ul>
          <li><span class="dian">●</span> 公司名称：<span>{{item.company_name}}</span></li>
          <li><span class="dian">●</span> 公司行业：<span>{{item.company_industry}}</span></li>
          <li><span class="dian">●</span> 招聘部门：<span>{{item.department}}</span></li>
          <li><span class="dian">●</span> 公司位置：<span>{{item.address}}</span></li>
          <li><span class="dian">●</span> 联系电话：<span>{{item.phone}}</span></li>
          <li><span class="dian">●</span> 联系邮箱：<span>{{item.email}}</span></li>
          <li><span class="dian">●</span> 公司描述：<span>{{item.company_intro}}</span></li>
        </ul>
      </div>
      <div class="teil">
        <div class="del" @click="del()">删除</div>
        <div class="mod" @click="dialogFormVisible=true">修改</div>
      </div>
    </div>
    <div class="xiugai" style="width: 80%;">
      <el-dialog title="修改信息" :visible.sync="dialogFormVisible">
        <form ref="item" action="">
          <div>
            <lable>岗位名称</lable>
            <span><input v-model="item.job_name" type="text" placeholder="请输入岗位名称"></span>
          </div>
          <div>
            <lable>工作职能</lable>
            <span><input v-model="item.job_function" type="text" placeholder="请输入工作职能"></span>
          </div>
          <div>
            <lable>招聘人数</lable>
            <span><input v-model="item.num_hire" type="text" placeholder="请输入招聘人数"></span>
          </div>
          <div>
            <lable>性别要求</lable>
            <span><input v-model="item.gender" type="text" placeholder="请输入性别要求"></span>
          </div>
          <div>
            <lable>年龄要求</lable>
            <span><input v-model="item.age" type="text" placeholder="请输入年龄要求"></span>
          </div>
          <div>
            <lable>专业要求</lable>
            <span><input v-model="item.major_post" type="text" placeholder="请输入专业要求"></span>
          </div>
          <div>
            <lable>学位要求</lable>
            <span><input v-model="item.edu_require_post" type="text" placeholder="请输入学位要求"></span>
          </div>
          <div>
            <lable>学校等级要求</lable>
            <span><input v-model="item.school_level" type="text" placeholder="请输入学校等级要求"></span>
          </div>
          <div>
            <lable>语言技能要求</lable>
            <span><input v-model="item.language_post" type="text" placeholder="请输入语言技能要求"></span>
          </div>
          <div>
            <lable>专业技能要求</lable>
            <span><input v-model="item.prof_skill_post" type="text" placeholder="请输入专业技能要求"></span>
          </div>
          <div>
            <lable>软性技能要求</lable>
            <span><input v-model="item.soft_post" type="text" placeholder="请输入软性技能要求"></span>
          </div>
          <div>
            <lable>管理能力要求</lable>
            <span><input v-model="item.management_requirement" type="text" placeholder="请输入管理能力要求"></span>
          </div>
          <div>
            <lable>职能经验要求</lable>
            <span><input v-model="item.professional_requirement" type="text" placeholder="请输入职能经验要求"></span>
          </div>
          <div>
            <lable>行业经验要求</lable>
            <span><input v-model="item.industry_requirement" type="text" placeholder="请输入行业经验要求"></span>
          </div>
          <div>
            <lable>证书要求</lable>
            <span><input v-model="item.certificates" type="text" placeholder="请输入证书要求"></span>
          </div>
          <div>
            <lable>工作经历</lable>
            <span><input v-model="item.experience_post" type="text" placeholder="请输入工作经历"></span>
          </div>
          <div>
            <lable>工资</lable>
            <span><input v-model="item.salary" type="text" placeholder="请输入工资"></span>
          </div>
          <div>
            <lable>福利待遇</lable>
            <span><input v-model="item.benefit" type="text" placeholder="请输入福利待遇"></span>
          </div>
          <div>
            <lable>公司名称</lable>
            <span><input v-model="item.company_name" type="text" placeholder="请输入公司名称"></span>
          </div>
          <div>
            <lable>公司行业</lable>
            <span><input v-model="item.company_industry" type="text" placeholder="请输入公司行业"></span>
          </div>
          <div>
            <lable>招聘部门</lable>
            <span><input v-model="item.department" type="text" placeholder="请输入招聘部门"></span>
          </div>
          <div>
            <lable>公司位置</lable>
            <span><input v-model="item.address" type="text" placeholder="请输入公司位置"></span>
          </div>
          <div>
            <lable>联系电话</lable>
            <span><input v-model="item.phone" type="text" placeholder="请输入联系电话"></span>
          </div>
          <div>
            <lable>联系邮箱</lable>
            <span><input v-model="item.email" type="text" placeholder="请输入联系邮箱"></span>
          </div>
          <div>
            <lable>公司描述</lable>
            <span><input v-model="item.company_intro" type="text" placeholder="请输入公司描述"></span>
          </div>
        </form>
        <div slot="footer" class="dialog-footer">
          <el-button class="elbtn" @click="dialogFormVisible = false">取 消</el-button>
          <el-button class="elbtn" type="primary" @click="submit()">提 交</el-button>
        </div>
      </el-dialog>
    </div>

  </div>
</template>

<style scoped>
lable{
  /*background-color: #c25959;*/
  font-size: 30px;
  width: 25%;
  display: inline-block;
  text-align: right;
  margin: 10px 20px;
}
.xiugai span input{
  font-size: 27px;
  width: 100%;
  height: 32px;
  line-height: 30px;
  color: gray;
}
.xiugai span{
  /*background-color: #aa1111;*/
  width: 500px;
  font-size: 27px;
  display: inline-block;
}
.xiugai .elbtn{
  width: 130px;
  height: 70px;
  font-size: 30px;
}
.teil .mod{
  text-align: center;
  line-height: 50px;
  font-style: italic;
  font-size: 20px;
  float: right;
  width: 100px;
  height: 50px;
  /*background-color: #ffb8b8;*/
  display: inline-block;
}
.teil .del{
  text-align: center;
  line-height: 50px;
  font-style: italic;
  font-size: 20px;
  float: right;
  width: 100px;
  height: 50px;
  /*background-color: #cb3535;*/
  display: inline-block;
}
.teil{
  width: 90%;
  height: 130px;
  margin: 30px auto;
  /*background-color: #6366ff;*/
}
.six{
  width: 90%;
  /*height: 330px;*/
  margin: 30px auto;
  margin-top: 150px;
  /*background-color: #6366ff;*/
}
.five{
  width: 90%;
  /*height: 250px;*/
  margin: 0px auto;
  margin-top: 240px;
  /*background-color: #efff63;*/
}
.four{
  width: 90%;
  margin: 0px auto;
  margin-top: 130px;
  margin-bottom: 100px;
  /*background-color: #ffac63;*/
}
.thr{
  width: 90%;
  margin: 0px auto;
  margin-top: 150px;
  /*background-color: #f88eff;*/
}

ul{
  /*margin: 130px 30px;*/
  list-style-type: none;
}
ul li{
  margin-top: 25px;
  font-size: 30px;
  color: #9198a5;
}
li .dian{
  color: #6873e5;
}
li span{
  color: #494949;
}
div .left{
  width: 50%;
  /*height: 100%;*/
  display: inline-block;
  float: left;
  /*background-color: #ff8b8b;*/
}
div .right{
  width: 50%;
  /*height: 100%;*/
  display: inline-block;
  float: right;
  /*background-color: #e5d98c;*/
}
.fenjiexian {
  border: black;
  padding: 8px;
  background: repeating-linear-gradient(135deg, #d0d0d0 0px, #09090a 1px, transparent 1px, transparent 6px);
}
.two{
  width: 90%;
  height: 200px;
  margin: 30px auto;
  /*background-color: #8aff63;*/
}
.two .sinfo{
  width: 95%;
  height: 100%;
  margin: 0px auto;
  /*background-color: #e27070;*/
}
.two .salary{
  display: inline-block;
  height: 70px;
  margin-top: 30px;
  font-size: 70px;
  font-weight: bold;
  line-height: 70px;
  text-align: left;
  color: #f26e4a;
  /*background-color: #fff;*/
}
.two .name{
  width: 450px;
  display: inline-block;
  height: 70px;
  margin-top: 30px;
  margin-right: 50px;
  font-size: 60px;
  font-weight: bolder;
  line-height: 70px;
  text-align: left;
  overflow:hidden;
  /*background-color: #ea5454;*/
}
.two .sinfos{
  margin-top: 20px;
  height: 50px;
  font-size: 25px;
  color: #8a919f;
  /*background-color: #ffefef;*/
}
i {
  margin-right: 10px;
}
.mar_left{
  margin-left: 20px;
}
.one{
  width: 90%;
  height: 60px;
  margin: 30px auto;
  /*background-color: #e3e3e3;*/
}
.one .zhongwenjianli{
  width: 100px;
  height: 50px;
  line-height: 50px;
  text-align: center;
  color: #3155eb;
  font-size: 19px;
  border-style: solid;
  border-width: medium;
  border-color: #aec6ff;
  border-radius: 10px;
  /*background-color: #f0f5ff;*/
}
.info{
  width: 80%;
  height: 900px;
  overflow: auto;
  position: absolute;
  left: 10%;
  background-color: #ffffff;
  margin-top: 20px;
  -webkit-box-shadow: #666 0px 0px 50px;
  -moz-box-shadow: #666 0px 0px 50px;
  box-shadow: #666 0px 0px 20px;
}

.title_box{
  position: absolute;
  margin-top: 20px;
  width: 100%;
  height: 100px;
  /*background-color: #af3f3f;*/
}
._title_down{
  /*底色  设置长、宽、背景色*/
  width: 230px;
  height: 50px;
  background-color: #e7ecfb;
  position: absolute;
  left: 70px;
  top: 30px;
}
._title{
  /*文字  设置长、宽、字号、粗细、最上方显示*/
  z-index: 999;
  width: 200px;
  height: 60px;
  font-size: 50px;
  font-weight: normal;
  position: absolute;
  left: 40px;
  top: 10px;
}
</style>
<script>
export default {
  name: 'Find',
  data() {
    return {
      dialogFormVisible: false,
      formLabelWidth: '120px',
      item: {
        id: '00',
        job_name: '前端工程师前端工程师前端工程师',
        major_post: '计算机技术',
        edu_require_post: '硕士',
        language_post: '中文、英文',
        soft_post: '唱歌跳舞',
        experience_post: '2008--2021年在百度任后端工程师，2021年至今在家待业。2008--2021年在百度任后端工程师，2021年至今在家待业。2008--2021年在百度任后端工程师，2021年至今在家待业。',
        prof_skill_post: 'java、vue',
        company_name: '王菲的股份有限公司',
        department: '研发部',
        job_function: '负责前端界面的开发工作，辅助后端工程师进行测试工作',
        num_hire: '20',
        school_level: '985、211',
        certificates: '要求六级425分以上、具有前端工程师证。',
        gender: '男女不限',
        age: '18岁以上，35岁以下',
        company_industry: '前端',
        management_requirement: '有团队管理经验',
        professional_requirement: '有团队项目经验',
        industry_requirement: '要求过去三年内从事前端开发岗位工作',
        salary: '4-16K',
        benefit: '十三薪，五险一金，早九晚六，双休。',
        address: '山东青岛',
        email: '1226448774@qq.com',
        phone: '178603599858',
        company_intro: '公司规模足足有两人，占地六平方米。'
      }
    }
  },
  methods: {
    submit() {
      console.log('点击了提交')
      console.log(this.item)
      this.dialogFormVisible = false
    //  像后端传递信息
    },
    del() {
      //  将该简历信息传到后端，删除，并将界面跳转到前一页
      console.log('点击了删除')
      this.$router.push({ path: '/jobmanage' })
    },
    mod() {
      //  将当前页的简历信息进行修改，弹出表单进行修改，将信息提交到后端
      console.log('点击了修改')
      this.dialogFormVisible = false
      console.log(this.item)
    }
  },
  created() {
    console.log('成功跳转')
    this.item = this.$route.query.item
    console.log(this.item.job_name)
  }
}
</script>

