<template>
    <div style="text-align: center;" v-loading="loading" element-loading-text="正在匹配，请稍后……" element-loading-spinner="el-icon-loading" element-loading-background="rgba(0, 0, 0, 0.8)">
        <div style="margin: 0 auto;">
            <h1 style="color: #00aaff; text-align: center;margin-top: 10px;">以岗推人</h1>
        </div>
        <div v-if="active==0" style="width: 380px; height: 500px;display: flex;margin: 30px auto;">
            <div class="recomender-input-form-div"> 
                <div style="width:380px;margin-top: 20px;">
                    <p style="color: #424770;font-size:18px;font-weight: 500;letter-spacing: normal;line-height: 26px;text-align: left;margin-left: 25px;">职位名</p>
                </div>
                <div>
                    <el-input style="height: 40px;padding: 0px 20px;" v-model="postName" placeholder="请输入职位名"></el-input>
                </div>
                <div style="width:380px;margin-top: 20px;">
                    <p style="color: #424770;font-size:18px;font-weight: 500;letter-spacing: normal;line-height: 26px;text-align: left;margin-left: 25px;">职位描述</p>
                </div>
                <div>
                    <el-input style="padding: 0px 20px;" v-model="postDescription" placeholder="请输入任职要求" :rows="9" type="textarea"></el-input>
                    <el-button  style="margin-top: 20px;" size="medium"  type="primary" class="buttonClass" @click="postToPerson()">提交</el-button>
                </div>
            </div>
        </div>
        <div v-if="active==1" style="width: 900px; height: 500px;display: flex;margin: 30px auto;">
            <div class="recomender-input-form-div"> 
                <div style="width:380px;margin-top: 20px;">
                    <p style="color: #424770;font-size:18px;font-weight: 500;letter-spacing: normal;line-height: 26px;text-align: left;margin-left: 25px;">职位名</p>
                </div>
                <div>
                    <el-input style="height: 40px;padding: 0px 20px;" v-model="postName" placeholder="请输入职位名"></el-input>
                </div>
                <div style="width:380px;margin-top: 20px;">
                    <p style="color: #424770;font-size:18px;font-weight: 500;letter-spacing: normal;line-height: 26px;text-align: left;margin-left: 25px;">职位描述</p>
                </div>
                <div>
                    <el-input style="padding: 0px 20px;" v-model="postDescription" placeholder="请输入任职要求" :rows="9" type="textarea"></el-input>
                    <el-button style="margin-top: 20px;" size="medium"  type="primary" class="buttonClass" @click="postToPerson()">提交</el-button>
                </div>
            </div>
            <div class="recommender-result-form-div">
                <div style="width: 465px;margin: 0px auto" v-for="(item,index) in cardData" :key="index" class="text item" @click="movetodetail(item)">
                    <el-card class="box-card" >
                        <!-- <img v-if="item.sex_per==='男'" class="imgg" src="../../icons/man.jpg" alt="">
                        <img v-if="item.sex_per==='女'" class="imgg" src="../../icons/woman.jpg" alt=""> -->
                        <div class="info">
                        <div class="display__name"><b>{{ item.name_per }}</b></div>
                        <div class="sec">
                            <span>{{ item.sex_per }}</span><span v-if="item.sex_per.length>0&&(item.age_per.toString().length>0 || item.highest_edu_per.length>0 || (typeof item.major_per == 'string' && item.major_per.length>0 ) || typeof item.major_per != 'string' || (typeof item.gra_school_per == 'string' && item.gra_school_per.length>0) || typeof item.gra_school_per != 'string')"> | </span>
                            <span>{{ item.age_per }}</span><span v-if="item.age_per.toString().length>0 && (item.highest_edu_per.length>0 || (typeof item.major_per == 'string' && item.major_per.length>0 ) || typeof item.major_per != 'string' || (typeof item.gra_school_per == 'string' && item.gra_school_per.length>0) || typeof item.gra_school_per != 'string')"> | </span>
                            <span>{{ item.highest_edu_per }}</span><span v-if="item.highest_edu_per.length>0 && ( (typeof item.major_per == 'string' && item.major_per.length>0 ) || typeof item.major_per != 'string' || (typeof item.gra_school_per == 'string' && item.gra_school_per.length>0) || typeof item.gra_school_per != 'string' )"> | </span>
                            <span v-if="typeof item.major_per == 'string' && item.major_per.length>0">{{ item.major_per }}</span><span v-if="typeof item.major_per == 'string' && item.major_per.length>0 && ((typeof item.gra_school_per == 'string' && item.gra_school_per.length>0) || typeof item.gra_school_per != 'string')"> | </span>
                            <span v-if="typeof item.major_per != 'string'">{{ item.major_per[item.major_per.length-1] }}</span><span v-if="typeof item.major_per != 'string' && ((typeof item.gra_school_per == 'string' && item.gra_school_per.length>0) || typeof item.gra_school_per != 'string')"> | </span>
                            <span v-if="typeof item.gra_school_per == 'string' && item.gra_school_per.length>0 ">{{ item.gra_school_per }}</span>
                            <span v-if="typeof item.gra_school_per != 'string'">{{ item.gra_school_per[item.gra_school_per.length-1] }}</span>
                        </div>
                        <div v-if="typeof item.company_name =='string' && item.company_name.length>0 && item.job_title.length>0" class="th">
                            <span style="color: #5454ff; float: left;">
                            <b style="float: left;">● </b>
                            </span>
                            <span v-if="item.company_name.length>0" style="color: #40586f;float: left;">在{{ item.company_name }}</span>
                            <span v-if="item.job_title.length>0" style="color: #40586f;float: left;">任{{ item.job_title }}</span>
                        </div>
                        <div v-if="typeof item.company_name !='string'" class="th">
                                <span style="color: #5454ff;float: left;">
                                <b style="float: left;">● </b>
                                </span>
                                <span style="color: #40586f;float: left;">在{{ item.company_name[0] }}</span>
                                <span style="color: #40586f;float: left;">任{{ item.job_title[0] }}</span>
                        </div>
                        <div v-if="typeof item.prof_skill_per =='string' && item.prof_skill_per.length>0" class="forth">
                            <span style="color: #5454ff; float: left;">
                            <b style="float: left;margin-top: 12px;">● </b>
                            </span>
                            <label style="float: left;" class="biaoqian" >{{item.prof_skill_per}}</label>
                        </div>
                        <div v-if="typeof item.prof_skill_per !='string'" class="forth">
                            <span style="color: #5454ff; float: left;">
                            <b style="float: left;margin-top: 12px;">● </b>
                            </span>
                            <label style="float: left;" class="biaoqian" v-for="i in item.prof_skill_per">{{i}}</label>
                        </div>
                        </div>
                    </el-card>
                </div>
            </div>
        </div>
    </div>
</template>
  
  
<script>
// import * as axios from 'axios'
import axios from 'axios'
import Vue from 'vue'

export default {
    name: 'Index',
    data() {
        return {
            active: 0,
            postName: '',
            postDescription: '',
            cardData: [],
            loading: false,

        }
    },
    methods: {
        //列表数据处理
        data_processing(item){
            for (var i in item) {
                // console.log(i)
                if (i ==='work_year'){
                if(item[i] != ''){
                    item[i] = parseInt(item[i])
                    item[i] = item[i]+'年'
                }
                }
                if (i ==='age_per'){
                if(item[i] == '-1'){
                    console.log(item[i])
                    item[i] = ''
                    console.log(item[i])
                }
                }
                // console.log('item[i]:', item[i].toString().type())
                if (item[i].toString().indexOf('Ж')!= -1) {
                item[i] = item[i].split('Ж')
                }
            }

            // 教育
            var edu = []
            //遍历列表
            if (typeof (item.adm_date) != "string"){
                for (var i =0;i<item.adm_date.length;i++){
                edu.push({
                    adm_date : item.adm_date[i],
                    gra_date : item.gra_date[i],
                    gra_school_per : item.gra_school_per[i],
                    major_per : item.major_per[i],
                    edu_gpa : item.edu_gpa[i],
                    courses : item.courses[i],
                    school_level : item.school_level[i],
                })
                }
            }

            if (edu.length==0){
                if (item.adm_date == "" &&item.gra_date == "" &&item.gra_school_per == "" &&item.major_per == "" &&item.school_level == "" &&item.edu_gpa == "" &&item.courses == ""){

                }else {
                edu.push({
                    adm_date : item.adm_date,
                    gra_date : item.gra_date,
                    gra_school_per : item.gra_school_per,
                    major_per : item.major_per,
                    edu_gpa : item.edu_gpa,
                    courses : item.courses,
                    school_level : item.school_level,
                })
                }
            }
            // 工作
            var work = []
            if (typeof (item.work_date) != "string") {
                for (var i = 0; i < item.work_date.length; i++) {
                work.push({
                    work_date: item.work_date[i],
                    work_description: item.work_description[i],
                    // work_industry: item.work_industry[i]+'',
                    company_name: item.company_name[i],
                    job_title: item.job_title[i],
                })
                }
            }
            if (work.length==0){
                if (item.work_date == "" &&item.work_description == "" &&item.work_industry == "" &&item.company_name == "" &&item.job_title == "" ){

                }else {
                work.push({
                    work_date : item.work_date,
                    work_description : item.work_description,
                    work_industry : item.work_industry,
                    company_name : item.company_name,
                    job_title : item.job_title,
                })
                }
            }
            // 项目
            var project = []
            if (typeof (item.project_name) != "string") {
                for (var i = 0; i < item.project_name.length; i++) {
                project.push({
                    project_name: item.project_name[i],
                    project_description: item.project_description[i],
                    project_date: item.project_date[i],
                    project_position: item.project_position[i]
                })
                }
            }
            if (project.length==0){
                if (item.project_name == "" &&item.project_description == "" &&item.project_date == "" &&item.project_position == "" ){

                }else {
                project.push({
                    project_name : item.project_name,
                    project_description : item.project_description,
                    project_date : item.project_date,
                    project_position : item.project_position
                })
                }
            }
            // 社会
            var social = []
            if (typeof (item.social_pos) != "string") {
                for (var i = 0; i < item.social_pos.length; i++) {
                social.push({
                    social_pos: item.social_pos[i],
                    social_date: item.social_date[i],
                    social_cpy: item.social_cpy[i],
                    social_description: item.social_description[i]
                })
                }
            }
            if (social.length==0){
                if (item.social_pos == "" &&item.social_date == "" &&item.social_cpy == "" &&item.social_description == "" ){

                }else {
                social.push({
                    social_pos : item.social_pos,
                    social_date : item.social_date,
                    social_cpy : item.social_cpy,
                    social_description : item.social_description
                })
                }
            }
            // 培训
            var train = []
            if (typeof (item.train_org) != "string") {
                for (var i = 0; i < item.train_org.length; i++) {
                train.push({
                    train_org: item.train_org[i],
                    training_description: item.training_description[i],
                    train_date: item.train_date[i]
                })
                }
            }
            if (train.length==0){
                if (item.social_pos == "" &&item.social_date == "" &&item.social_cpy == "" &&item.social_description == "" ){

                }else {
                train.push({
                    train_org : item.train_org,
                    training_description : item.training_description,
                    train_date : item.train_date
                })
                }
            }
            item.edu = edu
            item.work = work
            item.project = project
            item.social = social
            item.train = train
        },
        // 人岗匹配
        postToPerson(){
            this.loading = true
            var formData = new FormData()
            formData.append('postName', this.postName);
            formData.append('postDescription', this.postDescription)
            let config = {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            }
            var that = this;
            axios.post('http://81.68.169.78:5000/select_perPost', formData, config).then(function(res) {
                if (res.status === 200) {
                    that.total = res.data.length
                    for (var i = 0; i < res.data.length; i++) {
                        for (var j = 0; j < res.data[i].length; j++) {
                            if (res.data[i][j] == null || res.data[i][j] === 'undefined') {
                            res.data[i][j] = ''
                            }
                        }
                        var highest_edu = ""
                        if(res.data[i][14] === ""){
                            highest_edu = "未知"
                        }else{
                            highest_edu = res.data[i][14]
                        }
                        var age = ''
                        if(res.data[i][4] == -1){
                            age = '未知'
                        }else{
                            age = res.data[i][4]
                        }
                        var name = ''
                        if(res.data[i][1] == ""){
                            name = '未知'
                        }else{
                            name = res.data[i][1]
                        }
                        that.cardData.push({
                            id: res.data[i][0] + '',
                            name_per: name,
                            sex_per: res.data[i][2],
                            email_per: res.data[i][3],
                            age_per: age,
                            phone_per: res.data[i][5],
                            qq: res.data[i][6],
                            weixin: res.data[i][7],
                            address_per: res.data[i][8],
                            height: res.data[i][9],
                            weight: res.data[i][10],
                            race: res.data[i][11],
                            nationality: res.data[i][12],
                            marital_status: res.data[i][13],
                            highest_edu_per: highest_edu,
                            adm_date: res.data[i][15],
                            gra_date: res.data[i][16],
                            gra_school_per: res.data[i][17],
                            major_per: res.data[i][18],
                            lan_skill_per: res.data[i][19],
                            prof_skill_per: res.data[i][20],
                            office_skill_per: res.data[i][21],
                            awards_per: res.data[i][22],
                            certificates: res.data[i][23],
                            political_status: res.data[i][24],
                            postal_code: res.data[i][25],
                            school_level: res.data[i][26],
                            courses: res.data[i][27],
                            edu_gpa: res.data[i][28],
                            job_title: res.data[i][29],
                            company_name: res.data[i][30],
                            work_date: res.data[i][31],
                            work_description: res.data[i][32],
                            work_industry: res.data[i][33],
                            work_year: res.data[i][34],
                            project_name: res.data[i][35],
                            project_position: res.data[i][36],
                            project_date: res.data[i][37],
                            project_description: res.data[i][38],
                            social_pos:res.data[i][39],
                            social_description: res.data[i][40],
                            social_cpy: res.data[i][41],
                            social_date: res.data[i][42],
                            train_org: res.data[i][43],
                            training_description: res.data[i][44],
                            train_date: res.data[i][45],
                            self_evaluation: res.data[i][46],
                            candidate_job_title: res.data[i][47],
                            parsing_time: res.data[i][48],
                            resume_type: res.data[i][49],
                            resume_name: res.data[i][50],
                            path_resume: res.data[i][51],
                            avatar_url: res.data[i][52],
                            pred_salary: res.data[i][53],
                            pos_tags: res.data[i][54],
                            skills_tags: res.data[i][55],
                            username: res.data[i][56]
                        })
                        for (var i in that.cardData) {
                            that.data_processing(that.cardData[i])
                        }
                    }
                    console.log("that.cardData:", that.cardData)
                    that.loading = false
                    that.active=1
                }
            }).catch(err => {
                this.$message.error(err.message);
                console.log(err)
            })

        }
    }
}
</script>
<style>
.recomender-input-form-div{
    border-radius: 4px;
    -webkit-box-shadow: 0 50px 100px rgba(50,50,93,.1), 0 15px 35px rgba(50,50,93,.15), 0 5px 15px rgba(0,0,0,.1);
    box-shadow: 0 50px 100px rgba(50,50,93,.1), 0 15px 35px rgba(50,50,93,.15), 0 5px 15px rgba(0,0,0,.1);
    background: #fff;
    /* padding: 5% 5% 1%; */
    /* margin: 0 3%; */
    height: 480px;
    width: 380px;
}
.el-input__inner{
    box-sizing: border-box;
    margin: 0;
    font-variant: tabular-nums;
    list-style: none;
    font-feature-settings: "tnum";
    position: relative;
    display: inline-block;
    width: 100%;
    height: 32px;
    padding: 4px 11px;
    color: rgba(0, 0, 0, 0.65);
    font-size: 15px;
    line-height: 1.5;
    background-color: #F6F9FC;
    background-image: none;
    border: 1px solid #cdd2d7;
    border-radius: 4px;
    transition: all .3s;
}
.el-textarea__inner{
    box-sizing: border-box;
    margin: 0;
    font-variant: tabular-nums;
    list-style: none;
    font-feature-settings: "tnum";
    position: relative;
    display: inline-block;
    width: 100%;
    /* height: 32px; */
    padding: 4px 11px;
    color: rgba(0,0,0,.65);
    font-size: 15px;
    line-height: 1.5;
    background-color: #F6F9FC;
    background-image: none;
    border: 1px solid #cdd2d7;
    border-radius: 4px;
    transition: all .3s;
}
.recommender-result-form-div{
    border-radius: 4px;
    /* padding: 7px; */
    margin: 0 2%;
    width: 520px;
    height: 480px;
    overflow-y: scroll;
}
.box-card {
  /* width: 70%; */
  width: 465px;
  margin: 0px auto;
  border-radius: 20px;
}
/* .box-card.info{
  width: 60%;
  height: 95%;
  overflow: auto;
  position: absolute;
  top: 0;left:0;right:0;bottom:0;
  margin: auto;
  background-color: #ffffff;
  -webkit-box-shadow: #666 0px 0px 50px;
  -moz-box-shadow: #666 0px 0px 50px;
  box-shadow: #666 0px 0px 20px;
} */
.info{
  /* width: 90%; */
  float: right;
  display: inline-block;
  padding-bottom: 10px;
}
.display__name{
float: left;
  width: 70px;
  /* height: 18px; */
  /* height: 200px; */
  font-size: 20px;
  font-family: 黑体;
  
  /*background-color: #fc6a6a;*/
}
.sec{
    float: left;
  font-weight: bold;
  color: #6873e5;
  font-size: small;
  margin-top: 3px;
  margin-left: 20px;
  
  /*background-color: #ffe7e7;*/
}
.th {
  height: 20px;
  font-size: 14px;
  margin-top: 38px;
  width: 420px;
}
.forth{
  font-size: small;
  width: 420px;
}
.biaoqian{
  background-color: #fff6e9;
  color: #ffa817;
  font-family: "Times New Roman";
  display: inline-block;
  padding: 2px 4px;
  margin-top: 10px;
  margin-left: 5px;
  border-style: solid;
  border-radius: 5px;
  border-width: 1px;
  /* text-align: right; */
}
.item {
  padding: 3px 0px;
}
/* .imgg{
  width: 10%;
  display: inline-block;
  float: left;
  padding-bottom: 20px;
} */
.el-loading-mask{
  position: fixed;
}
</style>