<template>
  <div>
    <div style="text-align: center;" v-if="active==0">
    <div style="width: 262px; height: 37px; margin: 0 auto;">
      <h1 style="color: #00aaff; text-align: center;margin-top: 2%;">简历解析</h1>
        <!-- <el-popover
          ref="popover"
          placement="right"
          trigger="hover"
          content="请上传简历进行解析或选择已上传简历解析"
          popper-class="el_popover_class1"
          >
          <el-button style="float: right;margin-top: -57px;margin-right: 45px;" size="medium" slot="reference"  icon="el-icon-question" circle></el-button>
      </el-popover> -->
    </div>
    <!-- <div style="width: 100%;">
      <el-tabs style="margin: 20px auto;width: 300px;" v-model="activeName" type="card" @tab-click="selectPattern">
        <el-tab-pane label="普通模式" name="普通模式"></el-tab-pane>
        <el-tab-pane label="极速模式" name="极速模式"></el-tab-pane>
        <el-tab-pane label="精准模式" name="精准模式"></el-tab-pane>        
      </el-tabs>
    </div> -->
    <div style="width: 500px;;margin: 25px auto;">
      <el-upload 
        style="margin: -15px 0 15px -10px;" 
        class="upload-demo" 
        ref="upload"
        drag
        action="action"
        :http-request="uploadResume"
        multiple>
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">将简历拖到此处，或<em>点击上传</em><br/>
          <div style="margin-top: 10px;">可以上传<em>jpg、png、word、pdf</em>文件</div>
        </div>
      </el-upload>
      <el-button type="primary" class="buttonClass" @click="resumeAnalysis()">开始解析</el-button>
    </div>
    <div v-if="activeTable===1" style="width: 1240px;margin: 5px auto;">
      <el-table
        style="width: 1240px;"
        :data="resumeTable.slice((currentPage-1)*PageSize,currentPage*PageSize).filter(data => !search || data.resume_name.toLowerCase().includes(search.toLowerCase())  || data.name_per.toLowerCase().includes(search.toLowerCase()) || (data.age_per+='').toLowerCase().includes(search.toLowerCase()) || data.highest_edu_per.toLowerCase().includes(search.toLowerCase()) || data.parsing_time.toLowerCase().includes(search.toLowerCase()))"
        :header-cell-style="{'text-align':'center'}"
        :cell-style="{'text-align':'center'}">
        <el-table-column prop="resume_name" sortable label="简历名称">
        </el-table-column>
        <el-table-column prop="name_per" sortable label="姓名">
        </el-table-column>
        <el-table-column prop="age_per" sortable label="年龄">
        </el-table-column>
        <el-table-column prop="highest_edu_per" sortable label="最高学历">
        </el-table-column>
        <el-table-column prop="parsing_time" sortable label="解析时间">
        </el-table-column>
        <el-table-column align="right" width="300px">
        <template slot="header" slot-scope="scope">
          <el-input v-model="search" size="mini" placeholder="输入关键字搜索" />
        </template>
        <template slot-scope="scope">
          <el-button size="mini" type="primary" @click="getAnalysisResult(scope.$index, scope.row)"><i
            class="el-icon-thumb"></i>查看</el-button>
          <el-button size="mini" type="danger" @click="resumeDelete(scope.$index, scope.row)"><i
            class="el-icon-delete"></i>移除</el-button>
        </template>
        </el-table-column>
      </el-table>
      <div class="block" align="center" style="margin-top: 10px;">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage"
        :page-sizes="pageSizes" :page-size="PageSize" layout="total, sizes, prev, pager, next, jumper"
        :total=total>
        </el-pagination>
      </div>
    </div>

    </div>
    <div v-if="active==1" class="big1" style="height: 100%">
      <i class="el-icon-back" style="display: inline-block;font-size: 40px;float:left;margin-top: 40px;margin-left: 80px" @click="go_back()" />
      <div class="info">
        <div class="one">
         <div class="zhongwenjianli" style="display: inline-block" v-if="resumeType!='英文'">中文简历</div>
         <div class="zhongwenjianli" style="display: inline-block" v-if="resumeType=='英文'">英文简历</div>
        </div>
        <div class="two">
          <img v-if="item.name_per === '鲁超峰'" class="imgg" src='http://81.68.169.78:1006/imgPath/鲁超峰的漂亮的照片.png' alt="">
          <img v-if="item.name_per != '鲁超峰' && item.avatar_url.length>0" class="imgg" :src="'http://81.68.169.78:1006/imgPath/'+item.avatar_url.split('/')[item.avatar_url.split('/').length-1]" alt="">
          <img v-if="item.name_per != '鲁超峰' && item.avatar_url.length==0 && item.sex_per==='男'" class="imgg" src="../../icons/man.jpg" alt="">
          <img v-if="item.name_per != '鲁超峰' && item.avatar_url.length==0 && item.sex_per==='女'" class="imgg" src="../../icons/woman.jpg" alt="">
          <!-- <img v-if="item_detail.avatar_url.length>0" class="imgg" :src="'http://81.68.169.78:1006/imgPath/'+item_detail.avatar_url.split('/')[item_detail.avatar_url.split('/').length-1]" alt="">
          <img v-if="item_detail.avatar_url.length==0 && item_detail.sex_per==='男'" class="imgg" src="../../icons/man.jpg" alt="">
          <img v-if="item_detail.avatar_url.length==0 && item_detail.sex_per==='女'" class="imgg" src="../../icons/woman.jpg" alt=""> -->
          <!-- <img v-if="item_detail.sex_per==='男'" class="imgg" src="../../icons/man.jpg" alt="头像">
          <img v-if="item_detail.sex_per==='女'" class="imgg" src="../../icons/woman.jpg" alt="头像"> -->
          <div class="sinfo">
            <div v-if="item_detail.name_per!=''" class="name" style="display: inline-block">{{ item_detail.name_per }}</div>
            <div v-if="item_detail.candidate_job_title!=''" class="name" style="font-size: larger;float: right;display: inline-block">投递职位：{{ item_detail.candidate_job_title }}</div>
            <div class="sinfos">
              <i v-if="item_detail.age_per.toString()!=''" class="el-icon-user-solid" />{{ item_detail.age_per }}
              <i v-if="item_detail.sex_per.length!=''" class="mar_left el-icon-s-opportunity" />{{ item_detail.sex_per }}
              <i v-if="item_detail.email_per.length!=''" class="mar_left el-icon-s-comment" />{{ item_detail.email_per }}
              <i v-if="item_detail.phone_per.length!=''" class="mar_left el-icon-phone" />{{ item_detail.phone_per }}
              <i v-if="item_detail.highest_edu_per!=''" class="mar_left el-icon-s-cooperation" />{{ item_detail.highest_edu_per }}
            </div>
          </div>
        </div>
        <hr class="fenjiexian">
        <div>
          <div  class="title_box">
            <div class="_title el-icon-user-solid" style="margin-top:-130px">人才指数</div>
            <!-- <div class="_title_down" /> -->
          </div>
          <div>
            <div v-if="talentEvl_list[10]!=''" id="myCharts" style="width:80px;height:80px;position: absolute;margin-left: 240px;margin-top: -60px;"></div>
            <div v-if="talentEvl_list[10]!=''" style="position: absolute;margin-left: 320px;margin-top: -30px;font-size: 16px;color: red;"><b>综合分:{{talentEvl_list[10]}}分</b></div>
          </div>
          <div id="myChart" style="width:470px;height:410px;margin:130px 0 0 50px"></div>
          <div style="width:220px;height:410px;float: left;margin-top: -460px;margin-left: 520px;">
            <div v-if="talentEvl_list[0]!=''&&talentEvl_list[0]!='未知'" id="myChart2" style="width:80px;height:60px;"></div>
            <div v-if="talentEvl_list[0]!=''&&talentEvl_list[0]!='未知'" style="float: left;margin-top: -38px;margin-left:70px;font-size: 14px;color: #3155eb;"><b>性别:{{talentEvl_list[0]}}</b></div>
            <div v-if="talentEvl_list[1]!=''&&talentEvl_list[1]!='未知'" id="myChart3" style="width:80px;height:60px;"></div>
            <div v-if="talentEvl_list[1]!=''&&talentEvl_list[1]!='未知'" style="float: left;margin-top: -38px;margin-left:70px;font-size: 14px;color: #3155eb;"><b>年龄:{{talentEvl_list[1]}}</b></div>
            <div v-if="talentEvl_list[2]!=''&&talentEvl_list[2]!='未知'" id="myChart4" style="width:80px;height:60px;"></div>
            <div v-if="talentEvl_list[2]!=''&&talentEvl_list[2]!='未知'" style="float: left;margin-top: -38px;margin-left:70px;font-size: 14px;color: #3155eb;"><b>政治面貌:{{talentEvl_list[2]}}</b></div>
            <div v-if="talentEvl_list[3]!=''&&talentEvl_list[3]!='未知'" id="myChart5" style="width:80px;height:60px;"></div>
            <div v-if="talentEvl_list[3]!=''&&talentEvl_list[3]!='未知'" style="float: left;margin-top: -38px;margin-left:70px;font-size: 14px;color: #3155eb;"><b>地点:{{talentEvl_list[3]}}</b></div>
            <div v-if="talentEvl_list[4]!=''&&talentEvl_list[4]!='未知'" id="myChart6" style="width:80px;height:60px;"></div>
            <div v-if="talentEvl_list[4]!=''&&talentEvl_list[4]!='未知'" style="float: left;margin-top: -38px;margin-left:70px;font-size: 14px;color: #5b9874;"><b>学历:{{talentEvl_list[4]}}</b></div>
            <div v-if="talentEvl_list[5]!=''&&talentEvl_list[5]!='未知'" id="myChart7" style="width:80px;height:60px;"></div>
            <div v-if="talentEvl_list[5]!=''&&talentEvl_list[5]!='未知'" style="float: left;margin-top: -38px;margin-left:70px;font-size: 14px;color: #5b9874;"><b>专业:{{talentEvl_list[5]}}</b></div>
            <div v-if="talentEvl_list[6]!=''&&talentEvl_list[6]!='未知'" id="myChart8" style="width:80px;height:60px;"></div>
            <div v-if="talentEvl_list[6]!=''&&talentEvl_list[6]!='未知'" style="float: left;margin-top: -38px;margin-left:70px;font-size: 14px;color: #5b9874;"><b>学校:{{talentEvl_list[6]}}</b></div>
            <div v-if="talentEvl_list[7]!=''&&talentEvl_list[7]!='未知'" id="myChart9" style="width:80px;height:60px;"></div>
            <div v-if="talentEvl_list[7]!=''&&talentEvl_list[7]!='未知'" style="float: left;margin-top: -38px;margin-left:70px;font-size: 14px;color: #5b9874;"><b>工作时长:{{talentEvl_list[7]}}</b></div>
            <div v-if="talentEvl_list[8]!=''&&talentEvl_list[8]!='未知'" id="myChart10" style="width:80px;height:60px;"></div>
            <div v-if="talentEvl_list[8]!=''&&talentEvl_list[8]!='未知'" style="float: left;margin-top: -38px;margin-left:70px;font-size: 14px;color: #5b9874;"><b>公司:{{talentEvl_list[8]}}</b></div>
            <div v-if="talentEvl_list[9]!=''&&talentEvl_list[9]!='未知'" id="myChart11" style="width:80px;height:60px;"></div>
            <div v-if="talentEvl_list[9]!=''&&talentEvl_list[9]!='未知'" style="float: left;margin-top: -38px;margin-left:70px;font-size: 14px;color: #5b9874;"><b>技能:{{talentEvl_list[9]}}</b></div>
            <!-- <div v-for="(talentEvl,index) in talentEvl_list"> -->
            
            <!-- </div> -->
          </div>
        </div>
        
        <div v-if="item_detail.name_per!='' || item_detail.age_per.toString()!='' || item_detail.phone_per!='' || item_detail.qq!='' || item_detail.height!='' || item_detail.race!='' || item_detail.nationality!='' || item_detail.highest_edu_per!='' || item_detail.political_status!='' || item_detail.sex_per!='' || item_detail.weixin!='' || item_detail.weight!='' || item_detail.marital_status!='' || item_detail.work_year!='' || item_detail.address_per!='' || item_detail.email_per!=''" class="title_box">
          <div class="_title el-icon-user-solid" style="margin-top: 20px;"> 基本信息</div>
          <div class="_title_down" />
        </div>
        <div v-if="item_detail.name_per!='' || item_detail.age_per.toString()!='' || item_detail.phone_per!='' || item_detail.qq!='' || item_detail.height!='' || item_detail.race!='' || item_detail.nationality!='' || item_detail.highest_edu_per!='' || item_detail.political_status!='' || item_detail.sex_per!='' || item_detail.weixin!='' || item_detail.weight!='' || item_detail.marital_status!='' || item_detail.work_year!='' || item_detail.address_per!='' || item_detail.email_per!=''"  class="thr">
          <div v-if="item_detail.name_per!='' || item_detail.age_per.toString()!='' || item_detail.phone_per!='' || item_detail.qq!='' || item_detail.height!='' || item_detail.race!='' || item_detail.nationality!='' || item_detail.highest_edu_per!='' || item_detail.political_status!=''" class="left">
            <ul>
              <li v-if="item_detail.name_per!=''"><span class="dian">●</span> 姓名：<span>{{ item_detail.name_per }}</span></li>
              <li v-if="item_detail.age_per.toString()!=''"><span class="dian">●</span> 年龄：<span>{{ item_detail.age_per }}</span></li>
              <li v-if="item_detail.phone_per!=''"><span class="dian">●</span> 联系方式：<span>{{ item_detail.phone_per }}</span></li>
              <li v-if="item_detail.qq!=''"><span class="dian">●</span> QQ：<span>{{ item_detail.qq }}</span></li>
              <li v-if="item_detail.height!=''"><span class="dian">●</span> 身高：<span>{{ item_detail.height }}</span></li>
              <li v-if="item_detail.race!=''"><span class="dian">●</span> 民族：<span>{{ item_detail.race }}</span></li>
              <li v-if="item_detail.nationality!=''"><span class="dian">●</span> 国籍：<span>{{ item_detail.nationality }}</span></li>
              <li v-if="item_detail.highest_edu_per!=''"><span class="dian">●</span> 最高学历：<span>{{ item_detail.highest_edu_per }}</span></li>
              <li v-if="item_detail.political_status!=''"><span class="dian">●</span> 政治面貌：<span>{{ item_detail.political_status }}</span></li>
<!--              <li v-if="item_detail.school_level!=''"><span class="dian">●</span> 学校等级：<span>{{ item_detail.school_level }}</span></li>-->
            </ul>
          </div>
          <div v-if="item_detail.sex_per!='' || item_detail.weixin!='' || item_detail.weight!='' || item_detail.marital_status!='' || item_detail.work_year!='' || item_detail.address_per!='' || item_detail.email_per!=''" class="right">
            <ul>
              <li v-if="item_detail.sex_per!=''"><span class="dian">●</span> 性别：<span>{{ item_detail.sex_per }}</span></li>
              <li v-if="item_detail.address_per!=''"><span class="dian">●</span> 住址：<span>{{ item_detail.address_per }}</span></li>
              <li v-if="item_detail.email_per!=''"><span class="dian">●</span> 邮箱：<span>{{ item_detail.email_per }}</span></li>
              <li v-if="item_detail.weixin!=''"><span class="dian">●</span> 微信：<span>{{ item_detail.weixin }}</span></li>
              <li v-if="item_detail.weight!=''"><span class="dian">●</span> 体重：<span>{{ item_detail.weight }}</span></li>
              <li v-if="item_detail.marital_status!=''"><span class="dian">●</span> 婚姻状况：<span>{{ item_detail.marital_status }}</span></li>
              <li v-if="item_detail.work_year!=''"><span class="dian">●</span> 工作经验：<span>{{ item_detail.work_year }}</span></li>
              <li v-if="item_detail.postal_code!=''"><span class="dian">●</span> 邮编：<span>{{ item_detail.postal_code }}</span></li>
<!--              <li v-if="item_detail.edu_gpa!=''"><span class="dian">●</span> 绩点：<span>{{ item_detail.edu_gpa }}</span></li>-->
            </ul>
          </div>
        </div>
        <div v-if="item_detail.edu!= ''" class="title_box">
          <div class="_title el-icon-s-management"> 教育背景</div>
          <div class="_title_down" />
        </div>
        <div v-if="item_detail.edu!=''" class="four">
          <div v-for="(item,index) in item_detail.edu" style="margin-bottom: 20px">
            <div style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px">{{ item.gra_school_per }}</div>
            <ul>
              <li v-if="item.adm_date!=''"><span class="dian">●</span> 时间：<span>{{ item.adm_date }} - {{ item.gra_date }}</span></li>
              <li v-if="item.major_per!=''"><span class="dian">●</span> 专业：<span>{{ item.major_per }}</span></li>
              <li v-if="item.edu_gpa.toString()!=''"><span class="dian">●</span> 绩点：<span>{{ item.edu_gpa }}</span></li>
              <li v-if="item.school_level!=''"><span class="dian">●</span> 学校水平：<span>{{ item.school_level }}</span></li>
              <li style="position: relative" v-if="item.courses!=''" ><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">所学课程：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.courses }}</div></li>
            </ul>
          </div>
        </div>

        <div v-if="item_detail.work!=''" class="title_box">
          <div class="_title el-icon-s-cooperation"> 工作经历</div>
          <div class="_title_down" />
        </div>
        <div v-if="item_detail.work!=''" class="five">
          <div v-for="(item,index) in item_detail.work" style="margin-bottom: 20px">
            <div style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px ">{{item.company_name}}</div>
            <ul>
              <li style="position: relative" v-if="item.work_date!=''"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">工作时间：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.work_date }}</div></li>
              <li style="position: relative" v-if="item.job_title!=''"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">岗位名称：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.job_title }}</div></li>
              <li style="position: relative" v-if="item.work_description!=''"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">工作描述：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.work_description }}</div></li>
            </ul>
          </div>
        </div>

        <div v-if="item_detail.project!=''" class="title_box">
          <div class="_title el-icon-s-cooperation"> 项目经历</div>
          <div class="_title_down" />
        </div>
        <div v-if="item_detail.project!=''" class="five">
          <div v-for="(item,index) in item_detail.project" style="margin-bottom: 20px">
            <div style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px">{{item.project_name}}</div>
            <ul>
              <li style="position: relative" v-if="item.project_position!=''"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">职位：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.project_position }}</div></li>
              <li style="position: relative" v-if="item.project_date!=''"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">项目时间：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.project_date }}</div></li>
              <li style="position: relative" v-if="item.project_description!=''"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">项目描述：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.project_description }}</div></li>
            </ul>
          </div>
        </div>

        <div v-if="item_detail.social!=''" class="title_box">
          <div class="_title el-icon-s-cooperation"> 社会经历</div>
          <div class="_title_down" />
        </div>
        <div v-if="item_detail.social!=''" class="five">
          <div v-for="(item,index) in item_detail.social" style="margin-bottom: 20px">
            <div style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px">{{item.social_cpy}}</div>
            <ul>
              <li style="position: relative" v-if="item.social_date!=''"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">实践时间：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.social_date }}</div></li>
              <li style="position: relative" v-if="item.social_pos!=''"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">担任角色：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.social_pos }}</div></li>
              <li style="position: relative" v-if="item.social_description!=''"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">实践描述：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.social_description }}</div></li>
            </ul>
          </div>
        </div>

        <div v-if="item_detail.train!=''" class="title_box">
          <div class="_title el-icon-s-cooperation"> 培训经历</div>
          <div class="_title_down" />
        </div>
        <div v-if="item_detail.train!=''" class="five">
          <div  v-for="(item,index) in item_detail.train" style="margin-bottom: 20px">
            <div v-if="item.train_org!=''" style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px">{{ item.train_org }}</div>
            <ul>
              <li style="position: relative" v-if="item.train_date!=''"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">培训时间：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.train_date }}</div></li>
              <li style="position: relative" v-if="item.training_description!=''"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">培训描述：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.training_description }}</div></li>
            </ul>
          </div>
        </div>
        <div class="title_box" v-if="item_detail.prof_skill_per!='' || item_detail.lan_skill_per!='' || item_detail.office_skill_per!='' ||item_detail.awards_per!='' || item_detail.certificates!='' || item_detail.self_evaluation!=''">
          <div class="_title">其他信息</div>
          <div class="_title_down" />
        </div>

        <div class="six" v-if="item_detail.prof_skill_per!='' || item_detail.lan_skill_per!='' || item_detail.office_skill_per!='' ||item_detail.awards_per!='' || item_detail.certificates!='' || item_detail.self_evaluation!=''">
          <ul>
            <li style="position: relative" v-if="item_detail.prof_skill_per!=''">
              <span style="position: absolute" class="dian">●</span>
              <span style="color: #9198a5;position: absolute;left: 18px">专业技能：</span>
              <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                <span v-if="typeof item_detail.prof_skill_per == 'string'">{{ item_detail.prof_skill_per }}</span>
                <span v-if="typeof item_detail.prof_skill_per != 'string'">{{ item_detail.prof_skill_per.join('、') }}</span>
              </div>
            </li>
            <li style="position: relative" v-if="item_detail.lan_skill_per!=''">
              <span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">语言技能：</span>
              <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                <span v-if="typeof item_detail.lan_skill_per == 'string'">{{ item_detail.lan_skill_per }}</span>
                <span v-if="typeof item_detail.lan_skill_per != 'string'">{{ item_detail.lan_skill_per.join('、') }}</span>
              </div>
            </li>
            <li style="position: relative" v-if="item_detail.office_skill_per!=''">
              <span style="position: absolute" class="dian">●</span>
              <span style="color: #9198a5;position: absolute;left: 18px">办公技能：</span>
              <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                <span v-if="typeof item_detail.office_skill_per == 'string'">{{ item_detail.office_skill_per }}</span>
                <span v-if="typeof item_detail.office_skill_per != 'string'">{{ item_detail.office_skill_per.join('、') }}</span>
              </div>
            </li>
            <li style="position: relative" v-if="item_detail.awards_per!=''">
              <span style="position: absolute" class="dian">●</span>
              <span style="color: #9198a5;position: absolute;left: 18px">所获奖项：</span>
              <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                <span v-if="typeof item_detail.awards_per == 'string'">{{ item_detail.awards_per }}</span>
                <span v-if="typeof item_detail.awards_per != 'string'">{{ item_detail.awards_per.join('、') }}</span>
              </div>
            </li>
            <li style="position: relative" v-if="item_detail.certificates!=''">
              <span style="position: absolute" class="dian">●</span>
              <span style="color: #9198a5;position: absolute;left: 18px">所获证书：</span>
              <div v-if="typeof item_detail.certificates != 'string'">
                <div v-for="(item,i) in item_detail.certificates" style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                  {{i+1}}、{{ item }}
                </div>
              </div>
              <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                <span v-if="typeof item_detail.certificates == 'string'">{{ item_detail.certificates }}</span>
              </div>
            </li>
            <li style="position: relative" v-if="item_detail.self_evaluation!=''">
              <span style="position: absolute" class="dian">●</span>
              <span style="color: #9198a5;position: absolute;left: 18px">自我描述：</span>
              <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                {{ item_detail.self_evaluation }}
              </div>
            </li>
          </ul>
        </div>

        <div class="teil" style="text-align: right">
          <!-- <el-button type="primary" size="mini" @click="$refs.aa.click()"><i class="el-icon-download" /><a ref="resumeDownloadUrl" :href="lianjie"></a>下载</el-button> -->
          <el-button type="primary" size="mini" @click="mod_btn()"><i class="el-icon-edit" />修改</el-button>
          <el-button type="danger" size="mini" @click="isdel=true"><i class="el-icon-delete" />删除</el-button>
        </div>
      </div>
    </div>
  </div>

</template>

<script>
import * as axios from 'axios'
import Vue from 'vue'
import Global from '../../global/global'
import a from 'file-saver'
import * as echarts from 'echarts'
export default {
  inject: ['reload'], // 注入刷新页面的依赖
  data() {
    return {
      resumeTable: [],
      currentPage: 1,
      PageSize: 5,
      pageSizes: [5, 10, 15, 20],
      total:0,
      activeTable: 1,
      search: '',
      active: 0,
      resumeUrl: '',
      resumeName: '',
      resumeId: '',
      mod_justnow: false,
      // 简历详情对象
      item_detail: {},
      resumeDownloadUrl:'',
      resumeType: '中文', //中文或英文
      // 人才指数
      talentEvl_list: [], //sex, age, edu, major, school, workTime, company, skill, politicalStatus, address
    }
  },
  mounted(){
    this.getResume()
  },
  watch:{
    'search': {
				handler(newVal, oldVal, data){
          console.log('scope:')
				}
			}
  },
  methods: {
    // 页面条数改变
    handleSizeChange(val) {
      this.PageSize = val
      this.currentPage = 1
      // this.fenye()
    },
    // 当前页面数改变
    handleCurrentChange(val) {
      this.currentPage = val
      // this.fenye()
    },
    //上传简历到后端
    async uploadResume(params){
      console.log("params:",params)
      // this.$refs.upload.submit();
      let formData = new FormData()
      formData.append("resume", params.file)
      var that = this;
      const res = await axios.post("http://81.68.169.78:5000/save_upload_resume2", formData).then(function(response) {
					console.log(response)
					if (response.status === 200) {
						that.$notify({
							title: '成功',
							message: params.file.name + '上传成功!',
							type: 'success'
						});
            that.resumeUrl = response.data
            that.resumeName = response.data.split("\\")[response.data.split("\\").length-1]
						// console.log(that.resumeName);
					}
				}).catch(err => {
					this.$message.error(err.message);
					console.log(err)
				})
    },
    // 获取全部简历
    getResume(){
      let formData = new FormData();
      formData.append('user', Global.username);
      // console.log("user:", formData.get('user'))
      // formData.append('type', item.resume);
      let config = {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }
      var that =this;
      axios.post('http://81.68.169.78:5000/getUserResume', formData, config).then(function(res) {
          console.log(res.data)
					if (res.status === 200) {
            that.total = res.data.length
            for (var i = 0; i < res.data.length; i++) {
              for (var j = 0; j < res.data[i].length; j++) {
                if (res.data[i][j] == null || res.data[i][j] === 'undefined') {
                  res.data[i][j] = ''
                }
              }
              var highest_edu = ""
              if(res.data[i][14] === ""){
                highest_edu = "未知"
              }else{
                highest_edu = res.data[i][14]
              }
              var age = ''
              if(res.data[i][4] == -1){
                age = '未知'
              }else{
                age = res.data[i][4]
              }
              var name = ''
              if(res.data[i][1] == ""){
                name = '未知'
              }else{
                name = res.data[i][1]
              }
              that.resumeTable.push({
                id: res.data[i][0] + '',
                name_per: name,
                sex_per: res.data[i][2],
                email_per: res.data[i][3],
                age_per: age,
                phone_per: res.data[i][5],
                qq: res.data[i][6],
                weixin: res.data[i][7],
                address_per: res.data[i][8],
                height: res.data[i][9],
                weight: res.data[i][10],
                race: res.data[i][11],
                nationality: res.data[i][12],
                marital_status: res.data[i][13],
                highest_edu_per: highest_edu,
                adm_date: res.data[i][15],
                gra_date: res.data[i][16],
                gra_school_per: res.data[i][17],
                major_per: res.data[i][18],
                lan_skill_per: res.data[i][19],
                prof_skill_per: res.data[i][20],
                office_skill_per: res.data[i][21],
                awards_per: res.data[i][22],
                certificates: res.data[i][23],
                political_status: res.data[i][24],
                postal_code: res.data[i][25],
                school_level: res.data[i][26],
                courses: res.data[i][27],
                edu_gpa: res.data[i][28],
                job_title: res.data[i][29],
                company_name: res.data[i][30],
                work_date: res.data[i][31],
                work_description: res.data[i][32],
                work_industry: res.data[i][33],
                work_year: res.data[i][34],
                project_name: res.data[i][35],
                project_position: res.data[i][36],
                project_date: res.data[i][37],
                project_description: res.data[i][38],
                social_pos:res.data[i][39],
                social_description: res.data[i][40],
                social_cpy: res.data[i][41],
                social_date: res.data[i][42],
                train_org: res.data[i][43],
                training_description: res.data[i][44],
                train_date: res.data[i][45],
                self_evaluation: res.data[i][46],
                candidate_job_title: res.data[i][47],
                parsing_time: res.data[i][48],
                resume_type: res.data[i][49],
                resume_name: res.data[i][50],
                path_resume: res.data[i][51],
                avatar_url: res.data[i][52],
                pred_salary: res.data[i][53],
                pos_tags: res.data[i][54],
                skills_tags: res.data[i][55],
                username: res.data[i][56]
              })
              for (var i in that.resumeTable) {
                that.data_processing(that.resumeTable[i])
              }
            }
            console.log(that.resumeTable)
            if(that.resumeTable.length > 0){
              that.activeTable = 1
            }else{
              that.activeTable = 0
            }
          }
				}).catch(err => {
					this.$message.error(err.message);
					that.loading = false;
					console.log(err)
				})
    },
    // 简历解析 resume_analysis
    resumeAnalysis(){
      console.log("this.resumeName:", this.resumeName)
      let formData = new FormData();
      formData.append('resumeUrl', this.resumeUrl);
      formData.append('resumeName', this.resumeName)
      // console.log("formData.resumeName:", formData.get('resumeName'))
      formData.append('username', Global.username)
      let config = {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }
      //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
      var that = this; 
      axios.post('http://81.68.169.78:5000/resume_analysis', formData, config).then(function(res) {
        console.log('后端返回:', res)
        if (res.status === 200) {
          that.$notify({
            title: '成功',
            message: that.resumeName + '解析成功!',
            type: 'success'
          });
          that.resumeName = ''
          that.resumeUrl = ''
          that.total = res.data.length
          that.resumeTable = []
          for (var i = 0; i < res.data.length; i++) {
            for (var j = 0; j < res.data[i].length; j++) {
              if (res.data[i][j] == null || res.data[i][j] === 'undefined') {
                res.data[i][j] = ''
              }
            }
            // console.log('写入resumeTable前', that.resumeTable)
            var highest_edu = ""
            if(res.data[i][14] === ""){
              highest_edu = "未知"
            }else{
              highest_edu = res.data[i][14]
            }
            var age = ''
            if(res.data[i][4] == -1){
              age = '未知'
            }else{
              age = res.data[i][4]
            }
            var name = ''
            if(res.data[i][1] == ""){
              name = '未知'
            }else{
              name = res.data[i][1]
            }
            that.resumeTable.push({
              id: res.data[i][0] + '',
              name_per: name,
              sex_per: res.data[i][2],
              email_per: res.data[i][3],
              age_per: age,
              phone_per: res.data[i][5],
              qq: res.data[i][6],
              weixin: res.data[i][7],
              address_per: res.data[i][8],
              height: res.data[i][9],
              weight: res.data[i][10],
              race: res.data[i][11],
              nationality: res.data[i][12],
              marital_status: res.data[i][13],
              highest_edu_per: highest_edu,
              adm_date: res.data[i][15],
              gra_date: res.data[i][16],
              gra_school_per: res.data[i][17],
              major_per: res.data[i][18],
              lan_skill_per: res.data[i][19],
              prof_skill_per: res.data[i][20],
              office_skill_per: res.data[i][21],
              awards_per: res.data[i][22],
              certificates: res.data[i][23],
              political_status: res.data[i][24],
              postal_code: res.data[i][25],
              school_level: res.data[i][26],
              courses: res.data[i][27],
              edu_gpa: res.data[i][28],
              job_title: res.data[i][29],
              company_name: res.data[i][30],
              work_date: res.data[i][31],
              work_description: res.data[i][32],
              work_industry: res.data[i][33],
              work_year: res.data[i][34],
              project_name: res.data[i][35],
              project_position: res.data[i][36],
              project_date: res.data[i][37],
              project_description: res.data[i][38],
              social_pos:res.data[i][39],
              social_description: res.data[i][40],
              social_cpy: res.data[i][41],
              social_date: res.data[i][42],
              train_org: res.data[i][43],
              training_description: res.data[i][44],
              train_date: res.data[i][45],
              self_evaluation: res.data[i][46],
              candidate_job_title: res.data[i][47],
              parsing_time: res.data[i][48],
              resume_type: res.data[i][49],
              resume_name: res.data[i][50],
              path_resume: res.data[i][51],
              avatar_url: res.data[i][52],
              pred_salary: res.data[i][53],
              pos_tags: res.data[i][54],
              skills_tags: res.data[i][55],
              username: res.data[i][56]
            })
            // console.log('写入resumeTable后', that.resumeTable)
            for (var i in that.resumeTable) {
              that.data_processing(that.resumeTable[i])
            }
            // console.log('---resumeTable:', that.resumeTable)
          }
          console.log("that.resumeTable:", that.resumeTable)

          // this.reload
          if(that.resumeTable.length > 0){
            that.activeTable = 1
          }else{
            that.activeTable = 0
          }
        }
      }).catch(err => {
        this.$message.error(err.message);
        console.log(err)
      })
    },
    // 查看解析的简历
    getAnalysisResult(index, row){
      this.item_detail = row
      this.resumeType = row.resume_type
      this.active = 1
      console.log('简历详情显示的信息为：',this.item_detail)
      let formData = new FormData()
      formData.append('name_per', this.item_detail.name_per)
      formData.append('sex_per', this.item_detail.sex_per)
      formData.append('age_per', this.item_detail.age_per)
      formData.append('highest_edu_per', this.item_detail.highest_edu_per)
      formData.append('major_per', this.item_detail.major_per)
      formData.append('gra_school_per', this.item_detail.gra_school_per)
      formData.append('work', JSON.stringify(this.item_detail.work))
      formData.append('skills_tags', this.item_detail.skills_tags)
      formData.append('political_status', this.item_detail.political_status)
      formData.append('address_per', this.item_detail.address_per)
      formData.append('pred_salary', this.item_detail.pred_salary)
      const config = {
        headers: {
        'Content-Type': 'multipart/form-data'
        }
      }
      var that = this
      axios.post("http://81.68.169.78:5000/talent_myspic", formData).then(function(response) {
					console.log("response.data:", response.data)
					if (response.status === 200) {
            // that.resumeUrl = response.data
            // that.resumeName = response.data.split("\\")[response.data.split("\\").length-1]
						// console.log(that.resumeName);
            that.drawLine(response.data)
					}
				}).catch(err => {
					this.$message.error(err.message);
					console.log(err)
				})
    },
    // 删除简历
    resumeDelete(index, row){
      console.log("row:", row)
      this.$confirm('确认是否删除此简历？', {
					confirmButtonText: '确认',
					cancelButtonText: '取消', //相当于取消按钮
					type: 'warning'
				}).then(() => {
          this.resumeId = row.id
					let formData = new FormData()
          formData.append('id', this.resumeId)
          formData.append('username', Global.username)
					// console.log(formData.get('resumePath'))
          const config = {
						headers: {
						'Content-Type': 'multipart/form-data'
						}
					}
					var that = this
					axios.post('http://81.68.169.78:5000/resumeDelete2', formData, config).then(res => {
						console.log("res:", res)
						if(res.status=="200"){
							that.$notify({
								title: '成功',
								message: '简历'+row.resume_name+'删除成功！',
								type: 'success'
							})
              that.total = res.data.length
              that.resumeTable = []
              for (var i = 0; i < res.data.length; i++) {
                for (var j = 0; j < res.data[i].length; j++) {
                  if (res.data[i][j] == null || res.data[i][j] === 'undefined') {
                    res.data[i][j] = ''
                  }
                }
                console.log('写入resumeTable前', that.resumeTable)
                var highest_edu = ""
                if(res.data[i][14] === ""){
                  highest_edu = "未知"
                }else{
                  highest_edu = res.data[i][14]
                }
                var age = ''
                if(res.data[i][4] == -1){
                  age = '未知'
                }else{
                  age = res.data[i][4]
                }
                var name = ''
                if(res.data[i][1] == ""){
                  name = '未知'
                }else{
                  name = res.data[i][1]
                }
                if(i == 3){
                  console.log(highest_edu, age, name)
                }
                that.resumeTable.push({
                  id: res.data[i][0] + '',
                  name_per: name,
                  sex_per: res.data[i][2],
                  email_per: res.data[i][3],
                  age_per: age,
                  phone_per: res.data[i][5],
                  qq: res.data[i][6],
                  weixin: res.data[i][7],
                  address_per: res.data[i][8],
                  height: res.data[i][9],
                  weight: res.data[i][10],
                  race: res.data[i][11],
                  nationality: res.data[i][12],
                  marital_status: res.data[i][13],
                  highest_edu_per: highest_edu,
                  adm_date: res.data[i][15],
                  gra_date: res.data[i][16],
                  gra_school_per: res.data[i][17],
                  major_per: res.data[i][18],
                  lan_skill_per: res.data[i][19],
                  prof_skill_per: res.data[i][20],
                  office_skill_per: res.data[i][21],
                  awards_per: res.data[i][22],
                  certificates: res.data[i][23],
                  political_status: res.data[i][24],
                  postal_code: res.data[i][25],
                  school_level: res.data[i][26],
                  courses: res.data[i][27],
                  edu_gpa: res.data[i][28],
                  job_title: res.data[i][29],
                  company_name: res.data[i][30],
                  work_date: res.data[i][31],
                  work_description: res.data[i][32],
                  work_industry: res.data[i][33],
                  work_year: res.data[i][34],
                  project_name: res.data[i][35],
                  project_position: res.data[i][36],
                  project_date: res.data[i][37],
                  project_description: res.data[i][38],
                  social_pos:res.data[i][39],
                  social_description: res.data[i][40],
                  social_cpy: res.data[i][41],
                  social_date: res.data[i][42],
                  train_org: res.data[i][43],
                  training_description: res.data[i][44],
                  train_date: res.data[i][45],
                  self_evaluation: res.data[i][46],
                  candidate_job_title: res.data[i][47],
                  parsing_time: res.data[i][48],
                  resume_type: res.data[i][49],
                  resume_name: res.data[i][50],
                  path_resume: res.data[i][51],
                  avatar_url: res.data[i][52],
                  pred_salary: res.data[i][53],
                  pos_tags: res.data[i][54],
                  skills_tags: res.data[i][55],
                  username: res.data[i][56]
                })
                console.log('写入resumeTable后', that.resumeTable)
              }
              // console.log("that.resumeTable:", that.resumeTable)

              // this.reload()
						}
          }).catch(error => {
						console.error(error)
					})
				}).catch(action => {
					this.$message({
					type: 'info',
					message: '成功取消删除此简历！'
				});
				})
    },
    // 返回解析初始页面
    go_back() {
      if (this.mod_justnow === true) {
        // 刚刚进行了修改操作，现在需要将原来的信息的id传到后端进行查询，然后显示最新的信息
        this.getResume()
        this.mod_justnow = false
      }
      this.active = 0
      this.talentEvl_list = []
    },
    // 列表数据处理
    data_processing(item){
      for (var i in item) {
        // console.log(i)
        if (i ==='work_year'){
          if(item[i] != ''){
            item[i] = parseInt(item[i])
            item[i] = item[i]+'年'
          }
        }
        if (i ==='age_per'){
          if(item[i] == '-1'){
            console.log(item[i])
            item[i] = ''
            console.log(item[i])
          }
        }
        // console.log('item[i]:', item[i].toString().type())
        if (item[i].toString().indexOf('Ж')!= -1) {
          item[i] = item[i].split('Ж')
        }
      }

      // 教育
      var edu = []
      //遍历列表
      if (typeof (item.adm_date) != "string"){
        for (var i =0;i<item.adm_date.length;i++){
          edu.push({
            adm_date : item.adm_date[i],
            gra_date : item.gra_date[i],
            gra_school_per : item.gra_school_per[i],
            major_per : item.major_per[i],
            edu_gpa : item.edu_gpa[i],
            courses : item.courses[i],
            school_level : item.school_level[i],
          })
        }
      }

      if (edu.length==0){
        if (item.adm_date == "" &&item.gra_date == "" &&item.gra_school_per == "" &&item.major_per == "" &&item.school_level == "" &&item.edu_gpa == "" &&item.courses == ""){

        }else {
          edu.push({
            adm_date : item.adm_date,
            gra_date : item.gra_date,
            gra_school_per : item.gra_school_per,
            major_per : item.major_per,
            edu_gpa : item.edu_gpa,
            courses : item.courses,
            school_level : item.school_level,
          })
        }
      }
      // 工作
      var work = []
      if (typeof (item.work_date) != "string") {
        for (var i = 0; i < item.work_date.length; i++) {
          work.push({
            work_date: item.work_date[i],
            work_description: item.work_description[i],
            // work_industry: item.work_industry[i]+'',
            company_name: item.company_name[i],
            job_title: item.job_title[i],
          })
        }
      }
      if (work.length==0){
        if (item.work_date == "" &&item.work_description == "" &&item.work_industry == "" &&item.company_name == "" &&item.job_title == "" ){

        }else {
          work.push({
            work_date : item.work_date,
            work_description : item.work_description,
            work_industry : item.work_industry,
            company_name : item.company_name,
            job_title : item.job_title,
          })
        }
      }
      // 项目
      var project = []
      if (typeof (item.project_name) != "string") {
        for (var i = 0; i < item.project_name.length; i++) {
          project.push({
            project_name: item.project_name[i],
            project_description: item.project_description[i],
            project_date: item.project_date[i],
            project_position: item.project_position[i]
          })
        }
      }
      if (project.length==0){
        if (item.project_name == "" &&item.project_description == "" &&item.project_date == "" &&item.project_position == "" ){

        }else {
          project.push({
            project_name : item.project_name,
            project_description : item.project_description,
            project_date : item.project_date,
            project_position : item.project_position
          })
        }
      }
      // 社会
      var social = []
      if (typeof (item.social_pos) != "string") {
        for (var i = 0; i < item.social_pos.length; i++) {
          social.push({
            social_pos: item.social_pos[i],
            social_date: item.social_date[i],
            social_cpy: item.social_cpy[i],
            social_description: item.social_description[i]
          })
        }
      }
      if (social.length==0){
        if (item.social_pos == "" &&item.social_date == "" &&item.social_cpy == "" &&item.social_description == "" ){

        }else {
          social.push({
            social_pos : item.social_pos,
            social_date : item.social_date,
            social_cpy : item.social_cpy,
            social_description : item.social_description
          })
        }
      }
      // 培训
      var train = []
      if (typeof (item.train_org) != "string") {
        for (var i = 0; i < item.train_org.length; i++) {
          train.push({
            train_org: item.train_org[i],
            training_description: item.training_description[i],
            train_date: item.train_date[i]
          })
        }
      }
      if (train.length==0){
        if (item.social_pos == "" &&item.social_date == "" &&item.social_cpy == "" &&item.social_description == "" ){

        }else {
          train.push({
            train_org : item.train_org,
            training_description : item.training_description,
            train_date : item.train_date
          })
        }
      }
      item.edu = edu
      item.work = work
      item.project = project
      item.social = social
      item.train = train
    },
    // 画图
    drawLine(resData) {
      let myChart = this.$echarts.init(document.getElementById('myChart'))
      let dataMax = [
        { name: '性别', max: '100', color: '#3155eb' },
        { name: '年龄', max: '100', color: '#3155eb' },
        { name: '学历', max: '100', color: '#5b9874' },
        { name: '专业', max: '100', color: '#5b9874' },
        { name: '学校', max: '100', color: '#5b9874' },
        { name: '工作年限', max: '100', color: '#5b9874' },
        { name: '公司', max: '100', color: '#5b9874' },
        { name: '技能', max: '100', color: '#5b9874' },
        { name: '政治面貌', max: '100', color: '#3155eb' },
        { name: '地区', max: '100', color: '#3155eb' },
      ]
      var sex_score = resData['性别分数']
      if(resData['性别分数']==0){
        sex_score = 90
      }
      var age_score = resData['年龄分数']
      if(resData['年龄分数']==0){
        age_score = 89
      }
      var edu_score = resData['学历分数']
      if(resData['学历分数']==0){
        edu_score = 92
      }
      var major_score = resData['专业分数']
      if(resData['专业分数']==0){
        major_score = 88
      }
      var school_score = resData['学校分数']
      if(resData['学校分数']==0){
        school_score = 91
      }
      var workTime_score = resData['工作时长分数']
      if(resData['学校分数']==0){
        workTime_score = 60
      }
      var company_score = resData['公司分数']
      if(resData['公司分数']==0){
        company_score = 60
      }
      var skills_score = resData['专业技能分数']
      if(resData['专业技能分数']==0){
        skills_score = 90
      }
      var politicalStatus_score = resData['政治面貌分数']
      if(resData['政治面貌分数']==0){
        politicalStatus_score = 70
      }
      var address_score = resData['籍贯或地址分数']
      if(resData['籍贯或地址分数']==0){
        address_score = 75
      }
      var composite_score = resData['综合分']
      if(resData['综合分']==0){
        composite_score = 90
      }
      this.talentEvl_list = []
      this.talentEvl_list[0]=resData['性别']
      this.talentEvl_list[1]=resData['年龄']
      this.talentEvl_list[2]=resData['政治面貌']
      this.talentEvl_list[3]=resData['地点']
      this.talentEvl_list[4]=resData['学历']
      this.talentEvl_list[5]=resData['专业']
      this.talentEvl_list[6]=resData['学校']
      this.talentEvl_list[7]=resData['工作时长']
      this.talentEvl_list[8]=resData['公司']
      this.talentEvl_list[9]=resData['技能']
      this.talentEvl_list[10]=resData['综合分']
      // 雷达图
      let option = {
        legend: {
          icon: 'roundRect',  //图例图形样式 
          data: ['基础信息', '教育/工作经历'],
          y:'bottom',
          x:'center',  //图例位置
          // textStyle: {   //图例文字样式
          //     color: '#3155eb',
          // },
        },
        //配置维度的最大值
        radar: {
          // name: {
          //   show: true,
          //   color: 'red',
          // },
          //   雷达图的指示器，用来指定雷达图中的多个变量（维度）
          indicator: dataMax,
          shape: 'circle', //对雷达图形设置成一个圆形,可选 circle:圆形,polygon:多角形(默认)
        },
        series: [
          {
            type: 'radar',
            label: {
              show: false, //显示数值
            },
            symbolSize: 0, // 拐点的大小
            areaStyle: {
              // color: '#ACB9FF', // 图表背景的颜色
              // type: 'dotted'
            }, //每个雷达图形成一个阴影的面积
            data: [
              // {
              //   name: '基础信息',
              //   value: [sex_score, age_score, edu_score, major_score, school_score, workTime_score, 
              //           company_score, skills_score, politicalStatus_score, address_score],
              //   itemStyle: {
              //   normal: {
              //       color: '#ACB9FF',
              //       // lineStyle: {
              //       //     width: 20,
              //       //     color: '#2087D8',
              //       // }
              //   }
              // },
              // },
              {
                name: '基础信息',
                value: [sex_score, age_score,edu_score,0,0,0,0,skills_score, politicalStatus_score, address_score],
                itemStyle: {
                  normal: {
                      color: '#3155eb',
                      // lineStyle: {
                      //     width: 20,
                      //     color: '#3155eb',
                      // }
                  },
                },
                textStyle:{
                    color:'#3155eb'
                  }
              },
              {
                name: '教育/工作经历',
                value: [0,0,edu_score, major_score, school_score, workTime_score, company_score, skills_score,0,0],
                itemStyle: {
                normal: {
                    color: '#5b9874',
                    lineStyle: {
                        width: 20,
                        color: '#5b9874',
                    }
                }
              },
              },
            ],
          },
        ],
        // splitLine: {     //分隔线样式
        //         lineStyle: {
        //             color: '#86D9FF',
        //             opacity: '0.3',
        //             type: 'dotted'
        //         },
        //     },
      }
      // 绘制图表
      myChart.setOption(option)

      //环形图1
      var myCharts = this.$echarts.init(document.getElementById('myCharts'))
      var options = {
        tooltip: {
          trigger: 'item'
        },
        title: {
          text: composite_score+"分",  
          left: "center",//对齐方式居中
          // center:['30%', "50%"],
          top: "30px",//距离顶部
          // left: "9%",
          textStyle: {
            color: "red",//文字颜色
            fontSize: 14,//字号
            // align: "center"//对齐方式
          }
        },
        series: [
          {
            type: 'pie',
            center: ['50%', '50%'], //修改圆心位置
            radius: ['50%', '70%'],
            color:['red', '#e7e7e7'],
            labelLine:{
              show:false,
              // position: 'outside'
            },
            label: {
              show: false,
              position: 'top',
              right: 'right'
              // position: 'right'
            },
            data: [
              { value: this.talentEvl_list[10], name: "综合分:"+this.talentEvl_list[10] },
              { value: 100-this.talentEvl_list[10], name:"差"}
            ]
          }
        ]
      };
      myCharts.setOption(options)
      //环形图1
      var myChart2 = this.$echarts.init(document.getElementById('myChart2'))
      var option2 = {
        title: {
          text: sex_score+"分",  
          left: "center",//对齐方式居中
          // center:['30%', "50%"],
          top: "20px",//距离顶部
          // left: "9%",
          textStyle: {
            color: "#3155eb",//文字颜色
            fontSize: 12,//字号
            // align: "center"//对齐方式
          }
        },
        series: [
          {
            type: 'pie',
            center: ['50%', '50%'], //修改圆心位置
            radius: ['55%', '70%'],
            color:['#3155eb', '#e7e7e7'],
            labelLine:{
              show:false,
              // position: 'outside'
            },
            label: {
              show: false,
              position: 'top',
              right: 'right'
              // position: 'right'
            },
            data: [
              { value: sex_score, name: "性别" },
              { value: 100-sex_score, name:"差"}
            ]
          }
        ]
      };
      myChart2.setOption(option2) 

      //环形图2
      var myChart3 = this.$echarts.init(document.getElementById('myChart3'))
      var option3 = {
        title: {
          text: age_score+"分",  
          left: "center",//对齐方式居中
          // center:['30%', "50%"],
          top: "20px",//距离顶部
          textStyle: {
            color: "#3155eb",//文字颜色
            fontSize: 12,//字号
            // align: "center"//对齐方式
          }
        },
        series: [
          {
            type: 'pie',
            center: ['50%', '50%'], //修改圆心位置
            radius: ['55%', '70%'],
            color:['#3155eb', '#e7e7e7'],
            labelLine:{
              show:false,
              // position: 'outside'
            },
            label: {
              show: false,
              position: 'top',
              right: 'right'
              // position: 'right'
            },
            data: [
              { value: age_score, name: "年龄" },
              { value: 100-age_score, name:"差"}
            ]
          }
        ]
      };
      myChart3.setOption(option3) 

      //环形图3
      var myChart4 = this.$echarts.init(document.getElementById('myChart4'))
      var option4 = {
        title: {
          text: politicalStatus_score+"分",  
          left: "center",//对齐方式居中
          // center:['30%', "50%"],
          top: "20px",//距离顶部
          textStyle: {
            color: "#3155eb",//文字颜色
            fontSize: 12,//字号
            // align: "center"//对齐方式
          }
        },
        series: [
          {
            type: 'pie',
            center: ['50%', '50%'], //修改圆心位置
            radius: ['55%', '70%'],
            color:['#3155eb', '#e7e7e7'],
            labelLine:{
              show:false,
              // position: 'outside'
            },
            label: {
              show: false,
              position: 'top',
              right: 'right'
              // position: 'right'
            },
            data: [
            { value: politicalStatus_score, name: "政治面貌" },
              { value: 100-politicalStatus_score, name:"差"}
            ]
          }
        ]
      };
      myChart4.setOption(option4) 

      //环形图4
      var myChart5 = this.$echarts.init(document.getElementById('myChart5'))
      var option5 = {
        title: {
          text: address_score+"分",  
          left: "center",//对齐方式居中
          // center:['30%', "50%"],
          top: "20px",//距离顶部
          textStyle: {
            color: "#3155eb",//文字颜色
            fontSize: 12,//字号
            // align: "center"//对齐方式
          }
        },
        series: [
          {
            type: 'pie',
            center: ['50%', '50%'], //修改圆心位置
            radius: ['55%', '70%'],
            color:['#3155eb', '#e7e7e7'],
            labelLine:{
              show:false,
              // position: 'outside'
            },
            label: {
              show: false,
              position: 'top',
              right: 'right'
              // position: 'right'
            },
            data: [
              { value: address_score, name: "地区" },
              { value: 100-address_score, name:"差"}
            ]
          }
        ]
      };
      myChart5.setOption(option5) 

      //环形图5
      var myChart6 = this.$echarts.init(document.getElementById('myChart6'))
      var option6 = {
        title: {
          text: edu_score+"分",  
          left: "center",//对齐方式居中
          // center:['30%', "50%"],
          top: "20px",//距离顶部
          textStyle: {
            color: "#5b9874",//文字颜色
            fontSize: 12,//字号
            // align: "center"//对齐方式
          }
        },
        series: [
          {
            type: 'pie',
            center: ['50%', '50%'], //修改圆心位置
            radius: ['55%', '70%'],
            color:['#5b9874', '#e7e7e7'],
            labelLine:{
              show:false,
              // position: 'outside'
            },
            label: {
              show: false,
              position: 'top',//
              right: 'right'
              // position: 'right'
            },
            data: [
              { value: edu_score, name: "学历"},
              { value: 100-edu_score, name:"差"}
            ]
          }
        ]
      };
      myChart6.setOption(option6) 

       //环形图6
      var myChart7 = this.$echarts.init(document.getElementById('myChart7'))
      var option7 = {
        title: {
          text: major_score+"分",  
          left: "center",//对齐方式居中
          // center:['30%', "50%"],
          top: "20px",//距离顶部
          textStyle: {
            color: "#5b9874",//文字颜色
            fontSize: 12,//字号
            // align: "center"//对齐方式
          }
        },
        series: [
          {
            type: 'pie',
            center: ['50%', '50%'], //修改圆心位置
            radius: ['55%', '70%'],
            color:['#5b9874', '#e7e7e7'],
            labelLine:{
              show:false,
              // position: 'outside'
            },
            label: {
              show: false,
              position: 'top',
              right: 'right'
              // position: 'right'
            },
            data: [
              { value: major_score, name: "专业" },
              { value: 100-major_score, name:"差"}
            ]
          }
        ]
      };
      myChart7.setOption(option7)

       //环形图7
      var myChart8 = this.$echarts.init(document.getElementById('myChart8'))
      var option8 = {
        title: {
          text: school_score+"分",  
          left: "center",//对齐方式居中
          // center:['30%', "50%"],
          top: "20px",//距离顶部
          textStyle: {
            color: "#5b9874",//文字颜色
            fontSize: 12,//字号
            // align: "center"//对齐方式
          }
        },
        series: [
          {
            type: 'pie',
            center: ['50%', '50%'], //修改圆心位置
            radius: ['55%', '70%'],
            color:['#5b9874', '#e7e7e7'],
            labelLine:{
              show:false,
              // position: 'outside'
            },
            label: {
              show: false,
              position: 'top',
              right: 'right'
              // position: 'right'
            },
            data: [
            { value: school_score, name: "学校"},
              { value: 100-school_score, name:"差"}
            ]
          }
        ]
      };
      myChart8.setOption(option8)

      //环形图6
      var myChart9 = this.$echarts.init(document.getElementById('myChart9'))
      var option9 = {
        title: {
          text: workTime_score+"分",  
          left: "center",//对齐方式居中
          // center:['30%', "50%"],
          top: "20px",//距离顶部
          textStyle: {
            color: "#5b9874",//文字颜色
            fontSize: 12,//字号
            // align: "center"//对齐方式
          }
        },
        series: [
          {
            type: 'pie',
            center: ['50%', '50%'], //修改圆心位置
            radius: ['55%', '70%'],
            color:['#5b9874', '#e7e7e7'],
            labelLine:{
              show:false,
              // position: 'outside'
            },
            label: {
              show: false,
              position: 'top',
              right: 'right'
              // position: 'right'
            },
            data: [
            { value: workTime_score, name: "工作时长"},
              { value: 100-workTime_score, name:"差"}
            ]
          }
        ]
      };
      myChart9.setOption(option9)

       //环形图9
      var myChart10 = this.$echarts.init(document.getElementById('myChart10'))
      var option10 = {
        title: {
          text: company_score+"分",  
          left: "center",//对齐方式居中
          // center:['30%', "50%"],
          top: "20px",//距离顶部
          textStyle: {
            color: "#5b9874",//文字颜色
            fontSize: 12,//字号
            // align: "center"//对齐方式
          }
        },
        series: [
          {
            type: 'pie',
            center: ['50%', '50%'], //修改圆心位置
            radius: ['55%', '70%'],
            color:['#5b9874', '#e7e7e7'],
            labelLine:{
              show:false,
              // position: 'outside'
            },
            label: {
              show: false,
              position: 'top',
              right: 'right'
              // position: 'right'
            },
            data: [
            { value: company_score, name: "公司" },
              { value: 100-company_score, name:"差"}
            ]
          }
        ]
      };
      myChart10.setOption(option10)

      //环形图10
      var myChart11 = this.$echarts.init(document.getElementById('myChart11'))
      var option11 = {
        title: {
          text: skills_score+"分",  
          left: "center",//对齐方式居中
          // center:['30%', "50%"],
          top: "20px",//距离顶部
          textStyle: {
            color: "#5b9874",//文字颜色
            fontSize: 12,//字号
            // align: "center"//对齐方式
          }
        },
        series: [
          {
            type: 'pie',
            center: ['50%', '50%'], //修改圆心位置
            radius: ['55%', '70%'],
            color:['#5b9874', '#e7e7e7'],
            labelLine:{
              show:false,
              // position: 'outside'
            },
            label: {
              show: false,
              position: 'top',
              right: 'right'
              // position: 'right'
            },
            data: [
            { value: skills_score, name: "技能"},
              { value: 100-skills_score, name:"差"}
            ]
          }
        ]
      };
      myChart11.setOption(option11)
    },
  },
}
</script>

<style>
  .el-tabs__active-bar {
    background-color: transparent !important;
    background-image: linear-gradient(
    	90deg, transparent 0, transparent 27%,
    	#4d72f6 0, #4d72f6 73%,
    	transparent 0, transparent
    );
  }
  .el-tabs__nav-wrap::after {
    position: static !important;
  }
  .el-popover.el_popover_class1{
    font-size: 14px !important;
    /* color: #00aaff; */
    /* width: 400px;
    height: 20px; */
    /* padding: 5%;*/
    background-color: white !important;
  }
  .el-icon-my-button{
    background: url('../../../src/icons/灯泡.png') no-repeat;
    font-size: 16px;
    background-size: cover;
  }
  .el-button--medium.is-circle{
    border: 0;
    max-height: 8px;
    max-width: 8px;
    /* 设置中间的图标位置使居中 */
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .el-icon-question:before{
    font-size: 16px;
  }
  .el-tabs--card .el-tabs__header{
    /* border-bottom: 1 solid #dfe4ed; */
    display: flex;
  }
  .el-tabs__nav-wrap{
    overflow: visible;
  }
  .el-tabs--card > .el-tabs__header .el-tabs__nav{
    border-bottom: 1px solid #dfe4ed;
  }
</style>

<style scoped>
.empty_box {
  margin: 20px auto;
  text-align: center;
  line-height: 100px;
  width: 700px;
  height: 100px;
  /*background-color: #ffecec;*/
  /*border: #2299dd;*/
  border-style: dotted;
  border-width: 2px;
  border: 2px dotted #2e8bff;
  border-radius: 15px;
}
</style>

<style scoped>
.biaoqian{
  background-color: #fff6e9;
  color: #ffa817;
  font-family: "Times New Roman";
  display: inline-block;
  padding: 2px 4px;
  margin: 5px 4px;
  /*margin-top: 10px;*/
  border-style: solid;
  border-radius: 5px;
  border-width: 1px;
  text-align: right;
}
.empty_box {
  margin: 20px auto;
  text-align: center;
  line-height: 100px;
  width: 700px;
  height: 100px;
  /*background-color: #ffecec;*/
  /*border: #2299dd;*/
  border-style: dotted;
  border-width: 2px;
  border: 2px dotted #2e8bff;
  border-radius: 15px;
}
.big1 lable{
  /*background-color: #c25959;*/
  font-size: small;
  width: 60px;
  display: inline-block;
  text-align: right;
  margin: 10px 20px;
}
.big1 .xiugai {
  width: 80%;
}
.big1 .xiugai span input{
  font-size: small;
  width: 100%;
  height: 32px;
  line-height: 30px;
  color: gray;
}
.big1 .xiugai span{
  /*background-color: #aa1111;*/
  width: 60%;
  /*font-size: 27px;*/
  display: inline-block;
}
.big1 .xiugai .elbtn{
  width: 70px;
  height: 40px;
  font-size: small;
}

.big1 .teil{
  width: 90%;
  height: 100px;
  margin: 30px auto;
  /*background-color: #6366ff;*/
}
.big1 .six{
  width: 90%;
  margin: 0px auto;
  margin-top: 130px;
  /*background-color: #6366ff;*/
}
.big1 .five{
  width: 90%;
  margin: 0px auto;
  margin-top: 130px;
  /*background-color: #efff63;*/
}
.big1 .four{
  width: 90%;
  margin: 0px auto;
  margin-top: 100px;
  /*background-color: #ffac63;*/
}
.big1 .thr{
  width: 90%;
  margin: 0px auto;
  margin-top: 100px;
  /*background-color: #f88eff;*/
}
.big1 ul{
  list-style-type: none;
}
.big1 ul li{
  font-size: large;
  margin-top: 25px;
  color: #9198a5;
}
.big li div {
  font-size: 16px !important;
}
.big1 li .dian{
  color: #6873e5;
}
.big1 li span{
  color: #494949;
  /*line-height: 40px;*/
  font-size: 16px;
}
.big1 div .left{
  width: 50%;
  height: 100%;
  display: inline-block;
  left: 0px;
  /*background-color: #ff8b8b;*/
}
.big1 div .right{
  width: 50%;
  height: 100%;
  display: inline-block;
  float: right;
  /*background-color: #e5d98c;*/
}
.big1 div .botom li,ul{
  margin-top: 5px !important;
}
.big1 .title_box{
  position: absolute;
  margin-top: 20px;
  width: 100%;
  height: 100px;
  /*background-color: #af3f3f;*/
}
.big1 ._title_down{
  /*底色  设置长、宽、背景色*/
  width: 150px;
  height: 40px;
  /*background-color: #ffd9b2;*/
  position: absolute;
  left: 30px;
  top: 10px;
}
.big1 ._title{
  /*文字  设置长、宽、字号、粗细、最上方显示*/
  z-index: 999;
  width: 200px;
  height: 60px;
  font-size: xx-large;
  font-weight: normal;
  position: absolute;
  left: 40px;
  top: 10px;
}
.big1 .fenjiexian {
  border: black;
  padding: 3px;
  margin-top: -20px;
  background: repeating-linear-gradient(135deg, #d0d0d0 0px, #09090a 1px, transparent 1px, transparent 6px);
}
.big1 .two{
  overflow: hidden;
  width: 90%;
  height: 150px;
  margin: 20px auto;
  /*background-color: #8aff63;*/
}
.big1 .two .sinfo{
  width: 83%;
  height: 100%;
  float: right;
  /*background-color: #fff;*/
}
.big1 .two .imgg{
  width: 12%;
  display: inline-block;
}
.big1 .two .name{
  height: 70px;
  font-size: 35px;
  font-weight: bolder;
  line-height: 70px;
  text-align: left;
  display: block;
  /*background-color: #fff;*/
}
.big1 .two .sinfos{
  margin-top: 10px;
  height: 50px;
  color: #8a919f;
  /*background-color: #ffefef;*/
}
.big1 i {
  margin-right: 6px;
}
.big1 .mar_left{
  margin-left: 20px;
}
.big1 .one{
  width: 90%;
  height: 40px;
  margin: 30px auto;
  /*background-color: #e3e3e3;*/
}
.big1 .one .zhongwenjianli{
  width: 70px;
  height: 40px;
  line-height: 40px;
  text-align: center;
  color: #3155eb;
  font-size: small;
  border-style: solid;
  border-width: medium;
  border-color: #aec6ff;
  border-radius: 10px;
  background-color: #f0f5ff;
}
/*.big1 .info{*/
/*  width: 80%;*/
/*  height: 95%;*/
/*  overflow: auto;*/
/*  position: absolute;*/
/*  left: 10%;*/
/*  background-color: #ffffff;*/
/*  margin-top: 20px;*/
/*  -webkit-box-shadow: #666 0px 0px 50px;*/
/*  -moz-box-shadow: #666 0px 0px 50px;*/
/*  box-shadow: #666 0px 0px 20px;*/
/*}*/

.big1 .info{
  width: 60%;
  height: 95%;
  overflow: auto;
  position: absolute;
  top: 0;left:0;right:0;bottom:0;
  margin: auto;
  background-color: #ffffff;
  -webkit-box-shadow: #666 0px 0px 50px;
  -moz-box-shadow: #666 0px 0px 50px;
  box-shadow: #666 0px 0px 20px;
}
.active{
  visibility: hidden;
}
.big form div {
  margin-bottom: 5px;
}
.big lable{
  /*background-color: #c25959;*/
  font-size: inherit;
  width: 100px;
  display: inline-block;
  text-align: right;
  margin-right: 10px;
  margin-bottom: 20px;
}
.big .dia {
  width: 80%;
}
.big .dia span input{
  font-size: small;
  width: 100%;
  height: 32px;
  line-height: 30px;
  color: gray;
}
.big .dia span{
  /*background-color: #aa1111;*/
  width: 60%;
  /*font-size: 27px;*/
  display: inline-block;
}
.big .dia .elbtn{
  padding: 0!important;
  width: 70px;
  height: 40px;
  text-align: center;
  font-size: small;
}
.big .imgg{
  width: 8%;
  display: inline-block;
  float: left;
  padding-bottom: 20px;
}
.big .info{
  width: 90%;
  float: right;
  display: inline-block;
  padding-bottom: 10px;
}
.big .caozuo{
  width: 80%;
  margin: 0px auto;
  margin-bottom: 20px;
}
.big .forth{
  font-size: small;
  margin-top: 10px;
  /*background-color: #a1ff5e;*/
}
.big .th {
  font-size: small;
  margin-top: 10px;
  /*background-color: #a8ffc5;*/
}
.big .sec{
  font-weight: bold;
  color: #6873e5;
  font-size: small;
  margin-top: 10px;
  /*background-color: #ffe7e7;*/
}
.big .display__name{
  font-size: x-large;
  font-family: 黑体;
  /*background-color: #fc6a6a;*/
}
.big{
  margin-top: 30px;
}
.big .item {
  padding: 7px 0px;
}

.big .box-card {
  /*width: 70%;*/
  width: 900px;
  margin: 0px auto;
  border-radius: 20px;
}
.big .box-card:hover {
  width: 920px;
  margin: 0px auto;
  border-radius: 20px;
  box-shadow: #9e9e9e 10px 10px 10px;
  transform: translateY(-1px);
}
</style>