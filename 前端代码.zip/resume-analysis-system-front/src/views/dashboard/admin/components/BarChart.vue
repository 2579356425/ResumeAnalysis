<template>
  <div :class="className" :style="{height:height,width:width}" />
</template>

<script>
import echarts from 'echarts'
require('echarts/theme/macarons') // echarts theme
import resize from './mixins/resize'

const animationDuration = 6000

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '300px'
    }
  },
  data() {
    return {
      chart: null
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart()
    })
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons')
      // const path = 'http://81.68.169.78:5000/resume_count_edu'
			// 	var that = this
			// 	axios.get(path).then(res => {
			// 		console.log(res.data)
			// 		// console.log(res.data.length)
			// 		// for (var i = 0; i < res.data.length; i++) {
			// 		// 	that.aurls.push(res.data[i][1])
			// 		// }
			// 		// console.log(that.aurls)
			// 		// that.total_easy_business = res.data.length
			// 	}).catch(error => {
			// 		console.error(error)
			// 	})
      this.chart.setOption({
        tooltip: {
          trigger: 'axis',
          axisPointer: { // 坐标轴指示器，坐标轴触发有效
            type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
          }
        },
        grid: {
          top: 10,
          left: '2%',
          right: '2%',
          bottom: '3%',
          containLabel: true
        },
        xAxis: [{
          type: 'category',
          data: ['小学','初中','高中', '专科', '本科', '硕士', '博士'],
          axisTick: {
            alignWithLabel: true
          }
        }],
        yAxis: [{
          type: 'value',
          axisTick: {
            show: false
          }
        }],
        series: [{
          name: '上传简历数',
          type: 'bar',
          stack: 'vistors',
          barWidth: '50%',
          data: [0,0,33,38, 84, 52, 24],
          animationDuration
        },{
          name: '画像构建次数',
          type: 'bar',
          stack: 'vistors',
          barWidth: '50%',
          data: [0,0,18, 22, 43, 31, 15],
          animationDuration
        },{
          name: '人岗匹配次数',
          type: 'bar',
          stack: 'vistors',
          barWidth: '50%',
          data: [0,0,24, 12, 52, 48, 22],
          animationDuration
        }]
      })
    },
    getResumeNum(){
      
    }
  },
  init(){
    this.initChart()
  }
}
</script>
