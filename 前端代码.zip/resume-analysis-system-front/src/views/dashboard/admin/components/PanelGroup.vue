<template>
	<el-row :gutter="40" class="panel-group">
		<el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
			<div class="card-panel" @click="handleSetLineChartData('newVisitis')">
				<div class="card-panel-icon-wrapper icon-people">
					<svg-icon icon-class="rili" class-name="card-panel-icon" />
				</div>
				<div class="card-panel-description">
					<div class="card-panel-text">
						今日解析简历
					</div>
					<count-to :start-val="0" :end-val=num_today_analysis_resume :duration="2600" class="card-panel-num" />
				</div>
			</div>
		</el-col>
		<el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
			<div class="card-panel" @click="handleSetLineChartData('messages')">
				<div class="card-panel-icon-wrapper icon-message">
					<svg-icon icon-class="shujuku" class-name="card-panel-icon" />
				</div>
				<div class="card-panel-description">
					<div class="card-panel-text">
						简历数
					</div>
					<count-to :start-val="0" :end-val=num_resume :duration="3000" class="card-panel-num" />
				</div>
			</div>
		</el-col>
		<el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
			<div class="card-panel" @click="handleSetLineChartData('purchases')">
				<div class="card-panel-icon-wrapper icon-money">
					<svg-icon icon-class="wendang1" class-name="card-panel-icon" />
				</div>
				<div class="card-panel-description">
					<div class="card-panel-text">
						画像构建次数
					</div>
					<count-to :start-val="0" :end-val=num_portrait :duration="3200" class="card-panel-num" />
				</div>
			</div>
		</el-col>
		<el-col :xs="12" :sm="12" :lg="6" class="card-panel-col">
			<div class="card-panel" @click="handleSetLineChartData('shoppings')">
				<div class="card-panel-icon-wrapper icon-shopping">
					<svg-icon icon-class="baogao" class-name="card-panel-icon" />
				</div>
				<div class="card-panel-description">
					<div class="card-panel-text">
						人岗匹配次数
					</div>
					<count-to :start-val="0" :end-val=num_person_post :duration="3600" class="card-panel-num" />
				</div>
			</div>
		</el-col>
	</el-row>
</template>

<script>
	import CountTo from 'vue-count-to'
	import axios from 'axios'

	export default {
		data() {
			return {
				num_today_analysis_resume: 6,
				num_resume: 6,
				num_portrait: 6,
				num_person_post: 6, 			
				// analysisResumeTable: [],
				// templateTable: [],
				// reportTable: [],
				// todayReportTable: [],
			}
		},
		components: {
			CountTo
		},
		created() {
			//进入页面之后检索数据库中相关资源的数量，并赋值给对应data
			this.gettodayAnaResumeNum();
			this.getResumeNum();
			this.getPortraitNum();
			this.getPersonPostNum();
		},
		methods: {
			handleSetLineChartData(type) {
				this.$emit('handleSetLineChartData', type)
			},
			// 获取今日解析简历数
			gettodayAnaResumeNum() {
				const path = 'http://81.68.169.78:5000/resume_count_today';
				var that = this
				axios.get(path).then(res => {
					console.log(res.data)
					that.num_today_analysis_resume = res.data;
					// that.num_today_analysis_resume = that.analysisResumeTable.length;
				}).catch(error => {
					console.error(error);
				});
			},// 获取简历数
			getResumeNum() {
				const path = 'http://81.68.169.78:5000/resume_count';
				var that = this
				axios.get(path).then(res => {
					console.log("简历数",res.data)
					that.num_resume = res.data;
					// that.num_template = that.templateTable.length;
				}).catch(error => {
					console.error(error);
				});
			},//获取画像生成次数
			getPortraitNum() {
				const path = 'http://81.68.169.78:5000/getTalent_count';
				var that = this
				axios.get(path).then(res => {
					console.log(res.data)
					that.num_portrait = res.data;
					// that.num_total_gen_report = that.reportTable.length
				}).catch(error => {
					console.error(error);
				});
			},
			// 获取人岗匹配次数
			getPersonPostNum() {
				const path = 'http://81.68.169.78:5000/getPerson_post_count';
				var that = this
				axios.get(path).then(res => {
					console.log(res.data)
					that.num_person_post = res.data;
					// that.num_total_gen_report = that.reportTable.length
				}).catch(error => {
					console.error(error);
				});
			},
		}
	}
</script>

<style lang="scss" scoped>
	.panel-group {
		margin-top: 18px;

		.card-panel-col {
			margin-bottom: 32px;
		}

		.card-panel {
			height: 108px;
			cursor: pointer;
			font-size: 12px;
			position: relative;
			overflow: hidden;
			color: #666;
			background: #fff;
			box-shadow: 4px 4px 40px rgba(0, 0, 0, .05);
			border-color: rgba(0, 0, 0, .05);

			&:hover {
				.card-panel-icon-wrapper {
					color: #fff;
				}

				.icon-people {
					background: #40c9c6;
				}

				.icon-message {
					background: #36a3f7;
				}

				.icon-money {
					background: #f4516c;
				}

				.icon-shopping {
					background: #34bfa3
				}
			}

			.icon-people {
				color: #40c9c6;
			}

			.icon-message {
				color: #36a3f7;
			}

			.icon-money {
				color: #f4516c;
			}

			.icon-shopping {
				color: #34bfa3
			}

			.card-panel-icon-wrapper {
				float: left;
				margin: 14px 0 0 14px;
				padding: 16px;
				transition: all 0.38s ease-out;
				border-radius: 6px;
			}

			.card-panel-icon {
				float: left;
				font-size: 48px;
			}

			.card-panel-description {
				float: right;
				font-weight: bold;
				margin: 26px;
				margin-left: 0px;

				.card-panel-text {
					line-height: 18px;
					color: rgba(0, 0, 0, 0.45);
					font-size: 16px;
					margin-bottom: 12px;
				}

				.card-panel-num {
					font-size: 20px;
				}
			}
		}
	}

	@media (max-width:550px) {
		.card-panel-description {
			display: none;
		}

		.card-panel-icon-wrapper {
			float: none !important;
			width: 100%;
			height: 100%;
			margin: 0 !important;

			.svg-icon {
				display: block;
				margin: 14px auto !important;
				float: none !important;
			}
		}
	}
</style>
