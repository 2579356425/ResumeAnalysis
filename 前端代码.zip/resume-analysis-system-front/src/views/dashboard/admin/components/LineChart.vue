<template>
  <div :class="className" :style="{height:height,width:width}" />
</template>

<script>
import echarts from 'echarts'
require('echarts/theme/macarons') // echarts theme
import resize from './mixins/resize'

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '350px'
    },
    autoResize: {
      type: Boolean,
      default: true
    },
    chartData: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      chart: null,
    }
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        this.setOptions(val)
      }
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart()
    })
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons')
      var xAxisTime = this.getTime()
      this.setOptions(this.chartData, xAxisTime)
      
    },
    setOptions({ expectedData, actualData } = {}, xAxisTime) {
      this.chart.setOption({
        xAxis: {
          // data: ['2023-07-06','2023-07-07','2023-07-08','2023-07-09','2023-07-10', '2023-07-11', '2023-07-12', '2023-07-13', '2023-07-14', '2023-07-15'],
          data: xAxisTime,
          boundaryGap: false,
          axisTick: {
            show: false
          }
        },
        grid: {
          left: 25,
          right: 35,
          bottom: 20,
          top: 30,
          containLabel: true
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross'
          },
          padding: [5, 10]
        },
        yAxis: {
          axisTick: {
            show: false
          }
        },
        legend: {
          data: ['简历解析数量']
        },
        series: [
          // {
        //   name: 'expected', itemStyle: {
        //     normal: {
        //       color: '#FF005A',
        //       lineStyle: {
        //         color: '#FF005A',
        //         width: 2
        //       }
        //     }
        //   },
        //   smooth: true,
        //   type: 'line',
        //   data: expectedData,
        //   animationDuration: 2800,
        //   animationEasing: 'cubicInOut'
        // },
        {
          name: '简历解析数量',
          smooth: false,
          type: 'line',
          itemStyle: {
            normal: {
              color: '#3888fa',
              lineStyle: {
                color: '#55aaff',
                width: 5
              },
              areaStyle: {
                color: '#f3f8ff'
              }
            }
          },
          // data: actualData,
          data:[34,22,35,33,53,38,43,48,39,28],
          animationDuration: 2800,
          animationEasing: 'quadraticOut'
        }]
      })
    },
    getTime(){
      //获取当前日期以及前九天日期
      var date1 = new Date();
      var date2 = new Date(new Date().getTime() - (1* 24 * 60 * 60 * 1000));
      var date3 = new Date(new Date().getTime() - (2* 24 * 60 * 60 * 1000));
      var date4 = new Date(new Date().getTime() - (3* 24 * 60 * 60 * 1000));
      var date5 = new Date(new Date().getTime() - (4* 24 * 60 * 60 * 1000));
      var date6 = new Date(new Date().getTime() - (5* 24 * 60 * 60 * 1000));
      var date7 = new Date(new Date().getTime() - (6* 24 * 60 * 60 * 1000));
      var date8 = new Date(new Date().getTime() - (7* 24 * 60 * 60 * 1000));
      var date9 = new Date(new Date().getTime() - (8* 24 * 60 * 60 * 1000));
      var date10 = new Date(new Date().getTime() - (9* 24 * 60 * 60 * 1000));
      var year1 = date1.getFullYear();
      var year2 = date2.getFullYear();
      var year3 = date3.getFullYear();
      var year4 = date4.getFullYear();
      var year5 = date5.getFullYear();
      var year6 = date6.getFullYear();
      var year7 = date7.getFullYear();
      var year8 = date8.getFullYear();
      var year9 = date9.getFullYear();
      var year10 = date10.getFullYear();
      var month1 = date1.getMonth() + 1;
      var month2 = date2.getMonth() + 1;
      var month3 = date3.getMonth() + 1;
      var month4 = date4.getMonth() + 1;
      var month5 = date5.getMonth() + 1;
      var month6 = date6.getMonth() + 1;
      var month7 = date7.getMonth() + 1;
      var month8 = date8.getMonth() + 1;
      var month9 = date9.getMonth() + 1;
      var month10 = date10.getMonth() + 1;
      var day1 = date1.getDate();
      var day2 = date2.getDate();
      var day3 = date3.getDate();
      var day4 = date4.getDate();
      var day5 = date5.getDate();
      var day6 = date6.getDate();
      var day7 = date7.getDate();
      var day8 = date8.getDate();
      var day9 = date9.getDate();
      var day10 = date10.getDate();
      if (month1 < 10) {
          month1 = "0" + month1;
      }
      if (month2 < 10) {
          month2 = "0" + month2;
      }
      if (month3 < 10) {
          month3 = "0" + month3;
      }
      if (month4 < 10) {
          month4 = "0" + month4;
      }
      if (month5 < 10) {
          month5 = "0" + month5;
      }
      if (month6 < 10) {
          month6 = "0" + month6;
      }
      if (month7 < 10) {
          month7 = "0" + month7;
      }
      if (month8 < 10) {
          month8 = "0" + month8;
      }
      if (month9 < 10) {
          month9 = "0" + month9;
      }
      if (month10 < 10) {
          month10 = "0" + month10;
      }
      if (day1 < 10) {
          day1 = "0" + day1;
      }
      if (day2 < 10) {
          day2 = "0" + day2;
      }
      if (day3 < 10) {
          day3 = "0" + day3;
      }
      if (day4 < 10) {
          day4 = "0" + day4;
      }
      if (day5 < 10) {
          day5 = "0" + day5;
      }
      if (day6 < 10) {
          day6 = "0" + day6;
      }
      if (day7 < 10) {
          day7 = "0" + day7;
      }
      if (day8 < 10) {
          day8 = "0" + day8;
      }
      if (day9 < 10) {
          day9 = "0" + day9;
      }
      if (day10 < 10) {
          day10 = "0" + day10;
      }
      var newDate1 = year1 + "-" + month1 + "-" + day1;
      var newDate2 = year2 + "-" + month2 + "-" + day2;
      var newDate3 = year3 + "-" + month3 + "-" + day3;
      var newDate4 = year4 + "-" + month4 + "-" + day4;
      var newDate5 = year5 + "-" + month5 + "-" + day5;
      var newDate6 = year6 + "-" + month6 + "-" + day6;
      var newDate7 = year7 + "-" + month7 + "-" + day7;
      var newDate8 = year8 + "-" + month8 + "-" + day8;
      var newDate9 = year9 + "-" + month9 + "-" + day9;
      var newDate10 = year10 + "-" + month10 + "-" + day10;    
      var xAxisTime = [newDate10, newDate9, newDate8, newDate7, newDate6, newDate5, newDate4, newDate3,newDate2, newDate1]
      console.log("xAxisTime:", xAxisTime)
      return xAxisTime
    }
  }
}
</script>
