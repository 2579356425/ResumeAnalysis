<template>
	<div>
		<el-steps style="margin: 15px;" :active="active" finish-status="success">
			<el-step title="上传数据源" icon="el-icon-upload"></el-step>
			<el-step title="选择报告模板" icon="el-icon-document"></el-step>
			<el-step title="选择图表样式" icon="el-icon-thumb"></el-step>
			<el-step title="报告预览" icon="el-icon-view"></el-step>
			<el-step title="报告生成" icon="el-icon-loading"></el-step>
		</el-steps>
		<div align="center">
			<el-button-group>
				<el-button type="primary" round icon="el-icon-arrow-left" @click='back'>上一步</el-button>
				<el-button :disabled="isAble" id="next_button" type="primary" round @click='next'>下一步<i
						class="el-icon-arrow-right el-icon--right"></i></el-button>
			</el-button-group>
		</div>
		<!-- 数据源上传 -->
		<div style="margin: 15px;" align="center" v-if="active==0">
			<el-button type="primary" @click="dataSourceFormVisible = true"><i class="el-icon-upload">上传数据源</i>
			</el-button>
			<!-- 上传数据源弹出的对话框 -->
			<el-dialog title="上传数据源" :visible.sync="dataSourceFormVisible">
				<el-upload class="upload-demo" drag action="#" :before-upload="upload_data_source" multiple>
					<i class="el-icon-upload"></i>
					<div class="el-upload__text">将文件拖到此处,或<em>点击上传</em></div>
				</el-upload>
				<a href="http://xk-files.qktts.asia/景气指数.csv" style="color: #0000EE;">下载查看数据源格式模板</a>
			</el-dialog>
			<!-- <el-dialog title="上传数据源" :visible.sync="dataSourceFormVisible">
				<el-form :model="dataSourceForm">
					<el-form-item label="数据源描述" :label-width="formLabelWidth">
						<el-input v-model="dataSourceForm.desc" autocomplete="off"></el-input>
					</el-form-item>
				</el-form>
				<div style="text-align: center;" slot="footer" class="dialog-footer">
					<input type="file" @change="getFile($event)">
					<el-button style="margin-left: 10px;" size="small" type="success" @click="uploadData($event)">上传到服务器
					</el-button>
				</div>
			</el-dialog> -->
			<!-- 数据源显示的列表 -->
			<div style="padding: 20px;">
				<el-card>
					<el-table border
						:data="dataSourceTable.slice((currentPage-1)*PageSize,currentPage*PageSize).filter(data => !search || data.filename.toLowerCase().includes(search.toLowerCase()))"
						style="width: 100%;text-align: center;" align="center">
						<el-table-column align="center" type="selection" width="55">
						</el-table-column>
						<el-table-column fixed prop="date" align="center" sortable label="上传日期">
						</el-table-column>
						<!-- <el-table-column prop="description" label="描述">
					</el-table-column> -->
						<el-table-column prop="filename" align="center" label="名称">
						</el-table-column>
						<el-table-column prop="filesize" align="center" sortable label="数据源大小">
						</el-table-column>
						<el-table-column align="center">
							<template slot="header" slot-scope="scope">
								<el-input v-model="search" size="mini" placeholder="输入关键字搜索" />
							</template>
							<template slot-scope="scope">
								<!-- 在使用这一步就直接生成相应的图表 -->
								<!-- <el-button size="mini" type="primary" @click="useDataSource(scope.$index, scope.row)"><i
										class="el-icon-check"></i>使用</el-button> -->
								<el-button size="mini" type="danger"
									@click="handleDataSourceDelete(scope.$index, scope.row)"><i
										class="el-icon-delete"></i>移除</el-button>
							</template>
						</el-table-column>
					</el-table>
				</el-card>
			</div>
			<div style="margin: 30px 0;"></div>
			<div class="block" align="center" style="margin-top: 10px;">
				<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
					:current-page="currentPage" :page-sizes="pageSizes" :page-size="PageSize"
					layout="total, sizes, prev, pager, next, jumper" :total=total>
				</el-pagination>
			</div>
		</div>
		<!-- 选择报告模板 -->
		<div style="margin: 15px;" align="center" v-if="active==1">
			<!-- 选择报告模板 -->
			<el-button type="primary" @click="templateFormVisible = true"><i class="el-icon-upload">上传报告模板</i>
			</el-button>
			<div class="block">
				<el-slider v-model="reportstyle" :step="33.33" :marks="marks" style="margin: 30px;" show-stops>
				</el-slider>
			</div>
			<!-- 上传报告模板弹出的对话框 -->
			<el-dialog title="上传报告模板" :visible.sync="templateFormVisible">
				<el-upload class="upload-demo" drag action="#" :before-upload="upload_template" multiple>
					<i class="el-icon-upload"></i>
					<div class="el-upload__text">将文件拖到此处,或<em>点击上传</em></div>
				</el-upload>
			</el-dialog>
			<!-- <el-dialog title="上传报告模板" :visible.sync="templateFormVisible">
				<el-form :model="dataSourceForm">
					<el-form-item label="模板描述" :label-width="formLabelWidth">
						<el-input v-model="templateForm.desc" autocomplete="off"></el-input>
					</el-form-item>
				</el-form>
				<div style="text-align: center;" slot="footer" class="dialog-footer">
					<input type="file" @change="getFile($event)">
					<el-button style="margin-left: 10px;" size="small" type="success" @click="uploadTemplate($event)">
						上传到服务器
					</el-button>
				</div>
			</el-dialog> -->
			<div style="margin: 15px;" align="center">
				<el-card>
					<el-table v-loading="template_loading" border
						:data="templateTable.slice((currentPage-1)*PageSize,currentPage*PageSize).filter(data => !search || data.filename.toLowerCase().includes(search.toLowerCase()))"
						style="width: 100%">
						<el-table-column align="center" type="selection" width="55">
						</el-table-column>
						<el-table-column fixed prop="date" align="center" sortable label="日期">
						</el-table-column>
						<!-- <el-table-column prop="description" label="描述">
					</el-table-column> -->
						<el-table-column prop="filename" align="center" label="模板名称">
						</el-table-column>
						</el-table-column>
						<el-table-column prop="filesize" sortable align="center" label="文件大小">
						</el-table-column>
						<el-table-column align="center">
							<template slot="header" slot-scope="scope">
								<el-input v-model="search" size="mini" placeholder="输入关键字搜索" />
							</template>
							<template slot-scope="scope">
								<el-button size="mini" @click="templatePreview(scope.row)"><i
										class="el-icon-view"></i>预览
								</el-button>
								<el-button size="mini" type="primary" @click="useTemplate(scope.row)"><i
										class="el-icon-check"></i>使用
								</el-button>
								<el-button size="mini" type="danger"
									@click="handleTemplateDelete(scope.$index, scope.row)">
									<i class="el-icon-delete"></i>移除
								</el-button>
							</template>
						</el-table-column>
					</el-table>
				</el-card>
			</div>
			<div style="margin: 30px 0;"></div>
			<div class="block" align="center" style="margin-top: 10px;">
				<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
					:current-page="currentPage" :page-sizes="pageSizes" :page-size="PageSize"
					layout="total, sizes, prev, pager, next, jumper" :total=total>
				</el-pagination>
			</div>
		</div>
		<!-- 选择图表样式 -->
		<div style="padding: 15px;" v-if="active==2">
			<el-tabs v-model="activeName" type="border-card" @tab-click="tabClick()">
				<!-- 忽然觉得类似景气指数也是可以动态渲染的吧?选择好了文档模板后根据图表标题动态渲染到tab的label -->
				<el-tab-pane name="景气指数" label="景气指数">
					<!-- 选择图表样式 -->
					<div style="margin: 15px;" align="center">
						<el-row>
							<el-col style="padding: 5px;" :span="8" v-for="url in aurls" :offset="0">
								<el-card :body-style="{ padding: '5px' }">
									<img :src=url.url class="image">
									<div style="padding: 10px;">
										<el-color-picker v-model="color"></el-color-picker>
										<div class="bottom clearfix">
											<el-button type="primary" icon="el-icon-check" round
												@click='choosecharttype(url.type)'>选择{{url.type}}
											</el-button>
										</div>
									</div>
								</el-card>
							</el-col>
						</el-row>
					</div>
				</el-tab-pane>
				<el-tab-pane name="旅客运输量指数" label="旅客运输量指数">
					<!-- 选择图表样式 -->
					<div style="margin: 15px;" align="center">
						<el-row>
							<el-col style="padding: 5px;" :span="8" v-for="url in burls" :offset="0">
								<el-card :body-style="{ padding: '5px' }">
									<img :src=url.url class="image">
									<div style="padding: 10px;">
										<el-color-picker v-model="color"></el-color-picker>
										<div class="bottom clearfix">
											<el-button type="primary" icon="el-icon-check" round
												@click='choosecharttype(url.type)'>选择{{url.type}}
											</el-button>
										</div>
									</div>
								</el-card>
							</el-col>
						</el-row>
					</div>
				</el-tab-pane>
				<el-tab-pane name="客座率指数" label="客座率指数">
					<!-- 选择图表样式 -->
					<div style="margin: 15px;" align="center">
						<el-row>
							<el-col style="padding: 5px;" :span="8" v-for="url in curls" :offset="0">
								<el-card :body-style="{ padding: '5px' }">
									<img :src=url.url class="image">
									<div style="padding: 10px;">
										<el-color-picker v-model="color"></el-color-picker>
										<div class="bottom clearfix">
											<el-button type="primary" icon="el-icon-check" round
												@click='choosecharttype(url.type)'>选择{{url.type}}
											</el-button>
										</div>
									</div>
								</el-card>
							</el-col>
						</el-row>
					</div>
				</el-tab-pane>
				<el-tab-pane name="运载率指数" label="运载率指数">
					<!-- 选择图表样式 -->
					<div style="margin: 15px;" align="center">
						<el-row>
							<el-col style="padding: 5px;" :span="8" v-for="url in durls" :offset="0">
								<el-card :body-style="{ padding: '5px' }">
									<!-- '`${publicPath}images/`+url.url' -->
									<img :src=url.url class="image">
									<div style="padding: 10px;">
										<el-color-picker v-model="color"></el-color-picker>
										<div class="bottom clearfix">
											<el-button type="primary" icon="el-icon-check" round
												@click='choosecharttype(url.type)'>选择{{url.type}}
											</el-button>
										</div>
									</div>
								</el-card>
							</el-col>
						</el-row>
					</div>
				</el-tab-pane>
				<el-tab-pane name="飞机日利用率指数" label="飞机日利用率指数">
					<!-- 选择图表样式 -->
					<div style="margin: 15px;" align="center">
						<el-row>
							<el-col style="padding: 5px;" :span="8" v-for="url in eurls" :offset="0">
								<el-card :body-style="{ padding: '5px' }">
									<img :src=url.url class="image">
									<div style="padding: 10px;">
										<el-color-picker v-model="color"></el-color-picker>
										<div class="bottom clearfix">
											<el-button type="primary" icon="el-icon-check" round
												@click='choosecharttype(url.type)'>选择{{url.type}}
											</el-button>
										</div>
									</div>
								</el-card>
							</el-col>
						</el-row>
					</div>
				</el-tab-pane>
				<el-tab-pane name="旅客周转量指数" label="旅客周转量指数">
					<!-- 选择图表样式 -->
					<div style="margin: 15px;" align="center">
						<el-row>
							<el-col style="padding: 5px;" :span="8" v-for="url in furls" :offset="0">
								<el-card :body-style="{ padding: '5px' }">
									<img :src=url.url class="image">
									<div style="padding: 10px;">
										<el-color-picker v-model="color"></el-color-picker>
										<div class="bottom clearfix">
											<el-button type="primary" icon="el-icon-check" round
												@click='choosecharttype(url.type)'>选择{{url.type}}
											</el-button>
										</div>
									</div>
								</el-card>
							</el-col>
						</el-row>
					</div>
				</el-tab-pane>
				<el-tab-pane name="景气指数预测" label="景气指数预测">
					<!-- 选择图表样式 -->
					<div style="margin: 15px;" align="center">
						<el-row>
							<el-col style="padding: 5px;" :span="8" v-for="url in gurls" :offset="0">
								<el-card :body-style="{ padding: '5px' }">
									<img :src=url.url class="image">
									<div style="padding: 10px;">
										<!-- <el-color-picker v-model="color"></el-color-picker> -->
										<div class="bottom clearfix">
											<el-button type="primary" icon="el-icon-check" round
												@click='choosecharttype(url.type)'>选择{{url.type}}
											</el-button>
										</div>
									</div>
								</el-card>
							</el-col>
						</el-row>
					</div>
				</el-tab-pane>
			</el-tabs>
		</div>
		<!-- 报告预览 -->
		<!-- 写一个点击按钮弹出pdf预览的对话框，需要将docx转为pdf -->
		<div v-if="active==3" v-loading="report_loading" element-loading-text="拼命加载中..."
			style="height: 100%;margin: 5px;">
			<iframe :src=reportpreviewurl style="width: 100%;height: 650px;"></iframe>
		</div>
		<!-- 模板预览弹出框 -->
		<el-dialog :fullscreen="true" style="height: auto;" center title="报告模板预览" custom-class="customWidth"
			:visible.sync="templatePreviewVisible">
			<div style="height: auto;" v-loading="loading">
				<!-- '`${publicPath}preview_files/`+previewfilename' -->
				<iframe id="bdIframe" :src=templatepreviewurl frameborder="0" style="width:100%; height: 100%;"
					scrolling="no"></iframe>
			</div>
		</el-dialog>
		<!-- 报告预览弹出框 -->
		<el-dialog :fullscreen="true" style="height: auto;" center title="报告模板预览" custom-class="customWidth"
			:visible.sync="reportPreviewVisible">
			<div style="height: auto;" v-loading='loading'>
				<iframe id="bdIframe" :src=reportpreviewurl frameborder="0" style="width:100%; height: 100%;"
					scrolling="no"></iframe>
			</div>
		</el-dialog>
		<!-- 报告生成 -->
		<div v-if="active==4" style="height: 100%;margin: 5px;">
			<el-dialog style="text-align: center;" title="填写报告生成的相关信息" :visible.sync="templateInfoFormVisible">
				<el-form :model="templateInfoForm">
					<el-form-item label="报告名称" :label-width="formLabelWidth">
						<el-input v-model="templateInfoForm.templatename" autocomplete="off"></el-input>
					</el-form-item>
					<el-form-item label="相关责任人姓名" :label-width="formLabelWidth">
						<el-input v-model="templateInfoForm.name" autocomplete="off"></el-input>
					</el-form-item>
					<el-form-item label="相关责任人手机号" :label-width="formLabelWidth">
						<el-input v-model="templateInfoForm.phonenum" autocomplete="off"></el-input>
					</el-form-item>
				</el-form>
				<div style="text-align: center;" slot="footer" class="dialog-footer">
					<el-button type="danger" @click="back()">取消</el-button>
					<el-button type="primary" @click="submitReportInfo()">确认</el-button>
				</div>
			</el-dialog>
		</div>
		<!-- 报告生成的历史记录 -->
		<div v-if="active==5" style="margin: 15px;" align="center">
			<el-card>
				<el-table border
					:data="reportTable.slice((currentPage-1)*PageSize,currentPage*PageSize).filter(data => !search || data.filename.toLowerCase().includes(search.toLowerCase()))"
					style="width: 100%">
					<el-table-column fixed prop="date" align="center" sortable label="生成日期">
					</el-table-column>
					<el-table-column prop="name" align="center" label="负责人">
					</el-table-column>
					<el-table-column prop="phonenum" align="center" label="联系方式">
					</el-table-column>
					</el-table-column>
					<el-table-column prop="filename" align="center" sortable label="文件名称">
					</el-table-column>
					<el-table-column prop="filesize" align="center" sortable label="文件大小">
					</el-table-column>
					<el-table-column align="center" width="300px">
						<template slot="header" slot-scope="scope">
							<el-input v-model="search" size="mini" placeholder="输入关键字搜索" />
						</template>
						<template slot-scope="scope">
							<el-button size="mini" type="primary" @click="reportDownload(scope.$index, scope.row)"><i
									class="el-icon-download"></i>下载</el-button>
							<el-button size="mini" type="danger" @click="handleReportDelete(scope.$index, scope.row)"><i
									class="el-icon-delete"></i>移除</el-button>
						</template>
					</el-table-column>
				</el-table>
			</el-card>
			<div class="block" align="center" style="margin-top: 10px;">
				<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
					:current-page="currentPage" :page-sizes="pageSizes" :page-size="PageSize"
					layout="total, sizes, prev, pager, next, jumper" :total=total>
				</el-pagination>
			</div>
		</div>
	</div>
</template>

<script>
	import axios from 'axios'
	import Vue from 'vue'
	export default {
		data() {
			return {
				color: '#409EFF',
				colora: '#409EFF',
				colorb: '#409EFF',
				colorc: '#409EFF',
				colord: '#409EFF',
				colore: '#409EFF',
				colorf: '#409EFF',
				colorg: '#409EFF',
				reportstyle: 0,
				marks: {
					0: {
						style: {
							color: '#1989FA'
						},
						label: this.$createElement('strong', '默认')
					},
					33.33: '商务风格',
					66.66: '学术风格',
					99.99: ' '
				},
				arr: [],
				prework: {},
				currentPage: 1,
				total: 0,
				pageSizes: [5, 10, 20, 30],
				PageSize: 10,
				// 前端分页设置
				reportpreviewurl: '',
				templatepreviewurl: '',
				usetemplatename: '',
				activeName: '景气指数',
				activeflag: 0, //暂存active step返回值
				loading: true,
				report_loading: false,
				data_source_loading: false,
				template_loading: false, //控制模板显示加载圈
				templatePreviewVisible: false, //控制模板预览弹出框
				reportPreviewVisible: false,
				previewfilename: 'preview.pdf', //预览的文件名称
				isAble: false, //控制下一步按钮是否可用
				templateInfoForm: {
					templatename: '',
					name: '',
					phonenum: ''
				},
				templateInfoFormVisible: false, //填写生成的报告的信息
				msg: '', //flask测试
				dataSourceFormVisible: false, //上传数据源对话框
				templateFormVisible: false, //上传报告模板对话框
				templateForm: {
					file: '',
					desc: ''
				},
				dataSourceForm: {
					file: '',
					desc: ''
				},
				formLabelWidth: '130px',
				search: '',
				dataSourceTable: [],
				templateTable: [],
				reportTable: [],
				publicPath: process.env.BASE_URL,
				active: 0, //步骤
				aurls: [{
					url: 'http://xk-files.qktts.asia/1景气指数柱状图.png',
					type: '柱状图'
				}, {
					url: 'http://xk-files.qktts.asia/1景气指数折线图.png',
					type: '折线图'
				}, {
					url: 'http://xk-files.qktts.asia/1景气指数混合图.png',
					type: '混合图'
				}], //景气指数图表样式
				burls: [{
					url: 'http://xk-files.qktts.asia/旅客运输量柱状图.png',
					type: '柱状图'
				}, {
					url: 'http://xk-files.qktts.asia/旅客运输量折线图.png',
					type: '折线图'
				}, {
					url: 'http://xk-files.qktts.asia/旅客运输量混合图.png',
					type: '混合图'
				}], //量价指数图表样式
				curls: [{
					url: 'http://xk-files.qktts.asia/客座率柱状图.png',
					type: '柱状图'
				}, {
					url: 'http://xk-files.qktts.asia/客座率折线图.png',
					type: '折线图'
				}, {
					url: 'http://xk-files.qktts.asia/客座率混合图.png',
					type: '混合图'
				}], //客座率指数图表样式
				durls: [{
					url: 'http://xk-files.qktts.asia/1运载率指数柱状图.png',
					type: '柱状图'
				}, {
					url: 'http://xk-files.qktts.asia/1运载率指数折线图.png',
					type: '折线图'
				}, {
					url: 'http://xk-files.qktts.asia/1运载率指数混合图.png',
					type: '混合图'
				}], //上半年民航国内旅行者图表样式
				eurls: [{
					url: 'http://xk-files.qktts.asia/飞机日利用率柱状图.png',
					type: '柱状图'
				}, {
					url: 'http://xk-files.qktts.asia/飞机日利用率折线图.png',
					type: '折线图'
				}, {
					url: 'http://xk-files.qktts.asia/飞机日利用率混合图.png',
					type: '混合图'
				}], //上半年民航国际旅行者图表样式
				furls: [{
					url: 'http://xk-files.qktts.asia/旅客周转量柱状图.png',
					type: '柱状图'
				}, {
					url: 'http://xk-files.qktts.asia/旅客周转量折线图.png',
					type: '折线图'
				}, {
					url: 'http://xk-files.qktts.asia/旅客周转量混合图.png',
					type: '混合图'
				}], //上半年节假日市场概况图表样式
				gurls: [{
					url: 'http://xk-files.qktts.asia/景气指数预测柱状图.png',
					type: '柱状图'
				}, {
					url: 'http://xk-files.qktts.asia/景气指数预测折线图.png',
					type: '折线图'
				}, {
					url: 'http://xk-files.qktts.asia/景气指数预测混合图.png',
					type: '混合图'
				}], //上半年节假日市场概况图表样式
			}
		},
		methods: {
			handleSizeChange(val) {
				this.PageSize = val
				this.currentPage = 1
				console.log(`每页 ${val} 条`);
			},
			handleCurrentChange(val) {
				this.currentPage = val
				console.log(`当前页: ${val}`);
			},
			choosecharttype(type) {
				var dict = {}
				dict['tabname'] = this.activeName;
				dict['type'] = type;
				var ta = this.arr;
				ta.push(dict);
				this.arr = ta;
				(this.prework)[this.usetemplatename] = this.arr;
				console.log(this.prework);
				//生成颜色图片
				let formData = new FormData();
				formData.append('activeName', this.activeName);
				formData.append('type', type);
				formData.append('color', this.color);
				formData.append('sentencestyle', this.reportstyle);
				let config = {
					headers: {
						'Content-Type': 'multipart/form-data'
					}
				}
				var that =
					this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
				axios.post('http://106.54.170.52:7777/genimagescolor', formData, config).then(function(response) {
					if (response.status === 200) {
						console.log(response.data)
					}
				}).catch(err => {
					this.$message.error(err.message);
					console.log(err);
				});		
				if (this.activeName === '景气指数') {
					this.activeName = '旅客运输量指数'
				} else if (this.activeName === '旅客运输量指数') {
					this.activeName = '客座率指数'
				} else if (this.activeName === '客座率指数') {
					this.activeName = '运载率指数'
				} else if (this.activeName === '运载率指数') {
					this.activeName = '飞机日利用率指数'
				} else if (this.activeName === '飞机日利用率指数') {
					this.activeName = '旅客周转量指数'
				} else if (this.activeName === '旅客周转量指数') {
					this.activeName = '景气指数预测'
				}
			},
			chooseChart(type) {
				// 最好能够得到tab的名称和图表样式，传给后端，在对应位置渲染
				let formData = new FormData();
				formData.append('type', type);
				formData.append('tabname', this.activeName);
				formData.append('templatename', this.usetemplatename);
				console.log(this.usetemplatename)
				let config = {
					headers: {
						'Content-Type': 'multipart/form-data'
					}
				}
				var that =
					this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
				axios.post('http://106.54.170.52:7777/choosecharttype', formData, config).then(function(response) {
					if (response.data === 'success') {
						that.$notify({
							title: '提示',
							message: that.activeName + '选择了' + type,
							type: 'info'
						});
						if (that.activeName === '景气指数') {
							that.activeName = '旅客运输量指数'
						} else if (that.activeName === '旅客运输量指数') {
							that.activeName = '客座率指数'
						} else if (that.activeName === '客座率指数') {
							that.activeName = '运载率指数'
						} else if (that.activeName === '运载率指数') {
							that.activeName = '飞机日利用率指数'
						} else if (that.activeName === '飞机日利用率指数') {
							that.activeName = '旅客周转量指数'
						}
					}
				}).catch(err => {
					this.$message.error(err.message);
					console.log(err)
				})
			},
			// 报告模板预览
			templatePreview(row) {
				this.templatePreviewVisible = true;
				var filename = row['filename'];
				filename = filename.substring(0, filename.lastIndexOf(".")) + '.pdf';
				// 根据filename数据库得到对应pdf的url(filepath)
				this.templatepreviewurl = "http://xk-files.qktts.asia/" + filename
				setTimeout(() => {
					this.loading = false;
				}, 500);
				setTimeout(function() {
					console.log("---------");
					/**
					 * iframe-宽高自适应显示
					 */
					const oIframe = document.getElementById("bdIframe");
					console.log(oIframe);
					const deviceWidth = document.documentElement.clientWidth;
					const deviceHeight = document.documentElement.clientHeight;
					// oIframe.style.width = Number(deviceWidth) - 220 + "px"; //数字是页面布局宽度差值
					oIframe.style.width = Number(deviceWidth); //数字是页面布局宽度差值
					oIframe.style.height = Number(deviceHeight) - 120 + "px"; //数字是页面布局高度差
				}, 500);
			},
			// 报告预览
			handleView(row) {
				this.templatePreviewVisible = true;
				var filename = row['filename'];
				this.previewfilename = filename.substring(0, filename.lastIndexOf(".")) + '.pdf';
				console.log(this.previewfilename)
				setTimeout(() => {
					this.loading = false;
				}, 1000);
				setTimeout(function() {
					console.log("---------");
					/**
					 * iframe-宽高自适应显示
					 */
					const oIframe = document.getElementById("bdIframe");
					console.log(oIframe);
					const deviceWidth = document.documentElement.clientWidth;
					const deviceHeight = document.documentElement.clientHeight;
					// oIframe.style.width = Number(deviceWidth) - 220 + "px"; //数字是页面布局宽度差值
					oIframe.style.width = Number(deviceWidth); //数字是页面布局宽度差值
					oIframe.style.height = Number(deviceHeight) - 120 + "px"; //数字是页面布局高度差
				}, 1000);
			},
			// 填写生成的报告信息
			submitReportInfo() {
				this.getReport();
				let formData = new FormData();
				var aa = JSON.stringify(this.prework);
				formData.append('prework', aa);
				formData.append('genreportname', this.templateInfoForm.templatename);
				formData.append('name', this.templateInfoForm.name);
				formData.append('phonenum', this.templateInfoForm.phonenum);
				let config = {
					'Content-Type': 'multipart/form-data'
				}

				var that =
					this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
				axios.post('http://106.54.170.52:7777/genreport', formData, config).then(function(response) {
					if (response.data === 'success') {
						that.$notify({
							title: '成功',
							message: '报告' + that.templateInfoForm.templatename + '生成成功！',
							type: 'success'
						});
						that.getReport();
					}
				}).catch(err => {
					this.$message.error(err.message);
					console.log(err)
				})
				this.templateInfoFormVisible = false;
				if (this.active++ > 5) this.active = 0;
				this.isAble = true;
			},
			reportDownload(index, row) {
				var filename = row['filename'];
				console.log(filename)
				console.log(index)
				console.log(this.reportTable[index]['url'])
				window.open(this.reportTable[index]['url'] + '?response-content-type=application/octet-stream');
			},
			// 获取数据库数据源信息
			getDataSource() {
				const path = 'http://106.54.170.52:7777/loaddatasource';
				var that = this
				axios.get(path).then(res => {
					console.log(res.data)
					that.dataSourceTable = res.data;
					that.total = that.dataSourceTable.length;
				}).catch(error => {
					console.error(error);
				});
			},
			// 获取数据库报告模板信息
			getTemplate() {
				const path = 'http://106.54.170.52:7777/loadtemplate';
				axios.get(path).then(res => {
					console.log(res.data)
					this.templateTable = res.data;
					this.total = this.templateTable.length;
				}).catch(error => {
					console.error(error);
				});
			},
			handleSizeChange(val) {
				this.PageSize = val
				this.currentPage = 1
				console.log(`每页 ${val} 条`);
			},
			handleCurrentChange(val) {
				this.currentPage = val
				console.log(`当前页: ${val}`);
			},
			getReport() {
				const path = 'http://106.54.170.52:7777/loadreport';
				axios.get(path).then(res => {
					console.log(res.data)
					this.reportTable = res.data;
					this.total = res.data.length
				}).catch(error => {
					console.error(error);
				});
			},
			// 获取点击事件的文件信息
			getFile(event) {
				this.file = event.target.files[0];
				console.log(this.file);
			},
			// 上传数据源
			uploadData(event) {
				event.preventDefault();
				let formData = new FormData();
				formData.append('filename', this.file.name);
				formData.append('filesize', this.file.size);
				formData.append('desc', this.dataSourceForm.desc);
				formData.append('file', this.file);
				let config = {
					headers: {
						'Content-Type': 'multipart/form-data'
					}
				}
				var that =
					this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
				axios.post('http://106.54.170.52:7777/updatasource', formData, config).then(function(response) {
					console.log(response.status)
					if (response.status === 200) {
						that.dataSourceFormVisible = false;
						console.log(response.data)
						that.dataSourceTable.push(response.data)
						console.log(that.dataSourceTable);
					}
				}).catch(err => {
					this.$message.error(err.message);
					console.log(err)
				})
			},
			upload_data_source(file) {
				let formData = new FormData();
				formData.append('file', file);
				let config = {
					headers: {
						'Content-Type': 'multipart/form-data'
					}
				}
				this.dataSourceFormVisible = false;
				this.data_source_loading = true;
				var that =
					this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下
				axios.post('http://106.54.170.52:7777/uploaddatasource', formData, config).then(function(response) {
					that.data_source_loading = false;
					console.log(response.status)
					if (response.status === 200) {
						console.log(response.data)
						that.dataSourceTable.push(response.data)
						console.log(that.dataSourceTable);
						that.total = that.dataSourceTable.length;
					}
				}).catch(err => {
					this.$message.error(err.message);
					that.loading = false;
					console.log(err)
				})
			},
			// 上传报告模板
			uploadTemplate() {
				event.preventDefault();
				let formData = new FormData();
				formData.append('filename', this.file.name);
				formData.append('filesize', this.file.size);
				formData.append('desc', this.templateForm.desc);
				formData.append('file', this.file);
				let config = {
					headers: {
						'Content-Type': 'multipart/form-data'
					}
				}
				this.templateFormVisible = false;
				this.template_loading = true;
				var that =
					this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
				axios.post('http://106.54.170.52:7777/uptemplate', formData, config).then(function(response) {
					console.log(response.status)
					that.template_loading = false;
					if (response.status === 200) {
						that.templateTable.push(response.data)
						that.total = that.templateTable.length;
						that.$notify({
							title: '成功',
							message: that.file.name + ' 报告模板上传成功!',
							type: 'success'
						});
						console.log(response.data);
					}
				}).catch(err => {
					this.$message.error(err.message);
					console.log(err)
				})
			},
			upload_template(file) {
				let formData = new FormData();
				formData.append('file', file);
				let config = {
					headers: {
						'Content-Type': 'multipart/form-data'
					}
				}
				this.templateFormVisible = false;
				this.template_loading = true;
				var that =
					this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下
				axios.post('http://106.54.170.52:7777/uploadtemplate', formData, config).then(function(response) {
					that.template_loading = false;
					if (response.status === 200) {
						that.templateTable.push(response.data)
						that.$notify({
							title: '成功',
							message: file.name + ' 上传成功!',
							type: 'success'
						});
						console.log(response.data);
					}
				}).catch(err => {
					this.$message.error(err.message);
					that.loading = false;
					console.log(err)
				})
			},
			useTemplate(row) {
				var templatename = row['filename'];
				//在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
				this.usetemplatename = templatename;
				console.log(this.usetemplatename)
				this.$notify({
					title: '成功',
					message: this.usetemplatename + ' 报告模板加载成功!',
					type: 'success'
				});
			},
			tabClick(tab, event) {
				console.log(tab, event);
			},
			useDataSource(index, row) {
				var filename = row['filename'];
				let formData = new FormData();
				formData.append('filename', filename);
				let config = {
					headers: {
						'Content-Type': 'multipart/form-data'
					}
				}
				var that =
					this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
				axios.post('http://106.54.170.52:7777/usedatasource', formData, config).then(function(response) {
					if (response.data === 'success') {
						that.$notify({
							title: '成功',
							message: filename + ' 数据加载成功!',
							type: 'success'
						});
					}
				}).catch(err => {
					this.$message.error(err.message);
					console.log(err)
				})
			},
			handleDataSourceDelete(index, row) {
				var filename = row['filename'];
				let formData = new FormData();
				formData.append('filename', filename);
				let config = {
					headers: {
						'Content-Type': 'multipart/form-data'
					}
				}
				var that =
					this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
				axios.post('http://106.54.170.52:7777/deldatasource', formData, config).then(function(response) {
					if (response.data === 'success') {
						that.getDataSource()
						that.$notify({
							title: '成功',
							message: filename + ' 移除成功!',
							type: 'success'
						});
					}
				}).catch(err => {
					this.$message.error(err.message);
					console.log(err)
				})
			},
			handleTemplateDelete(index, row) {
				var filename = row['filename'];
				let formData = new FormData();
				formData.append('filename', filename);
				let config = {
					headers: {
						'Content-Type': 'multipart/form-data'
					}
				}
				var that =
					this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
				axios.post('http://106.54.170.52:7777/deltemplate', formData, config).then(function(response) {
					if (response.data === 'success') {
						that.getTemplate()
						that.$notify({
							title: '成功',
							message: filename + ' 移除成功!',
							type: 'success'
						});
					}
				}).catch(err => {
					this.$message.error(err.message);
					console.log(err)
				})
			},
			handleReportDelete(index, row) {
				var filename = row['filename'];
				let formData = new FormData();
				formData.append('filename', filename);
				let config = {
					headers: {
						'Content-Type': 'multipart/form-data'
					}
				}
				var that =
					this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
				axios.post('http://106.54.170.52:7777/delreport', formData, config).then(function(response) {
					if (response.data === 'success') {
						that.getReport()
						that.$notify({
							title: '成功',
							message: filename + ' 移除成功!',
							type: 'success'
						});
					}
				}).catch(err => {
					this.$message.error(err.message);
					console.log(err)
				})
			},
			// 下一步,点击下一步，判断当前active等于几
			next() {
				if (this.active++ > 5) this.active = 0;
				if (this.active == 0) {
					this.getDataSource();
				}
				if (this.active == 1) {
					this.getTemplate();
					//图表全部生成，调用三次分别传123，图片命名柱状图，折线图，混合图，存到flask对应文件夹下
					let formData = new FormData();
					formData.append('genimages', 'genimages');
					let config = {
						headers: {
							'Content-Type': 'multipart/form-data'
						}
					}
					var that =
						this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
					axios.post('http://106.54.170.52:7777/genimages', formData, config).then(function(response) {
						if (response.status === 200) {
							console.log(response.data)
						}
					}).catch(err => {
						this.$message.error(err.message);
						console.log(err)
					})
				}
				if (this.active == 3) {
					let formData = new FormData();
					//前端JSON.stringify()，后端json.loads()
					var aa = JSON.stringify(this.prework);
					formData.append('prework', aa);
					let config = {
						headers: {
							'Content-Type': 'multipart/form-data'
						}
					}
					this.report_loading = true;
					var that =
						this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
					axios.post('http://106.54.170.52:7777/postprework', formData, config).then(function(response) {
						if (response.status === 200) {
							that.report_loading = false;
							console.log("预览文件名称：" + response.data)
							that.reportpreviewurl = response.data
						}
					}).catch(err => {
						that.report_loading = false;
						this.$message.error(err.message);
						console.log(err)
					})
				}
				if (this.active == 4) {
					this.templateInfoFormVisible = true;
				}
			},
			clear_dict() {
				let formData = new FormData();
				let config = {
					headers: {
						'Content-Type': 'multipart/form-data'
					}
				}
				var that =
					this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
				axios.post('http://106.54.170.52:7777/cleardict', formData, config).then(function(response) {
					if (response.status === 200) {
						console.log(response.data)
					}
				}).catch(err => {
					this.$message.error(err.message);
					console.log(err)
				})
			},
			// 上一步,就不需要出现填写信息的对话框（active=4）直接到active=3
			back() {
				this.isAble = false;
				if (this.active-- < 1) {
					this.active = 0;
					this.getDataSource();
				}
				if (this.active == 0) {
					this.getDataSource();
				}
				if (this.active == 1) {
					this.getTemplate();
					this.arr = [];
					this.prework = {};
				}
				if (this.active == 2) {
					this.arr = [];
					this.prework = {};
				}
				if (this.active == 4) {
					this.active--;
				}
			},
		},
		created() {
			this.getDataSource();
			this.arr = [];
			this.prework = {};
			this.clear_dict();
		}
	}
</script>

<style>
	/* 图表样式选择 */
	.time {
		font-size: 13px;
		color: #999;
	}

	.bottom {
		margin-top: 13px;
		line-height: 12px;
	}

	.button {
		padding: 0;
		float: right;
	}

	.image {
		width: 100%;
		display: block;
	}

	.clearfix:before,
	.clearfix:after {
		display: table;
		content: "";
	}

	.clearfix:after {
		clear: both
	}

	/* 图表样式选择 */
	/* customWidth用来调整预览框宽度 */
	.customWidth {
		width: 80%;
		height: 80%;
	}
</style>
