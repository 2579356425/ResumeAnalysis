<template>
  <div>
    <div align="center">
      <a style="color: #00aaff;"><h2>图像管理</h2></a>
          <!-- <el-row style="padding: 20px;" :gutter="10"> -->
        <!-- <div align="center">
          <a style="color: #00aaff;"><h3>图像上传</h3></a>
        </div> -->
        <el-col :span="6" :offset="3">
          <div class="grid-content bg-purple">
            <div style="float:left">
              <el-date-picker
                v-model="shotdate"
                type="date"
                placeholder="选择图像拍摄日期"
              />
            </div>
            <!-- <div style="float:left"> -->
              <!-- <el-cascader size="medium" v-model="interpretType" :options="options" placeholder="请选择解译类型" style="margin-left: 5px;margin-right: 5px;">
              </el-cascader> -->
              <!-- <el-input v-model="imageresolution" style="margin-left: 5px;margin-right: 5px;" placeholder="请输入图像分辨率" /> -->
            <!-- </div> -->
            <div style="float:left">
              <!-- <el-upload
                class="upload-demo"
                action="http://10.9.21.97:59999/workspace/whj/flask/images/"
                :http-request="uploadFile"
                :headers="upHeaders"
                :show-file-list="false"
                :on-change="uploadImage"
                :on-success="handleSuccess"
                :on-error="handleError"
                :limit="1"
              >
                <el-button size="small" type="primary" style="margin-left:10px;margin-top:1px;height: 34px;">上传图像</el-button>
              </el-upload> -->
              <el-upload
                class="upload-demo"
                action="http://10.9.21.97:59999/workspace/whj/flask/images/"
                :http-request="uploadFile"
                :headers="upHeaders"
                :show-file-list="false"
                :on-success="handleSuccess"
                :on-error="handleError"
                :limit="1"
              >
                <el-button size="small" type="primary" style="margin-left:10px;margin-top:1px;height: 34px;"><i class="el-icon-upload" />上传图像</el-button>
              </el-upload>
            </div>
          </div>
        </el-col>
      <!-- </el-row> -->
      <el-col :span="12" :offset="2">
        <span style="text-align:left; color: #00aaff ; font-size: 16px; font-weight: bold; margin-left: 40px;">请选择图像上传时间段：</span>
        <el-date-picker
          v-model="timeSearch"
          type="daterange"
          range-separator="至"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
        />
        <el-button size="small" type="primary" style="margin-left:10px;margin-top:1px;height: 34px;" @click="imageSearch(timeSearch)"><i class="el-icon-search" />搜索</el-button>
        <p />
      </el-col>

      <el-table
        id="extract"
        :data="imageInfo.slice((currentPage-1)*PageSize,currentPage*PageSize).filter(data => !search || data.relation.toLowerCase().includes(search.toLowerCase()))"
        border
        style="width: 95%;"
        :header-cell-style="{'text-align':'center'}"
        :cell-style="{'text-align':'center'}"
      >
        <el-table-column type="index" :index="indexMethod" label="序号" />
        <el-table-column prop="7" label="图像">
          <template slot-scope="scope">
            <el-image
              style="width: 35%; height: 35%"
              :src="scope.row[7]"
              :lazy="true"
              :preview-src-list="srcList"
            />
          </template>
        </el-table-column>
        <el-table-column prop="2" label="图像名" />
        <el-table-column prop="6" label="图像分辨率" />
        <el-table-column prop="4" label="图像拍摄时间" />
        <el-table-column prop="5" label="图像上传时间" />
        <el-table-column width="200px" align="right" label="图像信息管理">
          <!-- <template slot="header" slot-scope="scope"> -->
          <!-- <el-input v-model="search" size="mini" placeholder="输入关键字搜索" /> -->

          <!-- </template> -->
          <template slot-scope="scope">
            <el-button type="primary" size="mini" @click="getImageInfomation(scope.$index, scope.row);changeInfo = true"><i class="el-icon-edit" />修改</el-button>
            <el-button type="danger" size="mini" @click="imageDelete(scope.$index, scope.row)"><i class="el-icon-delete" />删除</el-button>
            <el-dialog title="修改图像信息" :visible.sync="changeInfo" width="30%">
              <el-form :model="form">
                <el-form-item label="图像名" label-width="20%" style="padding-left: 10%;">
                  <el-col :span="16" :offset="4">
                    <el-input v-model="form.imagename" style="width: 101%;" clearable />
                  </el-col>
                </el-form-item>
                <!-- <el-form-item label="图像大小" label-width="20%" style="width: 98%; padding-left: 14%;">
                  <el-col :span="17" :offset="3">
                    <el-input v-model="form.imagesize" style="width: 100%;margin-left: 5px;" disabled />
                  </el-col>
                </el-form-item> -->
                <el-form-item label="图像分辨率"  style="width: 98%; padding-left: 12%;margin-left: 12px;">
                  <el-col :span="13" :offset="2">
                    <el-input v-model="form.imageresolution" style="width: 103.5%;" disabled />
                  </el-col>
                </el-form-item>
                <!-- <el-form-item label="解译类型" label-width="20%" style="width: 100%; padding-left: 14%;">
                    <el-cascader size="medium" v-model="form.interpretType" :options="options" style="margin-right: 10px;width: 200px;">
                    </el-cascader>
                </el-form-item> -->
                <el-col :span="24">
                  <el-form-item label="图像拍摄时间" label-width="28%" style="width: 100%;padding-left: 12%;">
                    <el-date-picker v-model="form.shotdate" type="date" placeholder="选择图像拍摄日期" style="width: 76%;margin-right: 12%;" />
                  </el-form-item>
                </el-col>
              </el-form>
              <div slot="footer" class="dialog-footer" style="margin-top: 30px;">
                <el-button @click="changeInfo = false">取 消</el-button>
                <el-button type="primary" @click="changeImageInfomationConfirm()">确 定</el-button>
              </div>
            </el-dialog>
          </template>
        </el-table-column>
      </el-table>
      <div class="block" align="center" style="margin-top: 10px; margin-bottom: 10px;">
        <el-pagination
          :current-page="currentPage"
          :page-sizes="pageSizes"
          :page-size="PageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
import Vue from 'vue'
import { Message } from 'element-ui'
import { data } from 'jquery'
import { type } from 'os'
import { callbackify } from 'util'
export default {
  inject: ['reload'], // 注入刷新页面的依赖
  data() {
    return {
      shotdate: '',
      imageresolution: '',
      currentPage: 1,
      total: 0,
      imageInfo: [13, './image/test_2.png', 'test_2.png', '1KB', '2020-01', '2022-1', '1024*1920'],
      pageSizes: [5, 10, 20],
      PageSize: 5,
      changeInfo: false,
      form: {
        imagename: '',
        imagesize: '',
        imageresolution: '',
        shotdate: ''
      },
      formLabelWidth: '15%',
      search: '',
      row1: '', // 全局变量,用来传值给changeImageInfomationConfirm()
      url: 'http://10.9.21.97:59999/workspace/whj/flask/images/test_4.png',
      srcList: [],
      timeSearch: '',
      localPath: '',
      resolution: '',
      options: [{
          value: '目标提取',
          label: '目标提取',
          }, {
          value: '变化检测',
          label: '变化检测',
          }, {
          value: '目标检测',
          label: '目标检测',
          children:[{
            value: '操场',
            label: '操场'
          },{
            value: '油罐',
            label: '油罐'
          },{
            value: '天桥',
            label: '天桥'
          },{
            value: '飞机',
            label: '飞机'
          }]}, {
          value: '地物分类',
          label: '地物分类',
          }],
    }
  },
  created() {
    this.getImageInfo()
  },
  methods: {
    indexMethod(index) {
      return index + ((this.currentPage - 1) * this.PageSize) + 1
    },
    handleSizeChange(val) {
      this.PageSize = val
      this.currentPage = 1
      console.log(`每页 ${val} 条`)
    },
    handleCurrentChange(val) {
      this.currentPage = val
      console.log(`当前页: ${val}`)
    },
    uploadImage(file, resolution) {
      this.imageresolution = resolution
      var uploaddate = new Date().getTime() // 中国标准时间
      var uploadDate = new Date(uploaddate) // 用来比较拍摄时间和上传时间的大小（上传时间）
      var date = new Date(uploaddate)
      var y = date.getFullYear() // 年
      var m = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) // 月
      var d = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()) // 日
      uploaddate = y + '-' + m + '-' + d
      const config = {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }
      var shotDate = new Date(this.shotdate) // 用来比较拍摄时间和上传时间的大小（拍摄时间）
      if (uploadDate < shotDate) {
        this.$notify({
          title: '失败',
          message: '图像拍摄日期有误,请重新上传！',
          type: 'error'
        })
        return
      }
      var shotdate2 = new Date(this.shotdate)
      var y2 = shotdate2.getFullYear() // 年
      var m2 = (shotdate2.getMonth() + 1 < 10 ? '0' + (shotdate2.getMonth() + 1) : shotdate2.getMonth() + 1) // 月
      var d2 = (shotdate2.getDate() < 10 ? '0' + (shotdate2.getDate()) : shotdate2.getDate()) // 日
      this.shotdate = y2 + '-' + m2 + '-' + d2
      var data = { 'shotdate': this.shotdate, 'imagesize': file.size + 'KB', 'imageresolution': this.imageresolution, 'imagepath': 'http://10.9.21.97:59999/workspace/whj/flask/images/', 'uploaddate': uploaddate, 'imagename': file.name }
      const formData = new FormData()
      formData.append('shotdate', data['shotdate'])
      formData.append('imagesize', data['imagesize'])
      formData.append('imageresolution', data['imageresolution'])
      formData.append('imagepath', data['imagepath'])
      formData.append('uploaddate', data['uploaddate'])
      formData.append('imagename', data['imagename'])
      console.log("imageresolution:" + formData.get('imageresolution'))
      var that = this
      axios.post('http://10.9.21.97:5000/imageupload', formData, file, config).then(function(response) {
        if (response.status == 200) {
          that.$notify({
            title: '成功',
            message: '图像上传成功！',
            type: 'success'
          })
          that.reload()
        }
      }).catch(err => {
        this.$message.error(err.message)
        console.log(err)
      })
    },
    getImageInfomation(index, row) {
      console.log(row)
      this.form.imagename = row[2]
      this.form.imagesize = row[3]
      this.form.imageresolution = row[6]
      this.form.shotdate = row[4]
      this.row1 = row
    },
    changeImageInfomationConfirm() {
      console.log(this.row1)
      var row = this.row1
      var uploaddate = new Date().getTime() // 中国标准时间
      var date = new Date(uploaddate)
      var y = date.getFullYear() // 年
      var m = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) // 月
      var d = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()) // 日
      uploaddate = y + '-' + m + '-' + d
      const formData = new FormData()
      formData.append('imageid', row[0])
      formData.append('shotdate', this.form.shotdate)
      formData.append('imagesize', this.form.imagesize)
      formData.append('imageresolution', this.form.imageresolution)
      formData.append('imagepath', 'http://10.9.21.97:59999/workspace/whj/flask/images/')
      formData.append('uploaddate', uploaddate)
      formData.append('imagename', this.form.imagename)
      const config = {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }
      var that = this
      axios.post('http://10.9.21.97:5000/changeImageInfo', formData, config).then(function(response) {
        if (response.status === 200) {
          that.$notify({
            title: '成功',
            message: '图像信息修改成功！',
            type: 'success'
          })
        }
      }).catch(err => {
        this.$message.error(err.message)
        console.log(err)
      })
      this.reload()
    },
    imageDelete(index, row) {
      this.$confirm('此操作将永久删除该图像, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then(() => {
          console.log(row[0])
          const imageId = { 'imageid': row[0] }
          console.log(imageId)
          var that =
              this // 在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
          axios.post('http://10.9.21.97:5000/imageDelete', imageId).then(function(response) {
            if (response.data === 'success') {
              that.getTemplate()
              that.$notify({
                title: '成功',
                message: filename + ' 删除成功!',
                type: 'success'
              })
            }
          }).catch(err => {
            this.$message.error(err.message)
            console.log(err)
          })
          this.reload()
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });
        });
    },
    getImageInfo() {
      const path = 'http://10.9.21.97:5000/getImageInfo'
      var that = this
      axios.get(path).then(res => {
        console.log(res)
        that.imageInfo = res.data
        for (var i = 0; i < res.data.length; i++) {
          that.imageInfo[i].push(that.imageInfo[i][1] + that.imageInfo[i][2])
          that.srcList.push(that.imageInfo[i][1] + that.imageInfo[i][2])
        }
        console.log(that.srcList)
        console.log(that.imageInfo)
        that.total = that.imageInfo.length
      }).catch(error => {
        console.error(error)
      })
    },
    imageSearch(row) {
      var startTime = new Date(row[0])
      var startY = startTime.getFullYear() // 年
      var startM = (startTime.getMonth() + 1 < 10 ? '0' + (startTime.getMonth() + 1) : startTime.getMonth() + 1) // 月
      var startD = (startTime.getDate() < 10 ? '0' + (startTime.getDate()) : startTime.getDate()) // 日
      startTime = startY + '-' + startM + '-' + startD
      var endTime = new Date(row[1])
      var endY = endTime.getFullYear() // 年
      var endM = (endTime.getMonth() + 1 < 10 ? '0' + (endTime.getMonth() + 1) : endTime.getMonth() + 1) // 月
      var endD = (endTime.getDate() < 10 ? '0' + (endTime.getDate()) : endTime.getDate()) // 日
      endTime = endY + '-' + endM + '-' + endD
      const formData = new FormData()
      formData.append('startTime', startTime)
      formData.append('endTime', endTime)
      console.log(formData.get("startTime"))
      console.log(formData.get("endTime"))
      const config = {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }
      var that = this
      axios.post('http://10.9.21.97:5000/imageSearch', formData, config).then(res => {
        console.log(res.data)
        that.imageInfo = res.data
        for (var i = 0; i < res.data.length; i++) {
          that.imageInfo[i].push(that.imageInfo[i][1] + that.imageInfo[i][2])
          that.srcList.push(that.imageInfo[i][1] + that.imageInfo[i][2])
        }
        console.log(that.imageInfo)
        that.total = that.imageInfo.length
      }).catch(error => {
        console.error(error)
      })
      // axios.post('http://10.9.21.97:5000/imageSearch', formData, config).then(function(response) {
      //	if (response.data === 'success') {
      //		that.$notify({
      //			title: '成功',
      //			message: '查询成功！',
      //			type: 'success'
      //		});
      //	}
      // }).catch(err => {
      //	this.$message.error(err.message);
      //	console.log(err)
      // })
    },
    // 上传失败钩子
    handleError(err, file, fileList) {
      this.$message.error(err.errormsg)
    },
    // 上传成功钩子(在这里可以处理上传成功后端返回的数据)
    handleSuccess(rep, file, fileList) {
      console.log(req)
    },
    uploadFile(file){
      console.log(file)
      // 定义 filereader对象
      var reader = new FileReader()
      reader.readAsDataURL(file.file)
      var resolution = ""
      var that = this
      reader.onload = e=>{
          const img = e.target.result;
          const image = new Image()
          image.src=img
          image.onload= function(){
            //获取图像分辨率
            console.log(image.width.toString() + "*" + image.height.toString())
            that.imageresolution = image.width.toString() + "*" + image.height.toString()
            resolution = image.width.toString() + "*" + image.height.toString()
            if(image.complete){
              console.log("22222:"+resolution)
              that.imageresolution = image.width.toString() + "*" + image.height.toString()
              that.uploadImage(file.file, resolution)
            }
          }

      }
      // console.log("22222:"+resolution)
    }
  }
}
</script>

<style>
  .el-row {
    margin-bottom: 2px;

    &:last-child {
      margin-bottom: 0;
    }
  }

  .el-col {
    border-radius: 4px;
  }

  .bg-purple-dark {
    background: #99a9bf;
  }

  .bg-purple {
    background: #ffffff;
  }

  .bg-purple-light {
    background: #e5e9f2;
  }

  .grid-content {
    border-radius: 4px;
    min-height: 36px;
  }

  .row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
  }

  #extract {
    border-radius: 5px;
    box-shadow: 0 2px 6px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
  }

  .message_box_alert {
      width: 200px;
      height: 120px;
      word-break: break-all !important;
  }
</style>
