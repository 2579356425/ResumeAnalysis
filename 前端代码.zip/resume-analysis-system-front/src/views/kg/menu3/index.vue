<template>
  <div>
    <div>
      <el-row style="padding: 30px;" :gutter="10">
        <el-col :span="12" :offset="6">
          <div>
            <el-date-picker
                v-model="value1"
                type="date"
                placeholder="选择日期">
            </el-date-picker>
            <el-input v-model="taskname" style="width: 15%;margin-left: 5px;" placeholder="任务名称"></el-input>
            <el-button style="width: 22%;margin-left: 5px;" type="primary" @click='timer()'>发布定时任务</el-button>
          </div>
        </el-col>
      </el-row>
	</div>
	<div align="center">
		<a style="color: #00aaff;"><h3>热点事件采集任务列表</h3></a>
      <el-table id="extract"
        :data="tableData.filter(data => !search || data.relation.toLowerCase().includes(search.toLowerCase()))"
        border style="width: 95%;" :header-cell-style="{'text-align':'center'}" :cell-style="{'text-align':'center'}">
        <el-table-column prop="name" label="任务名称">
        </el-table-column>
        <el-table-column prop="starttime" label="开始时间">
        </el-table-column>
        <el-table-column prop="endtime" label="结束时间">
        </el-table-column>
        <el-table-column prop="taskstatus" label="状态">
        </el-table-column>
        <el-table-column align="right">
          <template slot="header" slot-scope="scope">
            <el-input v-model="search" size="mini" placeholder="输入关键字搜索" />
          </template>
          <template slot-scope="scope">
            <el-button type="primary" size="mini" @click="taskstart(scope.$index, scope.row)">开始</el-button>
            <el-button type="success" size="mini" @click="taskpause(scope.$index, scope.row)">暂停</el-button>
            <el-button type="danger" size="mini" @click="taskdel(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
	</div>
	  <!-- <div class="block" align="center" style="margin-top: 10px;">
	    <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage"
	      :page-sizes="pageSizes" :page-size="PageSize" layout="total, sizes, prev, pager, next, jumper" :total=total>
	    </el-pagination>
	  </div> -->
	<div align="center">
		  <a style="color: #00aaff;"><h3>热点事件列表</h3></a>
	  <el-table id="extract"
	    :data="tableData1.slice((currentPage-1)*PageSize,currentPage*PageSize).filter(data => !search1 || data.relation.toLowerCase().includes(search1.toLowerCase()))"
	    border style="width: 95%;" :header-cell-style="{'text-align':'center'}"
	    :cell-style="{'text-align':'center'}">
		<el-table-column type="index" label="序号">
		</el-table-column>
	    <el-table-column prop="title" label="新闻标题">
	    </el-table-column>
	    <el-table-column prop="content" label="新闻内容">
	    </el-table-column>
	    <el-table-column width="200px" align="right">
	      <template slot="header" slot-scope="scope">
	        <el-input v-model="search1" size="mini" placeholder="输入关键字搜索" />
	      </template>
	      <template slot-scope="scope">
	        <el-button type="primary" size="mini" @click="handleEdit(scope.$index, scope.row)">因果关系抽取</el-button>
	      </template>
	    </el-table-column>
	  </el-table>
	  <div class="block" align="center" style="margin-top: 10px;">
	    <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
	      :current-page="currentPage" :page-sizes="pageSizes" :page-size="PageSize"
	      layout="total, sizes, prev, pager, next, jumper" :total=total>
	    </el-pagination>
	  </div>
	</div>
  </div>
</template>

<script>
  import axios from 'axios'
  import Vue from 'vue'
  export default {
    data() {
      return {
        taskname: '',
        value2: '',
        currentPage: 1,
        total: 0,
        pageSizes: [5, 10, 20],
        PageSize: 5,
        newswebsite: 'http://news.carnoc.com/list/564/564791.html',
        tableData: [{
          name: '新闻采集',
          starttime: '2021-07-12 00:00:00',
          endtime: '2021-07-13 06:00:00',
          taskstatus: < el-tag type = "danger" > 暂停中 </el-tag>
        }],
		tableData1: [
			{
				title: "民航局对两个航班发出熔断指令",
				content: "据中国民航局网站消息，9月2日，民航局再发熔断指令，对埃及航空公司MS953航班（开罗至杭州）、孟加拉优速航空公司BS325航班（达卡至广州）实施熔断措施。",
			},
			{
				title: "黑龙江9月2日新增境外输入新冠肺炎确诊病例1例，详情公布",
				content: "黑龙江卫健委网站9月3日通报，2021年9月2日0-24时，黑龙江省新增境外输入新冠肺炎确诊病例1例。全省现有境外输入确诊病例4例。新增病例，男性，28岁，8月29日乘坐IJ213次航班由日本至哈尔滨太平国际机场。入境后，机场海关对其进行新冠病毒核酸检测结果呈阴性，闭环转运至入境人员集中隔离宾馆。9月1日晚，因发热闭环转运至定点医院观察治疗。9月2日，新冠病毒核酸检测结果呈阳性，经专家组诊断为新冠肺炎确诊病例（轻型）。",
			},
			{
				title: "8月27日起香港暂停卡塔尔航空从多哈来港航班",
				content: "香港特区政府卫生署卫生防护中心8月26日宣布，卡塔尔航空于8月24日由卡塔尔多哈飞抵香港的航班（QR818）有一名乘客抵达香港后确诊新冠肺炎，有两名乘客未能符合《预防及控制疾病（规管跨境交通工具及到港者）规例》指明的条件。因此，卫生署引用相关规例禁止卡塔尔航空营运的客机在8月27日至9月9日期间从卡塔尔多哈着陆香港。",
			},
		],
        search: '',
		search1: ''
      };
    },
    methods: {
      handleSizeChange(val) {
        this.PageSize = val
        this.currentPage = 1
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange(val) {
        this.currentPage = val
        console.log(`当前页: ${val}`);
      },
      timer() {
        var list = {
          name: this.taskname,
          starttime: (this.value2)[0],
          endtime: (this.value2)[1],
          taskstatus: < el-tag type = "success" > 运行中 </el-tag>
        }
        this.tableData.push(list)
        this.total = this.tableData.length
        console.log(this.tableData)
      },
      taskstart(index, row) {
        console.log(index)
        console.log(row)
        row['taskstatus'] = < el-tag type = "success" > 运行中 </el-tag>
      },
      taskpause(index, row) {
        row['taskstatus'] = < el-tag type = "danger" > 暂停中 </el-tag>
      },
      taskdel(index, row) {
        //index从0开始，如果不是从0开始就需要index-1传入splice，，用于删除数组第i个元素
        this.tableData.splice(index, 1)
      }
    },
    created() {
      this.total = this.tableData1.length
    }
  }
</script>

<style>
  .el-row {
    margin-bottom: 2px;

    &:last-child {
      margin-bottom: 0;
    }
  }

  .el-col {
    border-radius: 4px;
  }

  .bg-purple-dark {
    background: #99a9bf;
  }

  .bg-purple {
    background: #ffffff;
  }

  .bg-purple-light {
    background: #e5e9f2;
  }

  .grid-content {
    border-radius: 4px;
    min-height: 36px;
  }

  .row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
  }

  #extract {
    border-radius: 5px;
    box-shadow: 0 2px 6px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
  }
</style>
