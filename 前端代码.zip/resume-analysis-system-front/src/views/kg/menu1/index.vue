<template>
  <!-- 百度飞桨中文因果关系提取 https://aistudio.baidu.com/aistudio/projectdetail/2152707?forkThirdPart=1 -->
  <!-- https://gitee.com/-/ide/project/oscarlin/chinese-casual-extraction/edit/master/-/README.md -->
  <div style="padding:30px;">
    <el-row :gutter="24">
      <el-col :span="24">
        <div class="grid-content bg-purple">
          <div>
            <el-input style="width: 85%;" clearable placeholder="请输入新闻链接" prefix-icon="el-icon-search"
              v-model="newsurl"></el-input>
            <el-button style="width: 15%;" type="info" @click='getinfofromurl(newsurl)'>确定</el-button>
          </div>
          <div style="margin: 50px 0;"></div>
          <div style="vertical-align: middle;text-align: center;">
            <a style="color: #2196F3;font-size: larger;margin-right: 10px;">新闻标题</a>
            <el-input style="width: 65%;" placeholder="新闻标题" v-model="newstitle" :disabled="true">
            </el-input>
          </div>
          <div style="margin: 30px 0;"></div>
          <div style="vertical-align: middle;text-align: center;">
            <a style="margin-right: 10px;color: #2196F3;font-size: larger;">新闻内容</a>
            <el-input style="width: 85%;" type="textarea" autosize :rows="3" placeholder="新闻内容" v-model="newscontent"
              :disabled="true">
            </el-input>
          </div>
          <div style="margin: 50px 0;"></div>
          <el-table id="extract"
            :data="tableData.slice((currentPage-1)*PageSize,currentPage*PageSize).filter(data => !search || data.relation.toLowerCase().includes(search.toLowerCase()))"
            border style="width: 100%;" :header-cell-style="{'text-align':'center'}"
            :cell-style="{'text-align':'center'}">
            <el-table-column prop="sentence" label="原句">
            </el-table-column>
            <el-table-column prop="bsubject" label="原因主语">
            </el-table-column>
            <el-table-column prop="bpredicate" label="原因谓语">
            </el-table-column>
            <el-table-column prop="osubject" label="结果主语">
            </el-table-column>
            <el-table-column prop="opredicate" label="结果谓语">
            </el-table-column>
            <el-table-column prop="relation" label="关系词">
            </el-table-column>
            <el-table-column align="right">
              <template slot="header" slot-scope="scope">
                <el-input v-model="search" size="mini" placeholder="输入关键字搜索" />
              </template>
              <template slot-scope="scope">
                <el-button type="success" size="mini" @click="handleEdit(scope.$index, scope.row)">导入知识图谱</el-button>
              </template>
            </el-table-column>
          </el-table>
          <div class="block" align="center" style="margin-top: 10px;">
            <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
              :current-page="currentPage" :page-sizes="pageSizes" :page-size="PageSize"
              layout="total, sizes, prev, pager, next, jumper" :total=total>
            </el-pagination>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
  import axios from 'axios'
  import Vue from 'vue'
  export default {
    data() {
      return {
        currentPage: 1,
        total: 0,
        pageSizes: [5, 10, 20],
        PageSize: 5,
        newsurl: 'http://news.carnoc.com/list/564/564791.html',
        tableData: [
			{
				bpredicate: "3日晚发生漏水",
				bsubject: "纽约肯尼迪国际机场一个塔台",
				opredicate: "延误或改降其他机",
				osubject: "近300架航班",
				relation: "导致",
				sentence: "据美国媒体4日报道,纽约肯尼迪国际机场一个塔台3日晚发生漏水,导致近300架航班延误或改降其他机场",
			},
			{
				bpredicate: "轻微漏水",
				bsubject: "机场一个主塔台",
				opredicate: "转移",
				osubject: "空管人员",
				relation: "未识别出关系词",
				sentence: "肯尼迪机场3日19时左右在社交媒体上说,机场一个主塔台“轻微漏水”,空管人员转移至另一个塔台"
			}
		],
        newscontent: ['据美国媒体4日报道,纽约肯尼迪国际机场一个塔台3日晚发生漏水,导致近300架航班延误或改降其他机场', '\n肯尼迪机场3日19时左右在社交媒体上说,机场一个主塔台“轻微漏水”,空管人员转移至另一个塔台', '由于相关操作和当地天气等原因,美国联邦航空局正在叫停大多数前往该机场的航班起飞', '\n约1小时后,肯尼迪机场表示,空管人员正在返回主塔台', '机场仍然开放,但航班可能会出现延误', '\n据报道,塔台漏水当晚导致近300架航班延误或改降,目前塔台已被修复,机场运行正常', '\n肯尼迪国际机场是美国最繁忙的空港之一,2019年旅客吞吐量超过6250万人次,90多家航空公司在该机场运营', '7月4日是美国独立日', '据报道,美国本周末有约370万人计划乘飞机出行,比去年同期增加164%'],
        newstitle: '纽约肯尼迪机场塔台漏水 数百架航班延误或改降',
        search: ''
      }
    },
	created() {
		this.total = this.tableData.length;
	},
    methods: {
      handleSizeChange(val) {
        this.PageSize = val
        this.currentPage = 1
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange(val) {
        this.currentPage = val
        console.log(`当前页: ${val}`);
      },
      handleEdit(index, row) {
        //导入关系到知识图谱
        console.log(index, row);
        let formData = new FormData();
        formData.append('bpredicate', row['bpredicate']);
        formData.append('bsubject', row['bsubject']);
        formData.append('opredicate', row['opredicate']);
        formData.append('osubject', row['osubject']);
        formData.append('relation', row['relation']);
        formData.append('sentence', row['sentence']);
        let config = {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
        var that = this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
        axios.post('http://106.54.170.52:7777/importnoderelation', formData, config).then(function(response) {
          if (response.status === 200) {
            that.$notify({
              title: '成功',
              message: '知识图谱导入成功',
              type: 'success'
            });
          }
        }).catch(err => {
          this.$message.error(err.message);
          console.log(err)
        })
      },
      getinfofromurl(newsurl) {
        let formData = new FormData();
        formData.append('url', this.newsurl);
        let config = {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
        var that =
          this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
        axios.post('http://127.0.0.1:5000/newsurl', formData, config).then(function(response) {
          if (response.status === 200) {
            console.log(response.data)
            that.newstitle = response.data.title
            that.newscontent = response.data.content.toString()
            that.tableData = response.data.sentences
            that.total = that.tableData.length
            that.$notify({
              title: '成功',
              message: '新闻解析成功',
              type: 'success'
            });
          }
        }).catch(err => {
          this.$message.error(err.message);
          console.log(err)
        })
      }
    }
  }
</script>
<style>
  #extract {
    border-radius: 25px;
    box-shadow: 0 2px 6px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
  }
  .default-light {
    color: yellow;
  }
  .el-row {
    margin-bottom: 20px;

    &:last-child {
      margin-bottom: 0;
    }
  }

  .el-col {
    border-radius: 4px;
  }

  .bg-purple-dark {
    background: #99a9bf;
  }

  .bg-purple {
    background: #ffffff;
  }

  .bg-purple-light {
    background: #e5e9f2;
  }

  .grid-content {
    border-radius: 4px;
    min-height: 360px;
  }

  .row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
  }
</style>
