<!-- 目标检测 -->
<template>
  <div class="main">
     <baidu-map
        class="bm-view"
        :scroll-wheel-zoom="true"
        :center="center"
        :zoom="zoom"
        :dragging="mapDragging"
        mapType="BMAP_SATELLITE_MAP"
        @moving="syncCenterAndZoom"
        @moveend="syncCenterAndZoom"
        @zoomend="syncCenterAndZoom"
        >
        <!-- <bm-scale anchor="BMAP_ANCHOR_TOP_LEFT" style="font-color: red"></bm-scale> 比例尺 -->
        <bm-navigation anchor="BMAP_ANCHOR_BOTTOM_LEFT"></bm-navigation> <!--缩放-->
        <bm-map-type :map-types="['BMAP_SATELLITE_MAP', 'BMAP_HYBRID_MAP', 'BMAP_NORMAL_MAP']" anchor="BMAP_ANCHOR_TOP_LEFT"></bm-map-type> <!--地图类型-->
        <bm-overlay
          pane="labelPane"
          :class="{sample: true, active}"
          @draw="draw"
          @mouseover.native="active = true"
          @mouseleave.native="active = false">
          <div id="page" v-if="imageActive==1">
            <div class="wrapper" id="wrapper" style="width: var(--Width);height: var(--Height);">
              <div class="before" id="before" style="width: var(--Width);height: var(--Height);">
                <img id="img1" :src="url1" draggable="false" style="width: var(--Width);height: var(--Height);">
              </div>
            </div>
          </div>
        </bm-overlay>
      </baidu-map>

       <!--右侧表单-->
      <div style="width: 22%;height: 100%;position: absolute; right: 0px; top: -20px; background-color:#304156; border: 2px solid #fff;margin-top: 1.5%;" >
        <div style="margin: 0 auto;width: 80%; height: 90%; padding-top: 3%;" >

          <el-steps style="margin: 10px auto;" :active="active2" finish-status="success">
            <el-step title="选择图像模型" icon="el-icon-thumb"></el-step>
            <el-step title="解译结果" icon="el-icon-view"></el-step>
          </el-steps>
          <div style="height: 20%;" align="center" v-if="active2==0">
            <!-- <div>
              <i class="el-icon-picture-outline" style="font-size: 50px; margin: 0 auto;"></i>
            </div> -->
            <div style="margin: 10px;">
              <el-button size="medium" type="primary" style="margin-left:10px;margin-top:10px;height: 34px;" @click="getImageInfo(); selectPicture = true;">选择图像</el-button>
            </div>
            <div>
                <el-dialog title="图像选择" :visible.sync="selectPicture" width="80%">
                <el-table
                 :data="tableData.slice((currentPage-1)*PageSize,currentPage*PageSize).filter(data => !search || data.relation.toLowerCase().includes(search.toLowerCase()))"
                 style="width: 95%;"
                 :header-cell-style="{'text-align':'center'}"
                 :cell-style="{'text-align':'center'}">

                  <el-table-column type="index" :index="indexMethod" label="序号" />
                    <el-table-column prop="7" label="图像">
                      <template slot-scope="scope">
                        <el-image
                          style="width: 35%; height: 35%"
                          :src="scope.row[7]"
                          :lazy="true"
                          :preview-src-list="srcList"
                        />
                      </template>
                    </el-table-column>
                    <el-table-column prop="2" label="图像名称" />
                    <el-table-column prop="6" label="图像分辨率" />
                    <el-table-column prop="4" label="图像拍摄时间" />
                    <el-table-column prop="5" label="图像上传时间" />
                    <el-table-column width="200px" align="right" label="选择">
                      <template slot-scope="scope">
                        <!-- <el-button @click="selectImage(scope.$index, scope.row)">添加图像</el-button> -->
                        <el-checkbox @change="getRow(scope.row)"></el-checkbox>
                      </template>
                    </el-table-column>

                </el-table>
                <div class="block" align="center" style="margin-top: 10px;">
                  <el-pagination
                    :current-page="currentPage"
                    :page-sizes="pageSizes"
                    :page-size="PageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="total"
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                  />
                  <el-button size="small" type="primary" style="margin-left:78%;height: 34px;" @click="selectPicture = false;selectImages()">确认</el-button>
                </div>
              </el-dialog>
            </div>
            <br>
            <div style="margin-left: 10px; text-align: left;">
              <span style="color: red; left: 10px;align: left">*</span>
              <span style="text-align:left; font-size: 15px;color: #fff">目标&模型选择</span>
            </div>
            <div style="height: 10px;"></div>
             <el-cascader size="small" v-model="model" :options="options" placeholder="请选择目标&模型" style="width: 100%;" popper-class="pc-sel-area-cascader">
            </el-cascader>
            <div style="height: 8px;"></div>

            <div style="margin-left: 10px; margin-top: 5px;text-align: left;">
              <span style="color: red; left: 10px; align: left">*</span>
              <span style="text-align: left; font-size: 15px;color: #fff">过滤阈值</span>
              <el-popover
                placement="top-start"
                width="100"
                trigger="hover"
                content="选择图斑过滤面积，小于此面积不提取"
                popper-class="el_popover_class1">
              <el-button size="medium" slot="reference" type="goon" icon="el-icon-question" circle></el-button>
            </el-popover>
            </div>
            <div style="height: 4px;"></div>
            <div>
              <el-input size="mini" style="width: 73%;" v-model="threshold"></el-input>
              <!-- <el-span style="font-size:15px;width:25%; height:40px;border-radius:solid 2px ;margin-right: 30px">  像素  </el-span> -->
              <!-- <el-input type="text" size="mini" style="width: 25%;" placeholder="像素" disabled></el-input> -->
              <!-- <el-input type="textarea" placeholder="像素"></el-input> -->
              <el-input type="text" size="mini" style="width: 60px; height: 25px; border-width:1px;" v-model="像素"></el-input>
             <!-- <el-button size="mini" style="font-size: 14px; height: 27px; width: 20px; margin-top: 2px;" hover>像素</el-button> -->
            </div>
            <div style="height: 8px;"></div>

            <div style="margin-left: 10px; margin-top: 2px;text-align: left;">
              <span style="color: red; left: 10px;align: left">*</span>
              <span style="text-align:left; font-size: 15px;color: #fff">置信度</span>
              <el-popover
                placement="top-start"
                width="100"
                trigger="hover"
                content="选择识别目标的置信度，目前给定高、中、低三个选项"
                popper-class="el_popover_class2">
              <el-button size="medium" slot="reference" type="goon" icon="el-icon-question" circle></el-button>
            </el-popover>
            </div>
            <div style="height: 4px;"></div>
             <el-select size="small" v-model="confidence" placeholder="请选择置信度" style="width: 100%;" :popper-append-to-body="false">
              <el-option
                v-for="item in options2"
                :key="item.key"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
            <div style="height: 10px;"></div>

            <div style="margin-left: 10px; text-align: left;">
              <span style="color: red; left: 10px;align: left">*</span>
              <span style="text-align:left; font-size: 14px;color: #fff">裁块大小</span>
            </div>
            <div style="height: 10px;"></div>
             <el-select size="small" v-model="cropsize" placeholder="请选择裁块大小" style="width: 100%;" :popper-append-to-body="false">
              <el-option
                v-for="item in options3"
                :key="item.key"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
            <div style="height: 10px;"></div>

            <div style="margin-left: 10px; margin-top: 10px;text-align: left;">
              <span style="color: red; left: 10px; align: left">*</span>
              <span style="text-align:left font-size: 14px;color: #fff">结果名称</span>
            </div>
            <div style="height: 8px;"></div>
              <el-input size="mini" style="width: 100%;" v-model="resultName" placeholder="请输入结果文件名称"></el-input>
            <div style="height: 8px;"></div>

            <div>
              <el-button size="medium" type="primary" style="margin-left:10px;margin-top:25px;height: 34px;" @click="interpret();resultAppear()">处理分析</el-button>
            </div>
          </div>
          <div style="height: 20%;" align="center" v-if="active2==1">
            <div style="margin-top: 60px; margin-bottom: 20px;" align="center">
              <a style="color: #00aaff;"><h2>图斑统计</h2></a>
            </div>
            <div class="inputDeep">
              <el-form ref="form" :model="form" style="margin-left: 10px;font-size: 18px;" label-position="left" size="large">
                <el-form-item style="margin-bottom: 10px;" size="large">
                  <span slot="label">
                    <span style="font-size: 18px;color: #fff;">类型:</span>
                  </span>
                  <span class="el_input" size="large" slot="label" style="font-size: 18px;color: #fff;">{{form.type}}</span>
                  <!-- <el-input class="el_input" v-model="form.type" size="large" slot="label"></el-input> -->
                </el-form-item>
                <el-form-item style="margin-bottom: 10px;" size="large">
                  <span slot="label">
                    <span style="font-size: 18px;color: #fff;">检测目标:</span>
                  </span>
                  <span class="el_input" size="large" slot="label" style="font-size: 18px;color: #fff;">{{form.object}}</span>
                  <!-- <el-input class="el_input" v-model="form.object" size="large" slot="label"></el-input> -->
                </el-form-item>
                <el-form-item  style="margin-bottom: 10px;" size="large">
                  <span slot="label">
                    <span style="font-size: 18px;color: #fff;">图斑总数量:</span>
                  </span>
                  <span class="el_input" size="large" slot="label" style="font-size: 18px;color: #fff;">{{form.number}}</span>
                  <!-- <el-input class="el_input" v-model="form.number" size="large" slot="label"></el-input> -->
                </el-form-item>
                <el-form-item style="margin-bottom: 10px;" size="large">
                  <span slot="label">
                    <span style="font-size: 18px;color: #fff;">图斑总面积:</span>
                  </span>
                  <span class="el_input" size="large" slot="label" style="font-size: 18px;color: #fff;">{{form.area}}</span>
                  <!-- <el-input class="el_input" v-model="form.area" size="large" slot="label"></el-input> -->
                </el-form-item>
              </el-form>
              <el-button size="medium" type="primary" style="margin-top:40px;font-size: 15px;" @click="targetDetectionResultDownload()">
                <i class="el-icon-download"></i>&nbsp;解译结果下载
              </el-button>
              <el-button size="medium" type="danger" style="margin-top:20px; margin-left: 0px;font-size: 15px;" @click="targetDetectionResultDelete()">
                <i class="el-icon-delete"></i>&nbsp;解译结果删除
              </el-button>
            </div>
          </div>
        </div>
      </div>
  </div>
</template>

<script>
import axios from 'axios'
import Vue from 'vue'
import BaiduMap from 'vue-baidu-map'

Vue.use(BaiduMap, {
  // ak 是在百度地图开发者平台申请的密钥 详见 http://lbsyun.baidu.com/apiconsole/key */
  ak: 'LnP4INwY2AY2VSZFwcRMbNhPxUeBB7sA'
})

export default {
  inject: ['reload'], // 注入刷新页面的依赖
  data() {
    return {
      active: false,
      active2: 0,
      imageActive: 0,
      selectPicture: false,
      tableData: [],
      srcList: [],
      currentPage: 1,
      pageSizes: [5, 10, 20],
      PageSize: 5,
      total: 0,
      checkList: [],
      cropsize: [],
      resultName: '',
      threshold: 0,
      url1: '',
      像素: '像素',
      confidence: '',
      model: [],
      resultUrl: '',  // 压缩了结果图像的zip路径
      imageZoom: 0, //图片缩放次数
      imageWidth: 582,
      imageHeight: 500,
      options: [{
          value: '操场',
          label: '操场',
          children:[{
            value: 'YOLOv3',
            label: 'YOLOv3'
          },{
            value: 'FasterRCNN',
            label: 'FasterRCNN'
          },{
            value: 'PPYOLO',
            label: 'PPYOLO'
          },{
            value: 'MaskRCNN',
            label: 'MaskRCNN'
          }]}, {
          value: '油罐',
          label: '油罐',
          children:[{
            value: 'YOLOv3',
            label: 'YOLOv3'
          },{
            value: 'PicoDet',
            label: 'PicoDet'
          },{
            value: 'PPYOLO',
            label: 'PPYOLO'
          },{
            value: 'MaskRCNN',
            label: 'MaskRCNN'
          }]}, {
          value: '天桥',
          label: '天桥',
          children:[{
            value: 'YOLOv3',
            label: 'YOLOv3'
          },{
            value: 'PPYOLO',
            label: 'PPYOLO'
          },{
            value: 'PPYOLOTiny',
            label: 'PPYOLOTiny'
          },{
            value: 'MaskRCNN',
            label: 'MaskRCNN'
          }]}, {
          value: '飞机',
          label: '飞机',
          children:[{
            value: 'FasterRCNN',
            label: 'FasterRCNN'
          },{
            value: 'PPYOLO',
            label: 'PPYOLO'
          },{
            value: 'PPYOLOv2',
            label: 'PPYOLOv2'
          },{
            value: 'PicoDet',
            label: 'PicoDet'
          }]}],
        options2: [{
          key: '选项1',
          value: '低(算法模型召回高。)',
        }, {
          key: '选项2',
          value: '中(算法模型精度和召回平衡。)',
        }, {
          key: '选项3',
          value: '高(算法模型精度高。)',
        }],
        options3:[{
          key: '选项1',
          value: '8'
        },{
          key: '选项2',
          value: '16'
        },{
          key: '选项3',
          value: '32'
        },{
          key: '选项4',
          value: '64'
        },{
          key: '选项5',
          value: '128'
        }],
      resultTable: [{
        // type: '类型',
        // number: '图斑总数量',
        // area: '图版总面积',
        type: '',
        number: '',
        area: ''
      },],
      form: {
        type: '',
        number: '',
        area: ''
      },
      center: {
        lng: 120.485,
        lat: 36.125
      },
      zoom: 15,
      mapDragging: true,//允许地图拖动
    }
  },
  computed: {},
  watch: {},
  methods: {
    indexMethod(index) {
      return index + ((this.currentPage - 1) * this.PageSize) + 1
    },
    handleSizeChange(val) {
      this.PageSize = val
      this.currentPage = 1
      console.log(`每页 ${val} 条`)
    },
    handleCurrentChange(val) {
      this.currentPage = val
      console.log(`当前页: ${val}`)
    },
    getImageInfo() {
      const path = 'http://10.9.21.97:5000/getImageInfo'
      var that = this
      axios.get(path).then(res => {
        that.tableData = res.data
        for (var i = 0; i < res.data.length; i++) {
          that.tableData[i].push(that.tableData[i][1] + that.tableData[i][2])
          that.srcList.push(that.tableData[i][1] + that.tableData[i][2])
        }
        console.log(that.tableData)
        that.total = that.tableData.length
      }).catch(error => {
        console.error(error)
      })
    },
    interpret(){
      if(this.checkList.length == 0){
        this.$notify({
            title: '失败',
            message: '请选择要解译的图像！',
            type: 'error'
          })
        return
      }
      if(this.model == ''){
        this.$notify({
            title: '失败',
            message: '模型不能为空，请选择模型！',
            type: 'error'
          })
        return
      }
      if(this.confidence == ''){
        this.$notify({
            title: '失败',
            message: '置信度不能为空，请选择置信度！',
            type: 'error'
          })
        return
      }
      if(this.cropsize == ''){
        this.$notify({
            title: '失败',
            message: '裁块大小不能为空，请选择裁块大小！',
            type: 'error'
          })
        return
      }
      if(this.resultName == ''){
        this.$notify({
            title: '失败',
            message: '结果名称不能为空，请输入结果名称！',
            type: 'error'
          })
        return
      }
      const loading = this.$loading({
          lock: true,
          text: 'Loading',
          spinner: 'el-icon-loading',
          background: 'rgba(0, 0, 0, 0.7)'
        });
      let formData = new FormData()
      formData.append('imageid', this.checkList[0][0])
      formData.append('model', this.model)
      formData.append('threshold', this.threshold)
      formData.append('confidence', this.confidence)
      formData.append('cropsize', this.cropsize)
      formData.append('resultName', this.resultName)
      const config = {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }
      var that = this
      axios.post('http://10.9.21.97:5000/targetDetection', formData, config).then(res => {
        console.log(res.data)
        console.log(that.model)
        if(res.status===200){
          loading.close()
          that.active2 = 1
          that.resultInfo = res.data
          that.url1=res.data['img_address']
          that.resultUrl = that.resultInfo['zip_address']
          this.form.type='  目标检测',
          this.form.object= that.model[0],
          this.form.number="  "+this.resultInfo['result'][0],
          this.form.area="  "+this.resultInfo['result'][1] + "像素"
          console.log(that.url1)
        }
      }).catch(err => {
        this.$message.error(err.message)
        console.log(err)
      })
    },
    getRow(row){
      if(this.checkList.includes(row)){
        this.checkList.forEach(function (item, index, arr){
          if(item == row){
            arr.splice(index, 1)
          }
        })
      }
      else{
        this.checkList.push(row)
      }
      console.log(this.checkList)
    },
    selectImages(){
      var that = this
      if(this.checkList.length != 1){
        that.$notify({
            title: '失败',
            message: '请重新选择一张图像进行分析！',
            type: 'error'
          })
      }
      else{
        this.url1=this.checkList[0][7]
        this.imageActive = 1
        this.$nextTick(() => {
          this.listenImage()
      })
      }
    },
    listenImage(){
      var that = this
      document.querySelector('.wrapper').addEventListener('mousewheel', function(e) {
        //e.wheelDelta大于0,上滑；小于0，下滑
        if(e.wheelDelta > 0){  // 上滑
          that.imageZoom = that.imageZoom + 1
          that.imageWidth = that.imageWidth*2
          that.imageHeight = that.imageHeight*2
          document.getElementById("wrapper").style.width = that.imageWidth + "px"
          document.getElementById("wrapper").style.height = that.imageHeight + "px"
          document.getElementById("before").style.width = that.imageWidth + "px"
          document.getElementById("before").style.height = that.imageHeight + "px"
          document.getElementById("img1").style.width = that.imageWidth + "px"
          document.getElementById("img1").style.height = that.imageHeight + "px"
        }
        else{ // 下滑
          that.imageZoom = that.imageZoom - 1
          that.imageWidth = that.imageWidth*0.5
          that.imageHeight = that.imageHeight*0.5
          document.getElementById("wrapper").style.width = that.imageWidth + "px"
          document.getElementById("wrapper").style.height = that.imageHeight + "px"
          document.getElementById("before").style.width = that.imageWidth + "px"
          document.getElementById("before").style.height = that.imageHeight + "px"
          document.getElementById("img1").style.width = that.imageWidth + "px"
          document.getElementById("img1").style.height = that.imageHeight + "px"
        }
      })
    },
    targetDetectionResultDownload() {
      window.open(this.resultUrl + '?response-content-type=application/octet-stream')
      this.$notify({
        title: '成功',
        message: '解译结果下载成功！',
        type: 'success'
      })
    },
    targetDetectionResultDelete(){
       this.$confirm('此操作将永久删除该检测结果, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let formData = new FormData()
          formData.append('zipPath', this.resultUrl)
          const config = {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          }
          var that = this
          axios.post('http://10.9.21.97:5000/resultDelete', formData, config).then(res => {
            if(res.status===200){
              that.$notify({
                title: '成功',
                message: '解译结果删除成功！',
                type: 'success'
              })
            }
          }).catch(error => {
            console.error(error)
          })
          this.reload()
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });
        });
    },
    syncCenterAndZoom (e) {  //地图配置
      const {lng, lat} = e.target.getCenter()
      this.center.lng = lng
      this.center.lat = lat
      this.zoom = e.target.getZoom()
    },
    draw ({el, BMap, map}) {  //创建地图上的图层
      const pixel = map.pointToOverlayPixel(new BMap.Point(120.485, 36.125))
      el.style.left = pixel.x - 300 + 'px'
      el.style.top = pixel.y - 300 + 'px'
    },
    created() {}

  }}
</script>

<style scoped>
        #page {
            width: 100%;
            height: 100%;
            position: absolute;
        }

        * {
            margin: 0;
            box-sizing: border-box;
        }

        .wrapper {
            --Width: 582px;
            --Height: 500px;
            position: absolute;
            left: 40%;
            top: 50%;
            transform: translate3d(-50%, -50%, 0);
            overflow: hidden;
            /* box-shadow: 0 10px 20px rgba(0, 0, 0, 0.19), 0 6px 6px rgba(0, 0, 0, 0.23); */
        }

        .before{
            --Width: 560px;
            --Height: 560px;
        }
        .after {
            width: 100%;
            height: 100%;
            background-repeat: no-repeat;
            background-color: white;
            background-size: cover;
            background-position: center;
            position: absolute;
            top: 0;
            left: 0;
            pointer-events: none;
            overflow: hidden;
        }

        .content-image {
            height: 100%;
        }

        /* .after {
            width: 125px;
             animation-name: move;
            animation-duration: 10s;
            animation-iteration-count: 1;
        } */

        .scroller {
            width: 50px;
            height: 50px;
            position: absolute;
            left: 100px;
            top: 50%;
            transform: translateY(-50%);
            border-radius: 50%;
            background-color: transparent;
            opacity: 0.9;
            pointer-events: auto;
            cursor: pointer;
            /* animation-name:move1;
            animation-duration:10s;
            animation-iteration-count:1; */
        }

        .scroller:hover {
            opacity: 1;
        }

        .scrolling {
            pointer-events: none;
            opacity: 1;
            z-index: 1;
        }

        .scroller__thumb {
            width: 100%;
            height: 100%;
            padding: 5px;
        }

        .scroller:before,
        .scroller:after {
            content: " ";
            display: block;
            width: 7px;
            height: 9999px;
            position: absolute;
            left: 50%;
            margin-left: -3.5px;
            z-index: 30;
            transition: 0.1s;
        }

        .scroller:before {
            top: 100%;
        }

        .scroller:after {
            bottom: 100%;
        }

        .scroller {
            border: 5px solid #fff;
        }

        .scroller:before,
        .scroller:after {
            background: #fff;
        }

        .bm-view {
          width: 100%;
          height: 720px;
        }

        .sample {
          width: 582px;
          height: 500px;
          line-height: 40px;
          /* background: rgba(0,0,0,0.5); */
          overflow: hidden;
          /* box-shadow: 0 0 5px #000; */
          color: #fff;
          text-align: center;
          padding: 10px;
          position: absolute;
        }
        .sample.active {
          /* background: rgba(0,0,0,0.75); */
          color: #fff;
        }

        .el-steps /deep/ .el-step__icon{
            /* color: #fff; */
            background-color: #304156;
        }
        .el-steps /deep/ .el-step__head.is-process /deep/ .el-step__icon.is-icon{
          color: white;
          background-color: #304156;
        }
        .el-steps /deep/ .el-step__head.is-wait /deep/ .el-step__icon.is-icon{
          color: rgb(107, 108, 109);
          background-color: #304156;
        }
        .el-steps /deep/ .el-step__icon.is-finish{
          color: greenyellow;
          background-color: #304156;
        }
        .el-steps /deep/ .el-step__title.is-process{
          color: white;
        }
        .el-steps /deep/ .el-step__title.is-wait{
          /* color: #C0C4CC; */
          color: rgb(107, 108, 109);
        }
          .el-steps /deep/ .el-step__title.is-finish{
          color: greenyellow;
        }
        .step {
          width: 100%;
          height: 8%;
          margin-top: 4%;
        }
        .el-input /deep/ .el-input__inner{
          color: #fff;
          background-color: #1C2734;
        }
        .el-cascader.el-cascader--small /deep/ .el-input /deep/ .el-input__inner{
          color: #fff;
          background-color: #1C2734;
        }
        .el-select.el-select--small /deep/ .el-input.el-input--small /deep/  .el-input__inner{
          color: #fff;
          background-color: #1C2734;
        }
        /deep/ .el-select-dropdown{
           color: white !important;
           font-weight: bold;
           background-color: #1C2734 !important;
        }
        .el-button--goon {
          color: rgb(127, 125, 125);
          border-color: #304156;
          background-color: transparent;
          height: 10px;
          margin-bottom: 15px;
          vertical-align: middle;
        }
       @keyframes move {
            0% {
                width:10%
            }

            25% {
                width:30%
            }

            50% {
                width:50%
            }

            75% {
                width:80%

            }

            100% {
                width:100%
            }
        }
        @keyframes move1 {
            0% {
                left:0px
            }

            25% {
                left:10%
            }

            50% {
                left:30%
            }

            75% {
                left:60%

            }

            100% {
                left:100%
            }
        }

</style>
<style>
  .pc-sel-area-cascader{
          color: #fff;
          font-weight: bold;
          background-color: #1C2734;
          .el-scrollbar__view.el-cascader-menu__list{
            color: #fff;
            font-weight: bold;
             background-color: #1C2734;
          }
        }
    .el-popover.el_popover_class1{
            font-size: 10px !important;
            color: white;
            max-width: 5%;
            height: 5.5%;
            padding: 0.5%;
            background-color: #49596f !important;
        }
          .el-popover.el_popover_class2{
            font-size: 10px !important;
            color: white;
            max-width: 5%;
            height: 5.5%;
            padding: 0.5%;
            background-color: #49596f !important;
        }
        .el-input--small .el-input__inner{
           color: #fff;
           background-color: #1C2734;
         }

         .el-steps /deep/ .el-step__icon{
             /* color: #fff; */
             background-color: #304156;
         }
         .el-steps /deep/ .el-step__head.is-process /deep/ .el-step__icon.is-icon{
           color: white;
           background-color: #304156;
         }
         .el-step__head.is-wait{
           color: rgb(107, 108, 109);
           background-color: #304156;
         }
         .el-step__head.is-process{
           color: white;
           background-color: #304156;
         }
         .el-steps /deep/ .el-step__icon.is-finish{
           color: greenyellow;
           background-color: #304156;
         }
        .el-icon-thumb:before{
           color: white;
           background-color: #304156;
         }

         .el-select-dropdown__item{
           color: white;
         }
         .el-select-dropdown__item.hover {
           background-color: #304156;
         }

         .el-cascader-node__label {
           color: white;
         }
         .el-cascader-node:hover {
           background-color: #304156 !important;
         }
         .el-cascader-node.in-active-path{
           background-color: #304156 !important;
         }
         .el-cascader-node__label.hover {
           background-color: #304156;
         }
</style>
