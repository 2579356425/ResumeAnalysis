<template>
  <div :class="className" :style="{height:height,width:width}" />
</template>

<script>
import echarts from 'echarts'
import { color } from 'echarts/lib/theme/light'
require('echarts/theme/macarons') // echarts theme
import resize from './mixins/resize'

export default {
  mixins: [resize],
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '100%'
    },
    pieData: {
      type: Object
    }
  },
  data() {
    return {
      chart: null
    }
  },
  mounted() {
    this.$nextTick(() => {
      this.initChart()
    })
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      // console.log(this.pieData)
      this.chart = echarts.init(this.$el, 'macarons')
      this.setOptions(this.pieData)
    },
    setOptions(pieData){
      // console.log(pieData)
      this.chart.setOption({
        tooltip: {
          trigger: 'item',
        },
        legend: {
          type: 'scroll',
          orient: 'vertical',
          left: 120,
          textStyle: {
            color: '#FFFFFF'
          }
        },
        color: ['#0000FF', '#008000', '#FF003C', '#FF8C00'],
        series: [
          {
            type: 'pie',

            // roseType: 'radius',
            radius: ['30%', '60%'],
            avoidLabelOverlap: false,
            center: ['30%', '50%'],
            labelLine: {
              show: false
            },
            label: {
              show: false,
              position: 'center'
            },
            data: pieData
            // animationEasing: 'cubicInOut',
            // animationDuration: 2600
          }
        ]
      })
    }
  }
}
</script>
