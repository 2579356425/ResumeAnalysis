<!-- 变化检测 -->
<template>
  <div class="main">
    <!-- <div style="height:660px;">
      <div id="map" style="height: 100%;" />
    </div> -->
    <!-- 百度地图密钥：LnP4INwY2AY2VSZFwcRMbNhPxUeBB7sA -->
    <!--禁止地图拖拽 :dragging="false"-->
    <baidu-map
        class="bm-view"
        :scroll-wheel-zoom="true"
        :center="center"
        :zoom="zoom"
        :dragging="mapDragging"
        mapType="BMAP_SATELLITE_MAP"
        @moving="syncCenterAndZoom"
        @moveend="syncCenterAndZoom"
        @zoomend="syncCenterAndZoom"
        >
        <!-- <bm-scale anchor="BMAP_ANCHOR_TOP_LEFT" style="font-color: red"></bm-scale> 比例尺 -->
        <bm-navigation anchor="BMAP_ANCHOR_BOTTOM_LEFT"></bm-navigation> <!--缩放-->
        <bm-map-type :map-types="['BMAP_SATELLITE_MAP', 'BMAP_HYBRID_MAP', 'BMAP_NORMAL_MAP']" anchor="BMAP_ANCHOR_TOP_LEFT"></bm-map-type> <!--地图类型-->
        <bm-overlay
          pane="labelPane"
          :class="{sample: true, active3}"
          @draw="draw"
          @mouseover.native="active3 = true"
          @mouseleave.native="active3 = false">
          <div id="page" v-if="imageActive==1" >
            <div class="wrapper" id="wrapper" style="background-color: transparent;width: var(--Width);height: var(--Height);">
              <div class="after1" id="after1" style="z-index: 30; background-color: transparent;">
                <img id="img1" :src="url3" draggable="false" style="width: var(--Width);height: var(--Height);">
              </div>
              <div class="before" id="before" style="width: var(--Width);height: var(--Height);">
                <img id="img2" :src="url1" draggable="false" style="width: var(--Width);height: var(--Height);">
              </div>
              <div class="after" id="after" style="width: var(--Width);height: var(--Height);">
                <img id="img3" :src="url2" draggable="false" style="width: var(--Width);height: var(--Height);">
              </div>
              <div class="scroller" style="left: 125px;">
                <svg
                  class="scroller__thumb"
                  xmlns="http://www.w3.org/2000/svg"
                  width="100"
                  height="100"
                  viewBox="0 0 100 100"
                >
                  <polygon points="0 50 37 68 37 32 0 50" style="fill:#fff" />
                  <polygon points="100 50 64 32 64 68 100 50" style="fill:#fff" />
                </svg>
              </div>
            </div>
          </div>
        </bm-overlay>
    </baidu-map>
    <!--右侧表单-->
    <div style="width: 22%;height: 100%;position: absolute; right: 0px; top: -20px; background-color:#304156; border: 2px solid #ddd;margin-top: 1.5%;" >
      <div style="margin: 0 auto;width: 80%; height: 90%; padding-top: 3%; " >
        <div class="step">
          <el-steps  style="margin: 0 auto;" :active="active2" finish-status="success">
          <el-step title="选择图像模型"  icon="el-icon-thumb"></el-step>
          <el-step title="解译结果" icon="el-icon-view"></el-step>
        </el-steps>
        </div>
        <div style="height: 20%;" align="center" v-if="active2==0">
          <div style="margin: 10px;">
            <el-button size="medium" type="primary" style="margin-left:10px;margin-top:10px;height: 34px;" @click="getImageInfo(); selectPicture = true;">选择图像</el-button>
          </div>
          <div>
              <el-dialog title="图像选择" :visible.sync="selectPicture" width="80%">
              <el-table
              :data="tableData.slice((currentPage-1)*PageSize,currentPage*PageSize).filter(data => !search || data.relation.toLowerCase().includes(search.toLowerCase()))"
              style="width: 95%;"
              :header-cell-style="{'text-align':'center'}"
              :cell-style="{'text-align':'center'}">
                <el-table-column type="index" :index="indexMethod" label="序号" />
                  <el-table-column prop="7" label="图像">
                    <template slot-scope="scope">
                      <el-image
                        style="width: 35%; height: 35%"
                        :src="scope.row[7]"
                        :lazy="true"
                        :preview-src-list="srcList"
                      />
                    </template>
                  </el-table-column>
                  <el-table-column prop="2" label="图像名称" />
                  <el-table-column prop="6" label="图像分辨率" />
                  <el-table-column prop="4" label="图像拍摄时间" />
                  <el-table-column prop="5" label="图像上传时间" />
                  <el-table-column width="200px" align="right" label="选择">
                    <template slot-scope="scope">
                      <!-- <el-button @click="selectImage(scope.$index, scope.row)">添加图像</el-button> -->
                      <el-checkbox @change="getRow(scope.row)"></el-checkbox>
                    </template>
                  </el-table-column>
              </el-table>
              <div class="block" align="center" style="margin-top: 10px;">
                <el-pagination
                  :current-page="currentPage"
                  :page-sizes="pageSizes"
                  :page-size="PageSize"
                  layout="total, sizes, prev, pager, next, jumper"
                  :total="total"
                  @size-change="handleSizeChange"
                  @current-change="handleCurrentChange"
                />
                <el-button size="small" type="primary" style="margin-left:78%;height: 34px;" @click="selectPicture = false;selectImages()">确认</el-button>
              </div>
            </el-dialog>
          </div>
          <br>
          <div style="margin-left: 10px; text-align: left;">
            <span style="color: red; left: 10px;align: left">*</span>
            <span style="text-align:left; font-size: 16px;color: white;">模型选择</span>
          </div>
          <div style="height: 10px;"></div>
          <el-select size="small" v-model="model" placeholder="请选择模型" style="width: 100%;" :popper-append-to-body="false">
            <el-option
              v-for="item in options"
              :key="item.key"
              :label="item.label"
              :value="item.value"
              >
            </el-option>

          </el-select>
          <div style="height: 8px;"></div>

          <div style="margin-left: 10px; margin-top: 5px; text-align: left;">
            <span style="color: red; left: 10px;align: left;">*</span>
            <span style="text-align:left; font-size: 16px; color: white;">过滤阈值</span>
             <el-popover
                placement="top-start"
                width="100"
                trigger="hover"
                content="选择图斑过滤面积，小于此面积不提取"
                popper-class="el_popover_class1">
              <el-button size="medium" slot="reference" type="goon" icon="el-icon-question" circle></el-button>
            </el-popover>
          </div>
          <div style="height: 4px;"></div>
          <div>
            <el-input size="mini" style="width: 73%;" v-model="threshold"></el-input>
            <!-- <el-span style="font-size:15px;width:25%; height:40px;border-radius:solid 2px ;margin-right: 30px">  像素  </el-span> -->
            <!-- <el-input type="text" size="mini" style="width: 25%;" placeholder="像素" disabled></el-input> -->
            <!-- <el-input type="textarea" placeholder="像素"></el-input> -->
            <el-input type="text" size="mini" style="width: 60px; height: 25px; border-width:1px;" v-model="像素"></el-input>
          <!-- <el-button size="mini" style="font-size: 14px; height: 27px; width: 20px; margin-top: 2px;" hover>像素</el-button> -->
          </div>
          <div style="height: 8px;"></div>

          <div style="margin-left: 10px; margin-top: 2px; text-align: left;">
            <span style="color: red; left: 10px;align: left">*</span>
            <span style="text-align:left; font-size: 16px;color: white;">置信度</span>
            <el-popover
                placement="top-start"
                width="100"
                trigger="hover"
                content="选择识别目标的置信度，目前给定高、中、低三个选项"
                popper-class="el_popover_class2">
              <el-button size="medium" slot="reference" type="goon" icon="el-icon-question" circle></el-button>
            </el-popover>
          </div>
          <div style="height: 4px;"></div>
          <el-select size="small" v-model="confidence" placeholder="请选择置信度" style="width: 100%;" :popper-append-to-body="false">
            <el-option
              v-for="item in options2"
              :key="item.key"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
          <div style="height: 10px;"></div>

          <div style="margin-left: 10px; margin-top: 5px; text-align: left;">
            <span style="color: red; left: 10px;align: left">*</span>
            <span style="text-align:left; font-size: 16px;color: white;">裁块大小</span>
          </div>
          <div style="height: 10px;"></div>
          <el-select size="small" v-model="cropsize" placeholder="请选择裁块大小" style="width: 100%;" :popper-append-to-body="false">
            <el-option
              v-for="item in options3"
              :key="item.key"
              :label="item.label"
              :value="item.value">
            </el-option>
          </el-select>
          <div style="height: 10px;"></div>

          <div style="margin-left: 10px; margin-top: 5px; text-align: left;">
            <span style="color: red; left: 10px;align: left">*</span>
            <span style="text-align:left; font-size: 16px;color: white;">结果名称</span>
          </div>
          <div style="height: 8px;"></div>
            <el-input size="mini" style="width: 100%;" v-model="resultName" placeholder="请输入结果文件名称"></el-input>
          <div style="height: 8px;"></div>

          <div>
            <el-button size="medium" type="primary" style="margin-left:10px;margin-top:25px;height: 34px;" @click="interpret()">处理分析</el-button>
          </div>

        </div>
        <div style="height: 20%;" align="center" v-if="active2==1">
          <div style="margin-top: 80px; margin-bottom: 20px;" align="center">
            <a style="color: #00aaff;"><h2>图斑统计</h2></a>
          </div>
          <div class="inputDeep">
            <el-form ref="form" :model="form" style="margin-top: 0px; margin-left: 10px;font-size: 18px;" label-position="left" size="large">
              <el-form-item style="margin-bottom: 10px;" size="large">
                <span slot="label">
                  <span style="font-size: 18px;color: white;">类型:</span>
                </span>
                <span class="el_input" size="large" slot="label" style="font-size: 18px;color: white;">{{form.type}}</span>
                <!-- <el-input class="el_input" v-model="form.type" size="large" slot="label"></el-input> -->
              </el-form-item>
              <el-form-item style="margin-bottom: 10px;" size="large">
                <span slot="label">
                  <span style="font-size: 18px;color: white;">检测目标:</span>
                </span>
                <span class="el_input" size="large" slot="label" style="font-size: 18px;color: white;">{{form.object}}</span>
                <!-- <el-input class="el_input" v-model="form.object" size="large" slot="label"></el-input> -->
              </el-form-item>
              <el-form-item  style="margin-bottom: 10px;" size="large">
                <span slot="label">
                  <span style="font-size: 18px;color: white;">图斑总数量:</span>
                </span>
                <span class="el_input" size="large" slot="label" style="font-size: 18px;color: white;">{{form.number}}</span>
                <!-- <el-input class="el_input" v-model="form.number" size="large" slot="label"></el-input> -->
              </el-form-item>
              <el-form-item style="margin-bottom: 10px;" size="large">
                <span slot="label">
                  <span style="font-size: 18px;color: white;">图斑总面积:</span>
                </span>
                <span class="el_input" size="large" slot="label" style="font-size: 18px;color: white;">{{form.area}}</span>
                <!-- <el-input class="el_input" v-model="form.area" size="large" slot="label"></el-input> -->
              </el-form-item>
            </el-form>
            <el-button size="medium" type="primary" style="margin-top:40px;font-size: 15px;" @click="changeDetectionResultDownload()">
              <i class="el-icon-download"></i>&nbsp;解译结果下载
            </el-button>
            <el-button size="medium" type="danger" style="margin-top:30px; margin-left: 0px;font-size: 15px;" @click="changeDetectionResultDelete()">
              <i class="el-icon-delete"></i>&nbsp;解译结果删除
            </el-button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
import Vue from 'vue'
import BaiduMap from 'vue-baidu-map'

Vue.use(BaiduMap, {
  // ak 是在百度地图开发者平台申请的密钥 详见 http://lbsyun.baidu.com/apiconsole/key */
  ak: 'LnP4INwY2AY2VSZFwcRMbNhPxUeBB7sA'
})

export default {
  inject: ['reload'], // 注入刷新页面的依赖
  data() {
    return {
      active: false,
      active2: 0,
      active3: false,
      imageActive: 0,
      selectPicture: false,
      tableData: [],
      srcList: [],
      currentPage: 1,
      pageSizes: [5, 10, 20],
      PageSize: 5,
      total: 0,
      checkList: [],
      cropsize: [],
      resultName: '',
      threshold: 0,
      url1: '',
      url2: '',
      imageNum: 0,
      // url3: 'http://10.9.21.97:59999/workspace/whj/flask/1.png',
      url3: '',
      resultUrl: '',  // 压缩了结果图像的zip路径
      像素: '像素',
      resultInfo: '',
      fileList: [],
      imageZoom: 0, //图片缩放次数
      imageWidth: 560,
      imageHeight: 560,
      options: [{
          key: '选项1',
          value: 'BIT'
        }, {
          key: '选项2',
          value: 'CDNet'
        }, {
          key: '选项3',
          value: 'SNUNet'
        }, {
          key: '选项4',
          value: 'STANet'
        }],
        model: '',
        options2: [{
          key: '选项1',
          value: '低(算法模型召回高。)',
        }, {
          key: '选项2',
          value: '中(算法模型精度和召回平衡。)',
        }, {
          key: '选项3',
          value: '高(算法模型精度高。)',
        }],
        confidence: '',
        options3:[{
          key: '选项1',
          value: '8'
        },{
          key: '选项2',
          value: '16'
        },{
          key: '选项3',
          value: '32'
        },{
          key: '选项4',
          value: '64'
        },{
          key: '选项5',
          value: '128'
        }],
      resultTable: [{
        // type: '类型',
        // number: '图斑总数量',
        // area: '图版总面积',
        type: '',
        number: '',
        area: ''
      }],
      form: {
        type: '',
        number: '',
        area: ''
      },
      center: {
        lng: 120.48,
        lat: 36.12
      },
      zoom: 16,
      mapDragging: true,//允许地图拖动
    }
  },
  computed: {},
  watch: {},
  mounted() {
    // this.init()
    // this.initMap()
  },
  methods: {
    init() {
      let active = false
      var that = this
      document.querySelector('.scroller').addEventListener('mousedown', function() {
        active = true
        that.mapDragging = false
        document.querySelector('.scroller').classList.add('scrolling')
      })
      document.querySelector('.scroller').addEventListener('mouseleave', function() {
        that.mapDragging = true
      })
      document.querySelector('.main').addEventListener('mouseup', function() {
        active = false
        document.querySelector('.scroller').classList.remove('scrolling')
      })
      document.querySelector('.main').addEventListener('mouseleave', function() {
        active = false
        document.querySelector('.scroller').classList.remove('scrolling')
      })

      document.querySelector('.main').addEventListener('mousemove', function(e) {
        if (!active) return
        let x = e.pageX
        x -= document.querySelector('.wrapper').getBoundingClientRect().left
        scrollIt(x)
      })
      scrollIt(150)
      function scrollIt(x) {
        const transform = Math.max(0, (Math.min(x, document.querySelector('.wrapper').offsetWidth)))
        document.querySelector('.after').style.width = transform + 'px'
        document.querySelector('.scroller').style.left = transform - 25 + 'px'
      }
      document.querySelector('.scroller').addEventListener('touchstart', function() {
        active = true
        document.querySelector('.scroller').classList.add('scrolling')
      })
      document.querySelector('.main').addEventListener('touchend', function() {
        active = false
        document.querySelector('.scroller').classList.remove('scrolling')
      })
      document.querySelector('.main').addEventListener('touchcancel', function() {
        active = false
        document.querySelector('.scroller').classList.remove('scrolling')
      })
      document.querySelector('.wrapper').addEventListener('mousewheel', function(e) {
        //e.wheelDelta大于0,上滑；小于0，下滑
        if(e.wheelDelta > 0){  // 上滑
          that.imageZoom = that.imageZoom + 1
          that.imageWidth = that.imageWidth*2
          that.imageHeight = that.imageWidth
          document.getElementById("wrapper").style.width = that.imageWidth + "px"
          document.getElementById("wrapper").style.height = that.imageHeight + "px"
          document.getElementById("after1").style.width = that.imageWidth + "px"
          document.getElementById("after1").style.height = that.imageHeight + "px"
          document.getElementById("after").style.width = that.imageWidth + "px"
          document.getElementById("after").style.height = that.imageHeight + "px"
          document.getElementById("before").style.width = that.imageWidth + "px"
          document.getElementById("before").style.height = that.imageHeight + "px"
          document.getElementById("img1").style.width = that.imageWidth + "px"
          document.getElementById("img1").style.height = that.imageHeight + "px"
          document.getElementById("img2").style.width = that.imageWidth + "px"
          document.getElementById("img2").style.height = that.imageHeight + "px"
          document.getElementById("img3").style.width = that.imageWidth + "px"
          document.getElementById("img3").style.height = that.imageHeight + "px"
          document.querySelector('.scroller').style.left = that.imageWidth-25 + 'px'
        }
        else{ // 下滑
          that.imageZoom = that.imageZoom - 1
          that.imageWidth = that.imageWidth*0.5
          that.imageHeight = that.imageWidth
          document.getElementById("wrapper").style.width = that.imageWidth + "px"
          document.getElementById("wrapper").style.height = that.imageHeight + "px"
          document.getElementById("after1").style.width = that.imageWidth + "px"
          document.getElementById("after1").style.height = that.imageHeight + "px"
          document.getElementById("after").style.width = that.imageWidth + "px"
          document.getElementById("after").style.height = that.imageHeight + "px"
          document.getElementById("before").style.width = that.imageWidth + "px"
          document.getElementById("before").style.height = that.imageHeight + "px"
          document.getElementById("img1").style.width = that.imageWidth + "px"
          document.getElementById("img1").style.height = that.imageHeight + "px"
          document.getElementById("img2").style.width = that.imageWidth + "px"
          document.getElementById("img2").style.height = that.imageHeight + "px"
          document.getElementById("img3").style.width = that.imageWidth + "px"
          document.getElementById("img3").style.height = that.imageHeight + "px"
          document.querySelector('.scroller').style.left = that.imageHeight-25 + 'px'
        }
      })
    },
    indexMethod(index) {
      return index + ((this.currentPage - 1) * this.PageSize) + 1
    },
    handleSizeChange(val) {
      this.PageSize = val
      this.currentPage = 1
      console.log(`每页 ${val} 条`)
    },
    handleCurrentChange(val) {
      this.currentPage = val
      console.log(`当前页: ${val}`)
    },
    getImageInfo() {
      const path = 'http://10.9.21.97:5000/getImageInfo'
      var that = this
      axios.get(path).then(res => {
        that.tableData = res.data
        for (var i = 0; i < res.data.length; i++) {
          that.tableData[i].push(that.tableData[i][1] + that.tableData[i][2])
          that.srcList.push(that.tableData[i][1] + that.tableData[i][2])
        }
        console.log(that.tableData)
        that.total = that.tableData.length
      }).catch(error => {
        console.error(error)
      })
    },
    interpret(){
      if(this.checkList.length == 0){
        this.$notify({
            title: '失败',
            message: '请选择要解译的图像！',
            type: 'error'
          })
        return
      }
      if(this.model == ''){
        this.$notify({
            title: '失败',
            message: '模型不能为空，请选择模型！',
            type: 'error'
          })
        return
      }
      if(this.confidence == ''){
        this.$notify({
            title: '失败',
            message: '置信度不能为空，请选择置信度！',
            type: 'error'
          })
        return
      }
      if(this.cropsize == ''){
        this.$notify({
            title: '失败',
            message: '裁块大小不能为空，请选择裁块大小！',
            type: 'error'
          })
        return
      }
      if(this.resultName == ''){
        this.$notify({
            title: '失败',
            message: '结果名称不能为空，请输入结果名称！',
            type: 'error'
          })
        return
      }
      const loading = this.$loading({
          lock: true,
          text: 'Loading',
          spinner: 'el-icon-loading',
          background: 'rgba(0, 0, 0, 0.7)'
        });
      let formData = new FormData()
      formData.append('imageid1', this.checkList[0][0])
      formData.append('imageid2', this.checkList[1][0])
      formData.append('model', this.model)
      formData.append('threshold', this.threshold)
      formData.append('confidence', this.confidence)
      formData.append('cropsize', this.cropsize)
      formData.append('resultName', this.resultName)
      const config = {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }
      var that = this
      axios.post('http://10.9.21.97:5000/changeDetection', formData, config).then(res => {
        if(res.status===200){
          loading.close()
          that.active2 = 1
          that.resultInfo = res.data
          console.log(that.resultInfo)
          that.url3 = that.resultInfo['img_address2']
          that.resultUrl = that.resultInfo['zip_address']
          that.fileList.push(that.resultUrl)
          // that.url3 = "http://10.9.21.97:59999/workspace/whj/flask/bianhua/8.png"
          this.form.type='  变化检测',
          this.form.object='  建筑物',
          this.form.number="  "+this.resultInfo['edge_number'],
          this.form.area="  "+this.resultInfo['edge_area'] + "像素"
        }
      }).catch(error => {
        console.error(error)
      })
    },
    getRow(row){
      if(this.checkList.includes(row)){
        this.checkList.forEach(function (item, index, arr){
          if(item == row){
            arr.splice(index, 1)
          }
        })
      }
      else{
        this.checkList.push(row)
      }
      console.log(this.checkList)
    },
    selectImages(){
      var that = this
      if(this.checkList.length != 2){
        that.$notify({
            title: '失败',
            message: '请重新选择两张图像进行分析！',
            type: 'error'
          })
      }
      else{
        this.url1=this.checkList[0][7]
        this.url2=this.checkList[1][7]
        this.imageNum = 2
        this.imageActive = 1
        this.$nextTick(() => {
          this.init()
      })
      }
    },
    changeDetectionResultDownload() {
      window.open(this.resultUrl + '?response-content-type=application/octet-stream')
      this.$notify({
        title: '成功',
        message: '解译结果下载成功！',
        type: 'success'
      })
    },
    changeDetectionResultDelete(){
      this.$confirm('此操作将永久删除该检测结果, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then(() => {
          let formData = new FormData()
          formData.append('zipPath', this.resultUrl)
          const config = {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          }
          var that = this
          axios.post('http://10.9.21.97:5000/resultDelete', formData, config).then(res => {
            if(res.status===200){
              that.$notify({
                title: '成功',
                message: '解译结果删除成功！',
                type: 'success'
              })
            }
          }).catch(error => {
            console.error(error)
          })
          this.reload()
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });
        });
    },
    handleClick(tab, event) {
      console.log(tab, event)
    },
    syncCenterAndZoom (e) {  //地图配置
      const {lng, lat} = e.target.getCenter()
      this.center.lng = lng
      this.center.lat = lat
      this.zoom = e.target.getZoom()
    },
    draw ({el, BMap, map}) {  //创建地图上的图层
      const pixel = map.pointToOverlayPixel(new BMap.Point(120.48, 36.12))
      el.style.left = pixel.x - 300 + 'px'
      el.style.top = pixel.y - 300 + 'px'
    },
    created() {}
  }
}
</script>

<style scoped>
        #page {
            width: 100%;
            height: 100%;
            position: absolute;
        }

        * {
            margin: 0;
            box-sizing: border-box;
        }

        .wrapper {
            --Width: 560px;
            --Height: 560px;
            position: absolute;
            left: 40%;
            top: 50%;
            transform: translate3d(-50%, -50%, 0);
            overflow: hidden;
            /* border: 1px solid rgb(255, 255, 255);  */
        }

        .before{
            --Width: 560px;
            --Height: 560px;
            background-repeat: no-repeat;
            background-color: transparent;
            background-size: cover;
            background-position: center;
            position: absolute;
            top: 0;
            left: 0;
            pointer-events: none;
            overflow: hidden;
        }
        .after {
            --Width: 560px;
            --Height: 560px;
            background-repeat: no-repeat;
            background-color: transparent;
            background-size: cover;
            background-position: center;
            position: absolute;
            top: 0;
            left: 0;
            pointer-events: none;
            overflow: hidden;
        }
      .after1 {
            --Width: 560px;
            --Height: 560px;
            background-repeat: no-repeat;
            background-color: white;
            background-size: cover;
            background-position: center;
            position: absolute;
            top: 0;
            left: 0;
            pointer-events: none;
            overflow: hidden;
        }
        .content-image {
            height: 100%;
        }

        /* .after {
            width: 125px;
             animation-name: move;
            animation-duration: 10s;
            animation-iteration-count: 1;
        } */

        .scroller {
            width: 50px;
            height: 50px;
            position: absolute;
            left: 100px;
            top: 50%;
            transform: translateY(-50%);
            border-radius: 50%;
            background-color: transparent;
            opacity: 0.9;
            pointer-events: auto;
            cursor: pointer;
            /* animation-name:move1;
            animation-duration:10s;
            animation-iteration-count:1; */
        }

        .scroller:hover {
            opacity: 1;
        }

        .scrolling {
            pointer-events: none;
            opacity: 1;
            z-index: 31;
        }

        .scroller__thumb {
            width: 100%;
            height: 100%;
            padding: 5px;
        }

        .scroller:before,
        .scroller:after {
            content: " ";
            display: block;
            width: 7px;
            height: 9999px;
            position: absolute;
            left: 50%;
            margin-left: -3.5px;
            z-index: 29;
            transition: 0.1s;
        }

        .scroller:before {
            top: 100%;
        }

        .scroller:after {
            bottom: 100%;
        }

        .scroller {
            border: 5px solid #fff;
        }

        .scroller:before,
        .scroller:after {
            background: rgb(255, 255, 255);
        }

        /* 利用穿透，设置input边框隐藏 */
        .inputDeep>>>.el-input__inner {
          border: 0;
        }
        /* 如果你的 el-input type 设置成textarea ，就要用这个了 */
        .inputDeep>>>.span__inner {
          border: 0;
          resize: none;/* 这个是去掉 textarea 下面拉伸的那个标志，如下图 */
        }
        .el_input>>>.el_input_font{
          width: 150px;
          font-size: 14px;
          font-weight: bolder;
          font-family: 'Microsoft';
        }
        .right{
          /* background-color: rgb(255, 255, 255); */
          right: 0;
          top: 8%;
          position: fixed;
        }

        .bm-view {
          width: 100%;
          height: 720px;
        }

        .sample {
          width: 560px;
          height: 560px;
          line-height: 40px;
          /* background: rgba(0,0,0,0.5); */
          overflow: hidden;
          /* box-shadow: 0 0 5px #000; */
          color: #fff;
          text-align: center;
          padding: 10px;
          position: absolute;
        }
        .sample.active {
          color: #fff;
        }
        .el-steps /deep/ .el-step__icon{
            /* color: #fff; */
            background-color: #304156;
        }
        .el-steps /deep/ .el-step__head.is-process /deep/ .el-step__icon.is-icon{
          color: white;
          background-color: #304156;
        }
        .el-steps /deep/ .el-step__head.is-wait /deep/ .el-step__icon.is-icon{
          color: rgb(107, 108, 109);
          background-color: #304156;
        }
        .el-steps /deep/ .el-step__icon.is-finish{
          color: greenyellow;
          background-color: #304156;
        }
        .el-steps /deep/ .el-step__title.is-process{
          color: white;
        }
        .el-steps /deep/ .el-step__title.is-wait{
          /* color: #C0C4CC; */
          color: rgb(107, 108, 109);
        }
          .el-steps /deep/ .el-step__title.is-finish{
          color: greenyellow;
        }
        .step {
          width: 100%;
          height: 8%;
          margin-top: 4%;
        }
        .el-input /deep/ .el-input__inner{
          color: #fff;
          background-color: #1C2734;
        }
        .el-select.el-select--small /deep/ .el-input.el-input--small /deep/  .el-input__inner{
          color: #fff;
          background-color: #1C2734;
        }
         /deep/ .el-select-dropdown{
           color: white !important;
           background-color: #1C2734 !important;
        }
        .el-button--goon {
          color: rgb(127, 125, 125);
          border-color: #304156;
          background-color: transparent;
          height: 10px;
          margin-bottom: 15px;
          vertical-align: middle;
        }

       @keyframes move {
            0% {
                width:10%
            }

            25% {
                width:30%
            }

            50% {
                width:50%
            }

            75% {
                width:80%

            }

            100% {
                width:100%
            }
        }
        @keyframes move1 {
            0% {
                left:0px
            }

            25% {
                left:10%
            }

            50% {
                left:30%
            }

            75% {
                left:60%

            }

            100% {
                left:100%
            }
        }

</style>
<style>
          .el-popover.el_popover_class1{
            font-size: 10px !important;
            color: white;
            max-width: 5%;
            height: 5.5%;
            padding: 0.5%;
            background-color: #49596f !important;
        }
          .el-popover.el_popover_class2{
            font-size: 10px !important;
            color: white;
            max-width: 5%;
            height: 5.5%;
            padding: 0.5%;
            background-color: #49596f !important;
        }
</style>
