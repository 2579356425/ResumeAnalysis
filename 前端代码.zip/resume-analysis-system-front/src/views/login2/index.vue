<template>
  <div class="login-container">
    <el-form ref="loginForm" :model="loginForm"  :rules="loginRules" class="login-form" autocomplete="on" label-position="left" v-if="active==1">
      <div class="title-container">
        <h3 class="title">基于移动云的简历解析系统</h3>
      </div>
      <el-form-item prop="username">
        <span class="svg-container">
          <svg-icon icon-class="user" />
        </span>
        <el-input
          ref="username"
          v-model="loginForm.username"
          placeholder="用户名"
          name="username"
          type="text"
          tabindex="1"
          autocomplete="on"
        />
      </el-form-item>

      <el-tooltip v-model="capsTooltip" content="Caps lock is On" placement="right" manual>
        <el-form-item prop="password">
          <span class="svg-container">
            <svg-icon icon-class="password" />
          </span>
          <el-input
            :key="passwordType"
            ref="password"
            v-model="loginForm.password"
            :type="passwordType"
            placeholder="密码"
            name="password"
            tabindex="2"
            autocomplete="on"
            @keyup.native="checkCapslock"
            @blur="capsTooltip = false"
            
          />
          <span class="show-pwd" @click="showPwd">
            <svg-icon :icon-class="passwordType === 'password' ? 'eye' : 'eye-open'" />
          </span>
        </el-form-item>
      </el-tooltip>
      
      <el-button :loading="loading" type="primary" style="width:100%;" @click="handleLogin">登录</el-button>
      <el-button :loading="loading" type="primary" style="width:100%; margin-top:10px; margin-left:0;margin-bottom: 60px;" @click.native.prevent="handleRegister">注册</el-button>

      <div style="position:relative;text-align: center;">
        <el-button style="text-align: center;" class="thirdparty-button" type="primary" @click="showDialog=true">
          或其它方式登录
        </el-button>
      </div>
    </el-form>

    <el-form ref="registerForm" :model="registerForm" :rules="registerRules" class="login-form" autocomplete="on" label-position="left" v-if="active==2">
      <div class="title-container">
        <h3 class="title">基于移动云的简历解析系统</h3>
      </div>
      <div>
        <b style="color: #00aaff;float: left;margin-top: 10px;">请输入用户名</b>
      </div>
      <div style="margin-left: 120px;height: 60px;">
        <el-form-item prop="username" style="width: 235px;margin-top: -5px;">
          <span class="svg-container">
            <svg-icon icon-class="user"/>
          </span>
          <el-input
            ref="username"
            v-model="registerForm.username"
            placeholder="用户名"
            name="username"
            type="text"
            tabindex="1"
            autocomplete="on"
          />
        </el-form-item>
      </div>
      
      <div >
        <div>
          <b style="color: #00aaff;float: left;margin-top: 18px;">请输入密码</b>
        </div>
        <div style="margin-left: 120px;height: 60px; margin-top: 15px;">
          <el-tooltip v-model="capsTooltip" content="Caps lock is On" placement="right" manual>
            <el-form-item prop="password" style="width: 235px;margin-top: -5px;">
              <span class="svg-container">
                <svg-icon icon-class="password" />
              </span>
              <el-input
                :key="passwordType"
                ref="password"
                v-model="registerForm.password"
                :type="passwordType"
                placeholder="密码"
                name="password"
                tabindex="2"
                autocomplete="on"
                @keyup.native="checkCapslock"
                @blur="capsTooltip = false"
              />
              <span class="show-pwd" @click="showPwd">
                <svg-icon :icon-class="passwordType === 'password' ? 'eye' : 'eye-open'" />
              </span>
            </el-form-item>
          </el-tooltip>
        </div>
      </div>
      <div >
        <div>
          <b style="color: #00aaff;float: left;margin-top: 18px;">请再次输入密码</b>
        </div>
        <div style="margin-left: 120px;height: 60px; margin-top: 15px;">
          <el-tooltip v-model="capsTooltip" content="Caps lock is On" placement="right" manual>
            <el-form-item prop="password2" style="width: 235px;margin-top: -5px;">
              <span class="svg-container">
                <svg-icon icon-class="password" />
              </span>
              <el-input
                :key="passwordType2"
                ref="password2"
                v-model="registerForm.password2"
                :type="passwordType2"
                placeholder="密码"
                name="password2"
                tabindex="2"
                autocomplete="on"
                @keyup.native="checkCapslock"
                @blur="capsTooltip = false"
              />
              <span class="show-pwd" @click="showPwd2">
                <svg-icon :icon-class="passwordType2 === 'password' ? 'eye' : 'eye-open'" />
              </span>
            </el-form-item>
          </el-tooltip>
        </div>
      </div>
      <div style="height: 50px;margin-top: 10px;">
        <div>
          <b style="color: #00aaff; float: left;margin-top: 10px;">您的用户类型</b>
        </div>
        <div>
          <el-select style="border: 1px solid rgb(121,121,121);border-radius: 8px;" class="my-el-select" v-model="value" placeholder="普通用户">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
            disabled>
          </el-option>
        </el-select>
        </div>
      </div>
      
      <el-button :loading="loading" type="primary" style="width:100%; margin-top:10px; margin-left:0;margin-bottom: 60px;" @click="register">注册</el-button>

    </el-form>

    <el-dialog title="其它方式登录" :visible.sync="showDialog">
      抱歉，目前还未支持此功能。
      <br>
      <br>
      <br>
      <social-sign />
    </el-dialog>
  </div>
</template>

<script>
import { validUsername } from '@/utils/validate'
import SocialSign from './components/SocialSignin'
import axios from 'axios'
import Global from '../../global/global'
import dashboard from '../dashboard/index'
export default {
  name: 'Login',
  components: {
    SocialSign,
    dashboard
  },
  data() {
    const validatePassword = (rule, value, callback) => {
      console.log(value, validatePassword)
      if (value.length < 6) {
        callback(new Error('密码不能少于6个字符'))
      } else {
        callback()
      }
    }
    const validatePassword2 = (rule, value, callback) => {
      console.log("111:", value)
      if (value != this.registerForm.password) {
        callback(new Error('两次密码输入不同，请重新输入'))
      } else {
        callback()
      }
    }
    // wf下拉框数据
    return {
      options: [{
        value: '选项1',
        label: '管理员'
      }, {
        value: '选项2',
        label: '普通用户'
      }],
      value: '',
      loginForm: {
        username: '',
        password: ''
      },
      loginRules: {
        // password: [{ required: true, trigger: 'blur', validator: validatePassword }]
      },
      registerForm:{
        username: '',
        password: '',
        password2: ''
      },
      registerRules:{
        password: [{ required: true, trigger: 'blur', validator: validatePassword }],
        password2: [{ required: true, trigger: 'blur', validator: validatePassword2 }]
      },
      passwordType: 'password',
      passwordType2: 'password',
      capsTooltip: false,
      loading: false,
      showDialog: false,
      redirect: undefined,
      otherQuery: {},
      active: 1,
      loginFormVal:{
        username: '',
        password: ''
      }
    }
  },
  watch: {
    $route (to, from) {
      console.log("to:", to)
      console.log("from:", from)
      this.$router.go(0);
    }
  },
  created() {
    
  },
  mounted() {

  },
  destroyed() {
    
  },
  methods: {
    checkCapslock(e) {
      const { key } = e
      this.capsTooltip = key && key.length === 1 && (key >= 'A' && key <= 'Z')
    },
    showPwd() {
      if (this.passwordType === 'password') {
        this.passwordType = ''
      } else {
        this.passwordType = 'password'
      }
      // this.$nextTick(() => {
      //   this.$refs.password.focus()
      // })
    },
    showPwd2() {
      if (this.passwordType2 === 'password2') {
        this.passwordType2 = ''
      } else {
        this.passwordType2 = 'password2'
      }
      // this.$nextTick(() => {
      //   this.$refs.password2.focus()
      // })
    },
    handleLogin() {
        const formData = new FormData();
				formData.append('username', this.loginForm.username);
				formData.append('password', this.loginForm.password);
        console.log(formData.get("username"))
        console.log(formData.get("password"))
				const config = {
					headers: {
					'Content-Type': 'multipart/form-data'
					}
				}
				var that = this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
				axios.post('http://127.0.0.1:5000/loginUser', formData, config).then(function(response) {
					console.log(response.data)
					if (response.status === 200) {
						that.$notify({
							title: '成功',
							message: '登录成功!',
							type: 'success'
						});
            that.loading = true
            Global.username = that.loginForm.username
            console.log("Global.username:", Global.username)
            // that.$router.push("./dashboard/index") // 重定向
            that.loading = true
            that.redirect = "/dashboard/index"


            // console.log("that.loginForm:", that.loginForm)
            // that.$store.dispatch('user/login', that.loginForm)
            //   .then(() => {
            //     // Global.username = that.loginForm.username
            //     // console.log("Global.username:", Global.username)
            //     this.$router.push({ path: that.redirect || '/', query: that.otherQuery })
            //     this.loading = false
            //   })
            //   .catch(() => {
            //     this.loading = false
            //   })

            // that.$router.push({ path: that.redirect })
            // that.loading = false
            // router.push({path:"/dashboard"})
          }
          else{
            that.$notify({
							title: '失败',
							message: '用户名或密码错误，请重新输入!',
							type: 'error'
						});
            that.loginForm.username = ''
            that.loginForm.password = ''
          }
				}).catch(err => {
					this.$message.error(err.message);
					console.log(err)
				})
    },
    handleRegister(){
      this.active=2
    },
    register(){
        const formData = new FormData();
				formData.append('username', this.registerForm.username);
				formData.append('password', this.registerForm.password);
        console.log(formData.get("username"))
        console.log(formData.get("password"))
				const config = {
					headers: {
					'Content-Type': 'multipart/form-data'
					}
				}
				var that = this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
				axios.post('http://127.0.0.1:5000/registerUser', formData, config).then(function(response) {
					console.log(response.status)
					if (response.status === 200) {
						that.$notify({
							title: '成功',
							message: '注册成功!',
							type: 'success'
						});
						console.log(response.data);
            this.active=2
					}
				}).catch(err => {
					this.$message.error(err.message);
					console.log(err)
				})
    },
    getOtherQuery(query) {
      return Object.keys(query).reduce((acc, cur) => {
        if (cur !== 'redirect') {
          acc[cur] = query[cur]
        }
        return acc
      }, {})
    },
    // afterQRScan() {
    //   if (e.key === 'x-admin-oauth-code') {
    //     const code = getQueryObject(e.newValue)
    //     const codeMap = {
    //       wechat: 'code',
    //       tencent: 'code'
    //     }
    //     const type = codeMap[this.auth_type]
    //     const codeName = code[type]
    //     if (codeName) {
    //       this.$store.dispatch('LoginByThirdparty', codeName).then(() => {
    //         this.$router.push({ path: this.redirect || '/' })
    //       })
    //     } else {
    //       alert('第三方登录失败')
    //     }
    //   }
    // }
  }
}
</script>

<style lang="scss">
/* 修复input 背景不协调 和光标变色 */
/* Detail see https://github.com/PanJiaChen/vue-element-admin/pull/927 */

$bg:#283443;
$light_gray:#fff;
$cursor: #fff;

@supports (-webkit-mask: none) and (not (cater-color: $cursor)) {
  .login-container .el-input input {
    color: $cursor;
  }
}

/* reset element-ui css */
.login-container {
  .el-input {
    display: inline-block;
    height: 47px;
    width: 85%;

    input {
      background: transparent;
      border: 0;
      -webkit-appearance: none;
      // border-radius: 0px;
      padding: 12px 5px 12px 15px;
      // color: $light_gray;
      color: #211f1f;
      height: 47px;
      caret-color: $cursor;

      &:-webkit-autofill {
        box-shadow: 0 0 0px 1000px $bg inset !important;
        -webkit-text-fill-color: $cursor !important;
      }
    }
  }
  .el-form-item {
    border: 1px solid rgb(121, 121, 121);
    background: white;
    border-radius: 10px;
    color: #211f1f;
  }
  .my-el-select{
    height: 40px;
    width: 235px;
    margin-top: 1px;
    margin-left: 25px;
    .el-input__inner{
      width: 110%;
      margin-left: 10px;
      margin-top: -5px;
    }
    .el-select__caret.el-input__icon.el-icon-arrow-up{
      margin-right: -40px;
      margin-top: -5px;
    }
  }
}
</style>

<style lang="scss" scoped>
	// #2d3a4b
  .login-container {
    height: 100%;
    width: 100%;
    // background-color: $bg;
    overflow: hidden;
    // wf 背景图片
    background-image: url('./login.png');
    background-repeat:no-repeat;
    background-size: cover;
    .login-form {
      position: absolute;
      background-color: white;
      width: 420px;
      height: 470px;
      max-width: 100%;
      padding: 20px 30px 0;
      margin-top: 175px;
      margin-left: 945px;
      // overflow: hidden;
      // border: 5px solid #00ffff;
    }

    .tips {
      font-size: 14px;
      color: #fff;
      margin-bottom: 10px;

      span {
        &:first-of-type {
          margin-right: 16px;
        }
      }
    }

    .svg-container {
      padding: 6px 5px 6px 15px;
      vertical-align: middle;
      width: 30px;
      display: inline-block;
      // border: 1px;
    }

    .title-container {
      position: relative;
      .title {
        font-size: 26px;
        color: #00aaff;
        margin: 0px auto 40px auto;
        text-align: center;
        font-weight: bold;
      }
    }

    .show-pwd {
      position: absolute;
      right: 10px;
      top: 7px;
      font-size: 16px;
      // color: $dark_gray;
      cursor: pointer;
      user-select: none;
    }

    .thirdparty-button {
      position: absolute;
      right: 0;
      bottom: 6px;
    }
  @media only screen and (max-width: 470px) {
    .thirdparty-button {
      display: none;
    }
  }
}
</style>
