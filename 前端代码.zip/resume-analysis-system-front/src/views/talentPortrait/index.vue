<template>
  <div>
    <div class="big" v-if="active==0">
      <div style="text-align: center">
        <a align="center" style="color: #00aaff;">
          <h1 >人才画像 </h1>
        </a>
<!--        <div class="add_info" style="width: 80%;">-->
<!--          <el-dialog title="填写信息" :visible.sync="dialogFormVisible">-->
<!--            <form action="" ref="item">-->
<!--              <div>-->
<!--                <label id="name_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>姓名</label>-->
<!--                <span><input type="text"  v-model="item.name_per" placeholder="请输入姓名"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="sex_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>性别</label>-->
<!--                <span style="text-align: left">-->
<!--                  <el-radio v-model="item.sex_per" label="男" ><label style="width: 10px;margin-left: 5px">男</label></el-radio>-->
<!--                  <el-radio v-model="item.sex_per" label="女"><label style="width: 10px;margin-left: 5px">女</label></el-radio>-->
<!--                </span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="age_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>年龄</label>-->
<!--                <span><input type="text"  v-model="item.age_per" placeholder="请输入年龄范围"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="political_status"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>政治面貌</label>-->
<!--                <span><input type="text"  v-model="item.political_status" placeholder="请输入政治面貌"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="address_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>住址</label>-->
<!--                <span><input type="text"  v-model="item.address_per" placeholder="请输入住址"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="email_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>邮箱</label>-->
<!--                <span><input type="text"  v-model="item.email_per" placeholder="请输入邮箱"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="phone_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>手机号</label>-->
<!--                <span><input type="text"  v-model="item.phone_per" placeholder="请输入手机号"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="gra_school_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>毕业院校</label>-->
<!--                <span><input type="text"  v-model="item.gra_school_per" placeholder="请输入毕业院校"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="highest_edu_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>最高学历</label>-->
<!--                <span><input type="text"  v-model="item.highest_edu_per" placeholder="请输入最高学历"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="degree_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>学位</label>-->
<!--                <span><input type="text"  v-model="item.degree_per" placeholder="请输入学位"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="major_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>专业</label>-->
<!--                <span><input type="text"  v-model="item.major_per" placeholder="请输入专业"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="adm_date"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>入学时间</label>-->
<!--                <span><input type="text"  v-model="item.adm_date" placeholder="请输入入学时间"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="gra_school_date"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>毕业时间</label>-->
<!--                <span><input type="text"  v-model="item.gra_school_date" placeholder="请输入毕业时间"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="courses"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>所学课程</label>-->
<!--                <span><input type="text"  v-model="item.courses" placeholder="请输入所学课程"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                &lt;!&ndash;                <label id="school_level"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>院校水平</label>&ndash;&gt;-->
<!--                <label id="school_level">院校水平</label>-->
<!--                <span><input type="text"  v-model="item.school_level" placeholder="请输入院校水平"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="lan_skill_per">语言技能</label>-->
<!--                &lt;!&ndash;                <label id="lan_skill_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>语言技能</label>&ndash;&gt;-->
<!--                <span><input type="text"  v-model="item.lan_skill_per" placeholder="请输入语言技能"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="prof_skill_per">专业技能</label>-->
<!--                &lt;!&ndash;                <label id="prof_skill_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>专业技能</label>&ndash;&gt;-->
<!--                <span><input type="text"  v-model="item.prof_skill_per" placeholder="请输入专业技能"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="soft_skill_per">软性技能</label>-->
<!--                &lt;!&ndash;                <label id="soft_skill_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>软性技能</label>&ndash;&gt;-->
<!--                <span><input type="text"  v-model="item.soft_skill_per" placeholder="请输入软性技能"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="office_skill_per">办公技能</label>-->
<!--                &lt;!&ndash;                <label id="office_skill_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>办公技能</label>&ndash;&gt;-->
<!--                <span><input type="text"  v-model="item.office_skill_per" placeholder="请输入办公技能"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="certificates">所获证书</label>-->
<!--                &lt;!&ndash;                <label id="certificates"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>所获证书</label>&ndash;&gt;-->
<!--                <span><input type="text"  v-model="item.certificates" placeholder="请输入所获证书"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="awards_per">所获奖项</label>-->
<!--                &lt;!&ndash;                <label id="awards_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>所获奖项</label>&ndash;&gt;-->
<!--                <span><input type="text"  v-model="item.awards_per" placeholder="请输入所获奖项"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="job_title">曾任职位</label>-->
<!--                &lt;!&ndash;                <label id="job_title"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>曾任职位</label>&ndash;&gt;-->
<!--                <span><input type="text"  v-model="item.job_title" placeholder="请输入曾任职位"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="company_name">曾任公司名称</label>-->
<!--                &lt;!&ndash;                <label id="company_name"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>曾任公司名称</label>&ndash;&gt;-->
<!--                <span><input type="text"  v-model="item.company_name" placeholder="请输入曾任公司名称"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--              <div>-->
<!--                <label id="work_description">曾任工作描述</label>-->
<!--                &lt;!&ndash;                <label id="work_description"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>曾任工作描述</label>&ndash;&gt;-->
<!--                <span><input type="text"  v-model="item.work_description" placeholder="请输入曾任工作描述"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="social_description">社会经历</label>-->
<!--                &lt;!&ndash;                <label id="social_description"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>社会经历</label>&ndash;&gt;-->
<!--                <span><input type="text"  v-model="item.social_description" placeholder="请输入社会经历"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="project_description">曾负责项目描述</label>-->
<!--                &lt;!&ndash;                <label id="project_description"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>曾负责项目描述</label>&ndash;&gt;-->
<!--                <span><input type="text"  v-model="item.project_description" placeholder="请输入曾负责项目描述"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="training_organization_name">培训机构名称</label>-->
<!--                &lt;!&ndash;                <label id="training_organization_name"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>培训机构名称</label>&ndash;&gt;-->
<!--                <span><input type="text"  v-model="item.training_organization_name" placeholder="请输入培训机构名称"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="training_description">培训描述</label>-->
<!--                &lt;!&ndash;                <label id="training_description"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>培训描述</label>&ndash;&gt;-->
<!--                <span><input type="text"  v-model="item.training_description" placeholder="请输入培训描述"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="self_evaluation">自我评价</label>-->
<!--                &lt;!&ndash;                <label id="self_evaluation"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>自我评价</label>&ndash;&gt;-->
<!--                <span><input type="text"  v-model="item.self_evaluation" placeholder="请输入自我评价"></span>-->
<!--              </div>-->
<!--              <div>-->
<!--                <label id="candidate_job_title">所获奖项</label>-->
<!--                &lt;!&ndash;                <label id="candidate_job_title"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>所获奖项</label>&ndash;&gt;-->
<!--                <span><input type="text"  v-model="item.candidate_job_title" placeholder="请输入投递职位描述"></span>-->
<!--              </div>-->
<!--            </form>-->
<!--            <div slot="footer" class="dialog-footer">-->
<!--              <el-button class="elbtn" @click="dialogFormVisible = false">取 消</el-button>-->
<!--              <el-button class="elbtn biger" type="primary" @click="submit_add()">开始画像</el-button>-->
<!--            </div>-->
<!--          </el-dialog>-->
<!--        </div>-->


      </div>
      <div style="text-align: center;width: 500px;;margin: 25px auto">
        <el-upload
          class="upload-demo"
          ref="upload"
          drag
          action="action"
          :http-request="save_file"
          multiple>
          <i class="el-icon-upload"></i>
          <div class="el-upload__text">将简历拖到此处，或<em>点击上传</em><br/>
            <div style="margin-top: 10px;">可以上传<em>图片、Word、Pdf、Html</em>文件</div>
<!--            <div style="margin-top: 10px;">可以上传<em>jpg、png、word、pdf</em>文件</div>-->
          </div>
        </el-upload>
      </div>

      <div style="text-align: center;margin-top: 10px">
        <el-button size="medium" type="primary" style="margin-left:10px;margin-top:1px;height: 34px;" @click="submit_file()"><i class="el-icon-thumb" />开始画像</el-button>
      </div>
    </div>
    <div class="big1" v-if="active==1">
      <!--      <i class="el-icon-back" style="display: inline-block;font-size: 40px;float:left;margin-top: 20px;margin-left: 20px" @click="go_back()" />-->
      <i class="el-icon-back" style="display: inline-block;font-size: 40px;float:left;margin-top: 40px;margin-left: 80px" @click="go_back()" />
      <div class="info">
        <div class="one">
          <!--          <div v-if="active1===0" class="zhongwenjianli" style="display: inline-block;margin-right: 20px">中文简历</div>-->
          <!--          <div v-if="active1===1" class="zhongwenjianli" style="display: inline-block">人物画像</div>-->
        </div>
        <div class="two">
          <img v-if="item_detail.name_per === '鲁超峰'" class="imgg" src='http://81.68.169.78:1006/imgPath/鲁超峰的漂亮的照片.png' alt="">
          <img v-if="item_detail.name_per != '鲁超峰' && item_detail.avatar_url.length>0" class="imgg" :src="'http://81.68.169.78:1006/imgPath/'+item_detail.avatar_url.split('/')[item_detail.avatar_url.split('/').length-1]" alt="">
          <img v-if="item_detail.name_per != '鲁超峰' && item_detail.avatar_url.length==0 && item_detail.sex_per==='男'" class="imgg" src="../../icons/man.jpg" alt="">
          <img v-if="item_detail.name_per != '鲁超峰' && item_detail.avatar_url.length==0 && item_detail.sex_per==='女'" class="imgg" src="../../icons/woman.jpg" alt="">

<!--          <img v-if="item_detail.sex_per==='男'" class="imgg" src="../../icons/man.jpg" alt="头像">-->
<!--          <img v-if="item_detail.sex_per==='女'" class="imgg" src="../../icons/woman.jpg" alt="头像">-->
          <div class="sinfo">
            <div class="name">
              <span style="margin-right: 20px">{{ item_detail.name_per }}</span>
<!--              综合标签  暂时不要-->
<!--              <el-tooltip :open-delay= 300 v-for="str in item_info.per_tag" class="item" effect="dark" content="简历亮点" placement="top">-->
<!--                <label class="blue1">{{str}}</label>-->
<!--                &lt;!&ndash;                <label class="blue1" v-for="str in item_info.per_tag">{{str}}</label>&ndash;&gt;-->
<!--              </el-tooltip>-->
            </div>
            <div class="sinfos">
              <i v-if="item_detail.age_per.toString().length>0" class="el-icon-user-solid" />{{ item_detail.age_per }}
              <i v-if="item_detail.sex_per.length>0" class="mar_left el-icon-s-opportunity" />{{ item_detail.sex_per }}
              <i v-if="item_detail.email_per.length>0" class="mar_left el-icon-s-comment" />{{ item_detail.email_per }}
              <i v-if="item_detail.phone_per.length>0" class="mar_left el-icon-phone" />{{ item_detail.phone_per }}
              <i v-if="item_detail.highest_edu_per.length>0" class="mar_left el-icon-s-cooperation" />{{ item_detail.highest_edu_per }}
            </div>
          </div>
        </div>
        <a @click="click_jianli()">中文简历</a>
        <a @click="click_huaxiang()">人物画像</a>
        <div style="display: block;height: 10px;">
          <div :class="[active1==0? 'under_a_yes':'under_a_no']"></div>
          <div :class="[active1==1? 'under_a_yes':'under_a_no']"></div>
        </div>
        <hr class="fenjiexian">
        <div v-if="active1===0" class="jianli">
          <div v-if="item_detail.name_per.length>0 || item_detail.age_per.toString().length>0 || item_detail.phone_per.length>0 || item_detail.qq.length>0 || item_detail.height.length>0 || item_detail.race.length>0 || item_detail.nationality.length>0 || item_detail.highest_edu_per.length>0 || item_detail.political_status.length>0 || item_detail.sex_per.length>0 || item_detail.weixin.length>0 || item_detail.weight.length>0 || item_detail.marital_status.length>0 || item_detail.work_year.length>0 || item_detail.address_per.length>0 || item_detail.email_per.length>0" class="title_box">
            <div class="_title el-icon-user-solid "> 基本信息</div>
            <div class="_title_down" />
          </div>
          <div v-if="item_detail.name_per.length>0 || item_detail.age_per.toString().length>0 || item_detail.phone_per.length>0 || item_detail.qq.length>0 || item_detail.height.length>0 || item_detail.race.length>0 || item_detail.nationality.length>0 || item_detail.highest_edu_per.length>0 || item_detail.political_status.length>0 || item_detail.sex_per.length>0 || item_detail.weixin.length>0 || item_detail.weight.length>0 || item_detail.marital_status.length>0 || item_detail.work_year.length>0 || item_detail.address_per.length>0 || item_detail.email_per.length>0"  class="thr">
            <div v-if="item_detail.name_per.length>0 || item_detail.age_per.toString().length>0 || item_detail.phone_per.length>0 || item_detail.qq.length>0 || item_detail.height.length>0 || item_detail.race.length>0 || item_detail.nationality.length>0 || item_detail.highest_edu_per.length>0 || item_detail.political_status.length>0" class="left">
              <ul>
                <li v-if="item_detail.name_per.length>0"><span class="dian">●</span> 姓名：<span>{{ item_detail.name_per }}</span></li>
                <li v-if="item_detail.age_per.toString().length>0"><span class="dian">●</span> 年龄：<span>{{ item_detail.age_per }}</span></li>
                <li v-if="item_detail.phone_per.length>0"><span class="dian">●</span> 联系方式：<span>{{ item_detail.phone_per }}</span></li>
                <li v-if="item_detail.qq.length>0"><span class="dian">●</span> QQ：<span>{{ item_detail.qq }}</span></li>
                <li v-if="item_detail.height.length>0"><span class="dian">●</span> 身高：<span>{{ item_detail.height }}</span></li>
                <li v-if="item_detail.race.length>0"><span class="dian">●</span> 民族：<span>{{ item_detail.race }}</span></li>
                <li v-if="item_detail.nationality.length>0"><span class="dian">●</span> 国籍：<span>{{ item_detail.nationality }}</span></li>
                <li v-if="item_detail.highest_edu_per.length>0"><span class="dian">●</span> 最高学历：<span>{{ item_detail.highest_edu_per }}</span></li>
                <li v-if="item_detail.political_status.length>0"><span class="dian">●</span> 政治面貌：<span>{{ item_detail.political_status }}</span></li>
                <!--              <li v-if="item_detail.school_level.length>0"><span class="dian">●</span> 学校等级：<span>{{ item_detail.school_level }}</span></li>-->
              </ul>
            </div>
            <div v-if="item_detail.sex_per.length>0 || item_detail.weixin.length>0 || item_detail.weight.length>0 || item_detail.marital_status.length>0 || item_detail.work_year.length>0 || item_detail.address_per.length>0 || item_detail.email_per.length>0" class="right">
              <ul>
                <li v-if="item_detail.sex_per.length>0"><span class="dian">●</span> 性别：<span>{{ item_detail.sex_per }}</span></li>
                <li v-if="item_detail.address_per.length>0"><span class="dian">●</span> 住址：<span>{{ item_detail.address_per }}</span></li>
                <li v-if="item_detail.email_per.length>0"><span class="dian">●</span> 邮箱：<span>{{ item_detail.email_per }}</span></li>
                <li v-if="item_detail.weixin.length>0"><span class="dian">●</span> 微信：<span>{{ item_detail.weixin }}</span></li>
                <li v-if="item_detail.weight.length>0"><span class="dian">●</span> 体重：<span>{{ item_detail.weight }}</span></li>
                <li v-if="item_detail.marital_status.length>0"><span class="dian">●</span> 婚姻状况：<span>{{ item_detail.marital_status }}</span></li>
                <li v-if="item_detail.work_year.length>0"><span class="dian">●</span> 工作经验：<span>{{ item_detail.work_year }}</span></li>
                <li v-if="item_detail.postal_code.length>0"><span class="dian">●</span> 邮编：<span>{{ item_detail.postal_code }}</span></li>
                <!--              <li v-if="item_detail.edu_gpa.length>0"><span class="dian">●</span> 绩点：<span>{{ item_detail.edu_gpa }}</span></li>-->
              </ul>
            </div>
          </div>
          <div v-if="item_detail.edu.length>0" class="title_box">
            <div class="_title el-icon-s-management"> 教育背景</div>
            <div class="_title_down" />
          </div>
          <div v-if="item_detail.edu.length>0" class="four">
            <div v-for="(item,index) in item_detail.edu" style="margin-bottom: 20px">
              <div style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px">{{ item.gra_school_per }}</div>
              <ul>
                <li v-if="item.adm_date.length>0"><span class="dian">●</span> 时间：<span>{{ item.adm_date }} - {{ item.gra_date }}</span></li>
                <li v-if="item.major_per.length>0"><span class="dian">●</span> 专业：<span>{{ item.major_per }}</span></li>
                <li v-if="item.edu_gpa.toString().length>0"><span class="dian">●</span> 绩点：<span>{{ item.edu_gpa }}</span></li>
                <li v-if="item.school_level.length>0"><span class="dian">●</span> 学校水平：<span>{{ item.school_level }}</span></li>
                <li style="position: relative" v-if="item.courses.length>0" ><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">所学课程：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.courses }}</div></li>
              </ul>
            </div>
          </div>

          <div v-if="item_detail.work.length>0" class="title_box">
            <div class="_title el-icon-s-cooperation"> 工作经历</div>
            <div class="_title_down" />
          </div>
          <div v-if="item_detail.work.length>0" class="five">
            <div v-for="(item,index) in item_detail.work" style="margin-bottom: 20px">
              <div style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px ">{{item.company_name}}</div>
              <ul>
                <li style="position: relative" v-if="item.work_date.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">工作时间：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.work_date }}</div></li>
                <li style="position: relative" v-if="item.job_title.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">岗位名称：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.job_title }}</div></li>
                <!--              <li style="position: relative" v-if="item.work_industry.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">工作行业：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.work_industry }}</div></li>-->
                <li style="position: relative" v-if="item.work_description.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">工作描述：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.work_description }}</div></li>
              </ul>
            </div>
          </div>

          <div v-if="item_detail.project.length>0" class="title_box">
            <div class="_title el-icon-s-cooperation"> 项目经历</div>
            <div class="_title_down" />
          </div>
          <div v-if="item_detail.project.length>0" class="five">
            <div v-for="(item,index) in item_detail.project" style="margin-bottom: 20px">
              <div style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px">{{item.project_name}}</div>
              <ul>
                <li style="position: relative" v-if="item.project_position.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">职位：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.project_position }}</div></li>
                <li style="position: relative" v-if="item.project_date.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">项目时间：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.project_date }}</div></li>
                <li style="position: relative" v-if="item.project_description.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">项目描述：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.project_description }}</div></li>
              </ul>
            </div>
          </div>

          <div v-if="item_detail.social.length>0" class="title_box">
            <div class="_title el-icon-s-cooperation"> 社会经历</div>
            <div class="_title_down" />
          </div>
          <div v-if="item_detail.social.length>0" class="five">
            <div v-for="(item,index) in item_detail.social" style="margin-bottom: 20px">
              <div style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px">{{item.social_cpy}}</div>
              <ul>
                <!--              <li style="position: relative" v-if="item.social_cpy.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">组织单位：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px">{{ item.social_cpy }}</div></li>-->
                <li style="position: relative" v-if="item.social_date.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">实践时间：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.social_date }}</div></li>
                <li style="position: relative" v-if="item.social_pos.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">担任角色：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.social_pos }}</div></li>
                <li style="position: relative" v-if="item.social_description.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">实践描述：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.social_description }}</div></li>
              </ul>
            </div>
          </div>

          <div v-if="item_detail.train.length>0" class="title_box">
            <div class="_title el-icon-s-cooperation"> 培训经历</div>
            <div class="_title_down" />
          </div>
          <div v-if="item_detail.train.length>0" class="five">
            <div  v-for="(item,index) in item_detail.train" style="margin-bottom: 20px">
              <div v-if="item.train_org.length>0" style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px">{{ item.train_org }}</div>
              <ul>
                <li style="position: relative" v-if="item.train_date.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">培训时间：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.train_date }}</div></li>
                <li style="position: relative" v-if="item.training_description.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">培训描述：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.training_description }}</div></li>
              </ul>
            </div>
          </div>
          <!--       看这里-->
          <div class="title_box" v-if="item_detail.prof_skill_per.length>0 || item_detail.lan_skill_per.length>0 || item_detail.office_skill_per.length>0 ||item_detail.awards_per.length>0 || item_detail.certificates.length>0 || item_detail.self_evaluation.length>0">
            <div class="_title">其他信息</div>
            <div class="_title_down" />
          </div>

          <div class="six" v-if="item_detail.prof_skill_per.length>0 || item_detail.lan_skill_per.length>0 || item_detail.office_skill_per.length>0 ||item_detail.awards_per.length>0 || item_detail.certificates.length>0 || item_detail.self_evaluation.length>0">
            <ul>
              <!--            <li style="position: relative">-->
              <li style="position: relative" v-if="item_detail.prof_skill_per.length>0">
                <span style="position: absolute" class="dian">●</span>
                <span style="color: #9198a5;position: absolute;left: 18px">专业技能：</span>
                <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                  <span v-if="typeof item_detail.prof_skill_per == 'string'">{{ item_detail.prof_skill_per }}</span>
                  <span v-if="typeof item_detail.prof_skill_per != 'string'">{{ item_detail.prof_skill_per.join('、') }}</span>
                </div>
              </li>
              <li style="position: relative" v-if="item_detail.lan_skill_per.length>0">
                <span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">语言技能：</span>
                <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                  <span v-if="typeof item_detail.lan_skill_per == 'string'">{{ item_detail.lan_skill_per }}</span>
                  <span v-if="typeof item_detail.lan_skill_per != 'string'">{{ item_detail.lan_skill_per.join('、') }}</span>
                </div>
              </li>
              <li style="position: relative" v-if="item_detail.office_skill_per.length>0">
                <span style="position: absolute" class="dian">●</span>
                <span style="color: #9198a5;position: absolute;left: 18px">办公技能：</span>
                <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                  <span v-if="typeof item_detail.office_skill_per == 'string'">{{ item_detail.office_skill_per }}</span>
                  <span v-if="typeof item_detail.office_skill_per != 'string'">{{ item_detail.office_skill_per.join('、') }}</span>
                </div>
              </li>
              <li style="position: relative" v-if="item_detail.awards_per.length>0">
                <span style="position: absolute" class="dian">●</span>
                <span style="color: #9198a5;position: absolute;left: 18px">所获奖项：</span>
                <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                  <span v-if="typeof item_detail.awards_per == 'string'">{{ item_detail.awards_per }}</span>
                  <span v-if="typeof item_detail.awards_per != 'string'">{{ item_detail.awards_per.join('、') }}</span>
                </div>
              </li>
              <li style="position: relative" v-if="item_detail.certificates.length>0">
                <span style="position: absolute" class="dian">●</span>
                <span style="color: #9198a5;position: absolute;left: 18px">所获证书：</span>
                <div v-if="typeof item_detail.certificates != 'string'">
                  <div v-for="(item,i) in item_detail.certificates" style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                    {{i+1}}、{{ item }}
                  </div>
                </div>
                <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                  <span v-if="typeof item_detail.certificates == 'string'">{{ item_detail.certificates }}</span>
                </div>
              </li>
              <li style="position: relative" v-if="item_detail.self_evaluation.length>0">
                <span style="position: absolute" class="dian">●</span>
                <span style="color: #9198a5;position: absolute;left: 18px">自我描述：</span>
                <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                  {{ item_detail.self_evaluation }}
                </div>
              </li>
            </ul>
          </div>


        </div>
        <div v-if="active1===1" class="huaxiang">
          <div class="title_box">
            <div class="_title">简历亮点</div>
            <div class="_title_down" />
          </div>
          <div class="thr">
            <div class="light">
              <div >
                <div v-if="item_info.highlights.length>0" class="line_title"><i class="el-icon-s-opportunity blue_title"></i>简历亮点</div>
                <ul>
                  <li v-for="liangdian in item_info.highlights"><div class="con">{{liangdian}}</div></li>
                </ul>
              </div>
              <div v-if="item_info.predicted_salary.length>0 || parseFloat(item_info.predicted_stability) != 0" class="line_title"><i class="el-icon-star-on green_title"></i>智能预测</div>
              <ul>
                <li v-if="item_info.predicted_salary.length>0">结合工作经验、学历、行业、地域等因素，该求职者的市场薪资约为 {{item_info.predicted_salary}}</li>
                <li v-if="parseFloat(item_info.predicted_stability) != 0">结合工作经历以及项目项目，此求职者短期离职可能性<span v-if="parseFloat(item_info.predicted_stability)>0.7">较低</span><span v-if="parseFloat(item_info.predicted_stability)<=0.7">较高</span></li>
              </ul>
            </div>
          </div>
          <div v-if="item_info.tags.skills.length>0 ||item_info.tags.other.length>0 ||item_info.tags.education.length>0 ||item_info.tags.basic.length>0 || item_info.tags.professional.length>0 " class="title_box">
            <div class="_title">人物标签</div>
            <div class="_title_down" />
          </div>
          <div class="four">
            <div class="tag">
              <div v-if="item_info.tags.basic.length>0" class="line_title"><i class="el-icon-user-solid blue_title"></i>基本标签</div>
              <div v-if="item_info.tags.basic.length>0"  class="mar_left_20">
                <el-tooltip :open-delay=300  v-for="tag in item_info.tags.basic" class="item" effect="dark" :content="tag.type + '标签'" placement="top">
                  <label v-if="tag.tag.length>0" class="blue">{{tag.tag}}</label>
                </el-tooltip>
              </div>
              <div v-if="item_info.tags.education.length>0" class="line_title"><i class="el-icon-s-management yellow_title"></i>教育背景标签</div>
              <div v-if="item_info.tags.education.length>0" class="mar_left_20">
                <el-tooltip :open-delay=300  v-for="tag in item_info.tags.education" class="item" effect="dark" :content="tag.type + '标签'" placement="top">
                  <label  v-if="tag.tag.length>0" class="yellow">{{tag.tag}}</label>
                </el-tooltip>
              </div>
              <div v-if="item_info.tags.professional.length>0" class="line_title"><i class="el-icon-s-cooperation ggreen_title"></i>职业标签</div>
              <div v-if="item_info.tags.professional.length>0" class="mar_left_20">
                <el-tooltip :open-delay=300  v-for="tag in item_info.tags.professional" class="item" effect="dark" :content="tag.type + '标签'" placement="top">
                  <label v-if="tag.tag.length>0" class="green">{{tag.tag}}</label>
                </el-tooltip>
              </div>
              <div v-if="item_info.tags.other.length>0" class="line_title"><i class="el-icon-menu perpal_title"></i>其他信息标签</div>
              <div v-if="item_info.tags.other.length>0" class="mar_left_20">
                <el-tooltip :open-delay=300  v-for="tag in item_info.tags.other" class="item" effect="dark" :content="tag.type + '标签'" placement="top">
                  <label v-if="tag.tag.length>0" class="perpal">{{tag.tag}}</label>
                </el-tooltip>
              </div>
              <div v-if="item_info.tags.skills.length>0" class="line_title"><i class="el-icon-s-tools gggreen_title"></i>专业技能标签</div>
              <div v-if="item_info.tags.skills.length>0" class="mar_left_20">
                <el-tooltip :open-delay=300  v-for="tag in item_info.tags.skills" class="item" effect="dark" :content="'熟练度：'+tag.Proficiency" placement="top">
                  <label v-if="tag.Proficiency<0.5" class="skill1">{{tag.tag}}</label>
                  <label v-else-if="tag.Proficiency<0.7" class="skill2">{{tag.tag}}</label>
                  <label v-else-if="tag.Proficiency<0.85" class="skill3">{{tag.tag}}</label>
                  <label v-else class="skill4">{{tag.tag}}</label>
                </el-tooltip>
              </div>

            </div>
          </div>
          <div v-if="item_detail.company_name.length>0 || item_detail.job_title.length>0 || item_detail.work_description.length>0 || item_detail.social_description.length>0 || item_detail.train_org.length>0 || item_detail.training_description.length>0 || item_detail.project_description.length>0" class="title_box">
            <div class="_title">综合能力</div>
            <div class="_title_down" />
          </div>
          <div class="five">
            <div id="mychart_pie" style="margin:0px auto;width: 700px;height: 350px;position:relative;"></div>
          </div>
          <div v-if="item_detail.company_name.length>0 || item_detail.job_title.length>0 || item_detail.work_description.length>0 || item_detail.social_description.length>0 || item_detail.train_org.length>0 || item_detail.training_description.length>0 || item_detail.project_description.length>0" class="title_box">
            <div class="_title">行业背景</div>
            <div class="_title_down" />
          </div>
          <div class="five">
            <div id="mychart_radar" style="margin:0px auto;width: 700px;height: 350px;position:relative;"></div>
          </div>
<!--          看这里::  下面这个v-if需要改  -->
          <div v-if="item_detail.company_name.length>0 || item_detail.job_title.length>0 ||  item_detail.work_description.length>0 || item_detail.social_description.length>0 || item_detail.train_org.length>0 || item_detail.training_description.length>0 || item_detail.project_description.length>0" class="title_box">
            <div class="_title">职能预测</div>
            <div class="_title_down" />
          </div>
          <div class="five" style="text-align: center">
            <div class="ciyun">
              <canvas style="margin: auto auto;width: 400px;height: 200px;" id="myCanvas"></canvas>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div v-loading="true" class="big2" v-if="active==2" style="padding-top: 500px">
<!--      显示的加载界面  在上传文件之后   接收到两批数据之前进行显示     -->
    </div>
  </div>
</template>
<style lang="scss" scoped>
.ciyun {
  border-style: solid;
  border-radius: 30px;
  border-color: #abc8ff;
  display: inline-block;
  margin: 0px auto;
  padding-top: 20px;
  width: 450px;
  height: 250px;
}
.wordcloud-wrapper {
  height: 300px;
  width: 300px
}
.mar_left_20 {
  margin-left: 20px;
}
.big1 .huaxiang ul li {
  margin-top: 15px;
}
.big1 .line_title {
  margin: 5px 10px;
  font-size: larger;
}
.big1 .line_title i{
  font-size: x-large;
}
.big1 .huaxiang .light ul{
  display: block;
  background-color: #fff;
  list-style-type: disc;
}
.big1 .light {
  width: 100%;
  //height: 200px;
  //background-color: #ff7070;
}
.blue {
  background-color: #f0f8ff;
  border-color: #5b99ff;
  color: #5b99ff;
}
.blue:hover {
  background-color: #1a91ff;
  border-color: #1a91ff;
  color: #cee8ff;
}
.blue1 {
  background-color: #f0f8ff;
  border-color: #5b99ff;
  color: #5b99ff;
}
.blue1:hover {
  background-color: #cfe8ff;
  border-color: #0061ff;
  color: #0060ff;
}
.yellow {
  background-color: #fff9eb;
  border-color: #dba200;
  color: #dba200;
}
.yellow:hover {
  background-color: #fa8d18;
  border-color: #fa8d18;
  color: #ffffff;
}
.green {
  background-color: #fff2e8;
  border-color: #ffc5a6;
  color: #fa5f2b;
}
.green:hover {
  background-color: #fa551e;
  border-color: #fa551e;
  color: #ffffff;
}
.perpal {
  background-color: #f9f0ff;
  border-color: #d5b2f7;
  color: #7735d2;
}
.perpal:hover {
  background-color: #7330d1;
  border-color: #7330d1;
  color: #ffffff;
}
.blue_title {
  color: #005fff;
}
.yellow_title {
  color: #dba200;
}
.green_title {
  color: #23a300;
}
.ggreen_title {
  color: #fa551e;
}
.gggreen_title {
  color: #005c0a;
}
.perpal_title {
  color: #8e00e8;
}
.skill1 {
  background-color: #5bdd95;
  border-color: #5bdd95;
  color: #ffffff;
}
.skill2 {
  background-color: #62cd94;
  border-color: #62cd94;
  color: #ffffff;
}
.skill3 {
  background-color: #37c277;
  border-color: #37c277;
  color: #ffffff;
}
.skill4 {
  background-color: #18bb63;
  border-color: #18bb63;
  color: #ffffff;
}
.skill4:hover , .skill3:hover , .skill2:hover , .skill1:hover  {
  background-color: #00893f;
  border-color: #00893f;
  color: #ffffff;
}
.big1 label{
  //background-color: #c25959;
  font-size: small;
  //width: 60px;
  display: inline-block;
  padding: 7px 12px;
  margin: 10px 5px;
  margin-top: 10px;
  border-style: solid;
  border-radius: 15px;
  border-width: 1px;
  text-align: right;
}
.big1 .xiugai {
  width: 80%;
}
.big1 .xiugai span input{
  font-size: small;
  width: 100%;
  height: 32px;
  line-height: 30px;
  color: gray;
}
.big1 .xiugai span{
  /*background-color: #aa1111;*/
  width: 60%;
  /*font-size: 27px;*/
  display: inline-block;
}
.big1 .xiugai .elbtn{
  width: 70px;
  height: 40px;
  font-size: small;
}

.big1 .teil{
  width: 90%;
  height: 100px;
  margin: 30px auto;
  /*background-color: #6366ff;*/
}
.big1 .six{
  width: 90%;
  margin: 0px auto;
  margin-top: 130px;
  margin-bottom: 130px;
  /*background-color: #6366ff;*/
}
.big1 .five{
  width: 90%;
  margin: 0px auto;
  margin-top: 130px;
  padding-bottom: 60px;
  /*background-color: #efff63;*/
}
.big1 .four{
  width: 90%;
  margin: 0px auto;
  margin-top: 120px;
  /*background-color: #ffac63;*/
}
.big1 .thr{
  width: 90%;
  margin: 0px auto;
  //margin-top: 100px;
  padding-top: 90px;
  /*background-color: #f88eff;*/
}
.big1 ul{
  list-style-type: none;
}
.big1 ul li{
  font-size: large;
  margin-top: 25px;
  color: #9198a5;
}
.big1 li .dian{
  color: #6873e5;
}
.big1 li span{
  color: #494949;
}
.big1 div .left{
  width: 50%;
  height: 100%;
  display: inline-block;
  left: 0px;
  /*background-color: #ff8b8b;*/
}
.big1 div .right{
  width: 50%;
  height: 100%;
  display: inline-block;
  float: right;
  /*background-color: #e5d98c;*/
}
.big1 div .botom li,ul{
  margin-top: 5px !important;
}
.big1 .title_box{
  position: absolute;
  margin-top: 20px;
  width: 100%;
  height: 100px;
  /*background-color: #af3f3f;*/
}
.big1 ._title_down{
  /*底色  设置长、宽、背景色*/
  width: 150px;
  height: 40px;
  /*background-color: #ffd9b2;*/
  position: absolute;
  left: 30px;
  top: 10px;
}
.big1 ._title{
  /*文字  设置长、宽、字号、粗细、最上方显示*/
  z-index: 999;
  width: 200px;
  height: 60px;
  font-size: xx-large;
  font-weight: normal;
  position: absolute;
  left: 40px;
  top: 10px;
}
.big1 .under_a_yes{
  display: inline-block;
  width: 100px;
  height: 5px;
  background-color: #2269ff;
  margin-left: 50px;
  margin-right: 20px;
}
.big1 .under_a_no{
  display: inline-block;
  width: 100px;
  height: 5px;
  background-color: #ffffff;
  margin-left: 50px;
  margin-right: 20px;
}
.big1 a{
  display: inline-block;
  font-size: large;
  text-align: center;
  line-height: 60px;
  width: 100px;
  height: 45px;
  //background-color: #ff6e6e;
  margin-left: 50px;
  margin-right: 20px;
}
.big1 .fenjiexian {
  border: black;
  padding: 3px;
  //margin-top: 80px;
  background: repeating-linear-gradient(135deg, #d0d0d0 0px, #09090a 1px, transparent 1px, transparent 6px);
}
.big1 .two{
  overflow: hidden;
  width: 90%;
  height: 150px;
  margin: 20px auto;
  margin-bottom: 0px;
  /*background-color: #8aff63;*/
}
.big1 .two .sinfo{
  width: 83%;
  height: 100%;
  float: right;
  /*background-color: #fff;*/
}
.big1 .two .imgg{
  width: 12%;
  display: inline-block;
}
.big1 .two .name{
  height: 70px;
  font-size: 35px;
  font-weight: bolder;
  //line-height: 70px;
  text-align: left;
  display: block;
  /*background-color: #fff;*/
}
.big1 .two .sinfos{
  margin-top: 10px;
  height: 50px;
  color: #8a919f;
  /*background-color: #ffefef;*/
}
.big1 i {
  margin-right: 10px;
}
.big1 .mar_left{
  margin-left: 20px;
}
.big1 .one{
  width: 90%;
  height: 40px;
  margin: 30px auto;
  /*background-color: #e3e3e3;*/
}
.big1 .one .zhongwenjianli{
  width: 70px;
  height: 40px;
  line-height: 40px;
  text-align: center;
  color: #3155eb;
  font-size: small;
  border-style: solid;
  border-width: medium;
  border-color: #aec6ff;
  border-radius: 10px;
  background-color: #f0f5ff;
}
.big1 .info{
  width: 60%;
  height: 95%;
  overflow: auto;
  position: absolute;
  top: 0;left:0;right:0;bottom:0;
  margin: auto;
  background-color: #ffffff;
  //margin-top: 20px;
  //left: auto;
  //margin: 0px auto;
  -webkit-box-shadow: #666 0px 0px 50px;
  -moz-box-shadow: #666 0px 0px 50px;
  box-shadow: #666 0px 0px 20px;
}

.big label{
  //background-color: #c25959;
  font-size: inherit;
  width: 80px;
  display: inline-block;
  text-align: right;
  margin: 10px 20px;
}
.big .add_info {
  width: 80%;
}
.big .add_info span input{
  font-size: small;
  width: 100%;
  height: 32px;
  line-height: 30px;
  color: gray;
}
.big .add_info span{
  /*background-color: #aa1111;*/
  width: 65%;
  font-size: 27px;
  display: inline-block;
}
.big .add_info .elbtn{
  width: 70px;
  height: 40px;
  font-size: small;
}
.add_info .biger{
  text-align: center;
  padding: 0;
  margin: 0;
  margin-left: 5px;
  width: 90px;
  height: 40px;
  font-size: small;
}
.big .ti{
  text-align: center ;
  font-size: 50px;
  font-family: 华文彩云;
  line-height: 100px;
  width: 50%;
  height: 100px;
  margin: 0 auto;
  //background-color: #5656fa;
}
.big .drag {
  width: 50%;
  height: 300px;
  border: 5px dashed;
  border-color: #a3a3a3;
  border-radius: 30px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
  .drag-icon-box {
    width: 100%;
    //height: 30px;
    text-align: center;
    font-size: large;
    line-height: 30px;
    color: #606266;
  }
  .drag-message {
    //background-color: #de5454;
    width: 100%;
    //height: 50px;
    line-height: 50px;
    text-align: center;
    margin-top: 40px;
    .drag-message-title {
      font-size: large;
      //font-size: 14px;
      color: #606266;
    }
    .drag-message-label {
      //width: 120px;
      //height: 50px;
      //height: auto;
      //background-color: #713535;
      position: relative;
      overflow: hidden;
      .drag-message-input {
        position: absolute;
        left: -100px;
        top: -100px;
        z-index: -1;
        display: none;
      }
      .drag-message-manual {
        font-size: large;
        color: #4b87ff;
        cursor: pointer;
      }
    }
  }
}
</style>
<script src="echarts.min.js"></script>
<script src="echarts-wordcloud.min.js"></script>
<script src='./echarts.simple.js'></script>
<script src='./echarts-wordcloud.js'></script>

<script>
import * as axios from 'axios'
import Global from '../../global/global'
import WordCloud from 'wordcloud';
export default {
  name: 'Index',
  data() {
    return {
      datalist : [
        ['计算机',30],
        ['软件工程',20],
        ['前端',14],
        ['后端',21],
        ['java',10],
        ['springboot',12],
        ['ajax',14],
        ['axios',16],
        ['电子信息',18],
        ['修电脑',20],
        ['软件科学',30],
        ['数字科学大数据',30],
      ],
      resumeName:'',
      resumeUrl: '',
      obj_item: {},
      active: 0,
      active1: 0,
      // active: 1,
      // active1: 1,
      // 上传建立的时候手动输入的信息
      // item: {
      //   name_per: '',
      //   sex_per: '',
      //   age_per: '',
      //   political_status: '',
      //   address_per: '',
      //   email_per: '',
      //   phone_per: '',
      //   gra_school_per: '',
      //   school_level: '',
      //   highest_edu_per: '',
      //   degree_per: '',
      //   major_per: '',
      //   adm_date: '',
      //   gra_date: '',
      //   courses: '',
      //   lan_skill_per: '',
      //   prof_skill_per: '',
      //   soft_skill_per: '',
      //   office_skill_per: '',
      //   certificates: '',
      //   awards_per: '',
      //   job_title: '',
      //   company_name: '',
      //   work_description: '',
      //   social_description: '',
      //   project_description: '',
      //   training_organization_name: '',
      //   training_description: '',
      //   self_evaluation: '',
      //   candidate_job_title: '',
      //   path_resume: ''
      // },

      // item_detail: {},
      // item_info: {},

      // // 显示的简历信息   文件传到后端，进行分析，将数据保存到数据库 然后将数据回显
      item_detail: {
        name_per: "郭芳天",
        age_per: "29",
        sex_per: "男",
        email_per: "service@500d.me",
        phone_per: "13800138000",
        qq: "1226442222",
        weixin: "wx1226442222",
        address_per: "上海浦东新区",
        height: "180",
        weight: "70",
        race: "汉族",
        nationality: "中国",
        marital_status: "未婚",
        highest_edu_per: "大专",
        political_status: "中共党员",
        work_year: "5年",
        adm_date: "2013.07Ж2017.07",
        gra_date: "2017.6Ж2019.6",
        gra_school_per: "上海外国语大学Ж上海大学",
        major_per: "市场营销Ж市场营销",
        school_level: "普通学校Ж普通学校",
        edu_gpa: "3.0Ж5.0",
        courses: "管理学、微观经济学、宏观经济学、管理信息系统、统计学、会计学、财务管理、市场营销、经济法、消费者行为学、国际市场营销。Ж管理学、微观经济学、宏观经济学、管理信息系统、统计学、会计学、财务管理、市场营销、经济法、消费者行为学、国际市场营销。",
        postal_code: "271000",
        work_date: "2017.12-2018.12Ж2018.12-2019.12Ж2019.12-至今",
        work_description: "负责事业部产品对外推广和宣传，制定各种整合营销的活动；;执行媒体投放计划，跟踪和监督媒体投放效果，进行数据分析撰写报告；;向市场总监提供营销支持，并协助相关的公关事宜。Ж根据公司发展情况进行战略调整，配合前端销售部门搭建销售渠道；;研究行业发展动态，定期进行市场调查,为产品更新提供建议；;负责公司部门(营运、品牌策划)制度规范，负责组织及监管市场部关于对外合作、推广策划以相关工作的落实。Ж负责协助集团旗下事业部开展各项工作，制定品牌传播方案；;结合集团与事业部发展，制定营销策略、广告策略、品牌策略和公关策略，并组织推进执行；;制定和执行媒体投放计划，跟踪和监督媒体投放效果，进行数据分析与撰写报告；",
        work_industry: "教育Ж教育Ж教育",
        company_name: "枫辰设计俱乐部Ж源清设计有限公司Ж翔汇投资控股集团",
        job_title: "市场副总监Ж市场及运营总监Ж副总监",
        project_name: "枫辰设计设计集团品牌升级发布会Ж源清设计设计商业模式发布会Ж翔汇投资控股集团6A自媒体生态圈建设",
        project_description: "集团全新品牌logo及VI上线，在多渠道进行了传播；;企业VIP客户群体逾60人，结合了线上发布、线下体验；;后续媒体报道持续升温，子品牌结合明星代言人制造话题营销，为期3周；Ж整场活动以会议+洽谈双重模式进行，首日以介绍源清内部平台资源优势，政府背景优势等为主，一对多推介会进行推广普及；;现场签署地方合作意向书，如：新疆、江西、浙江等优秀企业商户；;以中国的波尔多为宣传点，主推旗下新疆大型项目，制造营销、品牌热点。Ж本项目重构了公司现有微信企业号的功能与架构。;提高公众号的关注粉丝量的同时，对于有客户进行统一宣传，统一管理",
        project_date: "ЖЖ",
        project_position: "ЖЖ",
        social_pos: "队长Ж管理员",
        social_date: "2014.05-2017.06Ж2014.11-2017.06",
        social_cpy: "上海外国语大学Ж沟通与交流协会",
        social_description: "负责50余人团队的日常训练、选拔及团队建设；; 作为负责人对接多项商业校园行活动，如《奔跑吧兄弟》上海外国语大学站录制、《时代周末》校园行。Ж协助上海沟通协会创立上海外国语大学分部，从零开始组建初期团队；; 策划协会会员制，选拔、培训协会导师，推出一系列沟通课程。",
        train_org: "达内教育Ж一本教育Ж啥都会俱乐部",
        training_description: "学前后端Ж学语言表达艺术Ж学与人交往的礼仪",
        train_date: "2012.6--2015.9Ж2015.6--2016.3Ж2016.3--2016.9",
        self_evaluation: "拥有多年的市场管理及品牌营销经验，卓越的规划、组织、策划、方案执行和团队领导能力，积累较强的人际关系处理能力和商务谈判技巧，善于沟通，具备良好的合作关系掌控能力与市场开拓能力；;敏感的商业和市场意识，具备优秀的资源整合能力、业务推进能力； ;思维敏捷，有培训演讲能力，懂激励艺术，能带动团队的积极性；擅长协调平衡团队成员的竞争与合作的关系，善于通过培训提高团队综合能力和凝聚力。",
        awards_per: "2016年  新长城上海外国语大学自强社“优秀社员”;2015年  三下乡”社会实践活动“优秀学生”;2015年  上海外国语大学学生田径运动会10人立定跳远团体赛第三名;2015年  学生军事技能训练“优秀学员”;2015年  上海外国语大学盼盼杯烘焙食品创意大赛优秀奖;2014年  高校大学生主题征文一等奖;2014年  上海外国语大学“青春”微博文征集大赛二等奖;普通话一级甲等;通过全国计算机二级考试，熟练运用office相关软件。;熟练使用绘声绘色软件，剪辑过各种类型的电影及班级视频。;大学英语四/六级（CET-4/6），良好听说读写能力，快速浏览英语专业书籍。",
        certificates: "2016年  新长城上海外国语大学自强社“优秀社员”;2015年  三下乡”社会实践活动“优秀学生”;2015年  上海外国语大学学生田径运动会10人立定跳远团体赛第三名;2015年  学生军事技能训练“优秀学员”;2015年  上海外国语大学盼盼杯烘焙食品创意大赛优秀奖;2014年  高校大学生主题征文一等奖;2014年  上海外国语大学“青春”微博文征集大赛二等奖;普通话一级甲等;通过全国计算机二级考试，熟练运用office相关软件。;熟练使用绘声绘色软件，剪辑过各种类型的电影及班级视频。;大学英语四/六级（CET-4/6），良好听说读写能力，快速浏览英语专业书籍。",
        candidate_job_title: "销售总监",
        pred_salary: "12000--15000",
        lan_skill_per: "中文、英文",
        prof_skill_per: "javaЖpython",
        office_skill_per: "word、ppt",
        // highlights: "具有博士学位，属于高层次人才Ж就读于985类型高校，具备优秀的学习能力Ж有丰富的专业技能，对前端、数据分析、公关、演讲、商务谈判等技能或工具有深入的理解Ж主修课程:管理学、微观经济学、宏观经济学、管理信息系统、统计学、会计学、财务管理、市场营销、经济法、消费者行为学、国际市场营销Ж2016年  自强社“优秀社员”、2016年  三下乡”社会实践活动“优秀学生”、2015年  田径运动会10人立定跳远团体赛第三名、2015年  学生军事技能训练“优秀学员”、2015年  盼盼杯烘焙食品创意大赛优秀奖、2014年  高校学生主题征文一等奖",
        // predicted_stability: "0.7"
      },
      // // 显示的画像信息     上传文件分析完数据保存数据库后，再次发送请求，将resume id 传递给后端  在获取下面这些信息
      item_info: {
        // 简历亮点
        highlights: ['拥有硕士学位', '熟练掌握英语，可以流利地进行听说读写', '有丰富的产品设计经验，对互联网产品、用户需求、产品设计、需求文档、产品研发、产品开发等技能或工具有深入的理解'],
        // highlights: [],
        // 综合标签
        // per_tag: ['名企经历', '英语能力良好', '技术达标'],
        // 预测薪资
        predicted_salary: '10000-15000元/月',
        // 预测稳定性
        predicted_stability: 0.8,
        // 人物标签
        tags: {
          basic: [
            {
              tag: '',
              type: '性别'
            },
            {
              tag: '26到30岁',
              type: '年龄'
            },
            {
              tag: '初级',
              type: '等级'
            }
          ],
          education: [
            {
              tag: '硕士学历',
              type: '学历'
            },
            {
              tag: '软件工程',
              type: '专业'
            },
            {
              tag: '英语CET6',
              type: '专业'
            }
          ],
          professional: [
            {
              tag: '互联网/软件',
              type: '行业'
            },
            {
              tag: '产品运营',
              type: '职位名称'
            },
            {
              tag: '产品经理',
              type: '职位名称'
            },
            {
              tag: '龙头互联网企业',
              type: '公司类型'
            }
          ],
          other: [
            {
              tag: '英语',
              type: '语言'
            },
            {
              tag: '国家计算机三级',
              type: '证书'
            },
            {
              tag: 'cet6',
              type: '证书'
            }
          ],
          // 专业技能标签
          skills: [
            {
              tag: '市场调研',
              Proficiency: '60'
            },
            {
              tag: '产品运营',
              Proficiency: '60'
            },
            {
              tag: '产品经理',
              Proficiency: '50'
            },
            {
              tag: '龙头互联网企业',
              Proficiency: '50'
            },
            {
              tag: '计算机',
              Proficiency: '70'
            },
            {
              tag: '软禁工程',
              Proficiency: '69'
            },
            {
              tag: '大堂经理',
              Proficiency: '56'
            },
            {
              tag: '快递员',
              Proficiency: '65'
            }
          ],
          positions:[
            {
              tag: 'ios开发工程师',
              Proficiency: '0.179'
            },
            {
              tag: '项目总监',
              Proficiency: '0.17'
            },
            {
              tag: '执行总经理',
              Proficiency: '0.178'
            },
            {
              tag: 'ios软件开发师',
              Proficiency: '0.196'
            },
            {
              tag: '公司总经理',
              Proficiency: '0.18570'
            },

            {
              tag: '项目主管',
              Proficiency: '1.2'
            },
            {
              tag: '总经理',
              Proficiency: '1.0'
            },
            {
              tag: '工程师',
              Proficiency: '0.2'
            },
            {
              tag: '副总经理',
              Proficiency: '0.196'
            },
            {
              tag: '公司总经理',
              Proficiency: '0.18570'
            },{
              tag: 'ios开发工程师',
              Proficiency: '0.179'
            },
            {
              tag: '项目总监',
              Proficiency: '0.17'
            },
            {
              tag: '执行总经理',
              Proficiency: '0.178'
            },
            {
              tag: 'ios软件开发师',
              Proficiency: '0.196'
            },
            {
              tag: '公司总经理',
              Proficiency: '0.18570'
            },

            {
              tag: '项目主管',
              Proficiency: '1.2'
            },
            {
              tag: '总经理',
              Proficiency: '1.0'
            },
            {
              tag: '工程师',
              Proficiency: '0.2'
            },
            {
              tag: '副总经理',
              Proficiency: '0.196'
            },
            {
              tag: '公司总经理',
              Proficiency: '0.18570'
            },{
              tag: 'ios开发工程师',
              Proficiency: '0.179'
            },
            {
              tag: '项目总监',
              Proficiency: '0.17'
            },
            {
              tag: '执行总经理',
              Proficiency: '0.178'
            },
            {
              tag: 'ios软件开发师',
              Proficiency: '0.196'
            },
            {
              tag: '公司总经理',
              Proficiency: '0.18570'
            },

            {
              tag: '项目主管',
              Proficiency: '1.2'
            },
            {
              tag: '总经理',
              Proficiency: '1.0'
            },
            {
              tag: '工程师',
              Proficiency: '0.2'
            },
            {
              tag: '副总经理',
              Proficiency: '0.196'
            },
            {
              tag: '公司总经理',
              Proficiency: '0.18570'
            },
          ]
        },
        predicted_capability: {
          '语言': 89,
          '社交能力': 99,
          '领导能力': 60,
          '工作能力': 75,
          '教育经历': 60,
          '所获奖项': 90
        },
        predicted_industry: {
          '互联网': 53,
          '产品': 48,
          '人事/行政/高级管理': 84,
          '其他': 40,
          '咨询/法律/公务员': 25,
          '工程师': 50,
          '建筑/房地产': 55,
          '教育/翻译/服务业': 30,
          '生产/采购/物流': 61,
          '生物/制药/医疗/护理': 20,
          '运营/客服/销售/市场': 60,
          '金融': 50,
        }
      },
      dialogFormVisible: false,
      file: null,
      conn: Global.data().conn,
      uploadProgress: 0
    }
  },
  async mounted() {
    // 看这里：  仅测试，流程上注释掉这句话
    // this.data_processing(this.item_detail)

    // 假装点击了人物画像
    // this.click_huaxiang()
    // this.initEcharts()
  },
  methods: {
    // 人物画像界面的图标显示
    initEcharts() {
      // 处理数据
      var data = []
      // 看这里   先用skill假装一下数据  格式是一样的
      var coun = 1
      for (var i in this.item_info.tags.positions){
        // console.log(this.item_info.tags.skills[i].tag)
        // console.log(this.item_info.tags.skills[i].Proficiency)
        var dx
        if (coun<2){
          dx=30
        }else if (coun<4){
          dx = 26
        // }else if (coun<7){
        //   dx = 24
        }else if (coun<10){
          dx = 22
        }else if (coun<13){
          dx = 20
        }else if (coun<16){
          dx = 18
        }else if (coun<19){
          dx = 15
        }else {
          dx = 12
        }
        coun++

        var dd = [this.item_info.tags.positions[i].tag,dx]
        data.push(dd)
      }
      console.log(data)


      WordCloud(document.getElementById('myCanvas'), {
        list: data,
        prefer_horizontal :0,
        // shape: 'circle',
        shape: 'pentagon',
        // width: 700,
        // height: 400
        // 其他自定义选项
      });
      // var chart = this.$echarts.init(document.getElementById('myCanvas'));
      // var option = {
      //   tooltip: {},
      //   series: [ {
      //     type: 'wordCloud',
      //     gridSize: 2,
      //     sizeRange: [12, 50],
      //     rotationRange: [-90, 90],
      //     shape: 'pentagon',
      //     width: 600,
      //     height: 400,
      //     drawOutOfBound: true,
      //     textStyle: {
      //       normal: {
      //         color: function () {
      //           return 'rgb(' + [
      //             Math.round(Math.random() * 160),
      //             Math.round(Math.random() * 160),
      //             Math.round(Math.random() * 160)
      //           ].join(',') + ')';
      //         }
      //       },
      //       emphasis: {
      //         shadowBlur: 10,
      //         shadowColor: '#333'
      //       }
      //     },
      //     data: data
      //   } ]
      // };
      //
      // chart.setOption(option);
      //
      // window.onresize = chart.resize;



      console.log('执行了创建图的函数')
      var pie = document.getElementById('mychart_pie')
      var radar = document.getElementById('mychart_radar')
      // var cloud = document.getElementById('wordcloud')
      console.log(pie)
      console.log(radar)
      var Chart_pie = this.$echarts.init(pie, null, {
        renderer: 'canvas',
        useDirtyRect: false
      });
      var Chart_radar = this.$echarts.init(radar, null, {
        renderer: 'canvas',
        useDirtyRect: false
      });

      const option_pei = {
        color: [ '#7db391', '#f69e9e','#5571c6','#74c0de','#fc8553', '#9b61b4', '#c1957b', '#b60089', '#67c7b9', '#ffd57c'],
        // legend: {
        //   top: 'bottom'
        // },
        tooltip: {
          show: true,
          trigger: 'item',

        },
        toolbox: {
          show: true,
          feature: {
            mark: { show: true },
            // dataView: { show: true, readOnly: false },
            // restore: { show: true },
            // saveAsImage: { show: true }
          }
        },
        series: [
          {
            name: '综合能力',
            type: 'pie',
            radius: [30, 130],
            center: ['50%', '50%'],
            roseType: 'area',
            itemStyle: {
              borderRadius: [50,50, 10, 10]
            },
            data: []
          }
        ]
      };
      const option_radar = {
        color: ['#645bdb'],
        // color: ['#67F9D8', '#FFE434', '#56A3F1', '#FF917C'],

        // 鼠标经过，显示信息
        tooltip: {
          show: false,
          triggerOn: 'mouseover',
          formatter: function () {
            return '';
          }
        },
        // 雷达原图
        radar: [
          {
            //需要自定义    属性名
            indicator: [],
            center: ['50%', '50%'],
            radius :120,
            shape: 'circle',
            splitArea: {
              areaStyle: {
                // 雷达的⚪
                // color: ['#e2e2e2', '#bababa', '#d0d0d0', '#e7e7e7'],
                shadowColor: 'rgba(0,0,0,0.2)',
                shadowBlur: 30
              }
            },
            // 字体和射线
            axisLine: {
              lineStyle: {
                color: 'rgb(127,127,127)'
              }
            },
            // 圆圈线
            splitLine: {
              lineStyle: {
                color: 'rgba(198,198,198,0.8)'
              }
            }
          },
        ],
        series: [
          {
            type: 'radar',
            // 选中时的样式
            emphasis: {

              lineStyle: {
                width: 4
              }
            },
            data: [
              {
                value: [],
                name: '行业分析',
                symbol: 'rect',
                symbolSize: 8,
                areaStyle: {
                  color: 'rgba(104,115,229,0.3)'
                  // color: 'rgba(255,255,255,0.8)'
                },
                label: {
                  normal: {
                    textStyle:{
                      fontSize:15
                    },
                    // fontsize: 20,
                    show: false,
                    formatter:function(params) {
                      return params.value;
                    }
                  }
                },

              }
            ]
          },
        ]
      };


      for (var i in this.item_info.predicted_capability){
        var nengli = {value: this.item_info.predicted_capability[i],name:i}
        option_pei.series[0].data.push(nengli)
        // console.log(i)
        // console.log(this.item_info.predicted_capability[i])
      }
      for (var i in this.item_info.predicted_industry){
        // console.log(i)
        // console.log(this.item_info.predicted_industry[i])
        // 看这里
        option_radar.series[0].data[0].value.push(this.item_info.predicted_industry[i])
        option_radar.radar[0].indicator.push({name: i,max:100})
        // console.log(i)
        // console.log(this.item_info.predicted_capability[i])
      }



      pie.removeAttribute('_echarts_instance_');
      radar.removeAttribute('_echarts_instance_');
      // cloud.removeAttribute('_echarts_instance_');
      if (option_pei && typeof option_pei === 'object') {
        Chart_pie.setOption(option_pei);
      }
      Chart_pie.on('mouseover', function(params) {
        Chart_pie.dispatchAction({
          type: 'select',
          seriesName: params.name
        })
      });
      if (option_radar && typeof option_radar === 'object') {
        Chart_radar.setOption(option_radar);
      }
      Chart_radar.on('mouseover', function(params) {
        // console.log(params)
        if (option_radar.series[0].data[0].label.normal.show ==false) {
          option_radar.series[0].data[0].label.normal.show = true
          Chart_radar.setOption(option_radar);
        }

      });
      Chart_radar.on('mouseout', function(params) {
        // console.log(params)
        if (option_radar.series[0].data[0].label.normal.show ==true) {
          option_radar.series[0].data[0].label.normal.show = false
          Chart_radar.setOption(option_radar);
        }
      });
    },
    // 用户上传文件之后的等待界面的画面显示，需要将当前文件进行上传，获取后端的返回值，放到当前的变量item_info中去

    // 返回上一页
    go_back() {
      this.active = 0
    },
    // 点击中文简历
    click_jianli() {
      this.active1 = 0
    },
    // 点击人物画像  因为刚刚创建dom的时候获取div值为null，为了避免无法执行init，所以需要将该函数执行多遍，一直到能够获取到dom为止
    // 使用了setInterval方法，该方法在timer实体被销毁之前，都会一直调用第一个参数中的函数，间隔时间为第二个参数。
    click_huaxiang() {
      console.log('点击了人物画像')
      this.timer = setInterval(this.click_huaxiang1, 1);
      console.log('执行完了timer')
      // this.click_huaxiang1()
      // this.click_huaxiang1()
      // this.click_huaxiang1()
      // this.active1 = 1
      // this.initEcharts()
    },
    // 该函数被不间断地调用，直到能够获取当前文件的dom。将timer实体销毁，将不再继续调用函数。
    click_huaxiang1() {
      console.log('进入调用的函数了')
      if (document.getElementById('mychart_pie') != null && document.getElementById('mychart_radar') != null){
        clearInterval(this.timer);
        console.log('创建好了.现在输出两个dom文件,然后跳转界面')
        console.log(document.getElementById('mychart_pie'))
        console.log(document.getElementById('mychart_radar'))
        this.active1 = 1
        this.initEcharts()
      }else {
        // 进入界面加载dom  加载echarts
        console.log('还没创建')
        this.active1 = 1
        this.initEcharts()
      }
      // clearInterval(this.timer);

    },

    resumeAnalysis(){
      let formData = new FormData();
      formData.append('resumeUrl', this.resumeUrl);
      formData.append('resumeName', this.resumeName)
      console.log("formData.resumeName:", formData.get('resumeName'))
      formData.append('username', Global.username)
      let config = {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }
      var table = []
      //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
      var that = this;
      axios.post(this.conn+'/resume_analysis', formData, config).then(function(res) {
        that.PageSize = 3
        console.log('解析的后端返回:', res)
        if (res.status === 200) {
          that.$notify({
            title: '成功',
            message: that.resumeName + '解析成功!',
            type: 'success'
          });
          // 现在我只需要将最后一条res数据提取出来  存在item_detial中就行了   在跳转this。active=1
          // var bianliang = res.data[res.data.length-1]
          var item = []
          item.push({
            id: res.data[res.data.length-1][0] + '',
            name_per: res.data[res.data.length-1][1],
            sex_per: res.data[res.data.length-1][2],
            email_per: res.data[res.data.length-1][3],
            age_per: res.data[res.data.length-1][4] + '',
            phone_per: res.data[res.data.length-1][5],
            qq: res.data[res.data.length-1][6],
            weixin: res.data[res.data.length-1][7],
            address_per: res.data[res.data.length-1][8],
            height: res.data[res.data.length-1][9],
            weight: res.data[res.data.length-1][10],
            race: res.data[res.data.length-1][11],
            nationality: res.data[res.data.length-1][12],
            marital_status: res.data[res.data.length-1][13],
            highest_edu_per: res.data[res.data.length-1][14],
            adm_date: res.data[res.data.length-1][15],
            gra_date: res.data[res.data.length-1][16],
            gra_school_per: res.data[res.data.length-1][17],
            major_per: res.data[res.data.length-1][18],
            lan_skill_per: res.data[res.data.length-1][19],
            prof_skill_per: res.data[res.data.length-1][20],
            office_skill_per: res.data[res.data.length-1][21],
            awards_per: res.data[res.data.length-1][22],
            certificates: res.data[res.data.length-1][23],
            political_status: res.data[res.data.length-1][24],
            postal_code: res.data[res.data.length-1][25],
            school_level: res.data[res.data.length-1][26],
            courses: res.data[res.data.length-1][27],
            edu_gpa: res.data[res.data.length-1][28],
            job_title: res.data[res.data.length-1][29],
            company_name: res.data[res.data.length-1][30],
            work_date: res.data[res.data.length-1][31],
            work_description: res.data[res.data.length-1][32],
            work_industry: res.data[res.data.length-1][33],
            work_year: res.data[res.data.length-1][34],
            project_name: res.data[res.data.length-1][35],
            project_position: res.data[res.data.length-1][36],
            project_date: res.data[res.data.length-1][37],
            project_description: res.data[res.data.length-1][38],
            social_pos: res.data[res.data.length-1][39],
            social_description: res.data[res.data.length-1][40],
            social_cpy: res.data[res.data.length-1][41],
            social_date: res.data[res.data.length-1][42],
            train_org: res.data[res.data.length-1][43],
            training_description: res.data[res.data.length-1][44],
            train_date: res.data[res.data.length-1][45],
            self_evaluation: res.data[res.data.length-1][46],
            candidate_job_title: res.data[res.data.length-1][47],
            parsing_time: res.data[res.data.length-1][48],
            resume_type: res.data[res.data.length-1][49],
            resume_name: res.data[res.data.length-1][50],
            path_resume: res.data[res.data.length-1][51],
            avatar_url: res.data[res.data.length-1][52],
            pred_salary: res.data[res.data.length-1][53],
            pos_tags: res.data[res.data.length-1][54],
            skills_tags: res.data[res.data.length-1][55],
            username: res.data[res.data.length-1][56]
          })
          console.log(item)
          that.item_detail = item[0]
          that.data_processing(that.item_detail)
          console.log(that.item_detail)
          that.resumeName = ''
          that.resumeUrl = ''
          that.start_huaxiang()
        }
      }).catch(err => {
        // this.$message.error(err.message);
        console.log(err)
      })
    },
    start_huaxiang(){
      var data = new FormData()
      var that = this
      data.append('id',this.item_detail.id)
      axios.post(this.conn+'/portrait',data).then(function(res){
        console.log('人物画像后端返回的数据',res)
        if (res.status == 200){
          // 看看数据是什么格式的再说
          that.item_info = res.data
          console.log("that.item_info",that.item_info)
          for (var i in that.item_info) {
            console.log(i,'===',that.item_info,'===',typeof that.item_info)
          }
          that.active = 1
        }
      })

    },

    async submit_file() {
      // 点击开始画像，跳转到加载界面。还是执行请求  接收参数
      this.active = 2
      let formData = new FormData()
      formData.append("resume", this.file)
      formData.append("username", Global.username)
      var that = this;
      console.log(this.file)
      const res = await axios.post(this.conn+"/save_upload_resume2", formData).then(function(response) {
        console.log('保存到后端的返回值为：：',response)
        if (response.status === 200) {
          that.$notify({
            title: '成功',
            message: that.file.name + '上传成功!',
            type: 'success'
          });
          that.resumeUrl = response.data
          that.resumeName = response.data.split("/")[response.data.split("/").length-1]
          console.log('简历地址',that.resumeUrl)
          console.log('简历名称',that.resumeName)
          that.resumeAnalysis()
        }
      }).catch(err => {
        this.$message.error(err.message);
        console.log(err)
      })
      // const res1 = await axios.post(this.conn+"/update_talent", formData).then(function(response) {
      // }).catch(err => {
      //   // this.$message.error(err.message);
      //   // console.log(err)
      // })

    },
    // 拖动触发函数
    save_file(params){
      this.file = params.file
      console.log(this.file)
    },
    // 点击上传触发函数   将文件包存在变量里面
    handleFileChange(e) {
      const file = e.target.files[0]
      this.file = file
      console.log(this.file)
    },
    data_processing(item){
      for (var i in item) {
        // console.log(i)
        if (i ==='work_year'){
          if(item[i] != ''){
            item[i] = parseInt(item[i])
            item[i] = item[i]+'年'
          }
        }
        if (i ==='age_per'){
          if(item[i] == '-1'){
            console.log(item[i])
            item[i] = ''
            console.log(item[i])
          }
        }
        if (item[i].indexOf('Ж')!= -1) {
          item[i] = item[i].split('Ж')
        }
      }

      // 教育
      var edu = []
      //遍历列表
      if (typeof (item.adm_date) != "string"){
        for (var i =0;i<item.adm_date.length;i++){
          edu.push({
            adm_date : item.adm_date[i],
            gra_date : item.gra_date[i],
            gra_school_per : item.gra_school_per[i],
            major_per : item.major_per[i],
            edu_gpa : item.edu_gpa[i],
            courses : item.courses[i],
            school_level : item.school_level[i],
          })
        }
      }

      if (edu.length==0){
        if (item.adm_date == "" &&item.gra_date == "" &&item.gra_school_per == "" &&item.major_per == "" &&item.school_level == "" &&item.edu_gpa == "" &&item.courses == ""){

        }else {
          edu.push({
            adm_date : item.adm_date,
            gra_date : item.gra_date,
            gra_school_per : item.gra_school_per,
            major_per : item.major_per,
            edu_gpa : item.edu_gpa,
            courses : item.courses,
            school_level : item.school_level,
          })
        }
      }
      // 工作
      var work = []
      if (typeof (item.work_date) != "string") {
        for (var i = 0; i < item.work_date.length; i++) {
          work.push({
            work_date: item.work_date[i],
            work_description: item.work_description[i],
            // work_industry: item.work_industry[i]+'',
            company_name: item.company_name[i],
            job_title: item.job_title[i],
          })
        }
      }
      if (work.length==0){
        if (item.work_date == "" &&item.work_description == "" &&item.work_industry == "" &&item.company_name == "" &&item.job_title == "" ){

        }else {
          work.push({
            work_date : item.work_date,
            work_description : item.work_description,
            work_industry : item.work_industry,
            company_name : item.company_name,
            job_title : item.job_title,
          })
        }
      }
      // 项目
      var project = []
      if (typeof (item.project_name) != "string") {
        for (var i = 0; i < item.project_name.length; i++) {
          project.push({
            project_name: item.project_name[i],
            project_description: item.project_description[i],
            project_date: item.project_date[i],
            project_position: item.project_position[i]
          })
        }
      }
      if (project.length==0){
        if (item.project_name == "" &&item.project_description == "" &&item.project_date == "" &&item.project_position == "" ){

        }else {
          project.push({
            project_name : item.project_name,
            project_description : item.project_description,
            project_date : item.project_date,
            project_position : item.project_position
          })
        }
      }
      // 社会
      var social = []
      if (typeof (item.social_pos) != "string") {
        for (var i = 0; i < item.social_pos.length; i++) {
          social.push({
            social_pos: item.social_pos[i],
            social_date: item.social_date[i],
            social_cpy: item.social_cpy[i],
            social_description: item.social_description[i]
          })
        }
      }
      if (social.length==0){
        if (item.social_pos == "" &&item.social_date == "" &&item.social_cpy == "" &&item.social_description == "" ){

        }else {
          social.push({
            social_pos : item.social_pos,
            social_date : item.social_date,
            social_cpy : item.social_cpy,
            social_description : item.social_description
          })
        }
      }
      // 培训
      var train = []
      if (typeof (item.train_org) != "string") {
        for (var i = 0; i < item.train_org.length; i++) {
          train.push({
            train_org: item.train_org[i],
            training_description: item.training_description[i],
            train_date: item.train_date[i]
          })
        }
      }
      if (train.length==0){
        if (item.social_pos == "" &&item.social_date == "" &&item.social_cpy == "" &&item.social_description == "" ){

        }else {
          train.push({
            train_org : item.train_org,
            training_description : item.training_description,
            train_date : item.train_date
          })
        }
      }



      item.edu = edu
      item.work = work
      item.project = project
      item.social = social
      item.train = train
      // console.log('item.edu',item.edu)
      // console.log('item.work',item.work)
      // console.log('item.project',item.project)
      // console.log('item.social',item.social)
      // console.log('item.train',item.train)
      // console.log('candidate_job_title.len',item.candidate_job_title.length)
    }
  },

}
</script>
