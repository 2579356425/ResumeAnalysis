<template>
  <div>
    <div class="big" v-if="active==0">
      <div style="text-align: center">
        <a align="center" style="color: #00aaff;">
          <h2 >人物画像 </h2>
          <h5 style="display: inline-block;color: #000000;font-weight: normal">请上传简历,或 </h5>
          <a style="font-size: small;font-weight: bold" @click="dialogFormVisible = true"> 填写信息</a>
        </a>
        <div class="add_info" style="width: 80%;">
          <el-dialog title="填写信息" :visible.sync="dialogFormVisible">
            <form action="" ref="item">
              <div>
                <label id="name_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>姓名</label>
                <span><input type="text"  v-model="item.name_per" placeholder="请输入姓名"></span>
              </div>
              <div>
                <label id="sex_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>性别</label>
                <span style="text-align: left">
                  <el-radio v-model="item.sex_per" label="男" ><label style="width: 10px;margin-left: 5px">男</label></el-radio>
                  <el-radio v-model="item.sex_per" label="女"><label style="width: 10px;margin-left: 5px">女</label></el-radio>
                </span>
              </div>
              <div>
                <label id="age_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>年龄</label>
                <span><input type="text"  v-model="item.age_per" placeholder="请输入年龄范围"></span>
              </div>
              <div>
                <label id="political_status"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>政治面貌</label>
                <span><input type="text"  v-model="item.political_status" placeholder="请输入政治面貌"></span>
              </div>
              <div>
                <label id="address_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>住址</label>
                <span><input type="text"  v-model="item.address_per" placeholder="请输入住址"></span>
              </div>
              <div>
                <label id="email_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>邮箱</label>
                <span><input type="text"  v-model="item.email_per" placeholder="请输入邮箱"></span>
              </div>
              <div>
                <label id="phone_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>手机号</label>
                <span><input type="text"  v-model="item.phone_per" placeholder="请输入手机号"></span>
              </div>
              <div>
                <label id="gra_school_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>毕业院校</label>
                <span><input type="text"  v-model="item.gra_school_per" placeholder="请输入毕业院校"></span>
              </div>
              <div>
                <label id="highest_edu_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>最高学历</label>
                <span><input type="text"  v-model="item.highest_edu_per" placeholder="请输入最高学历"></span>
              </div>
              <div>
                <label id="degree_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>学位</label>
                <span><input type="text"  v-model="item.degree_per" placeholder="请输入学位"></span>
              </div>
              <div>
                <label id="major_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>专业</label>
                <span><input type="text"  v-model="item.major_per" placeholder="请输入专业"></span>
              </div>
              <div>
                <label id="adm_date"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>入学时间</label>
                <span><input type="text"  v-model="item.adm_date" placeholder="请输入入学时间"></span>
              </div>
              <div>
                <label id="gra_school_date"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>毕业时间</label>
                <span><input type="text"  v-model="item.gra_school_date" placeholder="请输入毕业时间"></span>
              </div>
              <div>
                <label id="courses"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>所学课程</label>
                <span><input type="text"  v-model="item.courses" placeholder="请输入所学课程"></span>
              </div>
              <div>
                <!--                <label id="school_level"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>院校水平</label>-->
                <label id="school_level">院校水平</label>
                <span><input type="text"  v-model="item.school_level" placeholder="请输入院校水平"></span>
              </div>
              <div>
                <label id="lan_skill_per">语言技能</label>
                <!--                <label id="lan_skill_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>语言技能</label>-->
                <span><input type="text"  v-model="item.lan_skill_per" placeholder="请输入语言技能"></span>
              </div>
              <div>
                <label id="prof_skill_per">专业技能</label>
                <!--                <label id="prof_skill_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>专业技能</label>-->
                <span><input type="text"  v-model="item.prof_skill_per" placeholder="请输入专业技能"></span>
              </div>
              <div>
                <label id="soft_skill_per">软性技能</label>
                <!--                <label id="soft_skill_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>软性技能</label>-->
                <span><input type="text"  v-model="item.soft_skill_per" placeholder="请输入软性技能"></span>
              </div>
              <div>
                <label id="office_skill_per">办公技能</label>
                <!--                <label id="office_skill_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>办公技能</label>-->
                <span><input type="text"  v-model="item.office_skill_per" placeholder="请输入办公技能"></span>
              </div>
              <div>
                <label id="certificates">所获证书</label>
                <!--                <label id="certificates"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>所获证书</label>-->
                <span><input type="text"  v-model="item.certificates" placeholder="请输入所获证书"></span>
              </div>
              <div>
                <label id="awards_per">所获奖项</label>
                <!--                <label id="awards_per"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>所获奖项</label>-->
                <span><input type="text"  v-model="item.awards_per" placeholder="请输入所获奖项"></span>
              </div>
              <div>
                <label id="job_title">曾任职位</label>
                <!--                <label id="job_title"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>曾任职位</label>-->
                <span><input type="text"  v-model="item.job_title" placeholder="请输入曾任职位"></span>
              </div>
              <div>
                <label id="company_name">曾任公司名称</label>
                <!--                <label id="company_name"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>曾任公司名称</label>-->
                <span><input type="text"  v-model="item.company_name" placeholder="请输入曾任公司名称"></span>
              </div>
              <div>
                <label id="job_function">曾任职位所属职能</label>
                <!--                <label id="job_function"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>曾任职位所属职能</label>-->
                <span><input type="text"  v-model="item.job_function" placeholder="请输入曾任职位所属职能"></span>
              </div>
              <div>
                <label id="work_description">曾任工作描述</label>
                <!--                <label id="work_description"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>曾任工作描述</label>-->
                <span><input type="text"  v-model="item.work_description" placeholder="请输入曾任工作描述"></span>
              </div>
              <div>
                <label id="social_description">社会经历</label>
                <!--                <label id="social_description"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>社会经历</label>-->
                <span><input type="text"  v-model="item.social_description" placeholder="请输入社会经历"></span>
              </div>
              <div>
                <label id="project_description">曾负责项目描述</label>
                <!--                <label id="project_description"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>曾负责项目描述</label>-->
                <span><input type="text"  v-model="item.project_description" placeholder="请输入曾负责项目描述"></span>
              </div>
              <div>
                <label id="training_organization_name">培训机构名称</label>
                <!--                <label id="training_organization_name"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>培训机构名称</label>-->
                <span><input type="text"  v-model="item.training_organization_name" placeholder="请输入培训机构名称"></span>
              </div>
              <div>
                <label id="training_description">培训描述</label>
                <!--                <label id="training_description"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>培训描述</label>-->
                <span><input type="text"  v-model="item.training_description" placeholder="请输入培训描述"></span>
              </div>
              <div>
                <label id="self_evaluation">自我评价</label>
                <!--                <label id="self_evaluation"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>自我评价</label>-->
                <span><input type="text"  v-model="item.self_evaluation" placeholder="请输入自我评价"></span>
              </div>
              <div>
                <label id="candidate_job_title">所获奖项</label>
                <!--                <label id="candidate_job_title"><span style="display: inline-block;width: 10px;height: 10px;margin-right: 10px;color: #ff0000;font-size: large">*</span>所获奖项</label>-->
                <span><input type="text"  v-model="item.candidate_job_title" placeholder="请输入投递职位描述"></span>
              </div>
            </form>
            <div slot="footer" class="dialog-footer">
              <el-button class="elbtn" @click="dialogFormVisible = false">取 消</el-button>
              <el-button class="elbtn biger" type="primary" @click="submit_add()">开始画像</el-button>
            </div>
          </el-dialog>
        </div>
      </div>
      <!--  给下面这个div添加拖拽方法-->
      <div ref="drag" class="drag">
        <div class="drag-icon-box">
          <!-- 采用的是 element-ui 的图标 -->
          <i class="el-icon-upload"  style="font-size: 50px; font-weight: 500"></i>
        </div>
        <div class="drag-message">
          <span class="drag-message-title">将文件拖动到此处，或</span>
          <label for="file" class="drag-message-label">
            <input
              class="drag-message-input"
              type="file"
              id="file"
              name="file"
              ref="input"
              @change="handleFileChange"
            />
            <span class="drag-message-manual">点击上传</span>
          </label>
        </div>

      </div>
      <div style="text-align: center;margin-top: 10px">
        <el-button size="medium" type="primary" style="margin-left:10px;margin-top:1px;height: 34px;" @click="submit_file()"><i class="el-icon-thumb" />开始画像</el-button>
      </div>
    </div>
    <div class="big1" v-if="active==1">
      <!--      <i class="el-icon-back" style="display: inline-block;font-size: 40px;float:left;margin-top: 20px;margin-left: 20px" @click="go_back()" />-->
      <i class="el-icon-back" style="display: inline-block;font-size: 40px;float:left;margin-top: 40px;margin-left: 80px" @click="go_back()" />
      <div class="info">
        <div class="one">
          <!--          <div v-if="active1===0" class="zhongwenjianli" style="display: inline-block;margin-right: 20px">中文简历</div>-->
          <!--          <div v-if="active1===1" class="zhongwenjianli" style="display: inline-block">人物画像</div>-->
        </div>
        <div class="two">
          <img v-if="item_detail.sex_per==='男'" class="imgg" src="../../icons/man.jpg" alt="头像">
          <img v-if="item_detail.sex_per==='女'" class="imgg" src="../../icons/woman.jpg" alt="头像">
          <div class="sinfo">
            <div class="name">
              <span style="margin-right: 20px">{{ item_detail.name_per }}</span>
              <el-tooltip :open-delay= 300 v-for="str in item_info.per_tag" class="item" effect="dark" content="简历亮点" placement="top">
                <label class="blue1">{{str}}</label>
                <!--                <label class="blue1" v-for="str in item_info.per_tag">{{str}}</label>-->
              </el-tooltip>
            </div>
            <div class="sinfos">
              <i v-if="item_detail.age_per.toString().length>0" class="el-icon-user-solid" />{{ item_detail.age_per }}
              <i class="mar_left el-icon-s-opportunity" />{{ item_detail.sex_per }}
              <i class="mar_left el-icon-s-comment" />{{ item_detail.email_per }}
              <i class="mar_left el-icon-phone" />{{ item_detail.phone_per }}
              <i class="mar_left el-icon-s-cooperation" />{{ item_detail.highest_edu_per }}
            </div>
          </div>
        </div>
        <a @click="click_jianli()">中文简历</a>
        <a @click="click_huaxiang()">人物画像</a>
        <div style="display: block;height: 10px;">
          <div :class="[active1==0? 'under_a_yes':'under_a_no']"></div>
          <div :class="[active1==1? 'under_a_yes':'under_a_no']"></div>
        </div>
        <hr class="fenjiexian">
        <div v-if="active1===0" class="jianli">

          <div v-if="item_detail.name_per.length>0 || item_detail.age_per.toString().length>0 || item_detail.phone_per.length>0 || item_detail.qq.length>0 || item_detail.height.length>0 || item_detail.race.length>0 || item_detail.nationality.length>0 || item_detail.highest_edu_per.length>0 || item_detail.political_status.length>0 || item_detail.sex_per.length>0 || item_detail.weixin.length>0 || item_detail.weight.length>0 || item_detail.marital_status.length>0 || item_detail.work_year.length>0 || item_detail.address_per.length>0 || item_detail.email_per.length>0" class="title_box">
            <div class="_title el-icon-user-solid"> 基本信息</div>
            <div class="_title_down" />
          </div>
          <div v-if="item_detail.name_per.length>0 || item_detail.age_per.toString().length>0 || item_detail.phone_per.length>0 || item_detail.qq.length>0 || item_detail.height.length>0 || item_detail.race.length>0 || item_detail.nationality.length>0 || item_detail.highest_edu_per.length>0 || item_detail.political_status.length>0 || item_detail.sex_per.length>0 || item_detail.weixin.length>0 || item_detail.weight.length>0 || item_detail.marital_status.length>0 || item_detail.work_year.length>0 || item_detail.address_per.length>0 || item_detail.email_per.length>0"  class="thr">
            <div v-if="item_detail.name_per.length>0 || item_detail.age_per.toString().length>0 || item_detail.phone_per.length>0 || item_detail.qq.length>0 || item_detail.height.length>0 || item_detail.race.length>0 || item_detail.nationality.length>0 || item_detail.highest_edu_per.length>0 || item_detail.political_status.length>0" class="left">
              <ul>
                <li v-if="item_detail.name_per.length>0"><span class="dian">●</span> 姓名：<span>{{ item_detail.name_per }}</span></li>
                <li v-if="item_detail.age_per.toString().length>0"><span class="dian">●</span> 年龄：<span>{{ item_detail.age_per }}</span></li>
                <li v-if="item_detail.phone_per.length>0"><span class="dian">●</span> 联系方式：<span>{{ item_detail.phone_per }}</span></li>
                <li v-if="item_detail.qq.length>0"><span class="dian">●</span> QQ：<span>{{ item_detail.qq }}</span></li>
                <li v-if="item_detail.height.length>0"><span class="dian">●</span> 身高：<span>{{ item_detail.height }}</span></li>
                <li v-if="item_detail.race.length>0"><span class="dian">●</span> 民族：<span>{{ item_detail.race }}</span></li>
                <li v-if="item_detail.nationality.length>0"><span class="dian">●</span> 国籍：<span>{{ item_detail.nationality }}</span></li>
                <li v-if="item_detail.highest_edu_per.length>0"><span class="dian">●</span> 最高学历：<span>{{ item_detail.highest_edu_per }}</span></li>
                <li v-if="item_detail.political_status.length>0"><span class="dian">●</span> 政治面貌：<span>{{ item_detail.political_status }}</span></li>
                <!--              <li v-if="item_detail.school_level.length>0"><span class="dian">●</span> 学校等级：<span>{{ item_detail.school_level }}</span></li>-->
              </ul>
            </div>
            <div v-if="item_detail.sex_per.length>0 || item_detail.weixin.length>0 || item_detail.weight.length>0 || item_detail.marital_status.length>0 || item_detail.work_year.length>0 || item_detail.address_per.length>0 || item_detail.email_per.length>0" class="right">
              <ul>
                <li v-if="item_detail.sex_per.length>0"><span class="dian">●</span> 性别：<span>{{ item_detail.sex_per }}</span></li>
                <li v-if="item_detail.address_per.length>0"><span class="dian">●</span> 住址：<span>{{ item_detail.address_per }}</span></li>
                <li v-if="item_detail.email_per.length>0"><span class="dian">●</span> 邮箱：<span>{{ item_detail.email_per }}</span></li>
                <li v-if="item_detail.weixin.length>0"><span class="dian">●</span> 微信：<span>{{ item_detail.weixin }}</span></li>
                <li v-if="item_detail.weight.length>0"><span class="dian">●</span> 体重：<span>{{ item_detail.weight }}</span></li>
                <li v-if="item_detail.marital_status.length>0"><span class="dian">●</span> 婚姻状况：<span>{{ item_detail.marital_status }}</span></li>
                <li v-if="item_detail.work_year.length>0"><span class="dian">●</span> 工作经验：<span>{{ item_detail.work_year }}</span></li>
                <li v-if="item_detail.postal_code.length>0"><span class="dian">●</span> 邮编：<span>{{ item_detail.postal_code }}</span></li>
              </ul>
            </div>
          </div>

          <div v-if="item_detail.edu.length>0">
            <div class="title_box">
              <div class="_title el-icon-s-management"> 教育背景</div>
              <div class="_title_down" />
            </div>
            <div class="four">
              <div v-for="(item,index) in item_detail.edu" style="margin-bottom: 20px">
                <div style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px">{{ item.gra_school_per }}</div>
                <ul>
                  <li v-if="item.adm_date.length>0"><span class="dian">●</span> 时间：<span>{{ item.adm_date }} - {{ item.gra_date }}</span></li>
                  <li v-if="item.major_per.length>0"><span class="dian">●</span> 专业：<span>{{ item.major_per }}</span></li>
                  <li v-if="item.edu_gpa.length>0"><span class="dian">●</span> 绩点：<span>{{ item.edu_gpa }}</span></li>
                  <li v-if="item.school_level.length>0"><span class="dian">●</span> 学校水平：<span>{{ item.school_level }}</span></li>
                  <li style="position: relative" v-if="item.courses.length>0" ><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">所学课程：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.courses }}</div></li>
                </ul>
              </div>
            </div>
          </div>

          <div v-if="item_detail.work.length>0">
            <div class="title_box">
              <div class="_title el-icon-s-cooperation"> 工作经历</div>
              <div class="_title_down" />
            </div>
            <div class="five">
              <div v-for="(item,index) in item_detail.work" style="margin-bottom: 20px">
                <div style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px ">{{item.company_name}}</div>
                <ul>
                  <li style="position: relative" v-if="item.work_date.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">工作时间：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.work_date }}</div></li>
                  <li style="position: relative" v-if="item.job_title.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">岗位名称：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.job_title }}</div></li>
                  <li style="position: relative" v-if="item.work_industry.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">工作行业：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.work_industry }}</div></li>
                  <li style="position: relative" v-if="item.work_description.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">工作描述：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.work_description }}</div></li>
                </ul>
              </div>
            </div>
          </div>

          <div v-if="item_detail.project.length>0">
            <div class="title_box">
              <div class="_title el-icon-s-cooperation"> 项目经历</div>
              <div class="_title_down" />
            </div>
            <div class="five">
              <div v-for="(item,index) in item_detail.project" style="margin-bottom: 20px">
                <div style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px">{{item.project_name}}</div>
                <ul>
                  <li style="position: relative" v-if="item.project_position.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">职位：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.project_position }}</div></li>
                  <li style="position: relative" v-if="item.project_date.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">项目时间：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.project_date }}</div></li>
                  <li style="position: relative" v-if="item.project_description.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">项目描述：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.project_description }}</div></li>
                </ul>
              </div>
            </div>
          </div>

          <div v-if="item_detail.social.length>0">
            <div class="title_box">
              <div class="_title el-icon-s-cooperation"> 社会经历</div>
              <div class="_title_down" />
            </div>
            <div class="five">
              <div v-for="(item,index) in item_detail.social" style="margin-bottom: 20px">
                <div style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px">{{item.social_cpy}}</div>
                <ul>
                  <!--              <li style="position: relative" v-if="item.social_cpy.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">组织单位：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px">{{ item.social_cpy }}</div></li>-->
                  <li style="position: relative" v-if="item.social_date.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">实践时间：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.social_date }}</div></li>
                  <li style="position: relative" v-if="item.social_pos.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">担任角色：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.social_pos }}</div></li>
                  <li style="position: relative" v-if="item.social_description.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">实践描述：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.social_description }}</div></li>
                </ul>
              </div>
            </div>
          </div>

          <div v-if="item_detail.train.length>0">
            <div class="title_box">
              <div class="_title el-icon-s-cooperation"> 培训经历</div>
              <div class="_title_down" />
            </div>
            <div class="five">
              <div  v-for="(item,index) in item_detail.train" style="margin-bottom: 20px">
                <div v-if="item.train_org.length>0" style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px">{{ item.train_org }}</div>
                <ul>
                  <li style="position: relative" v-if="item.train_date.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">培训时间：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.train_date }}</div></li>
                  <li style="position: relative" v-if="item.training_description.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">培训描述：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.training_description }}</div></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="title_box" v-if="item_detail.prof_skill_per.length>0 || item_detail.lan_skill_per.length>0 || item_detail.office_skill_per.length>0 ||item_detail.awards_per.length>0 || item_detail.certificates.length>0 || item_detail.self_evaluation.length>0">
            <div class="_title">其他信息</div>
            <div class="_title_down" />
          </div>
          <div class="six" v-if="item_detail.prof_skill_per.length>0 || item_detail.lan_skill_per.length>0 || item_detail.office_skill_per.length>0 ||item_detail.awards_per.length>0 || item_detail.certificates.length>0 || item_detail.self_evaluation.length>0">
            <ul>
              <li style="position: relative" v-if="item_detail.prof_skill_per.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">专业技能：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item_detail.prof_skill_per.join('、') }}</div></li>
              <li style="position: relative" v-if="item_detail.lan_skill_per.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">语言技能：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item_detail.lan_skill_per }}</div></li>
              <li style="position: relative" v-if="item_detail.office_skill_per.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">办公技能：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item_detail.office_skill_per }}</div></li>
              <li style="position: relative" v-if="item_detail.awards_per.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">所获奖项：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item_detail.awards_per }}</div></li>
              <li style="position: relative" v-if="item_detail.certificates.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">所获证书：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item_detail.certificates }}</div></li>
              <li style="position: relative" v-if="item_detail.self_evaluation.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">自我描述：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item_detail.self_evaluation }}</div></li>
            </ul>
          </div>

        </div>
        <div v-if="active1===1" class="huaxiang">
          <div class="title_box">
            <div class="_title">简历亮点</div>
            <div class="_title_down" />
          </div>
          <div class="thr">
            <div class="light">
              <div class="line_title"><i class="el-icon-s-opportunity blue_title"></i>简历亮点</div>
<!--              <ul>-->
<!--                <li v-for="liangdian in item_info.highlights"><div class="con">{{liangdian}}</div></li>-->
<!--              </ul>-->
              <ul>
                <li v-for="liangdian in item_detail.highlights"><div class="con">{{liangdian}}</div></li>
              </ul>
              <div class="line_title"><i class="el-icon-star-on green_title"></i>智能预测</div>
              <ul>
                <li>结合工作经验、学历、行业、地域等因素，该求职者的市场薪资约为 {{item_info.predicted_salary}}</li>
                <li>结合工作经历以及项目项目，此求职者短期离职可能性<span v-if="item_info.predicted_stability>0.8">较低</span><span v-if="item_info.predicted_stability<=0.8">较高</span></li>
              </ul>
            </div>
          </div>
          <div v-if="item_detail.adm_date.length>0 || item_detail.gra_date.length>0 || item_detail.gra_school_per.length>0 || item_detail.school_level.length>0 || item_detail.highest_edu_per.length>0 || item_detail.degree_per.length>0 || item_detail.major_per.length>0 || item_detail.courses.length>0" class="title_box">
            <div class="_title">人物标签</div>
            <div class="_title_down" />
          </div>
          <div class="four">
            <div class="tag">
              <div class="line_title"><i class="el-icon-user-solid blue_title"></i>基本标签</div>
              <div class="mar_left_20"><el-tooltip :open-delay=300  v-for="tag in item_info.tags.basic" class="item" effect="dark" :content="tag.type + '标签'" placement="top"><label class="blue">{{tag.tag}}</label></el-tooltip></div>
              <div class="line_title"><i class="el-icon-s-management yellow_title"></i>教育背景标签</div>
              <div class="mar_left_20"><el-tooltip :open-delay=300  v-for="tag in item_info.tags.education" class="item" effect="dark" :content="tag.type + '标签'" placement="top"><label class="yellow">{{tag.tag}}</label></el-tooltip></div>
              <div class="line_title"><i class="el-icon-s-cooperation ggreen_title"></i>职业标签</div>
              <div class="mar_left_20"><el-tooltip :open-delay=300  v-for="tag in item_info.tags.professional" class="item" effect="dark" :content="tag.type + '标签'" placement="top"><label class="green">{{tag.tag}}</label></el-tooltip></div>
              <div class="line_title"><i class="el-icon-menu perpal_title"></i>其他信息标签</div>
              <div class="mar_left_20"><el-tooltip :open-delay=300  v-for="tag in item_info.tags.other" class="item" effect="dark" :content="tag.type + '标签'" placement="top"><label class="perpal">{{tag.tag}}</label></el-tooltip></div>
              <div class="line_title"><i class="el-icon-s-tools gggreen_title"></i>专业技能标签</div>
              <div class="mar_left_20">
                <el-tooltip :open-delay=300  v-for="tag in item_info.tags.skills" class="item" effect="dark" :content="'熟练度：'+tag.Proficiency" placement="top">
                  <label v-if="tag.Proficiency<0.5" class="skill1">{{tag.tag}}</label>
                  <label v-else-if="tag.Proficiency<0.7" class="skill2">{{tag.tag}}</label>
                  <label v-else-if="tag.Proficiency<0.85" class="skill3">{{tag.tag}}</label>
                  <label v-else class="skill4">{{tag.tag}}</label>
                </el-tooltip>
              </div>
              <!--              <div class="mar_left_20"><label style="margin-left: 2px" class="skill" v-for="tag in item_info.tags.skills">{{tag.tag}}</label></div>-->

            </div>
          </div>
          <div v-if="item_detail.company_name.length>0 || item_detail.job_title.length>0 || item_detail.job_function.length>0 || item_detail.work_description.length>0 || item_detail.social_description.length>0 || item_detail.training_organization_name.length>0 || item_detail.training_description.length>0 || item_detail.project_description.length>0" class="title_box">
            <div class="_title">综合能力</div>
            <div class="_title_down" />
          </div>
<!--          <div class="five">-->
<!--            <div id="mychart_pie" style="margin:0px auto;width: 700px;height: 350px;position:relative;"></div>-->
<!--          </div>-->
<!--          <div v-if="item_detail.company_name.length>0 || item_detail.job_title.length>0 || item_detail.job_function.length>0 || item_detail.work_description.length>0 || item_detail.social_description.length>0 || item_detail.training_organization_name.length>0 || item_detail.training_description.length>0 || item_detail.project_description.length>0" class="title_box">-->
<!--            <div class="_title">行业背景</div>-->
<!--            <div class="_title_down" />-->
<!--          </div>-->
<!--          <div class="five">-->
<!--            <div id="mychart_radar" style="margin:0px auto;width: 700px;height: 350px;position:relative;"></div>-->
<!--          </div>-->
<!--          <div v-if="item_detail.company_name.length>0 || item_detail.job_title.length>0 || item_detail.job_function.length>0 || item_detail.work_description.length>0 || item_detail.social_description.length>0 || item_detail.training_organization_name.length>0 || item_detail.training_description.length>0 || item_detail.project_description.length>0" class="title_box">-->
<!--            <div class="_title">职能预测</div>-->
<!--            <div class="_title_down" />-->
<!--          </div>-->
<!--          <div class="five">-->
<!--            <div id="mychart_pie_huan1" style="margin:0px auto;width: 700px;height: 350px;position:relative;"></div>-->
<!--            <div id="mychart_pie_huan2" style="margin:0px auto;width: 700px;height: 350px;position:relative;"></div>-->
<!--            <div id="mychart_pie_huan3" style="margin:0px auto;width: 700px;height: 350px;position:relative;"></div>-->
<!--          </div>-->
        </div>
      </div>
    </div>
    <div class="big2" v-if="active==2">
      <div id="jiazai" style="width: 100%;height: 750px;position:relative;"></div>
    </div>
  </div>
</template>
<style lang="scss" scoped>
.mar_left_20 {
  margin-left: 20px;
}
.big1 .huaxiang ul li {
  margin-top: 15px;
}
.big1 .line_title {
  margin: 5px 10px;
  font-size: larger;
}
.big1 .line_title i{
  font-size: x-large;
}
.big1 .huaxiang .light ul{
  display: block;
  background-color: #fff;
  list-style-type: disc;
}
.big1 .light {
  width: 100%;
  //height: 200px;
  //background-color: #ff7070;
}
.blue {
  background-color: #f0f8ff;
  border-color: #5b99ff;
  color: #5b99ff;
}
.blue:hover {
  background-color: #1a91ff;
  border-color: #1a91ff;
  color: #cee8ff;
}
.blue1 {
  background-color: #f0f8ff;
  border-color: #5b99ff;
  color: #5b99ff;
}
.blue1:hover {
  background-color: #cfe8ff;
  border-color: #0061ff;
  color: #0060ff;
}
.yellow {
  background-color: #fff9eb;
  border-color: #dba200;
  color: #dba200;
}
.yellow:hover {
  background-color: #fa8d18;
  border-color: #fa8d18;
  color: #ffffff;
}
.green {
  background-color: #fff2e8;
  border-color: #ffc5a6;
  color: #fa5f2b;
}
.green:hover {
  background-color: #fa551e;
  border-color: #fa551e;
  color: #ffffff;
}
.perpal {
  background-color: #f9f0ff;
  border-color: #d5b2f7;
  color: #7735d2;
}
.perpal:hover {
  background-color: #7330d1;
  border-color: #7330d1;
  color: #ffffff;
}
.blue_title {
  color: #005fff;
}
.yellow_title {
  color: #dba200;
}
.green_title {
  color: #23a300;
}
.ggreen_title {
  color: #fa551e;
}
.gggreen_title {
  color: #005c0a;
}
.perpal_title {
  color: #8e00e8;
}
.skill1 {
  background-color: #5bdd95;
  border-color: #5bdd95;
  color: #ffffff;
}
.skill2 {
  background-color: #62cd94;
  border-color: #62cd94;
  color: #ffffff;
}
.skill3 {
  background-color: #37c277;
  border-color: #37c277;
  color: #ffffff;
}
.skill4 {
  background-color: #18bb63;
  border-color: #18bb63;
  color: #ffffff;
}
.skill4:hover , .skill3:hover , .skill2:hover , .skill1:hover  {
  background-color: #00893f;
  border-color: #00893f;
  color: #ffffff;
}
.big1 label{
  //background-color: #c25959;
  font-size: small;
  //width: 60px;
  display: inline-block;
  padding: 7px 12px;
  margin: 10px 5px;
  margin-top: 10px;
  border-style: solid;
  border-radius: 15px;
  border-width: 1px;
  text-align: right;
}
.big1 .xiugai {
  width: 80%;
}
.big1 .xiugai span input{
  font-size: small;
  width: 100%;
  height: 32px;
  line-height: 30px;
  color: gray;
}
.big1 .xiugai span{
  /*background-color: #aa1111;*/
  width: 60%;
  /*font-size: 27px;*/
  display: inline-block;
}
.big1 .xiugai .elbtn{
  width: 70px;
  height: 40px;
  font-size: small;
}

.big1 .teil{
  width: 90%;
  height: 100px;
  margin: 30px auto;
  /*background-color: #6366ff;*/
}
.big1 .six{
  width: 90%;
  margin: 0px auto;
  margin-top: 130px;
  margin-bottom: 130px;
  /*background-color: #6366ff;*/
}
.big1 .five{
  width: 90%;
  margin: 0px auto;
  margin-top: 130px;
  padding-bottom: 60px;
  /*background-color: #efff63;*/
}
.big1 .four{
  width: 90%;
  margin: 0px auto;
  margin-top: 120px;
  /*background-color: #ffac63;*/
}
.big1 .thr{
  width: 90%;
  margin: 0px auto;
  //margin-top: 100px;
  padding-top: 90px;
  /*background-color: #f88eff;*/
}
.big1 ul{
  list-style-type: none;
}
.big1 ul li{
  font-size: large;
  margin-top: 25px;
  color: #9198a5;
}
.big1 li .dian{
  color: #6873e5;
}
.big1 li span{
  color: #494949;
}
.big1 div .left{
  width: 50%;
  height: 100%;
  display: inline-block;
  left: 0px;
  /*background-color: #ff8b8b;*/
}
.big1 div .right{
  width: 50%;
  height: 100%;
  display: inline-block;
  float: right;
  /*background-color: #e5d98c;*/
}
.big1 div .botom li,ul{
  margin-top: 5px !important;
}
.big1 .title_box{
  position: absolute;
  margin-top: 20px;
  width: 100%;
  height: 100px;
  /*background-color: #af3f3f;*/
}
.big1 ._title_down{
  /*底色  设置长、宽、背景色*/
  width: 150px;
  height: 40px;
  background-color: #e7ecfb;
  position: absolute;
  left: 60px;
  top: 25px;
}
.big1 ._title{
  /*文字  设置长、宽、字号、粗细、最上方显示*/
  z-index: 999;
  width: 200px;
  height: 60px;
  font-size: xx-large;
  font-weight: normal;
  position: absolute;
  left: 40px;
  top: 10px;
}
.big1 .under_a_yes{
  display: inline-block;
  width: 100px;
  height: 5px;
  background-color: #2269ff;
  margin-left: 50px;
  margin-right: 20px;
}
.big1 .under_a_no{
  display: inline-block;
  width: 100px;
  height: 5px;
  background-color: #ffffff;
  margin-left: 50px;
  margin-right: 20px;
}
.big1 a{
  display: inline-block;
  font-size: large;
  text-align: center;
  line-height: 60px;
  width: 100px;
  height: 45px;
  //background-color: #ff6e6e;
  margin-left: 50px;
  margin-right: 20px;
}
.big1 .fenjiexian {
  border: black;
  padding: 3px;
  //margin-top: 80px;
  background: repeating-linear-gradient(135deg, #d0d0d0 0px, #09090a 1px, transparent 1px, transparent 6px);
}
.big1 .two{
  overflow: hidden;
  width: 90%;
  height: 150px;
  margin: 20px auto;
  margin-bottom: 0px;
  /*background-color: #8aff63;*/
}
.big1 .two .sinfo{
  width: 83%;
  height: 100%;
  float: right;
  /*background-color: #fff;*/
}
.big1 .two .imgg{
  width: 12%;
  display: inline-block;
}
.big1 .two .name{
  height: 70px;
  font-size: 35px;
  font-weight: bolder;
  //line-height: 70px;
  text-align: left;
  display: block;
  /*background-color: #fff;*/
}
.big1 .two .sinfos{
  margin-top: 10px;
  height: 50px;
  color: #8a919f;
  /*background-color: #ffefef;*/
}
.big1 i {
  margin-right: 10px;
}
.big1 .mar_left{
  margin-left: 20px;
}
.big1 .one{
  width: 90%;
  height: 40px;
  margin: 30px auto;
  /*background-color: #e3e3e3;*/
}
.big1 .one .zhongwenjianli{
  width: 70px;
  height: 40px;
  line-height: 40px;
  text-align: center;
  color: #3155eb;
  font-size: small;
  border-style: solid;
  border-width: medium;
  border-color: #aec6ff;
  border-radius: 10px;
  background-color: #f0f5ff;
}
.big1 .info{
  width: 60%;
  height: 95%;
  overflow: auto;
  position: absolute;
  top: 0;left:0;right:0;bottom:0;
  margin: auto;
  background-color: #ffffff;
  //margin-top: 20px;
  //left: auto;
  //margin: 0px auto;
  -webkit-box-shadow: #666 0px 0px 50px;
  -moz-box-shadow: #666 0px 0px 50px;
  box-shadow: #666 0px 0px 20px;
}

.big label{
  //background-color: #c25959;
  font-size: inherit;
  width: 80px;
  display: inline-block;
  text-align: right;
  margin: 10px 20px;
}
.big .add_info {
  width: 80%;
}
.big .add_info span input{
  font-size: small;
  width: 100%;
  height: 32px;
  line-height: 30px;
  color: gray;
}
.big .add_info span{
  /*background-color: #aa1111;*/
  width: 65%;
  font-size: 27px;
  display: inline-block;
}
.big .add_info .elbtn{
  width: 70px;
  height: 40px;
  font-size: small;
}
.add_info .biger{
  text-align: center;
  padding: 0;
  margin: 0;
  margin-left: 5px;
  width: 90px;
  height: 40px;
  font-size: small;
}
.big .ti{
  text-align: center ;
  font-size: 50px;
  font-family: 华文彩云;
  line-height: 100px;
  width: 50%;
  height: 100px;
  margin: 0 auto;
  //background-color: #5656fa;
}
.big .drag {
  width: 50%;
  height: 300px;
  border: 5px dashed;
  border-color: #a3a3a3;
  border-radius: 30px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
  .drag-icon-box {
    width: 100%;
    //height: 30px;
    text-align: center;
    font-size: large;
    line-height: 30px;
    color: #606266;
  }
  .drag-message {
    //background-color: #de5454;
    width: 100%;
    //height: 50px;
    line-height: 50px;
    text-align: center;
    margin-top: 40px;
    .drag-message-title {
      font-size: large;
      //font-size: 14px;
      color: #606266;
    }
    .drag-message-label {
      //width: 120px;
      //height: 50px;
      //height: auto;
      //background-color: #713535;
      position: relative;
      overflow: hidden;
      .drag-message-input {
        position: absolute;
        left: -100px;
        top: -100px;
        z-index: -1;
        display: none;
      }
      .drag-message-manual {
        font-size: large;
        color: #4b87ff;
        cursor: pointer;
      }
    }
  }
}
</style>

<script>
import * as axios from 'axios'
import Global from '../../global/global'


export default {
  name: 'Index',
  data() {
    return {
      obj_item: {},
      active: 1,
      active1: 0,
      // 上传建立的时候手动输入的信息
      item: {
        name_per: '',
        sex_per: '',
        age_per: '',
        political_status: '',
        address_per: '',
        email_per: '',
        phone_per: '',
        gra_school_per: '',
        school_level: '',
        highest_edu_per: '',
        degree_per: '',
        major_per: '',
        adm_date: '',
        gra_date: '',
        courses: '',
        lan_skill_per: '',
        prof_skill_per: '',
        soft_skill_per: '',
        office_skill_per: '',
        certificates: '',
        awards_per: '',
        job_title: '',
        company_name: '',
        job_function: '',
        work_description: '',
        social_description: '',
        project_description: '',
        training_organization_name: '',
        training_description: '',
        self_evaluation: '',
        candidate_job_title: '',
        path_resume: ''
      },
      // 显示的简历信息
      item_detail: {
        name_per: "郭芳天",
        age_per: 19,
        sex_per: "男",
        email_per: "service@500d.me",
        phone_per: "13800138000",
        qq: "1226442222",
        weixin: "wx1226442222",
        address_per: "上海浦东新区",
        height: "180",
        weight: "70",
        race: "汉族",
        nationality: "中国",
        marital_status: "未婚",
        highest_edu_per: "大专",
        political_status: "中共党员",
        work_year: "5年",
        adm_date: "2013.07Ж2017.07",
        gra_date: "2017.6Ж2019.6",
        gra_school_per: "上海外国语大学Ж上海大学",
        major_per: "市场营销Ж市场营销",
        school_level: "普通学校Ж普通学校",
        edu_gpa: "3.0Ж5.0",
        courses: "管理学、微观经济学、宏观经济学、管理信息系统、统计学、会计学、财务管理、市场营销、经济法、消费者行为学、国际市场营销。Ж管理学、微观经济学、宏观经济学、管理信息系统、统计学、会计学、财务管理、市场营销、经济法、消费者行为学、国际市场营销。",
        postal_code: "271000",
        work_date: "2017.12-2018.12Ж2018.12-2019.12Ж2019.12-至今",
        work_description: "负责事业部产品对外推广和宣传，制定各种整合营销的活动；;执行媒体投放计划，跟踪和监督媒体投放效果，进行数据分析撰写报告；;向市场总监提供营销支持，并协助相关的公关事宜。Ж根据公司发展情况进行战略调整，配合前端销售部门搭建销售渠道；;研究行业发展动态，定期进行市场调查,为产品更新提供建议；;负责公司部门(营运、品牌策划)制度规范，负责组织及监管市场部关于对外合作、推广策划以相关工作的落实。Ж负责协助集团旗下事业部开展各项工作，制定品牌传播方案；;结合集团与事业部发展，制定营销策略、广告策略、品牌策略和公关策略，并组织推进执行；;制定和执行媒体投放计划，跟踪和监督媒体投放效果，进行数据分析与撰写报告；",
        work_industry: "教育Ж教育Ж教育",
        company_name: "枫辰设计俱乐部Ж源清设计有限公司Ж翔汇投资控股集团",
        job_title: "市场副总监Ж市场及运营总监Ж副总监",
        project_name: "枫辰设计设计集团品牌升级发布会Ж源清设计设计商业模式发布会Ж翔汇投资控股集团6A自媒体生态圈建设",
        project_description: "集团全新品牌logo及VI上线，在多渠道进行了传播；;企业VIP客户群体逾60人，结合了线上发布、线下体验；;后续媒体报道持续升温，子品牌结合明星代言人制造话题营销，为期3周；Ж整场活动以会议+洽谈双重模式进行，首日以介绍源清内部平台资源优势，政府背景优势等为主，一对多推介会进行推广普及；;现场签署地方合作意向书，如：新疆、江西、浙江等优秀企业商户；;以中国的波尔多为宣传点，主推旗下新疆大型项目，制造营销、品牌热点。Ж本项目重构了公司现有微信企业号的功能与架构。;提高公众号的关注粉丝量的同时，对于有客户进行统一宣传，统一管理",
        project_date: "ЖЖ",
        project_position: "ЖЖ",
        social_pos: "队长Ж管理员",
        social_date: "2014.05-2017.06Ж2014.11-2017.06",
        social_cpy: "上海外国语大学Ж沟通与交流协会",
        social_description: "负责50余人团队的日常训练、选拔及团队建设；; 作为负责人对接多项商业校园行活动，如《奔跑吧兄弟》上海外国语大学站录制、《时代周末》校园行。Ж协助上海沟通协会创立上海外国语大学分部，从零开始组建初期团队；; 策划协会会员制，选拔、培训协会导师，推出一系列沟通课程。",
        train_org: "达内教育Ж一本教育Ж啥都会俱乐部",
        training_description: "学前后端Ж学语言表达艺术Ж学与人交往的礼仪",
        train_date: "2012.6--2015.9Ж2015.6--2016.3Ж2016.3--2016.9",
        self_evaluation: "拥有多年的市场管理及品牌营销经验，卓越的规划、组织、策划、方案执行和团队领导能力，积累较强的人际关系处理能力和商务谈判技巧，善于沟通，具备良好的合作关系掌控能力与市场开拓能力；;敏感的商业和市场意识，具备优秀的资源整合能力、业务推进能力； ;思维敏捷，有培训演讲能力，懂激励艺术，能带动团队的积极性；擅长协调平衡团队成员的竞争与合作的关系，善于通过培训提高团队综合能力和凝聚力。",
        awards_per: "2016年  新长城上海外国语大学自强社“优秀社员”;2015年  三下乡”社会实践活动“优秀学生”;2015年  上海外国语大学学生田径运动会10人立定跳远团体赛第三名;2015年  学生军事技能训练“优秀学员”;2015年  上海外国语大学盼盼杯烘焙食品创意大赛优秀奖;2014年  高校大学生主题征文一等奖;2014年  上海外国语大学“青春”微博文征集大赛二等奖;普通话一级甲等;通过全国计算机二级考试，熟练运用office相关软件。;熟练使用绘声绘色软件，剪辑过各种类型的电影及班级视频。;大学英语四/六级（CET-4/6），良好听说读写能力，快速浏览英语专业书籍。",
        certificates: "2016年  新长城上海外国语大学自强社“优秀社员”;2015年  三下乡”社会实践活动“优秀学生”;2015年  上海外国语大学学生田径运动会10人立定跳远团体赛第三名;2015年  学生军事技能训练“优秀学员”;2015年  上海外国语大学盼盼杯烘焙食品创意大赛优秀奖;2014年  高校大学生主题征文一等奖;2014年  上海外国语大学“青春”微博文征集大赛二等奖;普通话一级甲等;通过全国计算机二级考试，熟练运用office相关软件。;熟练使用绘声绘色软件，剪辑过各种类型的电影及班级视频。;大学英语四/六级（CET-4/6），良好听说读写能力，快速浏览英语专业书籍。",
        candidate_job_title: "销售总监",
        pred_salary: "12000--15000",
        lan_skill_per: "中文、英文",
        prof_skill_per: "javaЖpython",
        office_skill_per: "word、ppt",
        highlights: "具有博士学位，属于高层次人才Ж就读于985类型高校，具备优秀的学习能力Ж有丰富的专业技能，对前端、数据分析、公关、演讲、商务谈判等技能或工具有深入的理解Ж主修课程:管理学、微观经济学、宏观经济学、管理信息系统、统计学、会计学、财务管理、市场营销、经济法、消费者行为学、国际市场营销Ж2016年  自强社“优秀社员”、2016年  三下乡”社会实践活动“优秀学生”、2015年  田径运动会10人立定跳远团体赛第三名、2015年  学生军事技能训练“优秀学员”、2015年  盼盼杯烘焙食品创意大赛优秀奖、2014年  高校学生主题征文一等奖",
        predicted_stability: "0.7"
      },


      // item_detail: {
      //   name_per: '王菲',
      //   sex_per: '女',
      //   age_per: '22',
      //   political_status: '共青团员',
      //   address_per: '山东青岛',
      //   email_per: '1226448774@qq.com',
      //   phone_per: '17860359958',
      //   gra_school_per: '青岛科技大学',
      //   school_level: '本科',
      //   highest_edu_per: '硕士研究牲',
      //   degree_per: '工学硕士',
      //   major_per: '计算机技术',
      //   adm_date: '2022.9.1',
      //   gra_date: '2025.6.1',
      //   courses: '人工智能/深度学习/机器学习/自然语言处理/人工智能/深度学习/机器学习/自然语言处理/人工智能/深度学习/机器学习/自然语言处理/',
      //   lan_skill_per: '中文/英文/法语',
      //   prof_skill_per: 'java/vue',
      //   soft_skill_per: '唱歌跳舞',
      //   office_skill_per: 'word/ppt',
      //   certificates: '英语四级/英语六级/计算机二级/教师资格证/厨师证/机动车驾驶证/二级营养师证',
      //   awards_per: '2022年度807最美舍员',
      //   job_title: '前端工程师',
      //   company_name: '百度',
      //   job_function: '前端界面的设计与实现',
      //   work_description: '前端界面设计与实现',
      //   social_description: '三好学生下乡,社区服务',
      //   project_description: '电影管理系统',
      //   training_organization_name: '无',
      //   training_description: '无',
      //   self_evaluation: '挺好一个人,善于XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX.反正是个大好人',
      //   candidate_job_title: '前端工程师或项目经理',
      //   path_resume: 'jar/wangfei.txt'
      // },


      // 显示的画像信息
      item_info: {
        // 简历亮点
        highlights: ['拥有硕士学位', '熟练掌握英语，可以流利地进行听说读写', '有丰富的产品设计经验，对互联网产品、用户需求、产品设计、需求文档、产品研发、产品开发等技能或工具有深入的理解'],
        // 综合标签
        // per_tag: ['名企经历', '英语能力良好', '技术达标'],
        // 预测薪资
        predicted_salary: '10000-15000',
        // 预测稳定性
        predicted_stability: 0.9,
        // 人物标签
        tags: {
          basic: [
            {
              tag: '男',
              type: '性别'
            },
            {
              tag: '26到30岁',
              type: '年龄'
            },
            {
              tag: '初级',
              type: '等级'
            }
          ],
          education: [
            {
              tag: '硕士学历',
              type: '学历'
            },
            {
              tag: '软件工程',
              type: '专业'
            },
            {
              tag: '英语CET6',
              type: '专业'
            }
          ],
          professional: [
            {
              tag: '互联网/软件',
              type: '行业'
            },
            {
              tag: '产品运营',
              type: '职位名称'
            },
            {
              tag: '产品经理',
              type: '职位名称'
            },
            {
              tag: '龙头互联网企业',
              type: '公司类型'
            }
          ],
          other: [
            {
              tag: '英语',
              type: '语言'
            },
            {
              tag: '国家计算机三级',
              type: '证书'
            },
            {
              tag: 'cet6',
              type: '证书'
            }
          ],
          // 专业技能标签
          skills: [
            {
              tag: '市场调研',
              Proficiency: '0.7'
            },
            {
              tag: '产品运营',
              Proficiency: '0.9'
            },
            {
              tag: '产品经理',
              Proficiency: '0.8'
            },
            {
              tag: '龙头互联网企业',
              Proficiency: '0.4'
            },
            {
              tag: '市场调研',
              Proficiency: '0.7'
            },
            {
              tag: '产品运营',
              Proficiency: '0.6'
            },
            {
              tag: '产品经理',
              Proficiency: '0.9'
            },
            {
              tag: '龙头互联网企业',
              Proficiency: '0.8'
            },
            {
              tag: '市场调研',
              Proficiency: '0.8'
            },
            {
              tag: '产品运营',
              Proficiency: '0.8'
            },
            {
              tag: '产品经理',
              Proficiency: '0.9'
            },
            {
              tag: '龙头互联网企业',
              Proficiency: '0.9'
            },
            {
              tag: '市场调研',
              Proficiency: '0.9'
            },
            {
              tag: '产品运营',
              Proficiency: '0.8'
            },
            {
              tag: '产品经理',
              Proficiency: '0.8'
            },
            {
              tag: '龙头互联网企业',
              Proficiency: '0.8'
            },
            {
              tag: '市场调研',
              Proficiency: '0.7'
            },
            {
              tag: '产品运营',
              Proficiency: '0.7'
            },
            {
              tag: '产品经理',
              Proficiency: '0.6'
            },
            {
              tag: '龙头互联网企业',
              Proficiency: '0.6'
            },
            {
              tag: '市场调研',
              Proficiency: '0.6'
            },
            {
              tag: '产品运营',
              Proficiency: '0.6'
            },
            {
              tag: '产品经理',
              Proficiency: '0.9'
            },
            {
              tag: '龙头互联网企业',
              Proficiency: '0.5'
            },
            {
              tag: '市场调研',
              Proficiency: '0.7'
            },
            {
              tag: '产品运营',
              Proficiency: '0.9'
            },
            {
              tag: '产品经理',
              Proficiency: '0.9'
            },
            {
              tag: '龙头互联网企业',
              Proficiency: '0.9'
            }
          ]
        },
        // 综合能力
        predicted_capability: {
          '语言': 89,
          '社交能力': 99,
          '领导能力': 60,
          '工作能力': 75,
          '教育经历': 60,
          '所获奖项': 90
        },
        // 行业背景
        predicted_industry: {
          '建筑/房地产': 55,
          '咨询/法律/公务员': 15,
          '生物/制药/医疗/护理': 20,
          '教育/翻译/服务业': 30,
          '其他': 40,
          '工程师': 50,
          '运营/客服/销售/市场': 60,
          '人事/行政/高级管理': 70,
          '生产/采购/物流': 80,
          '互联网': 90,
          '产品': 99,
          '金融': 50
        },
      },
      dialogFormVisible: false,
      file: null,
      conn: Global.data().conn,
      uploadProgress: 0
    }
  },
  async mounted() {
    console.log("1")
    //  看这里
    //   处理当前对象，把特殊字符处理掉  ====  仅测试
    //   前后端联通之后  这部分操作应该在上传数据到后端返回值的时候处理。。。

    // 遍历item_detail  看看里面的数据是不是使用特殊符号链接的多条数据和一的多信息数据
    // 如果包含指定的特殊字符，那就根基他叔字符把原字符串拆分成字符串列表



    for (var i in this.item_detail) {
      this.item_detail[i] = this.item_detail[i].toString()
      console.log(i,this.item_detail[i],this.item_detail[i].length)
      // 看看当前值中有没有预先定义的字符
      if (this.item_detail[i].indexOf('Ж')!= -1) {
        // 根据字符进行拆分  变成列表
        console.log("处理之前",this.item_detail[i])
        this.item_detail[i] = this.item_detail[i].split('Ж')
        console.log("处理之后",this.item_detail[i])
      }else {
        this.item_detail[i]==""
      }
    }



    console.log("2")
    // 将 教育经历、工作经历、项目经历、社会经历、培训经历  分别重新封装到对象列表中  放在原来的返回值对象里保存

    // 教育
    var edu = []
    for (var i =0;i<this.item_detail.adm_date.length;i++){
      edu.push({
        adm_date : this.item_detail.adm_date[i],
        gra_date : this.item_detail.gra_date[i],
        gra_school_per : this.item_detail.gra_school_per[i],
        major_per : this.item_detail.major_per[i],
        edu_gpa : this.item_detail.edu_gpa[i],
        courses : this.item_detail.courses[i],
        school_level : this.item_detail.school_level[i],
      })
    }
    if (edu.length==0){
      if (this.item_detail.adm_date == "" &&this.item_detail.gra_date == "" &&this.item_detail.gra_school_per == "" &&this.item_detail.major_per == "" &&this.item_detail.school_level == "" &&this.item_detail.edu_gpa == "" &&this.item_detail.courses == ""){

      }else {
        edu.push({
          adm_date : this.item_detail.adm_date,
          gra_date : this.item_detail.gra_date,
          gra_school_per : this.item_detail.gra_school_per,
          major_per : this.item_detail.major_per,
          edu_gpa : this.item_detail.edu_gpa,
          courses : this.item_detail.courses,
          school_level : this.item_detail.school_level,
        })
      }
    }
    // 工作
    var work = []
    for (var i =0;i<this.item_detail.work_date.length;i++){
      work.push({
        work_date : this.item_detail.work_date[i],
        work_description : this.item_detail.work_description[i],
        work_industry : this.item_detail.work_industry[i],
        company_name : this.item_detail.company_name[i],
        job_title : this.item_detail.job_title[i],
      })
    }
    if (work.length==0){
      if (this.item_detail.work_date == "" &&this.item_detail.work_description == "" &&this.item_detail.work_industry == "" &&this.item_detail.company_name == "" &&this.item_detail.job_title == "" ){

      }else {
        work.push({
          work_date : this.item_detail.work_date,
          work_description : this.item_detail.work_description,
          work_industry : this.item_detail.work_industry,
          company_name : this.item_detail.company_name,
          job_title : this.item_detail.job_title,
        })
      }
    }
    // 项目
    var project = []
    for (var i =0;i<this.item_detail.project_name.length;i++){
      project.push({
        project_name : this.item_detail.project_name[i],
        project_description : this.item_detail.project_description[i],
        project_date : this.item_detail.project_date[i],
        project_position : this.item_detail.project_position[i]
      })
    }
    if (project.length==0){
      if (this.item_detail.project_name == "" &&this.item_detail.project_description == "" &&this.item_detail.project_date == "" &&this.item_detail.project_position == "" ){

      }else {
        project.push({
          project_name : this.item_detail.project_name,
          project_description : this.item_detail.project_description,
          project_date : this.item_detail.project_date,
          project_position : this.item_detail.project_position
        })
      }
    }
    // 社会
    var social = []
    for (var i =0;i<this.item_detail.social_pos.length;i++){
      social.push({
        social_pos : this.item_detail.social_pos[i],
        social_date : this.item_detail.social_date[i],
        social_cpy : this.item_detail.social_cpy[i],
        social_description : this.item_detail.social_description[i]
      })
    }
    if (social.length==0){
      if (this.item_detail.social_pos == "" &&this.item_detail.social_date == "" &&this.item_detail.social_cpy == "" &&this.item_detail.social_description == "" ){

      }else {
        social.push({
          social_pos : this.item_detail.social_pos,
          social_date : this.item_detail.social_date,
          social_cpy : this.item_detail.social_cpy,
          social_description : this.item_detail.social_description
        })
      }
    }
    // 培训
    var train = []
    for (var i =0;i<this.item_detail.train_org.length;i++){
      train.push({
        train_org : this.item_detail.train_org[i],
        training_description : this.item_detail.training_description[i],
        train_date : this.item_detail.train_date[i]
      })
    }
    if (train.length==0){
      if (this.item_detail.social_pos == "" &&this.item_detail.social_date == "" &&this.item_detail.social_cpy == "" &&this.item_detail.social_description == "" ){

      }else {
        train.push({
          train_org : this.item_detail.train_org,
          training_description : this.item_detail.training_description,
          train_date : this.item_detail.train_date
        })
      }
    }


    // 对象为空：
    // 先看全部是不是空  就不加,
    //   不是空就把所有的都加进去







    this.item_detail.edu = edu
    this.item_detail.work = work
    this.item_detail.project = project
    this.item_detail.social = social
    this.item_detail.train = train

    var base = []
    //处理基本标签： 性别、年龄、政治面貌、婚姻状况
    if (this.item_detail.sex_per != ""){
      base.push({
        tag: this.item_detail.sex_per,
        type: "性别"
      })
    }
    if (parseFloat(this.item_detail.age_per)<22){
      base.push({
        tag: "22岁以下",
        type: "年龄"
      })
    }
    else if (parseFloat(this.item_detail.age_per)<26 && parseFloat(this.item_detail.age_per)>=22){
      base.push({
        tag: "22到26岁",
        type: "年龄"
      })
    }
    else if (parseFloat(this.item_detail.age_per)>=26 && parseFloat(this.item_detail.age_per)<30){
      base.push({
        tag: "26到30岁",
        type: "年龄"
      })
    }
    else if (parseFloat(this.item_detail.age_per)>=30 && parseFloat(this.item_detail.age_per)<35){
      base.push({
        tag: "30到35岁",
        type: "年龄"
      })
    }
    else if (parseFloat(this.item_detail.age_per)>=35 && parseFloat(this.item_detail.age_per)<40){
      base.push({
        tag: "35到40岁",
        type: "年龄"
      })
    }
    else if (parseFloat(this.item_detail.age_per)>=40){
      base.push({
        tag: "40岁以上",
        type: "年龄"
      })
    }


    // console.log(this.item_detail.edu_gpa)
    // console.log(this.item_detail.edu_gpa.join('Ж'))
    // console.log(this.item_detail.edu_gpa.join('Ж').length)
    console.log('this.item_detail.edu',this.item_detail.edu)
    console.log('this.item_detail.work',this.item_detail.work)
    console.log('this.item_detail.project',this.item_detail.project)
    console.log('this.item_detail.social',this.item_detail.social)
    console.log('this.item_detail.train',this.item_detail.train)
    // 给容器绑定相关的拖拽事件
    // this.bindEvents()
    // this.initEcharts()
  },
  methods: {
    // 人物画像界面的图标显示
    initEcharts() {
      var pie = document.getElementById('mychart_pie')
      var radar = document.getElementById('mychart_radar')
      var pie_huan1 = document.getElementById('mychart_pie_huan1')
      var pie_huan2 = document.getElementById('mychart_pie_huan2')
      var pie_huan3 = document.getElementById('mychart_pie_huan3')
      // if (pie == null || radar == null || pie_huan1 == null || pie_huan2 == null || pie_huan3 == null) {
      //   return
      // }
      var Chart_pie = this.$echarts.init(pie, null, {
        renderer: 'canvas',
        useDirtyRect: false
      });
      var Chart_radar = this.$echarts.init(radar, null, {
        renderer: 'canvas',
        useDirtyRect: false
      });
      var Chart_pie_huan1 = this.$echarts.init(pie_huan1, null, {
        renderer: 'canvas',
        useDirtyRect: false
      });
      var Chart_pie_huan2 = this.$echarts.init(pie_huan2, null, {
        renderer: 'canvas',
        useDirtyRect: false
      });
      var Chart_pie_huan3 = this.$echarts.init(pie_huan3, null, {
        renderer: 'canvas',
        useDirtyRect: false
      });

      const option_pei = {
        color: [ '#7db391', '#f69e9e','#5571c6','#74c0de','#fc8553', '#9b61b4', '#c1957b', '#b60089', '#67c7b9', '#ffd57c'],
        // legend: {
        //   top: 'bottom'
        // },
        tooltip: {
          show: true,
          trigger: 'item',

        },
        toolbox: {
          show: true,
          feature: {
            mark: { show: true },
            // dataView: { show: true, readOnly: false },
            // restore: { show: true },
            // saveAsImage: { show: true }
          }
        },
        series: [
          {
            name: '综合能力',
            type: 'pie',
            radius: [30, 130],
            center: ['50%', '50%'],
            roseType: 'area',
            itemStyle: {
              borderRadius: [50,50, 10, 10]
            },
            data: []
          }
        ]
      };
      const option_radar = {
        color: ['#645bdb'],
        // legend: {
        //   top: 'bottom'
        // },
        // title: {
        //   text: 'Customized Radar Chart'
        // },
        // legend: {},
        // 鼠标经过，显示信息
        tooltip: {
          show: true,
          trigger: 'item',
        },
        // 雷达原图
        radar: [
          {
            //需要自定义    属性名
            indicator: [],
            center: ['50%', '50%'],
            radius: 120,
            // startAngle: 90,
            // splitNumber: 2,
            shape: 'circle',
            axisName: {
              formatter: '{value}',
              color: '#000000'
            },
            splitArea: {
              areaStyle: {
                // 雷达的⚪
                // color: ['#bdecfc', '#ceefff', '#3fa6fc', '#1186ff'],
                // color: ['#9fe6ff', '#59c3f6', '#3fa6fc', '#1186ff'],
                shadowColor: 'rgba(0, 0, 0, 0.2)',
                shadowBlur: 30
              }
            },
            // 圆圈线和射线
            axisLine: {
              lineStyle: {
                color: 'rgba(0,0,0,0.8)'
              }
            },
            splitLine: {
              lineStyle: {
                color: 'rgba(255,255,255,0.8)'
              }
            }
          },
        ],
        series: [
          {
            type: 'radar',
            // 选中时的样式
            emphasis: {
              lineStyle: {
                width: 6
              }
            },
            data: [
              {
                value: [],
                name: '行业分析',
                symbol: 'rect',
                symbolSize: 8,
                areaStyle: {
                  color: 'rgba(104,115,229,0.3)'
                  // color: 'rgba(255,255,255,0.8)'
                },
                // lineStyle: {
                //   type: 'dashed'
                // },
                label: {
                  normal: {
                    show: true,
                    formatter:function(params) {
                      return params.value;
                    }
                  }
                },
              }
            ]
          },
        ]
      };
      const option_pie_huan1 = {
        color: [ '#7db391', '#f69e9e','#5571c6','#74c0de','#fc8553', '#9b61b4', '#c1957b', '#b60089', '#67c7b9', '#ffd57c'],
        title: {
          text: '一级职能',
          left: 'center',
        },
        tooltip: {
          trigger: 'item'
        },
        toolbox: {
          show: true,
          feature: {
            mark: { show: true },
          }
        },
        // legend: {
        //   top: '10%',
        //   left: 'center'
        // },
        series: [
          {
            name: '一级职能预测',
            type: 'pie',
            radius: [40, 70],
            center: ['50%', '50%'],
            // avoidLabelOverlap: false,
            itemStyle: {
              borderRadius: 10,
              borderColor: '#fff',
              borderWidth: 2
            },
            // label: {
            //   show: false,
            //   position: 'center'
            // },
            emphasis: {
              label: {
                show: true,
                fontSize: 20,
                fontWeight: 'bold'
              }
            },
            data: []
          }
        ]
      }
      const option_pie_huan2 = {
        color: [ '#7db391', '#f69e9e','#5571c6','#74c0de','#fc8553', '#9b61b4', '#c1957b', '#b60089', '#67c7b9', '#ffd57c'],
        title: {
          text: '二级职能',
          left: 'center',
        },
        tooltip: {
          trigger: 'item'
        },
        toolbox: {
          show: true,
          feature: {
            mark: { show: true },
          }
        },
        // legend: {
        //   top: '10%',
        //   left: 'center'
        // },
        series: [
          {
            name: '二级职能预测',
            type: 'pie',
            radius: [40, 70],
            center: ['50%', '50%'],
            // avoidLabelOverlap: false,
            itemStyle: {
              borderRadius: 10,
              borderColor: '#fff',
              borderWidth: 2
            },
            // label: {
            //   show: false,
            //   position: 'center'
            // },
            emphasis: {
              label: {
                show: true,
                fontSize: 20,
                fontWeight: 'bold'
              }
            },
            // labelLine: {
            //   show: false
            // },
            data: []
          }
        ]
      }
      const option_pie_huan3 = {
        color: [ '#7db391', '#f69e9e','#5571c6','#74c0de','#fc8553', '#9b61b4', '#c1957b', '#b60089', '#67c7b9', '#ffd57c'],
        title: {
          text: '三级职能',
          left: 'center',
        },
        tooltip: {
          trigger: 'item'
        },
        // legend: {
        //   top: '10%',
        //   left: 'center'
        // },
        series: [
          {
            name: '三级职能预测',
            type: 'pie',
            radius: [40, 70],
            center: ['50%', '50%'],
            // avoidLabelOverlap: false,
            itemStyle: {
              borderRadius: 10,
              borderColor: '#fff',
              borderWidth: 2
            },
            // label: {
            //   show: false,
            //   position: 'center'
            // },
            emphasis: {
              label: {
                show: true,
                fontSize: 30,
                fontWeight: 'bold'
              }
            },
            // labelLine: {
            //   show: false
            // },
            data: []
          }
        ]
      }

      for (var i in this.item_info.predicted_capability){
        var nengli = {value: this.item_info.predicted_capability[i],name:i}
        option_pei.series[0].data.push(nengli)
        // console.log(i)
        // console.log(this.item_info.predicted_capability[i])
      }
      for (var i in this.item_info.predicted_industry){
        option_radar.series[0].data[0].value.push(this.item_info.predicted_industry[i])
        option_radar.radar[0].indicator.push({name: i,max:100})

        // console.log(i)
        // console.log(this.item_info.predicted_industry[i])
      }
      for (var i in this.item_info.predicted_titles){
        option_pie_huan1.series[0].data.push({value:this.item_info.predicted_titles[i].score,name:this.item_info.predicted_titles[i].title.l1})
        // console.log(this.item_info.predicted_titles[i].score)
        // console.log(this.item_info.predicted_titles[i].title.l1)
      }
      for (var i in this.item_info.predicted_titles){
        option_pie_huan2.series[0].data.push({value:this.item_info.predicted_titles[i].score,name:this.item_info.predicted_titles[i].title.l2})
        // console.log(this.item_info.predicted_titles[i].score)
        // console.log(this.item_info.predicted_titles[i].title.l1)
      }
      for (var i in this.item_info.predicted_titles){
        option_pie_huan3.series[0].data.push({value:this.item_info.predicted_titles[i].score,name:this.item_info.predicted_titles[i].title.l3})
        // console.log(this.item_info.predicted_titles[i].score)
        // console.log(this.item_info.predicted_titles[i].title.l1)
      }

      if (option_pei && typeof option_pei === 'object') {
        Chart_pie.setOption(option_pei);
      }
      Chart_pie.on('mouseover', function(params) {
        Chart_pie.dispatchAction({
          type: 'select',
          seriesName: params.name
        })
      });
      if (option_radar && typeof option_radar === 'object') {
        Chart_radar.setOption(option_radar);
      }
      Chart_radar.on('mouseover', function(params) {
        Chart_radar.dispatchAction({
          type: 'select',
          seriesName: params.name
        })
      });
      option_pie_huan1 && Chart_pie_huan1.setOption(option_pie_huan1);
      option_pie_huan2 && Chart_pie_huan2.setOption(option_pie_huan2);
      option_pie_huan3 && Chart_pie_huan3.setOption(option_pie_huan3);
    },
    // 用户上传文件之后的等待界面的画面显示，需要将当前文件进行上传，获取后端的返回值，放到当前的变量item_info中去
    initJiazai() {
      var jiazai = document.getElementById('jiazai')
      var Chart_jiazai = this.$echarts.init(jiazai, null, {
        renderer: 'canvas',
        useDirtyRect: false
      });
      Chart_jiazai.showLoading();
      //  在该函数内发送请求，获得返回值。再将loading取消然后将active设为1，返回上一个函数
      console.log('正在上传文件')
      const data = new FormData()
      data.append('resume', this.file)
      var that = this
      axios.post(this.conn + '/upload_analysis_resume',data).then(function(res) {
        console.log(res)
        if (res.status === 200) {
          // 接收数据
          that.item_info = res.data
        }
      })
    },
    // 返回上一页
    go_back() {
      this.active = 0
    },
    // 点击中文简历
    click_jianli() {
      this.active1 = 0
    },
    // 点击人物画像  因为刚刚创建dom的时候获取div值为null，为了避免无法执行init，所以需要将该函数执行多遍，一直到能够获取到dom为止
    // 使用了setInterval方法，该方法在timer实体被销毁之前，都会一直调用第一个参数中的函数，间隔时间为第二个参数。
    click_huaxiang() {
      this.timer = setInterval(this.click_huaxiang1, 1);
    },
    // 该函数被不间断地调用，直到能够获取当前文件的dom。将timer实体销毁，将不再继续调用函数。
    click_huaxiang1() {
      // if (document.getElementById('mychart_pie') != null){
      //   clearInterval(this.timer);
      // }
      clearInterval(this.timer);

      console.log('1')
      console.log(document.getElementById('mychart_pie'))
      this.active1 = 1
      // this.initEcharts()
    },
    show_jiazai(){
      console.log('11111')
      this.active=2
      this.timer = setInterval(this.jiazai, 1);
    },
    jiazai(){
      console.log(document.getElementById('jiazai'))
      if (document.getElementById('jiazai') != null){
        clearInterval(this.timer);
      }
      console.log('22222')
      this.active=2

      this.initJiazai()
    },
    submit_file() {
      // 先把文件穿给后端,接收对象的信息,在调用对象信息进行分析的方法
      //  将文件穿给后端
      // console.log('正在上传文件')
      // const data = new FormData()
      // data.append('resume', this.file)
      // var that = this
      this.show_jiazai()

      this.active = 1
      console.log('123')
      // 应该是另外一个函数，将简历上传----解析---存储---返回（全部解析结果）
      // axios.post(this.coon + '/upload_analysis_resume',data).then(function(res){
      //   // 返回值中应该有data，即当前人物的全部信息
      //   console.log(res)
      //   if (res.status === 200) {
      //         that.active = 1
      //         that.$message({
      //           message: '简历上传成功！正在解析',
      //           type: 'success'
      //         })
      //   }
      // })




      // axios.post(this.conn + '/save_upload_resume', data).then(function(res) {
      //   if (res.status === 200) {
      //     that.active = 1
      //     that.$message({
      //       message: '简历上传成功！',
      //       type: 'success'
      //     })
      //   }
      // })
      // //  接收返回的对象
      // this.start_portraits()
    },
    start_portraits() {
      //  将对象类型的信息传递到后端进行分析
      //  接受返回信息跳转界面
      // 往后端传递信息，并接受返回值 obj_item
      // obj_item = axios()....

      // this.$router.push({ path: '/portraits_detail', query: { item: this.item }})
    },
    submit_add() {
      console.log('点击了新增表单的提交,判断信息是否全面之后,将信息传递给后端')
      var flag = true
      console.log(flag)
      for (var i in this.item) {
        if (this.item[i].length === 0) {
          if (i === 'id' || i === 'school_level' || i === 'lan_skill_per' || i === 'prof_skill_per' || i === 'soft_skill_per' || i === 'office_skill_per' || i === 'certificates' || i === 'awards_per' || i === 'job_title' || i === 'company_name' || i === 'job_function' || i === 'work_description' || i === 'social_description' || i === 'project_description' || i === 'training_organization_name' || i === 'training_description' || i === 'self_evaluation' || i === 'candidate_job_title' || i === 'path_resume') {
            continue
          } else {
            flag = false
            var res = document.getElementById(i).innerText
          }
          alert('请输入' + res)
          break
        }
      }
      console.log(flag)
      // 如果当前的flag是true 那表示所有的必填选项都填写了  调用start_portraits() 将item传递到后端
      if (flag) {
        this.dialogFormVisible = false
        console.log(this.item)
        this.start_portraits()
      }
    },
    // 点击上传触发函数
    handleFileChange(e) {
      const file = e.target.files[0]
      console.log(file)
      if (!file) return
      this.file = file
    },
    bindEvents() {
      const drag = this.$refs.drag
      // 被拖动的对象进入目标容器
      drag.addEventListener('dragover', e => {
        e.preventDefault()
        drag.style.borderColor = 'red'
      })
      // 被拖动的对象离开目标容器
      drag.addEventListener('dragleave', e => {
        e.preventDefault()
        drag.style.borderColor = '#eee'
      })
      // 被拖动的对象进入目标容器，释放鼠标键
      drag.addEventListener('drop', e => {
        e.preventDefault()
        drag.style.borderColor = '#eee'
        const fileList = e.dataTransfer.files
        this.file = fileList[0]
        console.log(this.file)
      })
    }
  },

}
</script>
