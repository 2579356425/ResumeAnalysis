<template>
	<div>
		<!-- <div style="padding: 10px;"></div>
		<div style="padding: 30px;">
			<el-carousel :interval="4000" type="card" height="500px">
				<el-carousel-item v-for="item in 4" :key="item">
					<h3 class="medium">{{ item }}</h3>
				</el-carousel-item>
			</el-carousel>
		</div> -->
		<div style="padding: 10px;"></div>
		<el-tag type="success" style="font-size: larger;color: #0000EE;">系统环境：</el-tag>
		<div style="padding: 30px;box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1)">Python3.7+Node.js+CUDA10.0+pytorch1.4.0</div>
		<div style="padding: 10px;"></div>
		<el-tag type="success" style="font-size: larger;color: #0000EE;">系统架构：</el-tag>
		<div style="padding: 30px;box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1)">
			本系统采用前后端分离架构实现，前后端通过JSON格式进行交互，前后端可独立部署。前端核心框架使用Vue.js,UI使用饿了么开源的Element，前后端交互使用了axios。后端使用Flask,选择使用MySQL关系型数据库以及Neo4j图数据库。
		</div>
		<div style="padding: 10px;"></div>
		<el-tag type="success" style="font-size: larger;color: #0000EE;">开发语言：</el-tag>
		<div style="padding: 30px;box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1)">HTML+CSS+JS+Python</div>
		<div style="padding: 10px;"></div>
		<el-tag type="success" style="font-size: larger;color: #0000EE;">系统特点：</el-tag>
		<div style="padding: 30px;box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1)">
			运用NLP技术和深度学习技术，训练OCR模型，提取简历信息，并使用NER、知识图谱、语义相似度等技术对简历信息进行分析、构建人才画像、人岗匹配，并可视化。</div>
	</div>
</template>

<script>
</script>

<style>
	.el-carousel__item h3 {
		color: #475669;
		font-size: 14px;
		opacity: 0.75;
		line-height: 200px;
		margin: 0;
	}

	.el-carousel__item:nth-child(2n) {
		background-color: #00ffff;
	}

	.el-carousel__item:nth-child(2n+1) {
		background-color: #00aa7f;
	}
</style>
