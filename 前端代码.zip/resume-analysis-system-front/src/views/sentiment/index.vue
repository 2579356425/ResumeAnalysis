<template>
	<div style="padding:30px;">
		<div style="margin: 20px 0;"></div>
		<el-row :gutter="24">
			<el-col :span="24">
				<div class="grid-content bg-purple">
					<div style="margin: 0 auto;text-align: center;">
						<el-input id="extract1" style="width: 50%;" clearable placeholder="请输入客户原话"
							prefix-icon="el-icon-search" v-model="sentence"></el-input>
						<div style="margin: 50px 0;"></div>
						<div style="text-align: center;">
							<el-button type="success" @click='predictLabel()'><i class="el-icon-edit"></i>单句预测
							</el-button>
							<el-button type="primary" @click="batchPredictVisible = true"><i
									class="el-icon-upload"></i>批量预测</el-button>
							<el-button type="info" @click="outTab()"><i class="el-icon-download"></i>导出数据
							</el-button>
							<!-- 用于批量预测上传数据集 -->
							<el-dialog title="选择需测试的数据集" :visible.sync="batchPredictVisible">
								<!-- <div style="margin: 30px;"><a
										style="font-weight: bold;font-size: large;">请上传固定格式的xlxs文件</a></div>
								<div style="text-align: center;margin-top: 50px;">
									<input style="color: #000FFF;" type="file" @change="getFile($event)">
									<el-button style="margin-left: 10px;" size="small" type="primary"
										@click="batchPredict($event)">开始预测</el-button>
								</div> -->
								<el-upload class="upload-demo" drag action="#" :before-upload="beforeUpload" multiple>
									<i class="el-icon-upload"></i>
									<div class="el-upload__text">将文件拖到此处,或<em>点击上传</em></div>
								</el-upload>
								<a href="http://xk-files.qktts.asia/10%E6%9D%A1.xlsx">下载查看支持的数据集格式模板</a>
								<!-- <el-button style="margin-left: 10px;" size="small" type="primary"
									@click="batchPredict($event)">开始预测</el-button> -->
							</el-dialog>
						</div>
					</div>
					<div style="margin: 50px 0;"></div>
					<div style="margin: 0 auto;text-align: center; width: 99%;">
						<el-table v-loading="loading" id="out-table"
							:data="tableData.slice((currentPage-1)*PageSize,currentPage*PageSize)"
							:header-cell-style="{'text-align':'center'}" :cell-style="{'text-align':'center'}">
							<el-table-column type="index" width="50" label="序号">
							</el-table-column>
							<el-table-column prop="question_number" width="90" sortable label="题号">
							</el-table-column>
							<el-table-column prop="question_score" sortable width="90" label="分值">
							</el-table-column>
							<el-table-column prop="question_type" width="110" label="维修类型">
							</el-table-column>
							<el-table-column prop="sentence" label="客户原话">
							</el-table-column>
							<el-table-column prop="dynamicTags" width="350" label="标签">
								<template slot-scope="scope">
									<el-tag style="margin: 2px;" :key="tag" v-for="tag in scope.row.dynamicTags"
										closable :disable-transitions="false" @close="handleClose(scope.$index,tag)">
										{{tag}}
									</el-tag>
								</template>
							</el-table-column>
							<el-table-column fixed="right" width="195" label="操作">
								<template slot-scope="scope">
									<el-cascader filterable clearable placeholder="添加标签" style="width: 100px;"
										v-model="scope.row.selectValue" :options="options"
										:props="{ expandTrigger: 'hover' }" @change="AddSelect(scope.$index)"
										size="small">
									</el-cascader><!-- 
									<el-button style="margin-left: 5px;" @click="predictRight(scope.row)" type="success"
										size="small">正确</el-button> -->
									<el-button style="margin-left: 5px;" @click="delPredict(scope.row)" type="danger"
										size="small"><i class="el-icon-delete"></i>删除</el-button>
								</template>
							</el-table-column>
						</el-table>
					</div>
					<div style="margin: 30px 0;"></div>
					<div class="block" align="center" style="margin-top: 10px;">
						<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
							:current-page="currentPage" :page-sizes="pageSizes" :page-size="PageSize"
							layout="total, sizes, prev, pager, next, jumper" :total=total>
						</el-pagination>
					</div>
				</div>
			</el-col>
		</el-row>
	</div>
</template>
<script>
	import axios from 'axios'
	import Vue from 'vue'
	import XLSX from 'xlsx'
	import FileSaver from 'file-saver'

	export default {
		data() {
			return {
				loading: false,
				batchPredictVisible: false, //控制批量预测标签上传数据集的对话框
				sentence: '',
				options: [{
						value: 'L2.1-友好帮助',
						label: 'L2.1-友好帮助',
						children: [{
							value: '服务人员言语傲慢/讽刺车主',
							label: '服务人员言语傲慢/讽刺车主'
						}, {
							value: '服务人员说话语气生硬',
							label: '服务人员说话语气生硬'
						}, {
							value: '...',
							label: '...'
						}]
					}, {
						value: 'L2.2-服务解释',
						label: 'L2.2-服务解释',
						children: [{
							value: '未用通俗易懂语言解释',
							label: '未用通俗易懂语言解释'
						}, {
							value: '未对保养项目进行解释',
							label: '未对保养项目进行解释'
						}, {
							value: '...',
							label: '...'
						}]
					},
					{
						value: 'L2.3-专业知识',
						label: 'L2.3-专业知识',
						children: [{
							value: '对车辆使用方面的问题解释模糊/乱解释',
							label: '对车辆使用方面的问题解释模糊/乱解释'
						}, {
							value: '对维修方面的问题解释模糊/乱解释',
							label: '对维修方面的问题解释模糊/乱解释'
						}, {
							value: '...',
							label: '...'
						}]
					},
					{
						value: 'L2.4-服务承诺',
						label: 'L2.4-服务承诺',
						children: [{
							value: '无法履行答应客户的承诺',
							label: '无法履行答应客户的承诺'
						}, {
							value: '说好与客户联系但是没有联系',
							label: '说好与客户联系但是没有联系'
						}, {
							value: '...',
							label: '...'
						}]
					}, {
						value: 'L2.5-客休区',
						label: 'L2.5-客休区',
						children: [{
							value: '客休区嘈杂',
							label: '客休区嘈杂'
						}, {
							value: '没有提供午餐',
							label: '没有提供午餐'
						}, {
							value: '...',
							label: '...'
						}]
					}, {
						value: 'L2.6-等待时间',
						label: 'L2.6-等待时间',
						children: [{
							value: '进店排队等待时间太久',
							label: '进店排队等待时间太久'
						}, {
							value: '开单时间太久',
							label: '开单时间太久'
						}, {
							value: '...',
							label: '...'
						}]
					}, {
						value: 'L2.7-维保质量',
						label: 'L2.7-维保质量',
						children: [{
							value: '过度保养/过度维修',
							label: '过度保养/过度维修'
						}, {
							value: '没有发现车辆问题',
							label: '没有发现车辆问题'
						}, {
							value: '...',
							label: '...'
						}]
					}, {
						value: 'L2.8-洗车质量',
						label: 'L2.8-洗车质量',
						children: [{
							value: '车身没有洗干净',
							label: '车身没有洗干净'
						}, {
							value: '轮毂没有洗干净',
							label: '轮毂没有洗干净'
						}, {
							value: '...',
							label: '...'
						}]
					}
				],
				currentPage: 1,
				total: 0,
				pageSizes: [1, 5, 10],
				PageSize: 5,
				tableData: [{
						sentence: '没有洗车，也没有问需不需要洗车',
						dynamicTags: ['不主动为客户提供服务', '经销商没提供洗车服务'],
						question_number: 'L2.8',
						question_type: '保养',
						question_score: '7',
						selectValue: ''
					},
					{
						sentence: '没有问需不需要洗车',
						dynamicTags: ['不主动为客户提供服务'],
						question_number: 'L2.8',
						question_type: '保养',
						question_score: '8',
						selectValue: '',
					},
					{
						sentence: '车没有洗干净',
						dynamicTags: ['车身没有洗干净'],
						question_number: 'L2.8',
						question_type: '保养',
						question_score: '6',
						selectValue: '',
					}
				],
				fileList: []
			}
		},
		created() {
			this.total = this.tableData.length;
		},
		methods: {
			// 将一个sheet转成最终的excel文件的blob对象
			sheet2blob(sheet, sheetName) {
				sheetName = sheetName || 'sheet1';
				var workbook = {
					SheetNames: [sheetName],
					Sheets: {}
				};
				workbook.Sheets[sheetName] = sheet;
				// 生成excel的配置项
				var wopts = {
					bookType: 'xlsx', // 要生成的文件类型
					bookSST: false, // 是否生成Shared String Table，官方解释是，如果开启生成速度会下降，但在低版本IOS设备上有更好的兼容性
					type: 'binary'
				};
				var wbout = XLSX.write(workbook, wopts);
				var blob = new Blob([s2ab(wbout)], {
					type: "application/octet-stream"
				});
				// 字符串转ArrayBuffer
				function s2ab(s) {
					var buf = new ArrayBuffer(s.length);
					var view = new Uint8Array(buf);
					for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
					return buf;
				}
				return blob;
			},
			outTab() {
				var data2excel = [
					['客户原话', '预测的标签']
				]
				for (var i = 0; i < this.tableData.length; i++) {
					var arr = []
					arr.push(JSON.stringify(this.tableData[i].sentence))
					arr.push(JSON.stringify(this.tableData[i].dynamicTags))
					data2excel.push(arr)
				}
				console.log(data2excel);
				var sheet = XLSX.utils.aoa_to_sheet(data2excel);
				FileSaver.saveAs(this.sheet2blob(sheet), '机器标注数据.xlsx');
			},
			// 获取点击事件的文件信息
			getFile(event) {
				this.file = event.target.files[0];
				console.log((this.file));
			},
			batchPredict(event) {
				event.preventDefault();
				let formData = new FormData();
				formData.append('filename', (this.file).name)
				formData.append('file', this.file);
				let config = {
					headers: {
						'Content-Type': 'multipart/form-data'
					}
				}
				this.batchPredictVisible = false;
				this.loading = true;
				var that =
					this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下
				axios.post('http://127.0.0.1:5000/batch', formData, config).then(function(response) {
					that.loading = false;
					console.log(response.status)
					if (response.status === 200) {
						that.tableData = (JSON.parse(response.data))
						that.total = that.tableData.length
					}
				}).catch(err => {
					this.$message.error(err.message);
					console.log(err)
				})
			},
			beforeUpload(file) {
				let formData = new FormData();
				//formData.append('filename', (this.file).name)
				formData.append('file', file);
				let config = {
					headers: {
						'Content-Type': 'multipart/form-data'
					}
				}
				this.batchPredictVisible = false;
				this.loading = true;
				var that =
					this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下
				axios.post('http://106.54.170.52/batch', formData, config).then(function(response) {
					that.loading = false;
					console.log(response.status)
					if (response.status === 200) {
						that.tableData = (JSON.parse(response.data))
						that.total = that.tableData.length
						console.log(that.tableData)
					}
				}).catch(err => {
					this.$message.error(err.message);
					that.loading = false;
					console.log(err)
				})
			},
			AddSelect(index) {
				let selectValue = (this.tableData[index]).selectValue;
				console.log(selectValue)
				if (selectValue) {
					(this.tableData[index]).dynamicTags.push(selectValue[1]);
				}
				(this.tableData[index]).selectValue = '';
			},
			handleClose(index, tag) {
				console.log(index);
				(this.tableData[index]).dynamicTags.splice((this.tableData[index]).dynamicTags.indexOf(tag), 1);
			},
			handleSizeChange(val) {
				this.PageSize = val
				this.currentPage = 1
				console.log(`每页 ${val} 条`);
			},
			handleCurrentChange(val) {
				this.currentPage = val
				console.log(`当前页: ${val}`);
			},
			predictLabel() {
				let formData = new FormData();
				formData.append('sentence', this.sentence);
				let config = {
					headers: {
						'Content-Type': 'multipart/form-data'
					}
				}
				var that =
					this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
				axios.post('http://106.54.170.52/nlp', formData, config).then(function(response) {
					if (response.status === 200) {
						console.log(response.data)
						that.tableData.push(response.data)
						that.total = that.tableData.length;
						that.$notify({
							title: '成功',
							message: '预测标签为：' + (response.data).dynamicTags,
							type: 'success'
						});
					}
				}).catch(err => {
					this.$message.error(err.message);
					console.log(err)
				})
			},
			delPredict(row){
				console.log(row)
				this.tableData.pop(row)
				this.$notify({
					title: '删除成功',
					message: '原话：' + (row).sentence + '\n' + '标签：' + (row).dynamicTags + '\n',
					type: 'success'
				});
			}
		}
	}
</script>
<style>
	#out-table {
		border-radius: 5px;
		box-shadow: 0 2px 6px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .03);
	}

	#extract1 {
		border-radius: 5px;
		box-shadow: 0 2px 1px rgba(0, 0, 0, .12), 0 0 1px rgba(0, 0, 0, .03);
	}

	.default-light {
		color: yellow;
	}

	.el-row {
		margin-bottom: 20px;

		&:last-child {
			margin-bottom: 0;
		}
	}

	.el-col {
		border-radius: 4px;
	}

	.bg-purple-dark {
		background: #99a9bf;
	}

	.bg-purple {
		background: #ffffff;
	}

	.bg-purple-light {
		background: #e5e9f2;
	}

	.grid-content {
		border-radius: 4px;
		min-height: 360px;
	}

	.row-bg {
		padding: 10px 0;
		background-color: #f9fafc;
	}

	.el-tag+.el-tag {
		margin-left: 10px;
	}

	.button-new-tag {
		margin-left: 10px;
		height: 32px;
		line-height: 30px;
		padding-top: 0;
		padding-bottom: 0;
	}

	.input-new-tag {
		width: 90px;
		margin-left: 10px;
		vertical-align: bottom;
	}

	.inline-block {
		display: inline-block;
	}
</style>
