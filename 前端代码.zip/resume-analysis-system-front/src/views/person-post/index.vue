<template>
  <div style="text-align: center;" v-loading="loading" element-loading-text="正在匹配，请稍后……" element-loading-spinner="el-icon-loading" element-loading-background="rgba(0, 0, 0, 0.8)">
    <div style="margin: 0 auto;">
      <h1 style="color: rgb(0, 170, 255); text-align: center;margin-top: 30px;">以人推岗</h1>
    </div>
    <div v-if="active==0" style="width: 500px;;margin: 35px auto;">
      <el-upload
        style="margin: -15px 0 15px -10px;"
        class="upload-demo"
        ref="upload"
        drag
        action="action"
        :http-request="uploadResume"
        multiple>
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">将简历拖到此处，或<em>点击上传</em><br/>
          <div style="margin-top: 10px;">可以上传<em>图片、Word、Pdf、Html</em>文件</div>
<!--          <div style="margin-top: 10px;">可以上传<em>jpg、png、word、pdf</em>文件</div>-->
        </div>
      </el-upload>
      <el-button type="primary" class="buttonClass" @click="resumeAnalysis()">开始匹配</el-button>
    </div>
    <div class="big1" v-if="active==1" style="height: 100%;">
      <i class="el-icon-back" style="display: inline-block;font-size: 40px;float:left;margin-top: 0px;margin-left: 80px" @click="go_back()" />
        <div class="info">
          <div class="two">
            <div class="sinfo">
              <div v-if="item_detail.name_per!=''" class="name" style="display: inline-block; margin: -10px auto;">{{ item_detail.name_per }}</div>
              <div class="sinfos">
                <i v-if="item_detail.age_per.toString()!=''" class="el-icon-user-solid" />{{ item_detail.age_per }}
                <i v-if="item_detail.sex_per.length!=''" class="mar_left el-icon-s-opportunity" />{{ item_detail.sex_per }}
                <i v-if="item_detail.email_per.length!=''" class="mar_left el-icon-s-comment" />{{ item_detail.email_per }}
                <div style="margin: 15px;"></div>
                <i v-if="item_detail.phone_per.length!=''" class="mar_left el-icon-phone" />{{ item_detail.phone_per }}
                <i v-if="item_detail.highest_edu_per!=''" class="mar_left el-icon-s-cooperation" />{{ item_detail.highest_edu_per }}
              </div>
            </div>
          </div>
          <hr class="fenjiexian">
          <div v-if="item_detail.name_per!='' || item_detail.age_per.toString()!='' || item_detail.phone_per!='' || item_detail.qq!='' || item_detail.height!='' || item_detail.race!='' || item_detail.nationality!='' || item_detail.highest_edu_per!='' || item_detail.political_status!='' || item_detail.sex_per!='' || item_detail.weixin!='' || item_detail.weight!='' || item_detail.marital_status!='' || item_detail.work_year!='' || item_detail.address_per!='' || item_detail.email_per!=''" class="title_box">
            <div class="_title el-icon-user-solid" style="margin-left: -20px;margin-top: 185px;"> 基本信息</div>
            <div class="_title_down" />
          </div>
          <div v-if="item_detail.name_per!='' || item_detail.age_per.toString()!='' || item_detail.phone_per!='' || item_detail.qq!='' || item_detail.height!='' || item_detail.race!='' || item_detail.nationality!='' || item_detail.highest_edu_per!='' || item_detail.political_status!='' || item_detail.sex_per!='' || item_detail.weixin!='' || item_detail.weight!='' || item_detail.marital_status!='' || item_detail.work_year!='' || item_detail.address_per!='' || item_detail.email_per!=''"  class="thr">
            <div v-if="item_detail.name_per!='' || item_detail.age_per.toString()!='' || item_detail.phone_per!='' || item_detail.qq!='' || item_detail.height!='' || item_detail.race!='' || item_detail.nationality!='' || item_detail.highest_edu_per!='' || item_detail.political_status!=''" class="left">
              <ul style="float: left;">
                <li v-if="item_detail.phone_per!=''" style="float: left;"><span class="dian">●</span> 联系方式：<span>{{ item_detail.phone_per }}</span></li><br/>
                <li v-if="item_detail.qq!=''" style="float: left;"><span class="dian">●</span> QQ：<span>{{ item_detail.qq }}</span></li><br/>
                <li v-if="item_detail.highest_edu_per!=''" style="float: left;"><span class="dian">●</span> 学历：<span>{{ item_detail.highest_edu_per }}</span></li><br/>
                <li v-if="item_detail.sex_per!=''" style="float: left;"><span class="dian">●</span> 性别：<span>{{ item_detail.sex_per }}</span></li><br/>
                <li v-if="item_detail.address_per!=''" style="float: left;"><span class="dian">●</span> 住址：<span>{{ item_detail.address_per }}</span></li><br/>
                <li v-if="item_detail.email_per!=''" style="float: left;"><span class="dian">●</span> 邮箱：<span>{{ item_detail.email_per }}</span></li><br/>
                <li v-if="item_detail.weixin!=''" style="float: left;"><span class="dian">●</span> 微信：<span>{{ item_detail.weixin }}</span></li><br/>
                <li v-if="item_detail.work_year!=''" style="float: left;"><span class="dian">●</span> 工作经验：<span>{{ item_detail.work_year }}</span></li><br/>
              </ul>
            </div>
          </div>
          <div v-if="item_detail.edu!= ''" style="width: 100%;">
            <div class="_title el-icon-s-management" style="margin-left: -20px;margin-top: 450px;"> 教育背景</div>
            <div class="_title_down" />
          </div>
          <div v-if="item_detail.edu!=''" class="four">
            <div v-for="(item,index) in item_detail.edu" style="margin-bottom: 0px">
              <div style="font-size: larger;color: #000000 ;font-weight: bolder;float: left;margin-left: 80px;margin-top: 60px;">{{ item.gra_school_per }}</div>
              <ul>
                <li v-if="item.adm_date!=''" style="float: left;"><span class="dian">●</span> 时间：<span>{{ item.adm_date }} - {{ item.gra_date }}</span></li><br/>
                <li v-if="item.major_per!=''" style="float: left;"><span class="dian">●</span> 专业：<span>{{ item.major_per }}</span></li><br/>
                <li v-if="item.edu_gpa.toString()!=''" style="float: left;"><span class="dian">●</span> 绩点：<span>{{ item.edu_gpa }}</span></li><br/>
              </ul>
            </div>
          </div>
          <div v-if="item_detail.work!=''">
            <div class="_title el-icon-s-cooperation" style="margin-top: 850px;margin-left: -20px;"> 工作经历</div>
            <div class="_title_down" />
          </div>
          <div v-if="item_detail.work!=''" class="four">
            <div v-for="(item,index) in item_detail.work">
              <div style="font-size: larger;color: #000000 ;font-weight: bolder;float: left;margin-left: 60px;margin-top: 90px;">{{ item.company_name }}</div>
              <ul>
                <li style="float: left;" v-if="item.work_date!=''">
                  <span style="float: left;" class="dian">●</span>
                  <span style="float: left;color: #9198a5;left: 18px">工作时间：</span>
                  <div style="float: left;color: #494949;font-size: 16px">{{ item.work_date }}</div>
                </li>
                <li style="float: left;" v-if="item.job_title!=''">
                  <span style="float: left;" class="dian">●</span>
                  <span style="float: left;color: #9198a5;left: 18px">岗位名称：</span>
                  <div style="float: left;color: #494949;font-size: 16px">{{ item.job_title }}</div>
                </li>
                <li style="float: left;" v-if="item.work_description!=''">
                  <span style="float: left;" class="dian">●</span>
                  <span style="float: left;color: #9198a5;left: 18px">工作描述：</span>
                  <div style="float: left;color: #494949;font-size: 16px">{{ item.work_description }}</div>
                </li>
              </ul>
            </div>
          </div>
          <div v-if="item_detail.project!=''">
            <div class="_title el-icon-s-cooperation" style="margin-top: 1500px;margin-left: -20px;"> 项目经历</div>
            <div class="_title_down" />
          </div>
          <div v-if="item_detail.project!=''" class="five">
            <div v-for="(item,index) in item_detail.project" >
              <div style="font-size: larger;color: #000000 ;font-weight: bolder;float: left;margin-left: 60px;margin-top: 90px;">{{ item.project_name }}</div>
              <ul>
                <li style="float: left;" v-if="item.project_position!=''">
                  <span  style="float: left;" class="dian">●</span>
                  <span style="float: left;color: #9198a5;left: 18px">职位：</span>
                  <div style="float: left;color: #494949;font-size: 16px">{{ item.project_position }}</div>
                </li>
                <li style="float: left;" v-if="item.project_date!=''">
                  <span  style="float: left;" class="dian">●</span>
                  <span style="float: left;color: #9198a5;left: 18px">项目时间：</span>
                  <div style="float: left;color: #494949;font-size: 16px">{{ item.project_date }}</div>
                </li>
                <li style="float: left;" v-if="item.project_description!=''">
                  <span style="float: left;" class="dian">●</span>
                  <span style="float: left;color: #9198a5;left: 18px">项目描述：</span>
                  <div style="float: left;color: #494949;font-size: 16px">{{ item.project_description }}</div>
                </li>
              </ul>
            </div>
          </div>
        <!-- <div class="title_box" v-if="item_detail.prof_skill_per!='' || item_detail.lan_skill_per!='' || item_detail.office_skill_per!='' ||item_detail.awards_per!='' || item_detail.certificates!='' || item_detail.self_evaluation!=''">
          <div class="_title">其他信息</div>
          <div class="_title_down" />
        </div>

      <div class="six" v-if="item_detail.prof_skill_per!='' || item_detail.lan_skill_per!='' || item_detail.office_skill_per!='' ||item_detail.awards_per!='' || item_detail.certificates!='' || item_detail.self_evaluation!=''">
        <ul>
          <li style="position: relative" v-if="item_detail.prof_skill_per!=''">
            <span style="position: absolute" class="dian">●</span>
            <span style="color: #9198a5;position: absolute;left: 18px">专业技能：</span>
            <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
              <span v-if="typeof item_detail.prof_skill_per == 'string'">{{ item_detail.prof_skill_per }}</span>
              <span v-if="typeof item_detail.prof_skill_per != 'string'">{{ item_detail.prof_skill_per.join('、') }}</span>
            </div>
          </li>
          <li style="position: relative" v-if="item_detail.lan_skill_per!=''">
            <span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">语言技能：</span>
            <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
              <span v-if="typeof item_detail.lan_skill_per == 'string'">{{ item_detail.lan_skill_per }}</span>
              <span v-if="typeof item_detail.lan_skill_per != 'string'">{{ item_detail.lan_skill_per.join('、') }}</span>
            </div>
          </li>
          <li style="position: relative" v-if="item_detail.office_skill_per!=''">
            <span style="position: absolute" class="dian">●</span>
            <span style="color: #9198a5;position: absolute;left: 18px">办公技能：</span>
            <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
              <span v-if="typeof item_detail.office_skill_per == 'string'">{{ item_detail.office_skill_per }}</span>
              <span v-if="typeof item_detail.office_skill_per != 'string'">{{ item_detail.office_skill_per.join('、') }}</span>
            </div>
          </li>
          <li style="position: relative" v-if="item_detail.awards_per!=''">
            <span style="position: absolute" class="dian">●</span>
            <span style="color: #9198a5;position: absolute;left: 18px">所获奖项：</span>
            <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
              <span v-if="typeof item_detail.awards_per == 'string'">{{ item_detail.awards_per }}</span>
              <span v-if="typeof item_detail.awards_per != 'string'">{{ item_detail.awards_per.join('、') }}</span>
            </div>
          </li>
          <li style="position: relative" v-if="item_detail.certificates!=''">
            <span style="position: absolute" class="dian">●</span>
            <span style="color: #9198a5;position: absolute;left: 18px">所获证书：</span>
            <div v-if="typeof item_detail.certificates != 'string'">
              <div v-for="(item,i) in item_detail.certificates" style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                {{i+1}}、{{ item }}
              </div>
            </div>
            <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
              <span v-if="typeof item_detail.certificates == 'string'">{{ item_detail.certificates }}</span>
            </div>
          </li>
          <li style="position: relative" v-if="item_detail.self_evaluation!=''">
            <span style="position: absolute" class="dian">●</span>
            <span style="color: #9198a5;position: absolute;left: 18px">自我描述：</span>
            <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
              {{ item_detail.self_evaluation }}
            </div>
          </li>
        </ul>
      </div> -->
      </div>

    </div>

    <div v-if="active==1" style="width: 490px;height: 500px;margin-left: 610px;margin-top: -10px;overflow-y: scroll;   border-radius: 4px;
    -webkit-box-shadow: 0 50px 100px rgba(50,50,93,.1), 0 15px 35px rgba(50,50,93,.15), 0 5px 15px rgba(0,0,0,.1);
    box-shadow: 0 50px 100px rgba(50,50,93,.1), 0 15px 35px rgba(50,50,93,.15), 0 5px 15px rgba(0,0,0,.1);">
        <div style="width: 465px;margin: 0px auto" v-for="(item,index) in postData" :key="index"  @click="movetodetail(item)">
          <el-card class="box-card" style="margin: 3px;">
            <div>
              <!-- <div style="float: left;height: 23px;"><b style="color: #40586f">岗位名称：</b><a style="font-size: 20px;">{{ item.job_name }}</a></div><br/> -->
              <!-- <span v-if="item.phone!=''" style="float: left;"><b style="color: #40586f">联系电话：</b><a>{{ item.phone }}</a></span><br/> -->
              <div style="float: left;"><b style="color: #000000;font-size: 26px;">{{ item.job_name }}</b></div><br/><br/>
              <span v-if="item.publish_time!=''" style="float: left;margin-top: 5px;"><b style="color: #3d66b8;">发布时间：</b><a>{{ item.publish_time }}</a></span><br/><br/>
              <span v-if="item.job_function!=''" style="float: left;margin-top: 5px;"><b style="color: #3d66b8;">工作职能：</b><a>{{ item.job_function }}</a></span><br/>
              <span v-if="item.job_requirement!=''" style="float: left;margin-top: 5px;"><b style="color: #3d66b8;">任职要求：</b><a>{{ item.job_requirement }}</a></span>
            </div>
          </el-card>
        </div>
      </div>
  </div>

</template>


<script>
import * as axios from 'axios'
import Vue from 'vue'
import Global from '../../global/global'
export default {
  name: 'Index',
  data() {
    return {
      active: 0,
      resumeUrl:'',
      resumeName:'',
      item_detail:{},
      loading: false,
      postData:[],
    }
  },
  methods: {
    //上传简历到后端
    async uploadResume(params){
      let formData = new FormData()
      formData.append("resume", params.file)
      var that = this;
      const res = await axios.post("http://81.68.169.78:5000/save_upload_resume2", formData).then(function(response) {
					console.log(response)
					if (response.status === 200) {
						that.$notify({
							title: '成功',
							message: params.file.name + '上传成功!',
							type: 'success'
						});
            that.resumeUrl = response.data
            that.resumeName = response.data.split("/")[response.data.split("/").length-1]
            console.log(that.resumeUrl)
            console.log(that.resumeName)
					}
				}).catch(err => {
					this.$message.error(err.message);
					console.log(err)
				})
    },
    //上传简历后 先解析
    resumeAnalysis(){
      axios.post('http://81.68.169.78:5000/update_person_post', formData, config).then(function(response) {
      }).catch(err => {
        that.$message.error(err.message);
        console.log(err)
      })
      this.loading = true
      console.log("this.resumeName:", this.resumeName)
      let formData = new FormData();
      formData.append('resumeUrl', this.resumeUrl);
      formData.append('resumeName', this.resumeName)
      console.log("formData.resumeName:", formData.get('resumeName'))
      formData.append('username', Global.username)
      let config = {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }
      //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
      var that = this;
      axios.post('http://81.68.169.78:5000/resume_analysis', formData, config).then(function(res) {
        console.log('后端返回:', res)
        console.log(res.data[res.data.length-1])
        if (res.status === 200) {
          that.personToPost(res.data[res.data.length-1])
          var highest_edu = ""
          if(res.data[res.data.length-1][14] === ""){
            highest_edu = "未知"
          }else{
            highest_edu = res.data[res.data.length-1][14]
          }
          var age = ''
          if(res.data[res.data.length-1][4] == -1){
            age = '未知'
          }else{
            age = res.data[res.data.length-1][4]
          }
          var name = ''
          if(res.data[res.data.length-1][1] == ""){
            name = '未知'
          }else{
            name = res.data[res.data.length-1][1]
          }
          that.item_detail['id'] = res.data[res.data.length-1][0] + '',
          that.item_detail['name_per'] = name,
          that.item_detail['sex_per'] = res.data[res.data.length-1][2] + '',
          that.item_detail['email_per'] = res.data[res.data.length-1][3] + '',
          that.item_detail['age_per'] = age,
          that.item_detail['phone_per'] = res.data[res.data.length-1][5] + '',
          that.item_detail['qq'] = res.data[res.data.length-1][6] + '',
          that.item_detail['weixin'] = res.data[res.data.length-1][7] + '',
          that.item_detail['address_per'] = res.data[res.data.length-1][8] + '',
          that.item_detail['height'] = res.data[res.data.length-1][9] + '',
          that.item_detail['weight'] = res.data[res.data.length-1][10] + '',
          that.item_detail['race'] = res.data[res.data.length-1][11] + '',
          that.item_detail['nationality'] = res.data[res.data.length-1][12] + '',
          that.item_detail['marital_status'] = res.data[res.data.length-1][13] + '',
          that.item_detail['highest_edu_per'] = highest_edu,
          that.item_detail['adm_date'] = res.data[res.data.length-1][15] + '',
          that.item_detail['gra_date'] = res.data[res.data.length-1][16] + '',
          that.item_detail['gra_school_per'] = res.data[res.data.length-1][17] + '',
          that.item_detail['major_per'] = res.data[res.data.length-1][18] + '',
          that.item_detail['lan_skill_per'] = res.data[res.data.length-1][19] + '',
          that.item_detail['prof_skill_per'] = res.data[res.data.length-1][20] + '',
          that.item_detail['office_skill_per'] = res.data[res.data.length-1][21] + '',
          that.item_detail['awards_per'] = res.data[res.data.length-1][22] + '',
          that.item_detail['certificates'] = res.data[res.data.length-1][23] + '',
          that.item_detail['political_status'] = res.data[res.data.length-1][24] + '',
          that.item_detail['postal_code'] = res.data[res.data.length-1][25] + '',
          that.item_detail['school_level'] = res.data[res.data.length-1][26] + '',
          that.item_detail['courses'] = res.data[res.data.length-1][27] + '',
          that.item_detail['edu_gpa'] = res.data[res.data.length-1][28] + '',
          that.item_detail['job_title'] = res.data[res.data.length-1][29] + '',
          that.item_detail['company_name'] = res.data[res.data.length-1][30] + '',
          that.item_detail['work_date'] = res.data[res.data.length-1][31] + '',
          that.item_detail['work_description'] = res.data[res.data.length-1][32] + '',
          that.item_detail['work_industry'] = res.data[res.data.length-1][33] + '',
          that.item_detail['work_year'] = res.data[res.data.length-1][34] + '',
          that.item_detail['project_name'] = res.data[res.data.length-1][35] + '',
          that.item_detail['project_position'] = res.data[res.data.length-1][36] + '',
          that.item_detail['project_date'] = res.data[res.data.length-1][37] + '',
          that.item_detail['project_description'] = res.data[res.data.length-1][38] + '',
          that.item_detail['social_pos'] = res.data[res.data.length-1][39] + '',
          that.item_detail['social_description'] = res.data[res.data.length-1][40] + '',
          that.item_detail['social_cpy'] = res.data[res.data.length-1][41] + '',
          that.item_detail['social_date'] = res.data[res.data.length-1][42] + '',
          that.item_detail['train_org'] = res.data[res.data.length-1][43] + '',
          that.item_detail['training_description'] = res.data[res.data.length-1][44] + '',
          that.item_detail['train_date'] = res.data[res.data.length-1][45] + '',
          that.item_detail['self_evaluation'] = res.data[res.data.length-1][46] + '',
          that.item_detail['candidate_job_title'] = res.data[res.data.length-1][47] + '',
          that.item_detail['parsing_time'] = res.data[res.data.length-1][48] + '',
          that.item_detail['resume_type'] = res.data[res.data.length-1][49] + '',
          that.item_detail['resume_name'] = res.data[res.data.length-1][50] + '',
          that.item_detail['path_resume'] = res.data[res.data.length-1][51] + '',
          that.item_detail['avatar_url'] = res.data[res.data.length-1][52] + '',
          that.item_detail['pred_salary'] = res.data[res.data.length-1][53] + '',
          that.item_detail['pos_tags'] = res.data[res.data.length-1][54] + '',
          that.item_detail['skills_tags'] = res.data[res.data.length-1][55] + '',
          that.item_detail['username'] = res.data[res.data.length-1][56] + '',
          that.data_processing(that.item_detail)
          console.log("item_detail:", that.item_detail)
        }
      }).catch(err => {
        this.$message.error(err.message);
        console.log(err)
      })
    },
    //简历解析完，开始人岗匹配
    personToPost(resumeData){
      let formData = new FormData();
      formData.append('resumeId', resumeData[0])
      formData.append('username', Global.username)
      let config = {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }
      //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
      var that = this;
      axios.post('http://81.68.169.78:5000/select_postPer', formData, config).then(function(res) {
        console.log('人岗匹配完成返回数据:', res.data)
        if (res.status === 200) {
          for (var i = 0; i < res.data.length; i++) {
            // console.log("res.data[i][0]:", res.data[i][0])
            var date = new Date(res.data[i][0][26]);
            var y = date.getFullYear();
            var m = date.getMonth() + 1;
            m = m < 10 ? ('0' + m) : m;
            var d = date.getDate();
            d = d < 10 ? ('0' + d) : d;
            var h = date.getHours();
            var minute = date.getMinutes();
            minute = minute < 10 ? ('0' + minute) : minute;
            let time = y + '-' + m + '-' + d+' '+h+':'+minute;
            that.postData.push({
              job_name: res.data[i][0][1],
              job_function: res.data[i][0][2],
              phone: res.data[i][0][25],
              publish_time: time,
              job_requirement: res.data[i][0][27]
            })
            // that.chuli_job_function()
            // that.chuli_job_requirement()
          }
          console.log("postData:", that.postData)
          that.active = 1
          that.loading = false
        }
      }).catch(err => {
        that.$message.error(err.message);
        console.log(err)
      })

    },
     // 列表数据处理
     data_processing(item){
      for (var i in item) {
        // console.log(i)
        if (i ==='work_year'){
          if(item[i] != ''){
            item[i] = parseInt(item[i])
            item[i] = item[i]+'年'
          }
        }
        if (i ==='age_per'){
          if(item[i] == '-1'){
            console.log(item[i])
            item[i] = ''
            console.log(item[i])
          }
        }
        // console.log('item[i]:', item[i].toString().type())
        if (item[i].toString().indexOf('Ж')!= -1) {
          item[i] = item[i].split('Ж')
        }
      }

      // 教育
      var edu = []
      //遍历列表
      if (typeof (item.adm_date) != "string"){
        for (var i =0;i<item.adm_date.length;i++){
          edu.push({
            adm_date : item.adm_date[i],
            gra_date : item.gra_date[i],
            gra_school_per : item.gra_school_per[i],
            major_per : item.major_per[i],
            edu_gpa : item.edu_gpa[i],
            courses : item.courses[i],
            school_level : item.school_level[i],
          })
        }
      }

      if (edu.length==0){
        if (item.adm_date == "" &&item.gra_date == "" &&item.gra_school_per == "" &&item.major_per == "" &&item.school_level == "" &&item.edu_gpa == "" &&item.courses == ""){

        }else {
          edu.push({
            adm_date : item.adm_date,
            gra_date : item.gra_date,
            gra_school_per : item.gra_school_per,
            major_per : item.major_per,
            edu_gpa : item.edu_gpa,
            courses : item.courses,
            school_level : item.school_level,
          })
        }
      }
      // 工作
      var work = []
      if (typeof (item.work_date) != "string") {
        for (var i = 0; i < item.work_date.length; i++) {
          work.push({
            work_date: item.work_date[i],
            work_description: item.work_description[i],
            // work_industry: item.work_industry[i]+'',
            company_name: item.company_name[i],
            job_title: item.job_title[i],
          })
        }
      }
      if (work.length==0){
        if (item.work_date == "" &&item.work_description == "" &&item.work_industry == "" &&item.company_name == "" &&item.job_title == "" ){

        }else {
          work.push({
            work_date : item.work_date,
            work_description : item.work_description,
            work_industry : item.work_industry,
            company_name : item.company_name,
            job_title : item.job_title,
          })
        }
      }
      // 项目
      var project = []
      if (typeof (item.project_name) != "string") {
        for (var i = 0; i < item.project_name.length; i++) {
          project.push({
            project_name: item.project_name[i],
            project_description: item.project_description[i],
            project_date: item.project_date[i],
            project_position: item.project_position[i]
          })
        }
      }
      if (project.length==0){
        if (item.project_name == "" &&item.project_description == "" &&item.project_date == "" &&item.project_position == "" ){

        }else {
          project.push({
            project_name : item.project_name,
            project_description : item.project_description,
            project_date : item.project_date,
            project_position : item.project_position
          })
        }
      }
      // 社会
      var social = []
      if (typeof (item.social_pos) != "string") {
        for (var i = 0; i < item.social_pos.length; i++) {
          social.push({
            social_pos: item.social_pos[i],
            social_date: item.social_date[i],
            social_cpy: item.social_cpy[i],
            social_description: item.social_description[i]
          })
        }
      }
      if (social.length==0){
        if (item.social_pos == "" &&item.social_date == "" &&item.social_cpy == "" &&item.social_description == "" ){

        }else {
          social.push({
            social_pos : item.social_pos,
            social_date : item.social_date,
            social_cpy : item.social_cpy,
            social_description : item.social_description
          })
        }
      }
      // 培训
      var train = []
      if (typeof (item.train_org) != "string") {
        for (var i = 0; i < item.train_org.length; i++) {
          train.push({
            train_org: item.train_org[i],
            training_description: item.training_description[i],
            train_date: item.train_date[i]
          })
        }
      }
      if (train.length==0){
        if (item.social_pos == "" &&item.social_date == "" &&item.social_cpy == "" &&item.social_description == "" ){

        }else {
          train.push({
            train_org : item.train_org,
            training_description : item.training_description,
            train_date : item.train_date
          })
        }
      }
      item.edu = edu
      item.work = work
      item.project = project
      item.social = social
      item.train = train
    },
        // 返回解析初始页面
    go_back() {
      this.active = 0
      this.item_detail = {},
      this.loading = false,
      this.postData = []
    },
    // 添加一个分号
    add_fenhao(str){
      console.log('；；；添加分号接受到的字符串是：：',str)
      var char = str.substring(str.length-1)
      if (this.chars.indexOf(char)==-1){
        // 最后一个字符不是 标点符号    -----  添加一个分号
        str = str+'；'
      }else {
        //  最后一个字符是标点符号
        str = str.substring(0,str.length-1)
        str = str+'；'
      }
      console.log('添加完变成了：：',str)
      return str
    },
    // 添加一个分号
    add_juhao(str){
      console.log('。。。添加句号接受到的字符串是：：',str)
      var char = str.substring(str.length-1)
      if (this.chars.indexOf(char)==-1){
        // 最后一个字符不是 标点符号    -----  添加一个分号
        str = str+'。'
      }else {
        //  最后一个字符是标点符号
        str = str.substring(0,str.length-1)
        str = str+'。'
      }
      console.log('添加完变成了：：',str)
      return str
    },
    // 将job_functioc处理成列表
    chuli_job_function(){
      if (this.tem_detail.job_function==''){
        console.log("job_function是空字符串，不用处理")
      }else {
        var str = this.tem_detail.job_function
        console.log('一开始的字符串为：：',str)
        var jieguo = []
        for (var i = 2; i <= 20 ; i++) {
          var temp = []
          if (str.indexOf(','+i)!=-1){
            temp =  str.split(','+i)
          }else if (str.indexOf('。'+i)!=-1){
            temp =  str.split('。'+i)
          }else if (str.indexOf('；'+i)!=-1){
            temp =  str.split('；'+i)
          }else if (str.indexOf(';'+i)!=-1){
            temp =  str.split(';'+i)
          }else if (str.indexOf(i+'.')!=-1){
            temp =  str.split(i+'.')
            temp[1] = '.'+temp[1]
          }else if (str.indexOf(i+'、')!=-1){
            temp =  str.split(i+'、')
            temp[1] = '、'+temp[1]
          }else {
            temp =  str.split(i)
          }

          // console.log(temp)
          if (temp.length==2){
          //  正好被分成两个
            jieguo.push(this.add_fenhao(temp[0]))
            // jieguo.push(temp[0])
            str = i + temp[1]
          }else if (temp.length==1){
            str = temp[0]
          }
          if (i==20){
            jieguo.push(this.add_juhao(temp[0]))
          }
        }
        console.log(jieguo)
        this.item_detail.job_function = jieguo
      }
    },
    // 将job_requirement处理成列表
    chuli_job_requirement(){
      if (this.item_detail.job_requirement==''){
        console.log("job_requirement是空字符串，不用处理")
      }else {
        var str = this.item_detail.job_requirement
        console.log('一开始的字符串为：：',str)
        var jieguo = []
        for (var i = 2; i <= 20 ; i++) {
          var temp = []
          if (str.indexOf(','+i)!=-1){
            temp =  str.split(','+i)
          }else if (str.indexOf('。'+i)!=-1){
            temp =  str.split('。'+i)
          }else if (str.indexOf('；'+i)!=-1){
            temp =  str.split('；'+i)
          }else if (str.indexOf(';'+i)!=-1){
            temp =  str.split(';'+i)
          }else if (str.indexOf(i+'.')!=-1){
            temp =  str.split(i+'.')
            temp[1] = '.'+temp[1]
          }else if (str.indexOf(i+'、')!=-1){
            temp =  str.split(i+'、')
            temp[1] = '、'+temp[1]
          }else {
            temp =  str.split(i)
          }

          // console.log(temp)
          if (temp.length==2){
            //  正好被分成两个
            jieguo.push(this.add_fenhao(temp[0]))
            // jieguo.push(temp[0])
            str = i + temp[1]
          }else if (temp.length==1){
            str = temp[0]
          }
          if (i==20){
            jieguo.push(this.add_juhao(temp[0]))
          }
        }
        console.log(jieguo)
        this.item_detail.job_requirement = jieguo
      }
    },
  }
}
</script>
<style>
.big1 lable{
  /*background-color: #c25959;*/
  font-size: small;
  width: 60px;
  display: inline-block;
  text-align: right;
  margin: 10px 20px;
}
.big1 .xiugai {
  width: 80%;
}
.big1 .xiugai span input{
  font-size: small;
  width: 100%;
  height: 32px;
  line-height: 30px;
  color: gray;
}
.big1 .xiugai span{
  /*background-color: #aa1111;*/
  width: 60%;
  /*font-size: 27px;*/
  display: inline-block;
}
.big1 .xiugai .elbtn{
  width: 70px;
  height: 40px;
  font-size: small;
}

.big1 .teil{
  width: 90%;
  height: 100px;
  margin: 30px auto;
  /*background-color: #6366ff;*/
}
.big1 .six{
  width: 90%;
  margin: 0px auto;
  margin-top: 130px;
  /*background-color: #6366ff;*/
}
.big1 .five{
  width: 380px;
  /* margin: 0px auto;
  margin-top: 130px; */
}
.big1 .four{
  width: 320px;
  /* height: 250px; */
  /* margin: 100px auto; */
  /* margin-top: 100px; */
  /*background-color: #ffac63;*/
}
.big1 .thr{
  width: 100%;
  height: 200px;
  margin: 50px auto;
  /* margin-top: 100px; */
  /*background-color: #f88eff;*/
}
.big1 ul{
  list-style-type: none;
}
.big1 ul li{
  font-size: large;
  margin-top: 25px;
  color: #9198a5;
}
.big li div {
  font-size: 16px !important;
}
.big1 li .dian{
  color: #6873e5;
}
.big1 li span{
  color: #494949;
  /*line-height: 40px;*/
  font-size: 16px;
}
.big1 div .left{
  /* position: ; */
  width: 380px;
  height: 250px;
  /* display: inline-block; */
  /* left: 0px; */
  /* background-color: #ff8b8b; */
}
.big1 div .right{
  width: 50%;
  height: 100%;
  display: inline-block;
  float: right;
  /*background-color: #e5d98c;*/
}
.big1 div .botom li,ul{
  margin-top: 5px !important;
}
/* .big1 .title_box{
  position: absolute;
  margin-left: -20px;
  width: 100%;
  height: 250px;
} */
.big1 ._title_down{
  /*底色  设置长、宽、背景色*/
  width: 150px;
  height: 40px;
  /*background-color: #ffd9b2;*/
  position: absolute;
  left: 30px;
  top: 10px;
}
.big1 ._title{
  /*文字  设置长、宽、字号、粗细、最上方显示*/
  z-index: 999;
  width: 200px;
  height: 60px;
  font-size: xx-large;
  font-weight: normal;
  position: absolute;
  left: 40px;
  top: 10px;
}
.big1 .fenjiexian {
  border: black;
  padding: 3px;
  margin-top: -20px;
  background: repeating-linear-gradient(135deg, #d0d0d0 0px, #09090a 1px, transparent 1px, transparent 6px);
}
.big1 .two{
  overflow: hidden;
  width: 90%;
  height: 150px;
  margin: 20px auto;
  /*background-color: #8aff63;*/
}
.big1 .two .sinfo{
  width: 100%;
  height: 100%;
  float: left;
  /*background-color: #fff;*/
}
.big1 .two .imgg{
  width: 12%;
  display: inline-block;
}
.big1 .two .name{
  height: 70px;
  font-size: 25px;
  font-weight: bolder;
  line-height: 70px;
  text-align: left;
  display: block;
  /*background-color: #fff;*/
}
.big1 .two .sinfos{
  /* float: left; */
  /* margin-top: 10px; */
  /* margin-left: 20px; */
  margin: 5px auto;
  height: 50px;
  color: #8a919f;
  /*background-color: #ffefef;*/
}
.big1 i {
  margin-right: 6px;
}
.big1 .mar_left{
  margin-left: 20px;
}
.big1 .one{
  /* width: 90%; */
  height: 40px;
  margin: 30px auto;
  /*background-color: #e3e3e3;*/
}
.big1 .one .zhongwenjianli{
  width: 70px;
  height: 40px;
  line-height: 40px;
  text-align: center;
  color: #3155eb;
  font-size: small;
  border-style: solid;
  border-width: medium;
  border-color: #aec6ff;
  border-radius: 10px;
  background-color: #f0f5ff;
}
/*.big1 .info{*/
/*  width: 80%;*/
/*  height: 95%;*/
/*  overflow: auto;*/
/*  position: absolute;*/
/*  left: 10%;*/
/*  background-color: #ffffff;*/
/*  margin-top: 20px;*/
/*  -webkit-box-shadow: #666 0px 0px 50px;*/
/*  -moz-box-shadow: #666 0px 0px 50px;*/
/*  box-shadow: #666 0px 0px 20px;*/
/*}*/
.big1 .info{
  width: 400px;
  height: 500px;
  overflow: auto;
  position: absolute;
  top: 0;left:0;right:0;bottom:0;
  margin: 80px 200px;
  background-color: #ffffff;
  -webkit-box-shadow: #666 0px 0px 50px;
  -moz-box-shadow: #666 0px 0px 50px;
  box-shadow: #666 0px 0px 20px;
}
.recommender-result-form-div{
    border-radius: 4px;
    /* padding: 7px; */
    margin: 0 2%;
    width: 520px;
    height: 480px;
    overflow-y: scroll;
}
.box-card {
  /* width: 70%; */
  width: 465px;
  margin: 0px auto;
  border-radius: 20px;
}
.el-loading-mask{
  position: fixed;
}
</style>
