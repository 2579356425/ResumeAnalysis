<template>
  <div>
    <el-steps style="margin: 15px;" :active="active" finish-status="success">
      <el-step title="上传数据源" icon="el-icon-upload"></el-step>
      <el-step title="选择报告模板" icon="el-icon-document"></el-step>
      <el-step title="选择图表样式" icon="el-icon-thumb"></el-step>
      <el-step title="报告预览" icon="el-icon-view"></el-step>
      <el-step title="报告生成" icon="el-icon-loading"></el-step>
    </el-steps>
    <div align="center">
      <el-button-group>
        <el-button type="primary" round icon="el-icon-arrow-left" @click='back'>上一步</el-button>
        <el-button :disabled="isAble" id="next_button" type="primary" round @click='next'>下一步<i
            class="el-icon-arrow-right el-icon--right"></i></el-button>
      </el-button-group>
    </div>
    <!-- 数据源上传 -->
    <div style="margin: 15px;" align="center" v-if="active==0">
      <el-button type="primary" @click="dataSourceFormVisible = true"><i class="el-icon-upload">上传数据源</i></el-button>
      <!-- 上传数据源弹出的对话框 -->
      <el-dialog title="上传数据源" :visible.sync="dataSourceFormVisible">
        <el-form :model="dataSourceForm">
          <el-form-item label="数据源描述" :label-width="formLabelWidth">
            <el-input v-model="dataSourceForm.desc" autocomplete="off"></el-input>
          </el-form-item>
        </el-form>
        <div style="text-align: center;" slot="footer" class="dialog-footer">
          <input type="file" @change="getFile($event)">
          <el-button style="margin-left: 10px;" size="small" type="success" @click="uploadData($event)">上传到服务器
          </el-button>
        </div>
      </el-dialog>
      <!-- 数据源显示的列表 -->
      <div style="padding: 15px;" align="center">
        <el-table
          :data="dataSourceTable.filter(data => !search || data.filename.toLowerCase().includes(search.toLowerCase()))"
          style="width: 100%">
          <el-table-column fixed prop="date" sortable label="上传日期">
          </el-table-column>
          <el-table-column prop="description" label="描述">
          </el-table-column>
          <el-table-column prop="filename" label="名称">
          </el-table-column>
          <el-table-column prop="filesize" sortable label="数据源大小">
          </el-table-column>
          <el-table-column align="right">
            <template slot="header" slot-scope="scope">
              <el-input v-model="search" size="mini" placeholder="输入关键字搜索" />
            </template>
            <template slot-scope="scope">
              <!-- 在使用这一步就直接生成相应的图表 -->
              <el-button size="mini" type="primary" @click="useDataSource(scope.$index, scope.row)"><i
                  class="el-icon-check"></i>使用</el-button>
              <el-button size="mini" type="danger" @click="handleDataSourceDelete(scope.$index, scope.row)"><i
                  class="el-icon-delete"></i>移除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    <!-- 选择报告模板 -->
    <div style="margin: 15px;" align="center" v-if="active==1">
      <!-- 选择报告模板 -->
      <el-button type="primary" @click="templateFormVisible = true"><i class="el-icon-upload">上传报告模板</i></el-button>
      <!-- 上传报告模板弹出的对话框 -->
      <el-dialog title="上传报告模板" :visible.sync="templateFormVisible">
        <el-form :model="dataSourceForm">
          <el-form-item label="模板描述" :label-width="formLabelWidth">
            <el-input v-model="templateForm.desc" autocomplete="off"></el-input>
          </el-form-item>
        </el-form>
        <div style="text-align: center;" slot="footer" class="dialog-footer">
          <input type="file" @change="getFile($event)">
          <el-button style="margin-left: 10px;" size="small" type="success" @click="uploadTemplate($event)">上传到服务器
          </el-button>
        </div>
      </el-dialog>
      <div style="margin: 15px;" align="center">
        <el-table
          :data="templateTable.filter(data => !search || data.filename.toLowerCase().includes(search.toLowerCase()))"
          style="width: 100%">
          <el-table-column fixed prop="date" sortable label="日期">
          </el-table-column>
          <el-table-column prop="description" label="描述">
          </el-table-column>
          <el-table-column prop="filename" label="模板名称">
          </el-table-column>
          </el-table-column>
          <el-table-column prop="filesize" sortable="" label="文件大小">
          </el-table-column>
          <el-table-column align="right">
            <template slot="header" slot-scope="scope">
              <el-input v-model="search" size="mini" placeholder="输入关键字搜索" />
            </template>
            <template slot-scope="scope">
              <el-button size="mini" @click="templatePreview(scope.row)"><i class="el-icon-view"></i>预览
              </el-button>
              <el-button size="mini" type="primary" @click="useTemplate(scope.row)"><i class="el-icon-check"></i>使用
              </el-button>
              <el-button size="mini" type="danger" @click="handleTemplateDelete(scope.$index, scope.row)"><i
                  class="el-icon-delete"></i>移除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    <!-- 选择图表样式 -->
    <div style="padding: 15px;" v-if="active==2">
      <el-tabs v-model="activeName" type="border-card" @tab-click="tabClick()">
        <!-- 忽然觉得类似景气指数也是可以动态渲染的吧?选择好了文档模板后根据图表标题动态渲染到tab的label -->
        <el-tab-pane name="景气指数" label="景气指数">
          <!-- 选择图表样式 -->
          <div style="margin: 15px;" align="center">
            <el-row>
              <el-col style="padding: 5px;" :span="8" v-for="url in aurls" :offset="0">
                <el-card :body-style="{ padding: '5px' }">
                  <img :src=url.url class="image">
                  <div style="padding: 10px;">
                    <div class="bottom clearfix">
                      <el-button type="primary" icon="el-icon-check" round @click='chooseChart(url.type)'>选择{{url.type}}
                      </el-button>
                      <!-- <el-checkbox v-model="atype" :label=url.type name="type"></el-checkbox> -->
                    </div>
                  </div>
                </el-card>
              </el-col>
            </el-row>
          </div>
        </el-tab-pane>
        <el-tab-pane name="旅客运输量指数" label="旅客运输量指数">
          <!-- 选择图表样式 -->
          <div style="margin: 15px;" align="center">
            <el-row>
              <el-col style="padding: 5px;" :span="8" v-for="url in burls" :offset="0">
                <el-card :body-style="{ padding: '5px' }">
                  <img :src=url.url class="image">
                  <div style="padding: 10px;">
                    <div class="bottom clearfix">
                      <el-button type="primary" icon="el-icon-check" round @click='chooseChart(url.type)'>选择{{url.type}}
                      </el-button>
                      <!-- <el-checkbox v-model="btype" :label=url.type name="type"></el-checkbox> -->
                    </div>
                  </div>
                </el-card>
              </el-col>
            </el-row>
          </div>
        </el-tab-pane>
        <el-tab-pane name="客座率指数" label="客座率指数">
          <!-- 选择图表样式 -->
          <div style="margin: 15px;" align="center">
            <el-row>
              <el-col style="padding: 5px;" :span="8" v-for="url in curls" :offset="0">
                <el-card :body-style="{ padding: '5px' }">
                  <img :src=url.url class="image">
                  <div style="padding: 10px;">
                    <div class="bottom clearfix">
                      <el-button type="primary" icon="el-icon-check" round @click='chooseChart(url.type)'>选择{{url.type}}
                      </el-button>
                      <!-- <el-checkbox v-model="ctype" :label=url.type name="type"></el-checkbox> -->
                    </div>
                  </div>
                </el-card>
              </el-col>
            </el-row>
          </div>
        </el-tab-pane>
        <el-tab-pane name="运载率指数" label="运载率指数">
          <!-- 选择图表样式 -->
          <div style="margin: 15px;" align="center">
            <el-row>
              <el-col style="padding: 5px;" :span="8" v-for="url in durls" :offset="0">
                <el-card :body-style="{ padding: '5px' }">
                  <!-- '`${publicPath}images/`+url.url' -->
                  <img :src=url.url class="image">
                  <div style="padding: 10px;">
                    <div class="bottom clearfix">
                      <el-button type="primary" icon="el-icon-check" round @click='chooseChart(url.type)'>选择{{url.type}}
                      </el-button>
                      <!-- <el-checkbox v-model="dtype" :label=url.type name="type"></el-checkbox> -->
                    </div>
                  </div>
                </el-card>
              </el-col>
            </el-row>
          </div>
        </el-tab-pane>
        <el-tab-pane name="飞机日利用率指数" label="飞机日利用率指数">
          <!-- 选择图表样式 -->
          <div style="margin: 15px;" align="center">
            <el-row>
              <el-col style="padding: 5px;" :span="8" v-for="url in eurls" :offset="0">
                <el-card :body-style="{ padding: '5px' }">
                  <img :src=url.url class="image">
                  <div style="padding: 10px;">
                    <div class="bottom clearfix">
                      <el-button type="primary" icon="el-icon-check" round @click='chooseChart(url.type)'>选择{{url.type}}
                      </el-button>
                      <!-- <el-checkbox v-model="etype" :label=url.type name="type"></el-checkbox> -->
                    </div>
                  </div>
                </el-card>
              </el-col>
            </el-row>
          </div>
        </el-tab-pane>
        <el-tab-pane name="旅客周转量指数" label="旅客周转量指数">
          <!-- 选择图表样式 -->
          <div style="margin: 15px;" align="center">
            <el-row>
              <el-col style="padding: 5px;" :span="8" v-for="url in furls" :offset="0">
                <el-card :body-style="{ padding: '5px' }">
                  <img :src=url.url class="image">
                  <div style="padding: 10px;">
                    <div class="bottom clearfix">
                      <el-button type="primary" icon="el-icon-check" round @click='chooseChart(url.type)'>选择{{url.type}}
                      </el-button>
                      <!-- <el-checkbox v-model="ftype" :label=url.type name="type"></el-checkbox> -->
                    </div>
                  </div>
                </el-card>
              </el-col>
            </el-row>
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>
    <!-- 报告预览 -->
    <!-- 写一个点击按钮弹出pdf预览的对话框，需要将docx转为pdf -->
    <div v-if="active==3" style="height: 100%;margin: 5px;">
      <iframe :src=reportpreviewurl style="width: 100%;height: 650px;"></iframe>
    </div>
    <!-- 模板预览弹出框 -->
    <el-dialog :fullscreen="true" style="height: auto;" center title="报告模板预览" custom-class="customWidth"
      :visible.sync="templatePreviewVisible">
      <div style="height: auto;" v-loading='loading'>
        <!-- '`${publicPath}preview_files/`+previewfilename' -->
        <iframe id="bdIframe" :src=templatepreviewurl frameborder="0"
          style="width:100%; height: 100%;" scrolling="no"></iframe>
      </div>
    </el-dialog>
    <!-- 报告预览弹出框 -->
    <el-dialog :fullscreen="true" style="height: auto;" center title="报告模板预览" custom-class="customWidth"
      :visible.sync="reportPreviewVisible">
      <div style="height: auto;" v-loading='loading'>
        <iframe id="bdIframe" :src=reportpreviewurl frameborder="0"
          style="width:100%; height: 100%;" scrolling="no"></iframe>
      </div>
    </el-dialog>
    <!-- 报告生成 -->
    <div v-if="active==4" style="height: 100%;margin: 5px;">
      <el-dialog style="text-align: center;" title="填写报告生成的相关信息" :visible.sync="templateInfoFormVisible">
        <el-form :model="templateInfoForm">
          <el-form-item label="报告名称" :label-width="formLabelWidth">
            <el-input v-model="templateInfoForm.templatename" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="相关责任人姓名" :label-width="formLabelWidth">
            <el-input v-model="templateInfoForm.name" autocomplete="off"></el-input>
          </el-form-item>
          <el-form-item label="相关责任人手机号" :label-width="formLabelWidth">
            <el-input v-model="templateInfoForm.phonenum" autocomplete="off"></el-input>
          </el-form-item>
        </el-form>
        <div style="text-align: center;" slot="footer" class="dialog-footer">
          <el-button type="danger" @click="back()">取消</el-button>
          <el-button type="primary" @click="submitReportInfo()">确认</el-button>
        </div>
      </el-dialog>
    </div>
    <!-- 报告生成的历史记录 -->
    <div v-if="active==5" style="margin: 15px;" align="center">
      <el-table :data="reportTable.slice((currentPage-1)*PageSize,currentPage*PageSize).filter(data => !search || data.filename.toLowerCase().includes(search.toLowerCase()))"
        style="width: 100%">
        <el-table-column fixed prop="date" sortable label="生成日期">
        </el-table-column>
        <el-table-column prop="name" label="负责人">
        </el-table-column>
        <el-table-column prop="phonenum" label="联系方式">
        </el-table-column>
        </el-table-column>
        <el-table-column prop="filename" sortable label="文件名称">
        </el-table-column>
        <el-table-column prop="filesize" sortable label="文件大小">
        </el-table-column>
        <el-table-column align="right" width="300px">
          <template slot="header" slot-scope="scope">
            <el-input v-model="search" size="mini" placeholder="输入关键字搜索" />
          </template>
          <template slot-scope="scope">
            <!-- <el-button size="mini" @click="handleView(scope.$index, scope.row)"><i class="el-icon-view"></i>预览
            </el-button> -->
            <el-button size="mini" type="primary" @click="reportDownload(scope.$index, scope.row)"><i
                class="el-icon-download"></i>下载</el-button>
            <el-button size="mini" type="danger" @click="handleReportDelete(scope.$index, scope.row)"><i
                class="el-icon-delete"></i>移除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="block" align="center" style="margin-top: 10px;">
        <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="currentPage"
          :page-sizes="pageSizes" :page-size="PageSize" layout="total, sizes, prev, pager, next, jumper"
          :total=total>
        </el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
  import axios from 'axios'
  import Vue from 'vue'
  export default {
    data() {
      return {
        currentPage: 1,
        total: 0,
        pageSizes: [5, 10, 20, 50],
        PageSize: 5,
        // 前端分页设置
        reportpreviewurl: '',
        templatepreviewurl: '',
        usetemplatename: '',
        activeName: '景气指数',
        reportname: 'preview.pdf',
        activeflag: 0, //暂存active step返回值
        loading: true,
        templatePreviewVisible: false, //控制模板预览弹出框
        reportPreviewVisible: false,
        previewfilename: 'preview.pdf', //预览的文件名称
        isAble: false, //控制下一步按钮是否可用
        templateInfoForm: {
          templatename: '',
          name: '',
          phonenum: ''
        },
        templateInfoFormVisible: false, //填写生成的报告的信息
        msg: '', //flask测试
        dataSourceFormVisible: false, //上传数据源对话框
        templateFormVisible: false, //上传报告模板对话框
        templateForm: {
          file: '',
          desc: ''
        },
        dataSourceForm: {
          file: '',
          desc: ''
        },
        formLabelWidth: '130px',
        search: '',
        dataSourceTable: [],
        templateTable: [],
        reportTable: [],
        publicPath: process.env.BASE_URL,
        // publicPath: 'D:/workspace/pycharm-workspace/SoftwareDesignFlask/',
        active: 0, //步骤
        urls: [{
          pos: 'a',
          url: '柱状图.png',
          type: '柱状图'
        }, {
          pos: 'a',
          url: '折线图.png',
          type: '折线图'
        }, {
          pos: 'a',
          url: '饼图.png',
          type: '饼图'
        }],
        aurls: [{
          url: 'http://xk-files.qktts.asia/景气指数柱状图.png',
          type: '柱状图'
        }, {
          url: 'http://xk-files.qktts.asia/景气指数折线图.png',
          type: '折线图'
        }, {
          url: 'http://xk-files.qktts.asia/景气指数混合图.png',
          type: '混合图'
        }], //景气指数图表样式
        burls: [{
          url: 'http://xk-files.qktts.asia/旅客运输量指数柱状图.png',
          type: '柱状图'
        }, {
          url: 'http://xk-files.qktts.asia/旅客运输量指数折线图.png',
          type: '折线图'
        }, {
          url: 'http://xk-files.qktts.asia/旅客运输量指数混合图.png',
          type: '混合图'
        }], //量价指数图表样式
        curls: [{
          url: 'http://xk-files.qktts.asia/客座率指数柱状图.png',
          type: '柱状图'
        }, {
          url: 'http://xk-files.qktts.asia/客座率指数折线图.png',
          type: '折线图'
        }, {
          url: 'http://xk-files.qktts.asia/客座率指数混合图.png',
          type: '混合图'
        }], //客座率指数图表样式
        durls: [{
          url: 'http://xk-files.qktts.asia/运载率指数柱状图.png',
          type: '柱状图'
        }, {
          url: 'http://xk-files.qktts.asia/运载率指数折线图.png',
          type: '折线图'
        }, {
          url: 'http://xk-files.qktts.asia/运载率指数混合图.png',
          type: '混合图'
        }], //上半年民航国内旅行者图表样式
        eurls: [{
          url: 'http://xk-files.qktts.asia/飞机日利用率指数柱状图.png',
          type: '柱状图'
        }, {
          url: 'http://xk-files.qktts.asia/飞机日利用率指数折线图.png',
          type: '折线图'
        }, {
          url: 'http://xk-files.qktts.asia/飞机日利用率指数混合图.png',
          type: '混合图'
        }], //上半年民航国际旅行者图表样式
        furls: [{
          url: 'http://xk-files.qktts.asia/旅客周转量指数柱状图.png',
          type: '柱状图'
        }, {
          url: 'http://xk-files.qktts.asia/旅客周转量指数折线图.png',
          type: '折线图'
        }, {
          url: 'http://xk-files.qktts.asia/旅客周转量指数混合图.png',
          type: '混合图'
        }], //上半年节假日市场概况图表样式
      }
    },
    methods: {
      handleSizeChange(val) {
        this.PageSize=val
        this.currentPage=1
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange(val) {
        this.currentPage=val
        console.log(`当前页: ${val}`);
      },
      chooseChart(type) {
        // 最好能够得到tab的名称和图表样式，传给后端，在对应位置渲染
        var type = type
        let formData = new FormData();
        formData.append('type', type);
        formData.append('tabname',this.activeName);
        formData.append('templatename',this.usetemplatename);
        console.log(this.usetemplatename)
        let config = {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
        var that =
          this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
        axios.post('http://127.0.0.1:5000/choosecharttype', formData, config).then(function(response) {
          if (response.data === 'success') {
            if (that.activeName === '景气指数'){
              that.activeName = '旅客运输量指数'}
            else if(that.activeName === '旅客运输量指数'){
              that.activeName = '客座率指数'}
            else if(that.activeName === '客座率指数'){
              that.activeName = '运载率指数'}
            else if(that.activeName === '运载率指数'){
              that.activeName = '飞机日利用率指数'}
            else if(that.activeName === '飞机日利用率指数'){
              that.activeName = '旅客周转量指数'}
            that.$notify({
              title: '成功',
              message: '选择'+ that.activeName + type,
              type: 'success'
            });
          }
        }).catch(err => {
          this.$message.error(err.message);
          console.log(err)
        })
      },
      // 报告模板预览
      templatePreview(row) {
        this.templatePreviewVisible = true;
        var filename = row['filename'];
        filename = filename.substring(0, filename.lastIndexOf(".")) + '.pdf';
        // 根据filename数据库得到对应pdf的url(filepath)
        this.templatepreviewurl = "http://xk-files.qktts.asia/" + filename
        setTimeout(() => {
          this.loading = false;
        }, 500);
        setTimeout(function() {
          console.log("---------");
          /**
           * iframe-宽高自适应显示
           */
          const oIframe = document.getElementById("bdIframe");
          console.log(oIframe);
          const deviceWidth = document.documentElement.clientWidth;
          const deviceHeight = document.documentElement.clientHeight;
          // oIframe.style.width = Number(deviceWidth) - 220 + "px"; //数字是页面布局宽度差值
          oIframe.style.width = Number(deviceWidth); //数字是页面布局宽度差值
          oIframe.style.height = Number(deviceHeight) - 120 + "px"; //数字是页面布局高度差
        }, 500);
      },
      // 报告预览
      handleView(row) {
        this.templatePreviewVisible = true;
        var filename = row['filename'];
        this.previewfilename = filename.substring(0, filename.lastIndexOf(".")) + '.pdf';
        console.log(this.previewfilename)
        setTimeout(() => {
          this.loading = false;
        }, 1000);
        setTimeout(function() {
          console.log("---------");
          /**
           * iframe-宽高自适应显示
           */
          const oIframe = document.getElementById("bdIframe");
          console.log(oIframe);
          const deviceWidth = document.documentElement.clientWidth;
          const deviceHeight = document.documentElement.clientHeight;
          // oIframe.style.width = Number(deviceWidth) - 220 + "px"; //数字是页面布局宽度差值
          oIframe.style.width = Number(deviceWidth); //数字是页面布局宽度差值
          oIframe.style.height = Number(deviceHeight) - 120 + "px"; //数字是页面布局高度差
        }, 1000);
      },
      // 填写生成的报告信息
      submitReportInfo() {
        let formData = new FormData();
        formData.append('genreportname', this.templateInfoForm.templatename);
        formData.append('name',this.templateInfoForm.name);
        formData.append('phonenum',this.templateInfoForm.phonenum);
        let config = {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
        var that =
          this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
        axios.post('http://127.0.0.1:5000/genreport', formData, config).then(function(response) {
          if (response.data === 'success') {
            that.$notify({
              title: '成功',
              message: '报告'+ that.templateInfoForm.templatename + '生成成功！',
              type: 'success'
            });
            that.getReport();
          }
        }).catch(err => {
          this.$message.error(err.message);
          console.log(err)
        })
        this.templateInfoFormVisible = false;
        if (this.active++ > 5) this.active = 0;
        this.isAble = true;
      },
      getMessage() {
        const path = 'http://127.0.0.1:5000/reportgen';
        axios.get(path).then(res => {
          this.msg = res.data;
        }).catch(error => {
          console.error(error);
        });
      },
      reportDownload(index,row){
        var filename = row['filename'];
        console.log(filename)
        console.log(index)
        console.log(this.reportTable[index]['url'])
        window.open(this.reportTable[index]['url'] + '?response-content-type=application/octet-stream');
      },
      // 获取数据库数据源信息
      getDataSource() {
        const path = 'http://127.0.0.1:5000/loaddatasource';
        axios.get(path).then(res => {
          console.log(res.data)
          this.dataSourceTable = res.data;
        }).catch(error => {
          console.error(error);
        });
      },
      // 获取数据库报告模板信息
      getTemplate() {
        const path = 'http://127.0.0.1:5000/loadtemplate';
        axios.get(path).then(res => {
          console.log(res.data)
          this.templateTable = res.data;
        }).catch(error => {
          console.error(error);
        });
      },
      getReport(){
        const path = 'http://127.0.0.1:5000/loadreport';
        axios.get(path).then(res => {
          console.log(res.data)
          this.reportTable = res.data;
          this.total = res.data.length
        }).catch(error => {
          console.error(error);
        });
        // let formData = new FormData();
        // let config = {
        //   headers: {
        //     'Content-Type': 'multipart/form-data'
        //   }
        // }
        // var that =
        //   this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
        // axios.post('http://127.0.0.1:5000/loadreport', formData, config).then(function(response) {
        //   if (response.status === 200) {
        //     console.log(response.data)
        //     // that.reportTable = response.data;
        //   }
        // }).catch(err => {
        //   this.$message.error(err.message);
        //   console.log(err)
        // })
      },
      // 获取点击事件的文件信息
      getFile(event) {
        this.file = event.target.files[0];
        console.log(this.file);
      },
      // 上传数据源
      uploadData(event) {
        event.preventDefault();
        let formData = new FormData();
        formData.append('filename', this.file.name);
        formData.append('filesize', this.file.size);
        formData.append('desc', this.dataSourceForm.desc);
        formData.append('file', this.file);
        let config = {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
        var that =
          this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
        axios.post('http://127.0.0.1:5000/updatasource', formData, config).then(function(response) {
          console.log(response.status)
          if (response.status === 200) {
            that.dataSourceFormVisible = false;
            console.log(response.data)
            that.dataSourceTable.push(response.data)
            console.log(that.dataSourceTable);
          }
        }).catch(err => {
          this.$message.error(err.message);
          console.log(err)
        })
      },
      // 上传报告模板
      uploadTemplate() {
        event.preventDefault();
        let formData = new FormData();
        formData.append('filename', this.file.name);
        formData.append('filesize', this.file.size);
        formData.append('desc', this.templateForm.desc);
        formData.append('file', this.file);
        let config = {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
        var that =
          this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
        axios.post('http://127.0.0.1:5000/uptemplate', formData, config).then(function(response) {
          console.log(response.status)
          if (response.status === 200) {
            that.templateFormVisible = false;
            that.templateTable.push(response.data)
            that.$notify({
              title: '成功',
              message: that.file.name + ' 报告模板上传成功!',
              type: 'success'
            });
            console.log(response.data);
          }
        }).catch(err => {
          this.$message.error(err.message);
          console.log(err)
        })
      },
      useTemplate(row) {
        var templatename = row['filename'];
        //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
        this.usetemplatename = templatename;
        console.log(this.usetemplatename)
        this.$notify({
              title: '成功',
              message: this.usetemplatename+' 报告模板选择成功!',
              type: 'success'
            });
      },
      handleRemove(file, fileList) {
        console.log(file, fileList);
      },
      tabClick(tab, event) {
        console.log(tab, event);
        // this.$notify({
        //   title: '成功',
        //   message: '选择'+ this.activeName + '图表',
        //   type: 'success'
        // });
      },
      handleTemplateChoose(index, row) {
        console.log(index, row);
      },
      useDataSource(index, row) {
        var filename = row['filename'];
        let formData = new FormData();
        formData.append('filename', filename);
        let config = {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
        var that =
          this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
        axios.post('http://127.0.0.1:5000/usedatasource', formData, config).then(function(response) {
          if (response.data === 'success') {
            that.$notify({
              title: '成功',
              message: filename + ' 数据加载成功!',
              type: 'success'
            });
          }
        }).catch(err => {
          this.$message.error(err.message);
          console.log(err)
        })
      },
      handleDataSourceDelete(index, row) {
        var filename = row['filename'];
        let formData = new FormData();
        formData.append('filename', filename);
        let config = {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
        var that =
          this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
        axios.post('http://127.0.0.1:5000/deldatasource', formData, config).then(function(response) {
          if (response.data === 'success') {
            that.getDataSource()
            that.$notify({
              title: '成功',
              message: filename + ' 移除成功!',
              type: 'success'
            });
          }
        }).catch(err => {
          this.$message.error(err.message);
          console.log(err)
        })
      },
      handleTemplateDelete(index, row) {
        var filename = row['filename'];
        let formData = new FormData();
        formData.append('filename', filename);
        let config = {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
        var that =
          this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
        axios.post('http://127.0.0.1:5000/deltemplate', formData, config).then(function(response) {
          if (response.data === 'success') {
            that.getTemplate()
            that.$notify({
              title: '成功',
              message: filename + ' 移除成功!',
              type: 'success'
            });
          }
        }).catch(err => {
          this.$message.error(err.message);
          console.log(err)
        })
      },
      handleReportDelete(index, row) {
        var filename = row['filename'];
        let formData = new FormData();
        formData.append('filename', filename);
        let config = {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
        var that =
          this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
        axios.post('http://127.0.0.1:5000/delreport', formData, config).then(function(response) {
          if (response.data === 'success') {
            that.getReport()
            that.$notify({
              title: '成功',
              message: filename + ' 移除成功!',
              type: 'success'
            });
          }
        }).catch(err => {
          this.$message.error(err.message);
          console.log(err)
        })
      },
      // 下一步,点击下一步，判断当前active等于几
      next() {
        if (this.active++ > 5) {
          this.active = 0;
          this.getDataSource();
          //将数据库中step=0设置为activeflag=true，step=4设置为activeflag=false
          let formData = new FormData();
          formData.append('step1', 0);
          formData.append('activeflag1', 'true');
          formData.append('step2', 4);
          formData.append('activeflag2', 'false');
          let config = {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          }
          var that =
            this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
          axios.post('http://127.0.0.1:5000/updateactive', formData, config).then(function(response) {
            if (response.status === 200) {
              that.getActive();
            }
          }).catch(err => {
            this.$message.error(err.message);
            console.log(err)
          })
        }
        if (this.active == 1) {
          this.getTemplate();
          //将数据库中step=1设置为activeflag=true，step=0设置为activeflag=false
          let formData = new FormData();
          formData.append('step1', 1);
          formData.append('activeflag1', 'true');
          formData.append('step2', 0);
          formData.append('activeflag2', 'false');
          let config = {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          }
          var that =
            this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
          axios.post('http://127.0.0.1:5000/updateactive', formData, config).then(function(response) {
            if (response.status === 200) {
              that.getActive();
            }
          }).catch(err => {
            this.$message.error(err.message);
            console.log(err)
          })
        }
        if (this.active == 2) {
          //将数据库中step=2设置为activeflag=true，step=1设置为activeflag=false
          let formData = new FormData();
          formData.append('step1', 2);
          formData.append('activeflag1', 'true');
          formData.append('step2', 1);
          formData.append('activeflag2', 'false');
          let config = {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          }
          var that =
            this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
          axios.post('http://127.0.0.1:5000/updateactive', formData, config).then(function(response) {
            if (response.status === 200) {
              that.getActive();
            }
          }).catch(err => {
            this.$message.error(err.message);
            console.log(err)
          })
        }
        if (this.active == 3) {
          //将数据库中step=3设置为activeflag=true，step=2设置为activeflag=false
          let formData = new FormData();
          formData.append('step1', 3);
          formData.append('activeflag1', 'true');
          formData.append('step2', 2);
          formData.append('activeflag2', 'false');
          let config = {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          }
          var that =
            this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
          axios.post('http://127.0.0.1:5000/yulan', formData, config).then(function(response) {
            if (response.status === 200) {
              console.log("预览文件名称："+response.data)
              that.reportpreviewurl = response.data
              that.getActive();
            }

          }).catch(err => {
            this.$message.error(err.message);
            console.log(err)
          })
        }
        if (this.active == 4) {
          this.templateInfoFormVisible = true;
          //将数据库中step=4设置为activeflag=true，step=3设置为activeflag=false
          let formData = new FormData();
          formData.append('step1', 4);
          formData.append('activeflag1', 'true');
          formData.append('step2', 3);
          formData.append('activeflag2', 'false');
          let config = {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          }
          var that =
            this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
          axios.post('http://127.0.0.1:5000/updateactive', formData, config).then(function(response) {
            if (response.status === 200) {
              that.getActive();
            }
          }).catch(err => {
            this.$message.error(err.message);
            console.log(err)
          })
        }
        if (this.active == 5) {
          //将数据库中step=5设置为activeflag=true，step=4设置为activeflag=false

        }
      },
      // 上一步,就不需要出现填写信息的对话框（active=4）直接到active=3
      back() {
        this.isAble = false;
        if (this.active-- < 1) {
          this.active = 0;
          this.getDataSource();
        }
        if (this.active == 0) {
          this.getDataSource();
          //然后将数据库中step=0设置为activeflag=true,step=1设置为activeflag=false
          let formData = new FormData();
          formData.append('step1', 0);
          formData.append('activeflag1', 'true');
          formData.append('step2', 1);
          formData.append('activeflag2', 'false');
          let config = {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          }
          var that =
            this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
          axios.post('http://127.0.0.1:5000/updateactive', formData, config).then(function(response) {
            if (response.status === 200) {
              that.getActive();
            }
          }).catch(err => {
            this.$message.error(err.message);
            console.log(err)
          })
        }
        if (this.active == 1) {
          this.getTemplate();
          //然后将数据库中step=1设置为activeflag=true,step=2设置为activeflag=false
          let formData = new FormData();
          formData.append('step1', 1);
          formData.append('activeflag1', 'true');
          formData.append('step2', 2);
          formData.append('activeflag2', 'false');
          let config = {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          }
          var that =
            this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
          axios.post('http://127.0.0.1:5000/updateactive', formData, config).then(function(response) {
            if (response.status === 200) {

              that.getActive();
            }
          }).catch(err => {
            this.$message.error(err.message);
            console.log(err)
          })
        }
        if (this.active == 2) {
          //然后将数据库中step=2设置为activeflag=true,step=3设置为activeflag=false
          let formData = new FormData();
          formData.append('step1', 2);
          formData.append('activeflag1', 'true');
          formData.append('step2', 3);
          formData.append('activeflag2', 'false');
          let config = {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          }
          var that =
            this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
          axios.post('http://127.0.0.1:5000/cleardict', formData, config).then(function(response) {
            if (response.status === 200) {
              that.getActive();
            }
          }).catch(err => {
            this.$message.error(err.message);
            console.log(err)
          })
        }
        if (this.active == 3) {
          //然后将数据库中step=3设置为activeflag=true,step=4设置为activeflag=false
          let formData = new FormData();
          formData.append('step1', 3);
          formData.append('activeflag1', 'true');
          formData.append('step2', 4);
          formData.append('activeflag2', 'false');
          let config = {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          }
          var that =
            this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
          axios.post('http://127.0.0.1:5000/updateactive', formData, config).then(function(response) {
            if (response.status === 200) {
              that.getActive();
            }
          }).catch(err => {
            this.$message.error(err.message);
            console.log(err)
          })
        }
        if (this.active == 4) {
          this.active--;
          //然后将数据库中step=3设置为activeflag=true,step=5设置为activeflag=false
          let formData = new FormData();
          formData.append('step1', 3);
          formData.append('activeflag1', 'true');
          formData.append('step2', 4);
          formData.append('activeflag2', 'false');
          let config = {
            headers: {
              'Content-Type': 'multipart/form-data'
            }
          }
          var that =
            this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
          axios.post('http://127.0.0.1:5000/updateactive', formData, config).then(function(response) {
            if (response.status === 200) {
              that.getActive();
            }
          }).catch(err => {
            this.$message.error(err.message);
            console.log(err)
          })
        }
      },
      //
      getActive() {
        let formData = new FormData();
        formData.append('active', this.active);
        formData.append('activeflag', this.activeflag);
        let config = {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        }
        var that =
          this; //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
        axios.post('http://127.0.0.1:5000/getactive', formData, config).then(function(response) {
          if (response.status === 200) {
            that.activeflag = response.data;
            that.active = that.activeflag;
            // alert("类型是"+typeof that.activeflag+"值为"+that.activeflag)
          }
        }).catch(err => {
          this.$message.error(err.message);
          console.log(err)
        })
      },
      depprase() {
        if (this.deppraseinput == '') { //判断是否输入校验
          this.$message({
            message: '请输入语句！',
            type: 'warning'
          });
        } else {
          axios({
              method: 'post',
              url: 'http://127.0.0.1:8586/Corenlp/depprase',
              data: {
                input: this.deppraseinput
              },
              dataType: 'json',
              headers: {
                'Content-Type': 'application/json;charset=UTF-8'
              }
            }).then(response => {
              this.deppraselist = [];
              console.log(response); //返回的数据
              var s = response.data.length;
              console.log(s); //输出返回数组的长度
              var size = response.data.length;
              for (var i = 0; i < size; i++) {
                this.deppraselist.push(response.data[i]);
              }
              console.log(this.deppraselist);
            })
            .catch(function(error) {
              console.log(error);
            });
        }
      },
    },
    created() {
      // 进入页面时先查询activeflag表中activeflag为true的step，然后设置this.active=step，就可以回到操作之前的状态了
      // 在数据库里设置几个标志，表示会导致前端界面刷新的几种情况，如果上传完模板就把模板标志设为true，然后加载时先读取模板标志判断
      this.getActive();
      this.getDataSource();
      this.getTemplate();
      this.getReport();
    }
  }
</script>

<style>
  /* 图表样式选择 */
  .time {
    font-size: 13px;
    color: #999;
  }

  .bottom {
    margin-top: 13px;
    line-height: 12px;
  }

  .button {
    padding: 0;
    float: right;
  }

  .image {
    width: 100%;
    display: block;
  }

  .clearfix:before,
  .clearfix:after {
    display: table;
    content: "";
  }

  .clearfix:after {
    clear: both
  }

  /* 图表样式选择 */
  /* customWidth用来调整预览框宽度 */
  .customWidth {
    width: 80%;
    height: 80%;
  }
</style>
