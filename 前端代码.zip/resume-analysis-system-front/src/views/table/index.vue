<!-- 历史解译结果 -->
<template>
	<div class="app-container">
		<div align="center">
			<el-card>
				<h2><i class="el-icon-date"></i>历史解译记录</h2>
			</el-card>
			<!-- <el-divider><i class="el-icon-mobile-phone"></i></el-divider> -->
		</div>
		<div style="margin: 30px 0;"></div>
		<el-card>
			<el-table border
				:data="resultTable.slice((currentPage-1)*PageSize,currentPage*PageSize).filter(data => !search || data[6].toLowerCase().includes(search.toLowerCase())|| data[1].toLowerCase().includes(search.toLowerCase()))"
				style="width: 100%">
				<el-table-column prop="5" align="center" label="解译图像">
					<template slot-scope="scope">
						<el-image
						style="width: 35%; height: 35%"
						:src="scope.row[5]"
						:lazy="true"
						:preview-src-list="srcList"
						/>
					</template>
				</el-table-column>
				<el-table-column prop="6" align="center" label="解译类型">
				</el-table-column>
				<el-table-column prop="4" align="center" sortable label="解译时间">
				</el-table-column>
				<el-table-column prop="2" align="center" label="解译结果">
					<template slot-scope="scope">
						<el-image
						style="width: 35%; height: 35%"
						:src="scope.row[2]"
						:lazy="true"
						:preview-src-list="srcList2"
						/>
					</template>
				</el-table-column>
				<el-table-column prop="1" align="center" label="解译名称">
				</el-table-column>
				<el-table-column prop="3" align="center" sortable label="文件大小">
				</el-table-column>
				<el-table-column align="center" width="300px">
					<template slot="header" slot-scope="scope">
						<el-input v-model="search" size="mini" placeholder="输入解译名称或解译类型搜索" />
					</template>
					<template slot-scope="scope">
						<el-button size="mini" type="primary" @click="resultDownload(scope.$index,scope.row)"><i
								class="el-icon-download"></i>下载</el-button>
						<el-button size="mini" type="danger" @click="handleResultDelete(scope.$index, scope.row)"><i
								class="el-icon-delete"></i>删除</el-button>
					</template>
				</el-table-column>
			</el-table>
		</el-card>
		<div class="block" align="center" style="margin-top: 10px;">
			<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
				:current-page="currentPage" :page-sizes="pageSizes" :page-size="PageSize"
				layout="total, sizes, prev, pager, next, jumper" :total=total>
			</el-pagination>
		</div>
	</div>
</template>

<script>
	import axios from 'axios'
	import Vue from 'vue'
	export default {
		inject: ['reload'], // 注入刷新页面的依赖
		data() {
			return {
				resultTable: [],
				search: '',
				currentPage: 1,
				total: 0,
				pageSizes: [5, 10, 20, 50],
				PageSize: 5,
				srcList: [],
				srcList2: []
			}
		},
		methods: {
			handleSizeChange(val) {
				this.PageSize = val
				this.currentPage = 1
				console.log(`每页 ${val} 条`);
			},
			handleCurrentChange(val) {
				this.currentPage = val
				console.log(`当前页: ${val}`);
			},
			getResult() {
				const path = 'http://10.9.21.97:5000/getResult';
				var that = this
				axios.get(path).then(res => {
					console.log(res.data)
					that.resultTable = res.data;
					for (var i = 0; i < res.data.length; i++) {
						that.srcList.push(that.resultTable[i][5])
						that.srcList2.push(that.resultTable[i][2])
					}
					console.log(that.srcList)
					this.total = res.data.length
				}).catch(error => {
					console.error(error);
				});
			},
			handleResultDelete(index, row) {
				this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then(() => {
					console.log(row[0])
					let formData = new FormData();
					formData.append('resultId', row[0]);
					let config = {
						headers: {
							'Content-Type': 'multipart/form-data'
						}
					}
					var that = this;
					axios.post('http://10.9.21.97:5000/handleResultDelete', formData, config).then( res=> {
						if (res.status === 200) {
							that.$notify({
								title: '成功',
								message: row[1] + ' 删除成功!',
								type: 'success'
							});
						}
					}).catch(err => {
						this.$message.error(err.message);
						console.log(err)
					})
					this.reload()
				}).catch(() => {
					this.$message({
						type: 'info',
						message: '已取消删除'
					});          
				});
			},
			resultDownload(index, row) {
				let formData = new FormData();
				formData.append('resultId', row[0]);
				let config = {
					headers: {
						'Content-Type': 'multipart/form-data'
					}
				}
				var that = this;
				axios.post('http://10.9.21.97:5000/resultDownload', formData, config).then( res=> {
					console.log(res.data['zip_address'])
					if (res.status === 200) {
						window.open(res.data['zip_address'] + '?response-content-type=application/octet-stream')
						that.$notify({
							title: '成功',
							message: row[1] + ' 下载成功!',
							type: 'success'
						});
					}
				}).catch(err => {
					this.$message.error(err.message);
					console.log(err)
				})
			}
		},
		created() {
			this.getResult()
		},
	}
</script>
