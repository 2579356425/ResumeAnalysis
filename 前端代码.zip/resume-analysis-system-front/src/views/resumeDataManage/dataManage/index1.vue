<template>
  <div style="margin: 10px auto;" :active="active" finish-status="success">
    <div v-if="active==0" class="big">
      <div class="caozuo">
        <a align="center" style="color: #00aaff;"><h2>简历管理</h2></a>
        <div style="width: 80%;margin: 20px auto;" align="center">

          <input id="sf" ref="input" type="file" style="display: none" v-on:change="submit_file()">
          <el-button size="medium"  type="primary" style="margin-left:10px;margin-top:1px;height: 34px;float: right" @click="btn()"><i class="el-icon-document-add" />上传简历</el-button>
          <el-input v-model="txt" size="small" style="width: 150px;margin-left: 15px;" placeholder="请输入关键词" />
          <el-button size="medium" type="primary" style="margin-left:10px;margin-top:1px;height: 34px;" @click="sousuo_mohuchaxun()"><i class="el-icon-thumb" />搜索</el-button>
          <el-button size="medium" type="primary" style="margin-left:10px;margin-top:1px;height: 34px;" @click="shaixuan_btn()"><i class="el-icon-menu" />筛选</el-button>
        </div>
        <!--      <el-input style="width: 700px;height: 170px;line-height: 70px;font-size: 20px" placeholder="请输入查询条件" v-model="input" clearable></el-input>-->
      </div>
      <div v-if="emptydata===true" class="empty_box">暂无数据</div>
      <!--  遍历tabledata中的信息，显示每一个-->
      <div v-if="emptydata===false">
        <div style="width: 920px;margin: 0px auto" v-for="(item,index) in tableData" :key="index" class="text item" @click="movetodetail(item)">
          <el-card class="box-card" >
            <!--      在card里面写内容-->
            <img v-if="item.sex_per==='男'" class="imgg" src="../../../icons/man.jpg" alt="">
            <img v-if="item.sex_per==='女'" class="imgg" src="../../../icons/woman.jpg" alt="">
            <div class="info">
              <div class="display__name" style="display: inline-block;margin-right: 20px"><b>{{ item.name_per }}</b></div>
              <div class="sec" style="display: inline-block">
                <span>{{ item.sex_per }}</span><span v-if="item.sex_per.length>0&&(item.age_per.toString().length>0 || item.highest_edu_per.length>0 || (typeof item.major_per == 'string' && item.major_per.length>0 ) || typeof item.major_per != 'string' || (typeof item.gra_school_per == 'string' && item.gra_school_per.length>0) || typeof item.gra_school_per != 'string')"> | </span>
                <span>{{ item.age_per }}</span><span v-if="item.age_per.toString().length>0 && (item.highest_edu_per.length>0 || (typeof item.major_per == 'string' && item.major_per.length>0 ) || typeof item.major_per != 'string' || (typeof item.gra_school_per == 'string' && item.gra_school_per.length>0) || typeof item.gra_school_per != 'string')"> | </span>
                <span>{{ item.highest_edu_per }}</span><span v-if="item.highest_edu_per.length>0 && ( (typeof item.major_per == 'string' && item.major_per.length>0 ) || typeof item.major_per != 'string' || (typeof item.gra_school_per == 'string' && item.gra_school_per.length>0) || typeof item.gra_school_per != 'string' )"> | </span>
                <span v-if="typeof item.major_per == 'string' && item.major_per.length>0">{{ item.major_per }}</span><span v-if="typeof item.major_per == 'string' && item.major_per.length>0 && ((typeof item.gra_school_per == 'string' && item.gra_school_per.length>0) || typeof item.gra_school_per != 'string')"> | </span>
                <span v-if="typeof item.major_per != 'string'">{{ item.major_per[item.major_per.length-1] }}</span><span v-if="typeof item.major_per != 'string' && ((typeof item.gra_school_per == 'string' && item.gra_school_per.length>0) || typeof item.gra_school_per != 'string')"> | </span>
                <span v-if="typeof item.gra_school_per == 'string' && item.gra_school_per.length>0 ">{{ item.gra_school_per }}</span>
                <span v-if="typeof item.gra_school_per != 'string'">{{ item.gra_school_per[item.gra_school_per.length-1] }}</span>
              </div>
              <div v-if="typeof item.company_name =='string' && item.company_name.length>0 && item.job_title.length>0" class="th">
                <span style="color: #5454ff">
                <b>● </b>
                </span>
                <span v-if="item.company_name.length>0" style="color: #40586f">在{{ item.company_name }}</span>
                <span v-if="item.job_title.length>0" style="color: #40586f">任{{ item.job_title }}</span>
              </div>
              <div v-if="typeof item.company_name !='string'" class="th">
                <span style="color: #5454ff">
                <b>● </b>
                </span>
<!--                <span style="color: #40586f">在{{ item.company_name[item.company_name.length-1] }}</span>-->
<!--                <span style="color: #40586f">任{{ item.job_title[item.job_title.length-1] }}</span>-->
                <span style="color: #40586f">在{{ item.company_name[0] }}</span>
                <span style="color: #40586f">任{{ item.job_title[0] }}</span>
              </div>
              <div v-if="typeof item.prof_skill_per =='string' && item.prof_skill_per.length>0" class="forth">
                <span style="color: #5454ff">
                  <b>● </b>
                </span>
                <label class="biaoqian" >{{item.prof_skill_per}}</label>

<!--                <span style="color: #40586f">{{ item.prof_skill_per }}</span>-->
              </div>
              <div v-if="typeof item.prof_skill_per !='string'" class="forth">
                <span style="color: #5454ff">
                  <b>● </b>
                </span>
                <label class="biaoqian" v-for="i in item.prof_skill_per">{{i}}</label>
<!--                <span style="color: #40586f">{{ item.prof_skill_per }}</span>-->
              </div>
            </div>
          </el-card>
        </div>
      </div>

      <div class="block" align="center" style="margin-top: 10px; margin-bottom: 10px;">
        <el-pagination
          :current-page="currentPage"
          :page-sizes="pageSizes"
          :page-size="PageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
      <div class="dia">
        <el-drawer
          title="筛选条件"
          :visible.sync="drawer"
          :direction="direction"
          :before-close="handleClose">
          <div style="width: 100%;text-align: center">
            <form ref="form1" action="" >
              <a @click="clean_()" style="font-size: small;color: #979797;position: relative;left: 200px">清除条件</a>
              <div style="margin-top: 10px">
                <lable>姓名</lable>
                <span><input v-model="form1.name_per" type="text" placeholder="请输入姓名"></span>
              </div>
              <div>
                <lable>性别</lable>
                <span style="display: inline-block;width: 60%;text-align:left; ">
                <el-radio v-model="form1.sex_per" style="" label="男"><span>男</span></el-radio>
                <el-radio v-model="form1.sex_per" label="女"><span>女</span></el-radio>
              </span>
              </div>
              <div>
                <lable>年龄</lable>
                <span style="text-align: left "><input style="width: 60px;" v-model="form1.low_age" type="text" placeholder="最低年龄"><span style="width: 20px;text-align: center"> - </span><input style="width: 60px;" v-model="form1.high_age" type="text" placeholder="最高年龄"></span>
              </div>
              <div>
                <lable>有无工作经验</lable>
                <span><input v-model="form1.work_description" type="text" placeholder="请输入有或无"></span>
              </div>
              <div>
                <lable>学历要求</lable>
                <span><input v-model="form1.highest_edu_per" type="text" placeholder="请输入最低学历要求"></span>
              </div>
              <div>
                <lable>专业</lable>
                <span><input v-model="form1.major_per" type="text" placeholder="请输入专业要求"></span>
              </div>
              <div>
                <lable>专业技能</lable>
                <span><input v-model="form1.prof_skill_per" type="text" placeholder="请输入专业技能要求"></span>
              </div>
              <div slot="footer" class="dialog-footer">
                <el-button class="elbtn" @click="drawer = false">取 消</el-button>
                <el-button class="elbtn" type="primary" @click="sousuo_tiaojianchaxun()">搜 索</el-button>
              </div>
            </form>
          </div>
        </el-drawer>
      </div>
      <el-dialog
        title="提示"
        :visible.sync="centerDialogVisible"
        width="30%"
        center>
        <span>当前查询条件是否提交？</span>
        <span slot="footer" class="dialog-footer">
          <el-button @click="centerDialogVisible = false;drawer = false">取 消</el-button>
          <el-button type="primary" @click="sousuo_tiaojianchaxun">提 交</el-button>
        </span>
      </el-dialog>
    </div>
    <div v-if="active==1" class="big1" style="height: 100%">
<!--      <i class="el-icon-back" style="display: inline-block;font-size: 40px;float:left;margin-top: 20px;margin-left: 20px" @click="go_back()" />-->
      <i class="el-icon-back" style="display: inline-block;font-size: 40px;float:left;margin-top: 40px;margin-left: 80px" @click="go_back()" />
      <div class="info">
        <div class="one">
<!--          <div class="zhongwenjianli" style="display: inline-block">中文简历</div>-->
        </div>
        <div class="two">
          <img v-if="item_detail.sex_per==='男'" class="imgg" src="../../../icons/man.jpg" alt="头像">
          <img v-if="item_detail.sex_per==='女'" class="imgg" src="../../../icons/woman.jpg" alt="头像">
          <div class="sinfo">
            <div v-if="item_detail.name_per.length>0" class="name" style="display: inline-block">{{ item_detail.name_per }}</div>
            <div v-if="item_detail.candidate_job_title.length>0" class="name" style="font-size: larger;float: right;display: inline-block">投递职位：{{ item_detail.candidate_job_title }}</div>
            <div class="sinfos">
              <i v-if="item_detail.age_per.toString().length>0" class="el-icon-user-solid" />{{ item_detail.age_per }}
              <i v-if="item_detail.sex_per.length>0" class="mar_left el-icon-s-opportunity" />{{ item_detail.sex_per }}
              <i v-if="item_detail.email_per.length>0" class="mar_left el-icon-s-comment" />{{ item_detail.email_per }}
              <i v-if="item_detail.phone_per.length>0" class="mar_left el-icon-phone" />{{ item_detail.phone_per }}
              <i v-if="item_detail.highest_edu_per.length>0" class="mar_left el-icon-s-cooperation" />{{ item_detail.highest_edu_per }}
            </div>
          </div>
        </div>
        <hr class="fenjiexian">
        <div v-if="item_detail.name_per.length>0 || item_detail.age_per.toString().length>0 || item_detail.phone_per.length>0 || item_detail.qq.length>0 || item_detail.height.length>0 || item_detail.race.length>0 || item_detail.nationality.length>0 || item_detail.highest_edu_per.length>0 || item_detail.political_status.length>0 || item_detail.sex_per.length>0 || item_detail.weixin.length>0 || item_detail.weight.length>0 || item_detail.marital_status.length>0 || item_detail.work_year.length>0 || item_detail.address_per.length>0 || item_detail.email_per.length>0" class="title_box">
          <div class="_title el-icon-user-solid"> 基本信息</div>
          <div class="_title_down" />
        </div>
        <div v-if="item_detail.name_per.length>0 || item_detail.age_per.toString().length>0 || item_detail.phone_per.length>0 || item_detail.qq.length>0 || item_detail.height.length>0 || item_detail.race.length>0 || item_detail.nationality.length>0 || item_detail.highest_edu_per.length>0 || item_detail.political_status.length>0 || item_detail.sex_per.length>0 || item_detail.weixin.length>0 || item_detail.weight.length>0 || item_detail.marital_status.length>0 || item_detail.work_year.length>0 || item_detail.address_per.length>0 || item_detail.email_per.length>0"  class="thr">
          <div v-if="item_detail.name_per.length>0 || item_detail.age_per.toString().length>0 || item_detail.phone_per.length>0 || item_detail.qq.length>0 || item_detail.height.length>0 || item_detail.race.length>0 || item_detail.nationality.length>0 || item_detail.highest_edu_per.length>0 || item_detail.political_status.length>0" class="left">
            <ul>
              <li v-if="item_detail.name_per.length>0"><span class="dian">●</span> 姓名：<span>{{ item_detail.name_per }}</span></li>
              <li v-if="item_detail.age_per.toString().length>0"><span class="dian">●</span> 年龄：<span>{{ item_detail.age_per }}</span></li>
              <li v-if="item_detail.phone_per.length>0"><span class="dian">●</span> 联系方式：<span>{{ item_detail.phone_per }}</span></li>
              <li v-if="item_detail.qq.length>0"><span class="dian">●</span> QQ：<span>{{ item_detail.qq }}</span></li>
              <li v-if="item_detail.height.length>0"><span class="dian">●</span> 身高：<span>{{ item_detail.height }}</span></li>
              <li v-if="item_detail.race.length>0"><span class="dian">●</span> 民族：<span>{{ item_detail.race }}</span></li>
              <li v-if="item_detail.nationality.length>0"><span class="dian">●</span> 国籍：<span>{{ item_detail.nationality }}</span></li>
              <li v-if="item_detail.highest_edu_per.length>0"><span class="dian">●</span> 最高学历：<span>{{ item_detail.highest_edu_per }}</span></li>
              <li v-if="item_detail.political_status.length>0"><span class="dian">●</span> 政治面貌：<span>{{ item_detail.political_status }}</span></li>
<!--              <li v-if="item_detail.school_level.length>0"><span class="dian">●</span> 学校等级：<span>{{ item_detail.school_level }}</span></li>-->
            </ul>
          </div>
          <div v-if="item_detail.sex_per.length>0 || item_detail.weixin.length>0 || item_detail.weight.length>0 || item_detail.marital_status.length>0 || item_detail.work_year.length>0 || item_detail.address_per.length>0 || item_detail.email_per.length>0" class="right">
            <ul>
              <li v-if="item_detail.sex_per.length>0"><span class="dian">●</span> 性别：<span>{{ item_detail.sex_per }}</span></li>
              <li v-if="item_detail.address_per.length>0"><span class="dian">●</span> 住址：<span>{{ item_detail.address_per }}</span></li>
              <li v-if="item_detail.email_per.length>0"><span class="dian">●</span> 邮箱：<span>{{ item_detail.email_per }}</span></li>
              <li v-if="item_detail.weixin.length>0"><span class="dian">●</span> 微信：<span>{{ item_detail.weixin }}</span></li>
              <li v-if="item_detail.weight.length>0"><span class="dian">●</span> 体重：<span>{{ item_detail.weight }}</span></li>
              <li v-if="item_detail.marital_status.length>0"><span class="dian">●</span> 婚姻状况：<span>{{ item_detail.marital_status }}</span></li>
              <li v-if="item_detail.work_year.length>0"><span class="dian">●</span> 工作经验：<span>{{ item_detail.work_year }}</span></li>
              <li v-if="item_detail.postal_code.length>0"><span class="dian">●</span> 邮编：<span>{{ item_detail.postal_code }}</span></li>
<!--              <li v-if="item_detail.edu_gpa.length>0"><span class="dian">●</span> 绩点：<span>{{ item_detail.edu_gpa }}</span></li>-->
            </ul>
          </div>
        </div>
        <div v-if="item_detail.edu.length>0" class="title_box">
          <div class="_title el-icon-s-management"> 教育背景</div>
          <div class="_title_down" />
        </div>
        <div v-if="item_detail.edu.length>0" class="four">
          <div v-for="(item,index) in item_detail.edu" style="margin-bottom: 20px">
            <div style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px">{{ item.gra_school_per }}</div>
            <ul>
              <li v-if="item.adm_date.length>0"><span class="dian">●</span> 时间：<span>{{ item.adm_date }} - {{ item.gra_date }}</span></li>
              <li v-if="item.major_per.length>0"><span class="dian">●</span> 专业：<span>{{ item.major_per }}</span></li>
              <li v-if="item.edu_gpa.toString().length>0"><span class="dian">●</span> 绩点：<span>{{ item.edu_gpa }}</span></li>
              <li v-if="item.school_level.length>0"><span class="dian">●</span> 学校水平：<span>{{ item.school_level }}</span></li>
              <li style="position: relative" v-if="item.courses.length>0" ><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">所学课程：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.courses }}</div></li>
            </ul>
          </div>
        </div>

        <div v-if="item_detail.work.length>0" class="title_box">
          <div class="_title el-icon-s-cooperation"> 工作经历</div>
          <div class="_title_down" />
        </div>
        <div v-if="item_detail.work.length>0" class="five">
          <div v-for="(item,index) in item_detail.work" style="margin-bottom: 20px">
            <div style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px ">{{item.company_name}}</div>
            <ul>
              <li style="position: relative" v-if="item.work_date.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">工作时间：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.work_date }}</div></li>
              <li style="position: relative" v-if="item.job_title.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">岗位名称：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.job_title }}</div></li>
<!--              <li style="position: relative" v-if="item.work_industry.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">工作行业：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.work_industry }}</div></li>-->
              <li style="position: relative" v-if="item.work_description.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">工作描述：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.work_description }}</div></li>
            </ul>
          </div>
        </div>

        <div v-if="item_detail.project.length>0" class="title_box">
          <div class="_title el-icon-s-cooperation"> 项目经历</div>
          <div class="_title_down" />
        </div>
        <div v-if="item_detail.project.length>0" class="five">
          <div v-for="(item,index) in item_detail.project" style="margin-bottom: 20px">
            <div style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px">{{item.project_name}}</div>
            <ul>
              <li style="position: relative" v-if="item.project_position.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">职位：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.project_position }}</div></li>
              <li style="position: relative" v-if="item.project_date.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">项目时间：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.project_date }}</div></li>
              <li style="position: relative" v-if="item.project_description.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">项目描述：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.project_description }}</div></li>
            </ul>
          </div>
        </div>

        <div v-if="item_detail.social.length>0" class="title_box">
          <div class="_title el-icon-s-cooperation"> 社会经历</div>
          <div class="_title_down" />
        </div>
        <div v-if="item_detail.social.length>0" class="five">
          <div v-for="(item,index) in item_detail.social" style="margin-bottom: 20px">
            <div style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px">{{item.social_cpy}}</div>
            <ul>
              <!--              <li style="position: relative" v-if="item.social_cpy.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">组织单位：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px">{{ item.social_cpy }}</div></li>-->
              <li style="position: relative" v-if="item.social_date.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">实践时间：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.social_date }}</div></li>
              <li style="position: relative" v-if="item.social_pos.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">担任角色：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.social_pos }}</div></li>
              <li style="position: relative" v-if="item.social_description.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">实践描述：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.social_description }}</div></li>
            </ul>
          </div>
        </div>

        <div v-if="item_detail.train.length>0" class="title_box">
          <div class="_title el-icon-s-cooperation"> 培训经历</div>
          <div class="_title_down" />
        </div>
        <div v-if="item_detail.train.length>0" class="five">
          <div  v-for="(item,index) in item_detail.train" style="margin-bottom: 20px">
            <div v-if="item.train_org.length>0" style="font-size: larger;color: #000000 ;font-weight: bolder;margin-left: 10px">{{ item.train_org }}</div>
            <ul>
              <li style="position: relative" v-if="item.train_date.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">培训时间：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.train_date }}</div></li>
              <li style="position: relative" v-if="item.training_description.length>0"><span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">培训描述：</span><div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">{{ item.training_description }}</div></li>
            </ul>
          </div>
        </div>
<!--       看这里-->
        <div class="title_box" v-if="item_detail.prof_skill_per.length>0 || item_detail.lan_skill_per.length>0 || item_detail.office_skill_per.length>0 ||item_detail.awards_per.length>0 || item_detail.certificates.length>0 || item_detail.self_evaluation.length>0">
          <div class="_title">其他信息</div>
          <div class="_title_down" />
        </div>

        <div class="six" v-if="item_detail.prof_skill_per.length>0 || item_detail.lan_skill_per.length>0 || item_detail.office_skill_per.length>0 ||item_detail.awards_per.length>0 || item_detail.certificates.length>0 || item_detail.self_evaluation.length>0">
          <ul>
<!--            <li style="position: relative">-->
            <li style="position: relative" v-if="item_detail.prof_skill_per.length>0">
              <span style="position: absolute" class="dian">●</span>
              <span style="color: #9198a5;position: absolute;left: 18px">专业技能：</span>
              <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                <span v-if="typeof item_detail.prof_skill_per == 'string'">{{ item_detail.prof_skill_per }}</span>
                <span v-if="typeof item_detail.prof_skill_per != 'string'">{{ item_detail.prof_skill_per.join('、') }}</span>
              </div>
            </li>
            <li style="position: relative" v-if="item_detail.lan_skill_per.length>0">
              <span style="position: absolute" class="dian">●</span> <span style="color: #9198a5;position: absolute;left: 18px">语言技能：</span>
              <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                <span v-if="typeof item_detail.lan_skill_per == 'string'">{{ item_detail.lan_skill_per }}</span>
                <span v-if="typeof item_detail.lan_skill_per != 'string'">{{ item_detail.lan_skill_per.join('、') }}</span>
              </div>
            </li>
            <li style="position: relative" v-if="item_detail.office_skill_per.length>0">
              <span style="position: absolute" class="dian">●</span>
              <span style="color: #9198a5;position: absolute;left: 18px">办公技能：</span>
              <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                <span v-if="typeof item_detail.office_skill_per == 'string'">{{ item_detail.office_skill_per }}</span>
                <span v-if="typeof item_detail.office_skill_per != 'string'">{{ item_detail.office_skill_per.join('、') }}</span>
              </div>
            </li>
            <li style="position: relative" v-if="item_detail.awards_per.length>0">
              <span style="position: absolute" class="dian">●</span>
              <span style="color: #9198a5;position: absolute;left: 18px">所获奖项：</span>
              <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                <span v-if="typeof item_detail.awards_per == 'string'">{{ item_detail.awards_per }}</span>
                <span v-if="typeof item_detail.awards_per != 'string'">{{ item_detail.awards_per.join('、') }}</span>
              </div>
            </li>
            <li style="position: relative" v-if="item_detail.certificates.length>0">
              <span style="position: absolute" class="dian">●</span>
              <span style="color: #9198a5;position: absolute;left: 18px">所获证书：</span>
              <div v-if="typeof item_detail.certificates != 'string'">
                <div v-for="(item,i) in item_detail.certificates" style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                  {{i+1}}、{{ item }}
                </div>
              </div>
              <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                <span v-if="typeof item_detail.certificates == 'string'">{{ item_detail.certificates }}</span>
              </div>
            </li>
            <li style="position: relative" v-if="item_detail.self_evaluation.length>0">
              <span style="position: absolute" class="dian">●</span>
              <span style="color: #9198a5;position: absolute;left: 18px">自我描述：</span>
              <div style="color: #494949;display: inline-block;position: relative;width: 80%;left: 110px;font-size: 16px">
                {{ item_detail.self_evaluation }}
              </div>
            </li>
          </ul>
        </div>

        <div class="teil" style="text-align: right">
          <el-button type="primary" size="mini" @click="$refs.aa.click()"><i class="el-icon-download" /><a ref="aa" :href="lianjie"></a>下载</el-button>
          <el-button type="primary" size="mini" @click="mod_btn()"><i class="el-icon-edit" />修改</el-button>
          <el-button type="danger" size="mini" @click="isdel=true"><i class="el-icon-delete" />删除</el-button>
        </div>
      </div>
      <div style="text-align: left">
        <el-dialog title="重要提示" :visible.sync="isdel">
          <div style="color: red">是否确定要删除这份简历？</div>
          <div slot="footer" class="dialog-footer">
            <el-button @click="isdel = false">取 消</el-button>
            <el-button :plain="true" type="primary" @click="del()">确 定</el-button>
          </div>
        </el-dialog>
      </div>
      <div class="xiugai" style="width: 80%;">
        <el-dialog title="修改信息" :visible.sync="big1_dialogFormVisible">
          <form ref="item_detail_mod" action="">
            <div style="text-align: center">
              <div>
                <lable>姓名</lable>
                <span><input v-model="item_detail_mod.name_per" type="text" placeholder="请输入姓名"></span>
              </div>
              <div>
                <lable>性别</lable>
                <span style="display: inline-block;width: 60%;text-align:left; ">
                    <el-radio v-model="mod_sex" label="男"><span>男</span></el-radio>
                    <el-radio v-model="mod_sex" label="女"><span>女</span></el-radio>
<!--                    <el-radio v-model="item_detail_mod.sex_per" label="女"><span>女</span></el-radio>-->
                  </span>
              </div>
              <div>
                <lable>年龄</lable>
                <span><input v-model="item_detail_mod.age_per" type="text" placeholder="请输入年龄"></span>
              </div>
              <div>
                <lable>住址</lable>
                <span><input v-model="item_detail_mod.address_per" type="text" placeholder="请输入住址"></span>
              </div>
              <div>
                <lable>邮箱</lable>
                <span><input v-model="item_detail_mod.email_per" type="text" placeholder="请输入邮箱"></span>
              </div>
              <div>
                <lable>联系方式</lable>
                <span><input v-model="item_detail_mod.phone_per" type="text" placeholder="请输入联系方式"></span>
              </div>
              <div>
                <lable>QQ</lable>
                <span><input v-model="item_detail_mod.qq" type="text" placeholder="请输入QQ号码"></span>
              </div>
              <div>
                <lable>微信</lable>
                <span><input v-model="item_detail_mod.weixin" type="text" placeholder="请输入微信号码"></span>
              </div>
              <div>
                <lable>身高</lable>
                <span><input v-model="item_detail_mod.height" type="text" placeholder="请输入身高"></span>
              </div>
              <div>
                <lable>体重</lable>
                <span><input v-model="item_detail_mod.weight" type="text" placeholder="请输入体重"></span>
              </div>
              <div>
                <lable>国籍</lable>
                <span><input v-model="item_detail_mod.nationality" type="text" placeholder="请输入国籍"></span>
              </div>
              <div>
                <lable>婚姻状况</lable>
                <span><input v-model="item_detail_mod.marital_status" type="text" placeholder="请输入婚姻状况"></span>
              </div>
              <div>
                <lable>民族</lable>
                <span><input v-model="item_detail_mod.race" type="text" placeholder="请输入民族"></span>
              </div>
              <div>
                <lable>政治面貌</lable>
                <span><input v-model="item_detail_mod.political_status" type="text" placeholder="请输入政治面貌"></span>
              </div>
              <div>
                <lable>邮编</lable>
                <span><input v-model="item_detail_mod.postal_code" type="text" placeholder="请输入邮编"></span>
              </div>
              <div>
                <lable>最高学历</lable>
                <span><input v-model="item_detail_mod.highest_edu_per" type="text" placeholder="请输入最高学历"></span>
              </div>
              <div>
                <lable>入学时间</lable>
                <span><input v-model="item_detail_mod.adm_date" type="text" placeholder="请输入入学时间"></span>
              </div>
              <div>
                <lable>毕业时间</lable>
                <span><input v-model="item_detail_mod.gra_date" type="text" placeholder="请输入毕业时间"></span>
              </div>
              <div>
                <lable>毕业院校</lable>
                <span><input v-model="item_detail_mod.gra_school_per" type="text" placeholder="请输入毕业院校"></span>
              </div>
              <div>
                <lable>专业</lable>
                <span><input v-model="item_detail_mod.major_per" type="text" placeholder="请输入专业"></span>
              </div>
              <div>
                <lable>学校等级</lable>
                <span><input v-model="item_detail_mod.school_level" type="text" placeholder="请输入学校等级"></span>
              </div>
              <div>
                <lable>绩点</lable>
                <span><input v-model="item_detail_mod.edu_gpa" type="text" placeholder="请输入绩点"></span>
              </div>
              <div>
                <lable>所学课程</lable>
                <span><input v-model="item_detail_mod.courses" type="text" placeholder="请输入所学课程"></span>
              </div>
              <div>
                <lable>工作年限</lable>
                <span><input v-model="item_detail_mod.work_year" type="text" placeholder="请输入工作年限"></span>
              </div>
              <div>
                <lable>公司名</lable>
                <span><input v-model="item_detail_mod.company_name" type="text" placeholder="请输入公司名"></span>
              </div>
              <div>
                <lable>工作时间</lable>
                <span><input v-model="item_detail_mod.work_date" type="text" placeholder="请输入工作时间"></span>
              </div>
              <div>
                <lable>职位名</lable>
                <span><input v-model="item_detail_mod.job_title" type="text" placeholder="请输入职位名"></span>
              </div>
<!--              <div>-->
<!--                <lable>工作行业</lable>-->
<!--                <span><input v-model="item_detail_mod.work_description" type="text" placeholder="请输入曾任职位职能"></span>-->
<!--              </div>-->
              <div>
                <lable>工作描述</lable>
                <span><input v-model="item_detail_mod.work_description" type="text" placeholder="请输入工作描述"></span>
              </div>

              <div>
                <lable>项目名称</lable>
                <span><input v-model="item_detail_mod.project_name" type="text" placeholder="请输入项目名称"></span>
              </div>
              <div>
                <lable>项目日期</lable>
                <span><input v-model="item_detail_mod.project_date" type="text" placeholder="请输入项目日期"></span>
              </div>
              <div>
                <lable>担任角色</lable>
                <span><input v-model="item_detail_mod.project_position" type="text" placeholder="请输入担任角色"></span>
              </div>
              <div>
                <lable>项目描述</lable>
                <span><input v-model="item_detail_mod.project_description" type="text" placeholder="请输入项目描述"></span>
              </div>


              <div>
                <lable>实践名称</lable>
                <span><input v-model="item_detail_mod.social_cpy" type="text" placeholder="请输入实践名称"></span>
              </div>
              <div>
                <lable>实践日期</lable>
                <span><input v-model="item_detail_mod.social_date" type="text" placeholder="请输入实践日期"></span>
              </div>
              <div>
                <lable>担任角色</lable>
                <span><input v-model="item_detail_mod.social_pos" type="text" placeholder="请输入担任角色"></span>
              </div>
              <div>
                <lable>实践描述</lable>
                <span><input v-model="item_detail_mod.social_description" type="text" placeholder="请输入实践描述"></span>
              </div>


              <div>
                <lable>培训机构名称</lable>
                <span><input v-model="item_detail_mod.train_org" type="text" placeholder="请输入培训机构名称"></span>
              </div>
              <div>
                <lable>培训日期</lable>
                <span><input v-model="item_detail_mod.train_date" type="text" placeholder="请输入培训日期"></span>
              </div>
              <div>
                <lable>培训描述</lable>
                <span><input v-model="item_detail_mod.training_description" type="text" placeholder="请输入培训描述"></span>
              </div>

              <div>
                <lable>语言技能</lable>
                <span><input v-model="item_detail_mod.lan_skill_per" type="text" placeholder="请输入语言技能"></span>
              </div>
              <div>
                <lable>专业技能</lable>
                <span><input v-model="item_detail_mod.prof_skill_per" type="text" placeholder="请输入专业技能"></span>
              </div>
              <div>
                <lable>办公技能</lable>
                <span><input v-model="item_detail_mod.office_skill_per" type="text" placeholder="请输入办公技能"></span>
              </div>
              <div>
                <lable>自我评价</lable>
                <span><input v-model="item_detail_mod.self_evaluation" type="text" placeholder="请输入自我评价"></span>
              </div>
              <div>
                <lable>所获奖项</lable>
                <span><input v-model="item_detail_mod.awards_per" type="text" placeholder="请输入所获奖项"></span>
              </div>
              <div>
                <lable>所获证书</lable>
                <span><input v-model="item_detail_mod.certificates" type="text" placeholder="请输入所获证书"></span>
              </div>
              <div>
                <lable>投递岗位名称</lable>
                <span><input v-model="item_detail_mod.candidate_job_title" type="text" placeholder="请输入投递岗位名称"></span>
              </div>
            </div>
          </form>
          <div slot="footer" class="dialog-footer">
            <el-button class="elbtn" @click="big1_dialogFormVisible = false">取 消</el-button>
            <el-button class="elbtn" :plain="true" type="primary" @click="submit_mod()">确 定</el-button>
          </div>
        </el-dialog>
      </div>
    </div>
  </div>
</template>
<script>
import * as axios from 'axios'
import Global from '../../../global/global'
export default {
  inject: ['reload'], // 注入刷新页面的依赖
  name: 'Index',
  data() {
    return {
      resumeName: '',
      resumeUrl: '',
      // 下载链接
      lianjie:'',
      mod_justnow: false,
      // shuaxin: true,
      emptydata: false,
      // 抽屉取消的弹出框的可见性
      centerDialogVisible: false,
      // 抽屉的可见性
      drawer: false,
      // 抽屉的打开方式
      direction: 'rtl',
      // 修改对象时的性别显示
      mod_sex: '',
      file: null,
      uploadProgress: 0,
      conn: Global.data().conn,
      // 显示控制
      active: 0,
      // 分页控制
      currentPage: 1,
      total: 0,
      pageSizes: [2, 3, 5, 10],
      PageSize: 3,
      // 简历详情中的修改弹框的可见性
      big1_dialogFormVisible: false,
      // 简历详情中的确认删除
      isdel: false,
      // 筛选表单中的对象
      form1: {
        name_per: '',
        sex_per: '',
        low_age: '',
        high_age: '',
        work_description: '',
        highest_edu_per: '',
        major_per: '',
        prof_skill_per: ''
      },
      // 模糊查询内容
      txt: '',
      // 简历详情对象
      item_detail: {},
      // item_detail: {
      //   name_per: "郭芳天",
      //   age_per: 22,
      //   sex_per: "男",
      //   email_per: "service@500d.me",
      //   phone_per: "13800138000",
      //   qq: "1226442222",
      //   weixin: "wx1226442222",
      //   address_per: "上海浦东新区",
      //   height: "180",
      //   weight: "70",
      //   race: "汉族",
      //   nationality: "中国",
      //   marital_status: "未婚",
      //   highest_edu_per: "大专",
      //   political_status: "中共党员",
      //   work_year: "5年",
      //   adm_date: "2013.07Ж2017.07",
      //   gra_date: "2017.6Ж2019.6",
      //   gra_school_per: "上海外国语大学Ж上海大学",
      //   major_per: "市场营销Ж市场营销",
      //   school_level: "普通学校Ж普通学校",
      //   edu_gpa: "3.0Ж5.0",
      //   courses: "管理学、微观经济学、宏观经济学、管理信息系统、统计学、会计学、财务管理、市场营销、经济法、消费者行为学、国际市场营销。Ж管理学、微观经济学、宏观经济学、管理信息系统、统计学、会计学、财务管理、市场营销、经济法、消费者行为学、国际市场营销。",
      //   postal_code: "271000",
      //   work_date: "2017.12-2018.12Ж2018.12-2019.12Ж2019.12-至今",
      //   work_description: "负责事业部产品对外推广和宣传，制定各种整合营销的活动；;执行媒体投放计划，跟踪和监督媒体投放效果，进行数据分析撰写报告；;向市场总监提供营销支持，并协助相关的公关事宜。Ж根据公司发展情况进行战略调整，配合前端销售部门搭建销售渠道；;研究行业发展动态，定期进行市场调查,为产品更新提供建议；;负责公司部门(营运、品牌策划)制度规范，负责组织及监管市场部关于对外合作、推广策划以相关工作的落实。Ж负责协助集团旗下事业部开展各项工作，制定品牌传播方案；;结合集团与事业部发展，制定营销策略、广告策略、品牌策略和公关策略，并组织推进执行；;制定和执行媒体投放计划，跟踪和监督媒体投放效果，进行数据分析与撰写报告；",
      //   work_industry: "教育Ж教育Ж教育",
      //   company_name: "枫辰设计俱乐部Ж源清设计有限公司Ж翔汇投资控股集团",
      //   job_title: "市场副总监Ж市场及运营总监Ж副总监",
      //   project_name: "枫辰设计设计集团品牌升级发布会Ж源清设计设计商业模式发布会Ж翔汇投资控股集团6A自媒体生态圈建设",
      //   project_description: "集团全新品牌logo及VI上线，在多渠道进行了传播；;企业VIP客户群体逾60人，结合了线上发布、线下体验；;后续媒体报道持续升温，子品牌结合明星代言人制造话题营销，为期3周；Ж整场活动以会议+洽谈双重模式进行，首日以介绍源清内部平台资源优势，政府背景优势等为主，一对多推介会进行推广普及；;现场签署地方合作意向书，如：新疆、江西、浙江等优秀企业商户；;以中国的波尔多为宣传点，主推旗下新疆大型项目，制造营销、品牌热点。Ж本项目重构了公司现有微信企业号的功能与架构。;提高公众号的关注粉丝量的同时，对于有客户进行统一宣传，统一管理",
      //   project_date: "ЖЖ",
      //   project_position: "ЖЖ",
      //   social_pos: "队长Ж管理员",
      //   social_date: "2014.05-2017.06Ж2014.11-2017.06",
      //   social_cpy: "上海外国语大学Ж沟通与交流协会",
      //   social_description: "负责50余人团队的日常训练、选拔及团队建设；; 作为负责人对接多项商业校园行活动，如《奔跑吧兄弟》上海外国语大学站录制、《时代周末》校园行。Ж协助上海沟通协会创立上海外国语大学分部，从零开始组建初期团队；; 策划协会会员制，选拔、培训协会导师，推出一系列沟通课程。",
      //   train_org: "达内教育Ж一本教育Ж啥都会俱乐部",
      //   training_description: "学前后端Ж学语言表达艺术Ж学与人交往的礼仪",
      //   train_date: "2012.6--2015.9Ж2015.6--2016.3Ж2016.3--2016.9",
      //   self_evaluation: "拥有多年的市场管理及品牌营销经验，卓越的规划、组织、策划、方案执行和团队领导能力，积累较强的人际关系处理能力和商务谈判技巧，善于沟通，具备良好的合作关系掌控能力与市场开拓能力；;敏感的商业和市场意识，具备优秀的资源整合能力、业务推进能力； ;思维敏捷，有培训演讲能力，懂激励艺术，能带动团队的积极性；擅长协调平衡团队成员的竞争与合作的关系，善于通过培训提高团队综合能力和凝聚力。",
      //   awards_per: "2016年  新长城上海外国语大学自强社“优秀社员”;2015年  三下乡”社会实践活动“优秀学生”;2015年  上海外国语大学学生田径运动会10人立定跳远团体赛第三名;2015年  学生军事技能训练“优秀学员”;2015年  上海外国语大学盼盼杯烘焙食品创意大赛优秀奖;2014年  高校大学生主题征文一等奖;2014年  上海外国语大学“青春”微博文征集大赛二等奖;普通话一级甲等;通过全国计算机二级考试，熟练运用office相关软件。;熟练使用绘声绘色软件，剪辑过各种类型的电影及班级视频。;大学英语四/六级（CET-4/6），良好听说读写能力，快速浏览英语专业书籍。",
      //   certificates: "2016年  新长城上海外国语大学自强社“优秀社员”;2015年  三下乡”社会实践活动“优秀学生”;2015年  上海外国语大学学生田径运动会10人立定跳远团体赛第三名;2015年  学生军事技能训练“优秀学员”;2015年  上海外国语大学盼盼杯烘焙食品创意大赛优秀奖;2014年  高校大学生主题征文一等奖;2014年  上海外国语大学“青春”微博文征集大赛二等奖;普通话一级甲等;通过全国计算机二级考试，熟练运用office相关软件。;熟练使用绘声绘色软件，剪辑过各种类型的电影及班级视频。;大学英语四/六级（CET-4/6），良好听说读写能力，快速浏览英语专业书籍。",
      //   candidate_job_title: "销售总监",
      //   pred_salary: "12000--15000",
      //   lan_skill_per: "中文、英文",
      //   prof_skill_per: "javaЖpython",
      //   office_skill_per: "word、ppt"
      // },
      // 简历修改的时候的对象
      item_detail_mod: {},
      // 暂存简历修改的值
      // show_info: {},
      // 显示的所有对象
      tableData: [],
      // 从数据库中获取的全部对象
      allData: [],
      // 存放当前所有数据的id用于再次查询更新后的数据
      id_list: []
    }
  },
  methods: {
    // 点击筛选按钮，将筛选的弹框打开，筛选的条件清除
    shaixuan_btn() {
      this.drawer = true
      this.clean_()
      // Global.username
    },
    // 清除筛选条件
    clean_() {
      this.form1.high_age = ''
      this.form1.low_age = ''
      this.form1.name_per = ''
      this.form1.sex_per = ''
      this.form1.work_description = ''
      this.form1.highest_edu_per = ''
      this.form1.major_per = ''
      this.form1.prof_skill_per = ''
    },
    // 当点击抽屉外边的时候,,提示出现
    handleClose(done) {
      this.centerDialogVisible = true
    },
    // 上传功能   使用按钮的点击激活input的点击
    btn() {
      this.$refs.input.click()
    },
    // 上传文件
    // 参数为：文件+username
    // 将文件上传到后端  在调用方法，进行分析
    async submit_file(){
      let formData = new FormData()

      const blob = this.$refs.input.files[0]
      console.log(blob.name)
      formData.append("resume", blob)
      formData.append("username", Global.username)
      var that = this;
      const res = await axios.post(this.conn+"/save_upload_resume2", formData).then(function(response) {
        console.log(response)
        if (response.status === 200) {
          that.$notify({
            title: '成功',
            message: blob.name + '上传成功!',
            type: 'success'
          });
          that.resumeUrl = response.data
          that.resumeName = response.data.split("\\")[response.data.split("\\").length-1]
          that.resumeAnalysis()
          console.log(that.resumeName);
        }
      }).catch(err => {
        this.$message.error(err.message);
        console.log(err)
      })

    },
    resumeAnalysis(){
      console.log("this.resumeName:", this.resumeName)
      let formData = new FormData();
      formData.append('resumeUrl', this.resumeUrl);
      formData.append('resumeName', this.resumeName)
      console.log("formData.resumeName:", formData.get('resumeName'))
      formData.append('username', Global.username)
      let config = {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }
      var table = []
      //在 then的内部不能使用Vue的实例化的this, 因为在内部 this 没有被绑定。解决：用ES6箭头函数，箭头方法可以和父方法共享变量；在请求axios外面定义一下 var that=this
      var that = this;
      axios.post('http://127.0.0.1:5000/resume_analysis', formData, config).then(function(res) {
        that.PageSize = 3
        console.log('后端返回:', res)
        if (res.status === 200) {
          that.$notify({
            title: '成功',
            message: that.resumeName + '解析成功!',
            type: 'success'
          });
          that.resumeName = ''
          that.resumeUrl = ''
          that.total = res.data.length
          that.resumeTable = []
          for (var i = 0; i < res.data.length; i++) {
            for (var j = 0; j < res.data[i].length; j++) {
              if (res.data[i][j] == null || res.data[i][j] === 'undefined') {
                res.data[i][j] = ''
              }
            }
            console.log('写入resumeTable前', that.resumeTable)
            table.push({
              id: res.data[i][0] + '',
              name_per: res.data[i][1],
              sex_per: res.data[i][2],
              email_per: res.data[i][3],
              age_per: res.data[i][4] + '',
              phone_per: res.data[i][5],
              qq: res.data[i][6],
              weixin: res.data[i][7],
              address_per: res.data[i][8],
              height: res.data[i][9],
              weight: res.data[i][10],
              race: res.data[i][11],
              nationality: res.data[i][12],
              marital_status: res.data[i][13],
              highest_edu_per: res.data[i][14],
              adm_date: res.data[i][15],
              gra_date: res.data[i][16],
              gra_school_per: res.data[i][17],
              major_per: res.data[i][18],
              lan_skill_per: res.data[i][19],
              prof_skill_per: res.data[i][20],
              office_skill_per: res.data[i][21],
              awards_per: res.data[i][22],
              certificates: res.data[i][23],
              political_status: res.data[i][24],
              postal_code: res.data[i][25],
              school_level: res.data[i][26],
              courses: res.data[i][27],
              edu_gpa: res.data[i][28],
              job_title: res.data[i][29],
              company_name: res.data[i][30],
              work_date: res.data[i][31],
              work_description: res.data[i][32],
              work_industry: res.data[i][33],
              work_year: res.data[i][34],
              project_name: res.data[i][35],
              project_position: res.data[i][36],
              project_date: res.data[i][37],
              project_description: res.data[i][38],
              social_pos: res.data[i][39],
              social_description: res.data[i][40],
              social_cpy: res.data[i][41],
              social_date: res.data[i][42],
              train_org: res.data[i][43],
              training_description: res.data[i][44],
              train_date: res.data[i][45],
              self_evaluation: res.data[i][46],
              candidate_job_title: res.data[i][47],
              parsing_time: res.data[i][48],
              resume_type: res.data[i][49],
              resume_name: res.data[i][50],
              path_resume: res.data[i][51],
              avatar_url: res.data[i][52],
              pred_salary: res.data[i][53],
              pos_tags: res.data[i][54],
              skills_tags: res.data[i][55],
              username: res.data[i][56]
            })
          }
          for (var i in table) {
            that.data_processing(table[i])
          }
          console.log(table)
          that.allData = table
          that.total = table.length
          if (that.total < that.PageSize) {
            that.PageSize = that.total
          }
          console.log('当前变量中的值为：')
          console.log(that.allData)
          that.currentPage = 1
          that.fenye()
        }
      }).catch(err => {
        this.$message.error(err.message);
        console.log(err)
      })
    },

    fenye() {
      console.log('进行分页操作')
      this.tableData = []
      if (this.total === 0) {
        this.emptydata = true
        console.log('当前没有数据')
      } else {
        this.emptydata = false
        // console.log('当前  所有数据为::')
        // console.log(this.allData)
        for (var i in this.allData) {
          this.tableData[i] = this.allData[i]
        }
        if (this.total < this.PageSize) {
          this.tableData = this.tableData.splice((this.currentPage - 1) * this.PageSize, this.total)
        } else {
          this.tableData = this.tableData.splice((this.currentPage - 1) * this.PageSize, this.PageSize)
        }
      }
    },
    // 查询全部信息
    // 参数： 当前username  用于判断用户的查询权限
    // 返回值： 多条sql结果，
    // 操作： 需要遍历每一条，按顺序将变量放在对象当中（获取所有数据）
    // 总条数等于alldata长度，调用分页函数进行切分表格显示
    getInfo: async function() {
      var table = []
      var that = this
      var data = new FormData()
      data.append('username',Global.username)
      await axios.post(this.conn + '/getResumeInfo', data).then(res => {
        that.PageSize = 3
        console.log('当前界面展示条数：：',that.PageSize)
        console.log('获取全部简历信息的返回值',res)
        if (res.data === null){
          that.allData=[]
          that.total = 0
          that.fenye()
          console.log('返回值为null')
          that.$message.error('当前用户没有可用信息！')
          return
        }
        if (res.status === 200) {
          // 返回的信息是多个元组，应该遍历data，取对应位置的值
          for (var i = 0; i < res.data.length; i++) {
            for (var j = 0; j < res.data[i].length; j++) {
              if (res.data[i][j] == null || res.data[i][j] === 'undefined') {
                res.data[i][j] = ''
              }
            }
            table.push({
              id: res.data[i][0] + '',
              name_per: res.data[i][1],
              sex_per: res.data[i][2],
              email_per: res.data[i][3],
              age_per: res.data[i][4] + '',
              phone_per: res.data[i][5],
              qq: res.data[i][6],
              weixin: res.data[i][7],
              address_per: res.data[i][8],
              height: res.data[i][9],
              weight: res.data[i][10],
              race: res.data[i][11],
              nationality: res.data[i][12],
              marital_status: res.data[i][13],
              highest_edu_per: res.data[i][14],
              adm_date: res.data[i][15],
              gra_date: res.data[i][16],
              gra_school_per: res.data[i][17],
              major_per: res.data[i][18],
              lan_skill_per: res.data[i][19],
              prof_skill_per: res.data[i][20],
              office_skill_per: res.data[i][21],
              awards_per: res.data[i][22],
              certificates: res.data[i][23],
              political_status: res.data[i][24],
              postal_code: res.data[i][25],
              school_level: res.data[i][26],
              courses: res.data[i][27],
              edu_gpa: res.data[i][28],
              job_title: res.data[i][29],
              company_name: res.data[i][30],
              work_date: res.data[i][31],
              work_description: res.data[i][32],
              work_industry: res.data[i][33],
              work_year: res.data[i][34],
              project_name: res.data[i][35],
              project_position: res.data[i][36],
              project_date: res.data[i][37],
              project_description: res.data[i][38],
              social_pos: res.data[i][39],
              social_description: res.data[i][40],
              social_cpy: res.data[i][41],
              social_date: res.data[i][42],
              train_org: res.data[i][43],
              training_description: res.data[i][44],
              train_date: res.data[i][45],
              self_evaluation: res.data[i][46],
              candidate_job_title: res.data[i][47],
              parsing_time: res.data[i][48],
              resume_type: res.data[i][49],
              resume_name: res.data[i][50],
              path_resume: res.data[i][51],
              avatar_url: res.data[i][52],
              pred_salary: res.data[i][53],
              pos_tags: res.data[i][54],
              skills_tags: res.data[i][55],
              username: res.data[i][56]
            })
          }
          // 将取到的对象保存到变量里面。。设置总数据条数。。调用分页函数。。
          // 遍历table  处理table中的每一个元素。然后处理成需要的样子，在赋值
          for (var i in table) {
            that.data_processing(table[i])
          }
          that.allData = table
          that.total = table.length
          console.log("table",table)
          console.log("that.allData ",that.allData )
          if (that.total < that.PageSize) {
            that.PageSize = that.total
          }
          // console.log('当前变量中的值为：')
          // console.log(that.allData)
          that.currentPage = 1
          that.fenye()
        }
      }).catch(error => {
        console.error(error)
      })
    },
    // 页面条数改变
    handleSizeChange(val) {
      this.PageSize = val
      this.currentPage = 1
      this.fenye()
    },
    // 当前页面数改变
    handleCurrentChange(val) {
      this.currentPage = val
      this.fenye()
    },
    // 按照筛选条件进行查询
    // 参数: 对象的所有属性值
    // 返回值: 多条sql结果
    // 操作: 需要遍历每一条，按顺序将变量放在对象当中（获取所有数据）
    // 总条数等于alldata长度，当前显示第一页, 调用分页函数进行切分表格显示
    sousuo_tiaojianchaxun: async function()  {
      var that = this
      var table = []
      var data = new FormData()
      data.append('username', Global.username)
      data.append('name_per', this.form1.name_per)
      data.append('sex_per', this.form1.sex_per)
      data.append('low_age', this.form1.low_age)
      data.append('high_age', this.form1.high_age)
      data.append('work_description', this.form1.work_description)
      data.append('highest_edu_per', this.form1.highest_edu_per)
      data.append('major_per', this.form1.major_per)
      data.append('prof_skill_per', this.form1.prof_skill_per)
      for (var [a, b] of data.entries()) {
        console.log('筛选条件：：',a,'的值为：：', b);
      }
      var config = {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }
      await axios.post(this.conn + '/getResumeInfoBySelect', data, config).then(function(res) {
        that.PageSize = 3
        console.log('当前界面展示条数：：',that.PageSize)
        console.log('条件查询的返回值',res)
        if (res.status === 200 && res.data != null) {
          for (var i = 0; i < res.data.length; i++) {
            for (var j = 0; j < res.data[i].length; j++) {
              if (res.data[i][j] == null || res.data[i][j] === 'undefined') {
                res.data[i][j] = ''
              }
            }
            table.push({
              id: res.data[i][0] + '',
              name_per: res.data[i][1],
              sex_per: res.data[i][2],
              email_per: res.data[i][3],
              age_per: res.data[i][4] + '',
              phone_per: res.data[i][5],
              qq: res.data[i][6],
              weixin: res.data[i][7],
              address_per: res.data[i][8],
              height: res.data[i][9],
              weight: res.data[i][10],
              race: res.data[i][11],
              nationality: res.data[i][12],
              marital_status: res.data[i][13],
              highest_edu_per: res.data[i][14],
              adm_date: res.data[i][15],
              gra_date: res.data[i][16],
              gra_school_per: res.data[i][17],
              major_per: res.data[i][18],
              lan_skill_per: res.data[i][19],
              prof_skill_per: res.data[i][20],
              office_skill_per: res.data[i][21],
              awards_per: res.data[i][22],
              certificates: res.data[i][23],
              political_status: res.data[i][24],
              postal_code: res.data[i][25],
              school_level: res.data[i][26],
              courses: res.data[i][27],
              edu_gpa: res.data[i][28],
              job_title: res.data[i][29],
              company_name: res.data[i][30],
              work_date: res.data[i][31],
              work_description: res.data[i][32],
              work_industry: res.data[i][33],
              work_year: res.data[i][34],
              project_name: res.data[i][35],
              project_position: res.data[i][36],
              project_date: res.data[i][37],
              project_description: res.data[i][38],
              social_pos: res.data[i][39],
              social_description: res.data[i][40],
              social_cpy: res.data[i][41],
              social_date: res.data[i][42],
              train_org: res.data[i][43],
              training_description: res.data[i][44],
              train_date: res.data[i][45],
              self_evaluation: res.data[i][46],
              candidate_job_title: res.data[i][47],
              parsing_time: res.data[i][48],
              resume_type: res.data[i][49],
              resume_name: res.data[i][50],
              path_resume: res.data[i][51],
              avatar_url: res.data[i][52],
              pred_salary: res.data[i][53],
              pos_tags: res.data[i][54],
              skills_tags: res.data[i][55],
              username: res.data[i][56]
            })
          }
          // 如果是在弹窗数来之后进行查询,那就需要将弹窗的可见性关闭
          that.centerDialogVisible = false
          that.drawer = false
          for (var i in table) {
            that.data_processing(table[i])
          }
          console.log(table)
          that.allData = table
          that.total = that.allData.length
          if (that.total < that.PageSize) {
            that.PageSize = that.total
          }
          console.log('当前变量中的值为：')
          console.log(that.allData)
          that.currentPage = 1
          that.fenye()
          // 清除筛选变量
          that.clean_()
        } else {
          that.drawer = false
          that.$message.error('没有查到对应的信息！')
        }
      }).catch(err => {
        that.drawer = false
        this.$message.error(err.message)
        console.log(err)
      })
    },
    // 按照关键词进行查询
    // 参数: 用户输入的关键词
    // 返回值: 多条sql结果
    // 操作: 需要遍历每一条，按顺序将变量放在对象当中（获取所有数据）
    // 总条数等于alldata长度，当前显示第一页, 调用分页函数进行切分表格显示
    sousuo_mohuchaxun() {
      console.log('正在进行关键词查询，查询内容为：',this.txt)
      var data = new FormData()
      data.append('keyword', this.txt)
      data.append('username',Global.username)
      var that = this
      var table = []
      // 地址  根据关键词查询
      axios.post(this.conn + '/getResumeInfoByKeyword', data).then(function(res) {
        that.PageSize = 3
        console.log('当前界面展示条数：：',that.PageSize)
        console.log('关键词查询的返回值为：',res)
        if (res.data === null){
          that.allData=[]
          that.total = 0
          that.fenye()
          console.log('返回值为null')
          that.$message.error('当前用户没有可用信息！')
          return
        }
        if (res.status === 200) {
          for (var i = 0; i < res.data.length; i++) {
            for (var j = 0; j < res.data[i].length; j++) {
              if (res.data[i][j] == null || res.data[i][j] === 'undefined') {
                res.data[i][j] = ''
              }
            }
            table.push({
              id: res.data[i][0] + '',
              name_per: res.data[i][1],
              sex_per: res.data[i][2],
              email_per: res.data[i][3],
              age_per: res.data[i][4] + '',
              phone_per: res.data[i][5],
              qq: res.data[i][6],
              weixin: res.data[i][7],
              address_per: res.data[i][8],
              height: res.data[i][9],
              weight: res.data[i][10],
              race: res.data[i][11],
              nationality: res.data[i][12],
              marital_status: res.data[i][13],
              highest_edu_per: res.data[i][14],
              adm_date: res.data[i][15],
              gra_date: res.data[i][16],
              gra_school_per: res.data[i][17],
              major_per: res.data[i][18],
              lan_skill_per: res.data[i][19],
              prof_skill_per: res.data[i][20],
              office_skill_per: res.data[i][21],
              awards_per: res.data[i][22],
              certificates: res.data[i][23],
              political_status: res.data[i][24],
              postal_code: res.data[i][25],
              school_level: res.data[i][26],
              courses: res.data[i][27],
              edu_gpa: res.data[i][28],
              job_title: res.data[i][29],
              company_name: res.data[i][30],
              work_date: res.data[i][31],
              work_description: res.data[i][32],
              work_industry: res.data[i][33],
              work_year: res.data[i][34],
              project_name: res.data[i][35],
              project_position: res.data[i][36],
              project_date: res.data[i][37],
              project_description: res.data[i][38],
              social_pos: res.data[i][39],
              social_description: res.data[i][40],
              social_cpy: res.data[i][41],
              social_date: res.data[i][42],
              train_org: res.data[i][43],
              training_description: res.data[i][44],
              train_date: res.data[i][45],
              self_evaluation: res.data[i][46],
              candidate_job_title: res.data[i][47],
              parsing_time: res.data[i][48],
              resume_type: res.data[i][49],
              resume_name: res.data[i][50],
              path_resume: res.data[i][51],
              avatar_url: res.data[i][52],
              pred_salary: res.data[i][53],
              pos_tags: res.data[i][54],
              skills_tags: res.data[i][55],
              username: res.data[i][56]
            })
          }
          for (var i in table) {
            that.data_processing(table[i])
          }
          console.log(table)
          that.allData = table
          that.total = table.length
          if (that.total < that.PageSize) {
            that.PageSize = that.total
          }
          console.log('当前变量中的值为：')
          console.log(that.allData)
          that.currentPage = 1
          that.fenye()
        }
      }).catch(err => {
        that.drawer = false
        this.$message.error(err.message)
        console.log(err)
      })
    },
    re_get_data() {
      console.log('刚刚进行了修改，现在重新获取alltable中的对象内容')
      console.log('当前alltable中的全部对象的id为：')
      console.log(this.id_list)
      var data = new FormData()
      var that = this
      var table = []
      data.append('ids', this.id_list)
      data.append('username', Global.username)
      axios.post(this.conn + '/reload_resume', data).then(function(res) {
        that.PageSize = 3
        console.log('当前界面展示条数：：',that.PageSize)
        console.log('重新获取alltable中的数据的返回值为：',res)
        if (res.data === null){
          that.allData=[]
          that.total = 0
          that.fenye()
          console.log('返回值为null')
          that.$message.error('当前用户没有可用信息！')
          return
        }
        if (res.status === 200) {
          for (var i = 0; i < res.data.length; i++) {
            for (var j = 0; j < res.data[i].length; j++) {
              if (res.data[i][j] == null || res.data[i][j] === 'undefined') {
                res.data[i][j] = ''
              }
            }
            table.push({
              id: res.data[i][0] + '',
              name_per: res.data[i][1],
              sex_per: res.data[i][2],
              email_per: res.data[i][3],
              age_per: res.data[i][4] + '',
              phone_per: res.data[i][5],
              qq: res.data[i][6],
              weixin: res.data[i][7],
              address_per: res.data[i][8],
              height: res.data[i][9],
              weight: res.data[i][10],
              race: res.data[i][11],
              nationality: res.data[i][12],
              marital_status: res.data[i][13],
              highest_edu_per: res.data[i][14],
              adm_date: res.data[i][15],
              gra_date: res.data[i][16],
              gra_school_per: res.data[i][17],
              major_per: res.data[i][18],
              lan_skill_per: res.data[i][19],
              prof_skill_per: res.data[i][20],
              office_skill_per: res.data[i][21],
              awards_per: res.data[i][22],
              certificates: res.data[i][23],
              political_status: res.data[i][24],
              postal_code: res.data[i][25],
              school_level: res.data[i][26],
              courses: res.data[i][27],
              edu_gpa: res.data[i][28],
              job_title: res.data[i][29],
              company_name: res.data[i][30],
              work_date: res.data[i][31],
              work_description: res.data[i][32],
              work_industry: res.data[i][33],
              work_year: res.data[i][34],
              project_name: res.data[i][35],
              project_position: res.data[i][36],
              project_date: res.data[i][37],
              project_description: res.data[i][38],
              social_pos: res.data[i][39],
              social_description: res.data[i][40],
              social_cpy: res.data[i][41],
              social_date: res.data[i][42],
              train_org: res.data[i][43],
              training_description: res.data[i][44],
              train_date: res.data[i][45],
              self_evaluation: res.data[i][46],
              candidate_job_title: res.data[i][47],
              parsing_time: res.data[i][48],
              resume_type: res.data[i][49],
              resume_name: res.data[i][50],
              path_resume: res.data[i][51],
              avatar_url: res.data[i][52],
              pred_salary: res.data[i][53],
              pos_tags: res.data[i][54],
              skills_tags: res.data[i][55],
              username: res.data[i][56]
            })
          }
          for (var i in table) {
            that.data_processing(table[i])
          }
          console.log(table)
          that.allData = table
          that.total = table.length
          if (that.total < that.PageSize) {
            that.PageSize = that.total
          }
          console.log('当前变量中的值为：')
          console.log(that.allData)
          that.currentPage = 1
          that.fenye()
        }
      })
    },
    go_back() {
      if (this.mod_justnow === true) {
        // 刚刚进行了修改操作，现在需要将原来的信息的id传到后端进行查询，然后显示最新的信息
        this.re_get_data()
        this.mod_justnow = false
      }
      this.active = 0
    },
    // 删除信息
    // 参数: id:id
    // 返回值: 200
    // 操作: 判断成功之后,显示删除成功,刷新界面
    del() {
      console.log('点击了确认删除,删除的id和姓名是：')
      console.log(this.item_detail.id)
      console.log(this.item_detail.name_per)
      //  将该简历信息传到后端，删除，并将界面跳转到前一页
      var data = new FormData()
      data.append('id', this.item_detail.id)
      var that = this
      axios.post(this.conn + '/resumeDelete', data).then(function(response) {
        console.log('删除方法的返回值为：')
        console.log(response)
        if (response.status === 200) {
          // 提示是否删除的弹框关闭
          that.isdel = false
          that.$message({
            message: '删除成功',
            type: 'success'
          })
          // 当前界面刷新,到管理界面中去
          that.reload()
        }
      })
    },
    // 点击编辑按钮，先保存一个性别变量，然后复制一个对象出来进行修改
    mod_btn() {
      this.mod_sex = this.item_detail.sex_per
      for (var i in this.item_detail) {
        this.item_detail_mod[i] = this.item_detail[i]
      }
      this.big1_dialogFormVisible = true
    },
    // 修改信息
    // 参数: 当前对象的全部属性值
    // 返回值: 200
    // 操作: 判断成功之后将当前信息修改成新的信息
    // submit_mod1(){
    //   // 点击修改，将选择的性别赋值
    //   this.item_detail_mod.sex_per = this.mod_sex
    //   console.log(this.item_detail_mod)
    //   this.show_info = this.item_detail_mod
    //   console.log(this.show_info)
    //   for (var item in this.item_detail_mod) {
    //     if (typeof (this.item_detail_mod[item]) != 'string'){
    //       this.item_detail_mod[item] = this.item_detail_mod[item].join('Ж')
    //     }
    //   }
    //   this.submit_mod()
    //
    // },
    submit_mod() {
        // 点击修改，将选择的性别赋值
      this.item_detail_mod.sex_per = this.mod_sex
      // 将列表转换成字符串
      for (var item in this.item_detail_mod) {
        if (typeof (this.item_detail_mod[item]) != 'string'){
          this.item_detail_mod[item] = this.item_detail_mod[item].join('Ж')
        }
      }
      // console.log('点击了修改，修改的信息为：',this.item_detail_mod)
      //  将当前页的简历信息进行修改，弹出表单进行修改，将信息提交到后端
      var data = new FormData()
      data.append('id', this.item_detail_mod.id)
      data.append('name_per', this.item_detail_mod.name_per)
      data.append('sex_per', this.item_detail_mod.sex_per)
      data.append('email_per', this.item_detail_mod.email_per)
      data.append('age_per', this.item_detail_mod.age_per)
      data.append('phone_per', this.item_detail_mod.phone_per)
      data.append('qq', this.item_detail_mod.qq)
      data.append('weixin', this.item_detail_mod.weixin)
      data.append('address_per', this.item_detail_mod.address_per)
      data.append('height', this.item_detail_mod.height)
      data.append('weight', this.item_detail_mod.weight)
      data.append('race', this.item_detail_mod.race)
      data.append('nationality', this.item_detail_mod.nationality)
      data.append('marital_status', this.item_detail_mod.marital_status)
      data.append('highest_edu_per', this.item_detail_mod.highest_edu_per)
      data.append('adm_date', this.item_detail_mod.adm_date)
      data.append('gra_date', this.item_detail_mod.gra_date)
      data.append('gra_school_per', this.item_detail_mod.gra_school_per)
      data.append('major_per', this.item_detail_mod.major_per)
      data.append('lan_skill_per', this.item_detail_mod.lan_skill_per)
      data.append('prof_skill_per', this.item_detail_mod.prof_skill_per)
      data.append('office_skill_per', this.item_detail_mod.office_skill_per)
      data.append('awards_per', this.item_detail_mod.awards_per)
      data.append('certificates', this.item_detail_mod.certificates)
      data.append('political_status', this.item_detail_mod.political_status)
      data.append('postal_code', this.item_detail_mod.postal_code)
      data.append('school_level', this.item_detail_mod.school_level)
      data.append('courses', this.item_detail_mod.courses)
      data.append('edu_gpa', this.item_detail_mod.edu_gpa)
      data.append('job_title', this.item_detail_mod.job_title)
      data.append('company_name', this.item_detail_mod.company_name)
      data.append('work_description', this.item_detail_mod.work_description)
      data.append('work_date', this.item_detail_mod.work_date)
      data.append('work_industry', this.item_detail_mod.work_industry)
      data.append('work_year', this.item_detail_mod.work_year)
      data.append('project_name', this.item_detail_mod.project_name)
      data.append('project_position', this.item_detail_mod.project_position)
      data.append('project_date', this.item_detail_mod.project_date)
      data.append('project_description', this.item_detail_mod.project_description)
      data.append('social_pos', this.item_detail_mod.social_pos)
      data.append('social_description', this.item_detail_mod.social_description)
      data.append('social_cpy', this.item_detail_mod.social_cpy)
      data.append('social_date', this.item_detail_mod.social_date)
      data.append('train_org', this.item_detail_mod.train_org)
      data.append('train_date', this.item_detail_mod.train_date)
      data.append('training_description', this.item_detail_mod.training_description)
      data.append('self_evaluation', this.item_detail_mod.self_evaluation)
      data.append('candidate_job_title', this.item_detail_mod.candidate_job_title)
      data.append('parsing_time', this.item_detail_mod.parsing_time)
      data.append('resume_type', this.item_detail_mod.resume_type)
      data.append('resume_name', this.item_detail_mod.resume_name)
      data.append('path_resume', this.item_detail_mod.path_resume)
      data.append('avatar_url', this.item_detail_mod.avatar_url)
      data.append('pred_salary', this.item_detail_mod.pred_salary)
      data.append('pos_tags', this.item_detail_mod.pos_tags)
      data.append('skills_tags', this.item_detail_mod.skills_tags)
      data.append('username', this.item_detail_mod.username)

      for (var [a,b] of data.entries()) {
        console.log("修改的",a,"为：：：",b)
      }
      var config = {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      }
      var that = this
      axios.post(this.conn + '/resumeUpdate', data, config).then(function(res) {
        console.log('修改方法的返回值为：')
        console.log(res)
        if (res.data === null){
          that.allData=[]
          that.total = 0
          that.fenye()
          console.log('返回值为null')
          that.$message.error('当前用户没有可用信息！')
          return
        }
        if (res.status === 200) {
          // 修改信息之后点击返回，刷新当前界面
          that.mod_justnow = true
          that.item_detail = that.item_detail_mod
          that.$message({
            message: '简历信息修改成功！',
            type: 'success'
          })
          that.data_processing(that.item_detail_mod)

          console.log(that.item_detail_mod)
          that.big1_dialogFormVisible = false
          console.log(that.big1_dialogFormVisible)
        }
      }).catch(err => {
        that.big1_dialogFormVisible = false
        this.$message.error(err.message)
        console.log(err)
      })
    },
    movetodetail(item) {
      this.id_list = []
      // console.log('点击了简历')
      // 保存当前id列表
      for (var j in this.allData) {
        this.id_list.push(this.allData[j].id)
      }
      // 遍历当前变量,如果是null、undefined就赋值空字符串
      // for (var i in item) {
      //   // console.log(item[i],item[i].length)
      //   if (item[i] === null || item[i] === 'undefined') {
      //     item[i] = ''
      //   }
      // }

      // 改成当前界面的覆盖
      this.item_detail = item
      // this.data_processing(this.item_detail)

      // this.item_detail.path_resume = '/ruanjianbei/ruanjianbeipy/resume/99.docx'
      // var path = this.item_detail.path_resume.split('/')
      // var lj = 'resume/'+path[4]
      // this.lianjie = 'http://81.68.169.78:1005/'+lj
      // console.log(this.lianjie)
      this.active = 1
      console.log('简历详情显示的信息为：',this.item_detail)
    },
    data_processing(item){
      // console.log('姓名',item[name_per])
      // console.log('工作年限',item[work_year])
      // if (item[work_year] != ''){
      //   console.log('工作年限不是空，把它转换成int  再转成str')
      //   item[work_year] = parseInt(item[work_year])
      //   item[work_year] = item[work_year]+''
      // }
      for (var i in item) {
        // console.log(i)
        if (i ==='work_year'){
          if(item[i] != ''){
            item[i] = parseInt(item[i])
            item[i] = item[i]+'年'
          }
        }
        if (i ==='age_per'){
          if(item[i] == '-1'){
            console.log(item[i])
            item[i] = ''
            console.log(item[i])
          }
        }
        if (item[i].indexOf('Ж')!= -1) {
          item[i] = item[i].split('Ж')
        }
      }

      // 教育
      var edu = []
      //遍历列表
      if (typeof (item.adm_date) != "string"){
        for (var i =0;i<item.adm_date.length;i++){
          edu.push({
            adm_date : item.adm_date[i],
            gra_date : item.gra_date[i],
            gra_school_per : item.gra_school_per[i],
            major_per : item.major_per[i],
            edu_gpa : item.edu_gpa[i],
            courses : item.courses[i],
            school_level : item.school_level[i],
          })
        }
      }

      if (edu.length==0){
        if (item.adm_date == "" &&item.gra_date == "" &&item.gra_school_per == "" &&item.major_per == "" &&item.school_level == "" &&item.edu_gpa == "" &&item.courses == ""){

        }else {
          edu.push({
            adm_date : item.adm_date,
            gra_date : item.gra_date,
            gra_school_per : item.gra_school_per,
            major_per : item.major_per,
            edu_gpa : item.edu_gpa,
            courses : item.courses,
            school_level : item.school_level,
          })
        }
      }
      // 工作
      var work = []
      if (typeof (item.work_date) != "string") {
        for (var i = 0; i < item.work_date.length; i++) {
          work.push({
            work_date: item.work_date[i],
            work_description: item.work_description[i],
            // work_industry: item.work_industry[i]+'',
            company_name: item.company_name[i],
            job_title: item.job_title[i],
          })
        }
      }
      if (work.length==0){
        if (item.work_date == "" &&item.work_description == "" &&item.work_industry == "" &&item.company_name == "" &&item.job_title == "" ){

        }else {
          work.push({
            work_date : item.work_date,
            work_description : item.work_description,
            work_industry : item.work_industry,
            company_name : item.company_name,
            job_title : item.job_title,
          })
        }
      }
      // 项目
      var project = []
      if (typeof (item.project_name) != "string") {
        for (var i = 0; i < item.project_name.length; i++) {
          project.push({
            project_name: item.project_name[i],
            project_description: item.project_description[i],
            project_date: item.project_date[i],
            project_position: item.project_position[i]
          })
        }
      }
      if (project.length==0){
        if (item.project_name == "" &&item.project_description == "" &&item.project_date == "" &&item.project_position == "" ){

        }else {
          project.push({
            project_name : item.project_name,
            project_description : item.project_description,
            project_date : item.project_date,
            project_position : item.project_position
          })
        }
      }
      // 社会
      var social = []
      if (typeof (item.social_pos) != "string") {
        for (var i = 0; i < item.social_pos.length; i++) {
          social.push({
            social_pos: item.social_pos[i],
            social_date: item.social_date[i],
            social_cpy: item.social_cpy[i],
            social_description: item.social_description[i]
          })
        }
      }
      if (social.length==0){
        if (item.social_pos == "" &&item.social_date == "" &&item.social_cpy == "" &&item.social_description == "" ){

        }else {
          social.push({
            social_pos : item.social_pos,
            social_date : item.social_date,
            social_cpy : item.social_cpy,
            social_description : item.social_description
          })
        }
      }
      // 培训
      var train = []
      if (typeof (item.train_org) != "string") {
        for (var i = 0; i < item.train_org.length; i++) {
          train.push({
            train_org: item.train_org[i],
            training_description: item.training_description[i],
            train_date: item.train_date[i]
          })
        }
      }
      if (train.length==0){
        if (item.social_pos == "" &&item.social_date == "" &&item.social_cpy == "" &&item.social_description == "" ){

        }else {
          train.push({
            train_org : item.train_org,
            training_description : item.training_description,
            train_date : item.train_date
          })
        }
      }



      item.edu = edu
      item.work = work
      item.project = project
      item.social = social
      item.train = train
      // console.log('item.edu',item.edu)
      // console.log('item.work',item.work)
      // console.log('item.project',item.project)
      // console.log('item.social',item.social)
      // console.log('item.train',item.train)
      // console.log('candidate_job_title.len',item.candidate_job_title.length)
    }
  },
  async created() {
    // 获取所有的简历信息
    console.log('nihao')
    console.log(this.conn)
    this.getInfo()
  }
}
</script>

<style scoped>
.biaoqian{
  background-color: #fff6e9;
  color: #ffa817;
  font-family: "Times New Roman";
  display: inline-block;
  padding: 2px 4px;
  margin: 5px 4px;
  /*margin-top: 10px;*/
  border-style: solid;
  border-radius: 5px;
  border-width: 1px;
  text-align: right;
}
.empty_box {
  margin: 20px auto;
  text-align: center;
  line-height: 100px;
  width: 700px;
  height: 100px;
  /*background-color: #ffecec;*/
  /*border: #2299dd;*/
  border-style: dotted;
  border-width: 2px;
  border: 2px dotted #2e8bff;
  border-radius: 15px;
}
.big1 lable{
  /*background-color: #c25959;*/
  font-size: small;
  width: 60px;
  display: inline-block;
  text-align: right;
  margin: 10px 20px;
}
.big1 .xiugai {
  width: 80%;
}
.big1 .xiugai span input{
  font-size: small;
  width: 100%;
  height: 32px;
  line-height: 30px;
  color: gray;
}
.big1 .xiugai span{
  /*background-color: #aa1111;*/
  width: 60%;
  /*font-size: 27px;*/
  display: inline-block;
}
.big1 .xiugai .elbtn{
  width: 70px;
  height: 40px;
  font-size: small;
}

.big1 .teil{
  width: 90%;
  height: 100px;
  margin: 30px auto;
  /*background-color: #6366ff;*/
}
.big1 .six{
  width: 90%;
  margin: 0px auto;
  margin-top: 130px;
  /*background-color: #6366ff;*/
}
.big1 .five{
  width: 90%;
  margin: 0px auto;
  margin-top: 130px;
  /*background-color: #efff63;*/
}
.big1 .four{
  width: 90%;
  margin: 0px auto;
  margin-top: 100px;
  /*background-color: #ffac63;*/
}
.big1 .thr{
  width: 90%;
  margin: 0px auto;
  margin-top: 100px;
  /*background-color: #f88eff;*/
}
.big1 ul{
  list-style-type: none;
}
.big1 ul li{
  font-size: large;
  margin-top: 25px;
  color: #9198a5;
}
.big li div {
  font-size: 16px !important;
}
.big1 li .dian{
  color: #6873e5;
}
.big1 li span{
  color: #494949;
  /*line-height: 40px;*/
  font-size: 16px;
}
.big1 div .left{
  width: 50%;
  height: 100%;
  display: inline-block;
  left: 0px;
  /*background-color: #ff8b8b;*/
}
.big1 div .right{
  width: 50%;
  height: 100%;
  display: inline-block;
  float: right;
  /*background-color: #e5d98c;*/
}
.big1 div .botom li,ul{
  margin-top: 5px !important;
}
.big1 .title_box{
  position: absolute;
  margin-top: 20px;
  width: 100%;
  height: 100px;
  /*background-color: #af3f3f;*/
}
.big1 ._title_down{
  /*底色  设置长、宽、背景色*/
  width: 150px;
  height: 40px;
  /*background-color: #ffd9b2;*/
  position: absolute;
  left: 30px;
  top: 10px;
}
.big1 ._title{
  /*文字  设置长、宽、字号、粗细、最上方显示*/
  z-index: 999;
  width: 200px;
  height: 60px;
  font-size: xx-large;
  font-weight: normal;
  position: absolute;
  left: 40px;
  top: 10px;
}
.big1 .fenjiexian {
  border: black;
  padding: 3px;
  background: repeating-linear-gradient(135deg, #d0d0d0 0px, #09090a 1px, transparent 1px, transparent 6px);
}
.big1 .two{
  overflow: hidden;
  width: 90%;
  height: 150px;
  margin: 20px auto;
  /*background-color: #8aff63;*/
}
.big1 .two .sinfo{
  width: 83%;
  height: 100%;
  float: right;
  /*background-color: #fff;*/
}
.big1 .two .imgg{
  width: 12%;
  display: inline-block;
}
.big1 .two .name{
  height: 70px;
  font-size: 35px;
  font-weight: bolder;
  line-height: 70px;
  text-align: left;
  display: block;
  /*background-color: #fff;*/
}
.big1 .two .sinfos{
  margin-top: 10px;
  height: 50px;
  color: #8a919f;
  /*background-color: #ffefef;*/
}
.big1 i {
  margin-right: 6px;
}
.big1 .mar_left{
  margin-left: 20px;
}
.big1 .one{
  width: 90%;
  height: 40px;
  margin: 30px auto;
  /*background-color: #e3e3e3;*/
}
.big1 .one .zhongwenjianli{
  width: 70px;
  height: 40px;
  line-height: 40px;
  text-align: center;
  color: #3155eb;
  font-size: small;
  border-style: solid;
  border-width: medium;
  border-color: #aec6ff;
  border-radius: 10px;
  background-color: #f0f5ff;
}
/*.big1 .info{*/
/*  width: 80%;*/
/*  height: 95%;*/
/*  overflow: auto;*/
/*  position: absolute;*/
/*  left: 10%;*/
/*  background-color: #ffffff;*/
/*  margin-top: 20px;*/
/*  -webkit-box-shadow: #666 0px 0px 50px;*/
/*  -moz-box-shadow: #666 0px 0px 50px;*/
/*  box-shadow: #666 0px 0px 20px;*/
/*}*/

.big1 .info{
  width: 60%;
  height: 95%;
  overflow: auto;
  position: absolute;
  top: 0;left:0;right:0;bottom:0;
  margin: auto;
  background-color: #ffffff;
  -webkit-box-shadow: #666 0px 0px 50px;
  -moz-box-shadow: #666 0px 0px 50px;
  box-shadow: #666 0px 0px 20px;
}
.active{
  visibility: hidden;
}
.big form div {
  margin-bottom: 5px;
}
.big lable{
  /*background-color: #c25959;*/
  font-size: inherit;
  width: 100px;
  display: inline-block;
  text-align: right;
  margin-right: 10px;
  margin-bottom: 20px;
}
.big .dia {
  width: 80%;
}
.big .dia span input{
  font-size: small;
  width: 100%;
  height: 32px;
  line-height: 30px;
  color: gray;
}
.big .dia span{
  /*background-color: #aa1111;*/
  width: 60%;
  /*font-size: 27px;*/
  display: inline-block;
}
.big .dia .elbtn{
  padding: 0!important;
  width: 70px;
  height: 40px;
  text-align: center;
  font-size: small;
}
.big .imgg{
  width: 8%;
  display: inline-block;
  float: left;
  padding-bottom: 20px;
}
.big .info{
  width: 90%;
  float: right;
  display: inline-block;
  padding-bottom: 10px;
}
.big .caozuo{
  width: 80%;
  margin: 0px auto;
  margin-bottom: 20px;
}
.big .forth{
  font-size: small;
  margin-top: 10px;
  /*background-color: #a1ff5e;*/
}
.big .th {
  font-size: small;
  margin-top: 10px;
  /*background-color: #a8ffc5;*/
}
.big .sec{
  font-weight: bold;
  color: #6873e5;
  font-size: small;
  margin-top: 10px;
  /*background-color: #ffe7e7;*/
}
.big .display__name{
  font-size: x-large;
  font-family: 黑体;
  /*background-color: #fc6a6a;*/
}
.big{
  margin-top: 30px;
}
.big .item {
  padding: 7px 0px;
}

.big .box-card {
  /*width: 70%;*/
  width: 900px;
  margin: 0px auto;
  border-radius: 20px;
}
.big .box-card:hover {
  width: 920px;
  margin: 0px auto;
  border-radius: 20px;
  box-shadow: #9e9e9e 10px 10px 10px;
  transform: translateY(-1px);
}
</style>
