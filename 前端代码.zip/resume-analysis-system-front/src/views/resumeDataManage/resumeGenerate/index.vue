<template>
  <div>
    <div class="big" v-if="action==0">
      <a align="center" style="color: #00aaff;"><h1>请点击选择简历模板</h1></a>
      <div style="width: 1000px;height: 400px;margin: 20px auto;position: relative">
<!--      <div style="width: 1000px;height: 400px;background-color:#d25e5e;margin: 20px auto;position: relative">-->
        <img class="img1" @click="chose = 1;fsqq()" src="./img/1.png">
        <img class="img2" @click="chose = 2;fsqq()" src="./img/2.png">
        <img class="img3" @click="chose = 3;fsqq()" src="./img/3.png">
      </div>
    </div>
    <div class="big1"  v-if="action==1">
      <div class="caozuo" style="display: inline-block;width: 1250px;height: 40px;position: absolute;top: 8px;left: 20px">
<!--      <div class="caozuo" style="display: inline-block;background-color:#ff7070;width: 1250px;height: 40px;position: absolute;top: 8px;left: 20px">-->
        <el-button style="float: right;margin-left: 20px;margin-right: 50px" type="primary" @click="downloadDOCX" round>导出文件</el-button>
<!--        <el-button style="float: right"  type="primary" plain  @click="saveTxt" round>暂时保存</el-button>-->
        <i class="el-icon-back" style="display: inline-block;font-size: 40px;" @click="go_back()" />
      </div>
      <div style="margin: 60px 20px;margin-bottom:20px;width: 1250px;height: 100%;">
        <no-ssr>
          <mavon-editor
            :min-height="2000200"
            @change="change"
            @imgAdd="imgAdd"
            @imgDel="imgDel"
            ref="md"
            id="editor"
            fontSize="18px"
            boxShadowStyle="0px 2px 12px 1px rgba(0, 0, 0, 0.9)"
            v-model="text"
          />
        </no-ssr>

      </div>
      <div class="caozuo" style="display: inline-block;width: 1250px;height: 40px;left: 20px; margin-bottom: 20px">
        <!--      <div class="caozuo" style="display: inline-block;background-color:#ff7070;width: 1250px;height: 40px;position: absolute;top: 8px;left: 20px">-->
        <el-button style="float: right;margin-left: 20px;margin-right: 50px" type="primary" @click="downloadDOCX" round>导出文件</el-button>
        <!--        <el-button style="float: right"  type="primary" plain  @click="saveTxt" round>暂时保存</el-button>-->
<!--        <i class="el-icon-back" style="display: inline-block;font-size: 40px;" @click="go_back()" />-->
      </div>

    </div>
  </div>
</template>

<script>
import * as axios from 'axios'
import Global from '../../../global/global'
// import editor from './editor/mavon_editor'
import {mavonEditor} from "mavon-editor";
import "mavon-editor/dist/css/index.css";
import marked from 'marked'
//导出文件
import htmlDocx from 'html-docx-js/dist/html-docx';
import saveAs from 'file-saver';
export default {
// 页面注册组件
  components: {
    mavonEditor,
    // editor
  },
  name: 'index',
  data(){
    return {
      html: '',
      action:  0,
      conn: Global.data().conn,
      chose: '',
      text:'请稍候……',
      //data中的配置项,根据自己的需求使用
      toolbars: {
        min_height: 30,
        min_width: 30,
        bold: true, // 粗体
        italic: true, // 斜体
        header: true, // 标题
        underline: true, // 下划线
        strikethrough: true, // 中划线
        mark: true, // 标记
        superscript: true, // 上角标
        subscript: true, // 下角标
        quote: true, // 引用
        ol: true, // 有序列表
        ul: true, // 无序列表
        link: true, // 链接
        imagelink: true, // 图片链接
        code: true, // code
        table: true, // 表格
        fullscreen: true, // 全屏编辑
        readmodel: true, // 沉浸式阅读
        htmlcode: true, // 展示html源码
        help: false, // 帮助
        /* 1.3.5 */
        undo: true, // 上一步
        redo: true, // 下一步
        trash: true, // 清空
        save: false, // 保存（触发events中的save事件）
        /* 1.4.2 */
        navigation: true, // 导航目录
        /* 2.1.8 */
        alignleft: true, // 左对齐
        aligncenter: true, // 居中
        alignright: true, // 右对齐
        /* 2.2.1 */
        subfield: true, // 单双栏模式
        preview: true // 预览
      }

    }
  },
  methods:{
    imgAdd(filename,imgfile){
      console.log(filename)
      console.log(imgfile)
    },
    imgDel(filename,imgfile){
      console.log(filename)
      console.log(imgfile)
    },
    change(value, render){
      // render 为 markdown 解析后的结果
      this.html = render;
      // console.log(this.html)
    },
    downloadDOCX(){
      var markdownIt  = mavonEditor.getMarkdownIt()
      // console.log(markdownIt.html)
      // console.log(markdownIt.htmlcode)

      // // 导出为docx（失败）
      this.html.replaceAll('&emsp;',' ')
      console.log(this.html)
      var content = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body>' + this.html + '</body></html>';
      // var content = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body>' + this.html + '</body></html>';

      console.log(content)
      let converted = htmlDocx.asBlob(content);
      console.log(converted)
      saveAs(converted,'11.docx');
    },
    go_back(){
      this.action = 0
    },
    async fsqq(){
      var data = new FormData()
      data.append('resume_name',this.chose)
      var that = this
      await axios.post(this.conn+'/chose_resume', data).then(function(res){
        if (res.status == 200){
          that.text = res.data
          that.action = 1

        }
      })
    }
  }

}
</script>

<style scoped>
.img1{
  left: 50px;
}
.img2{
  left: 330px;
}
.img1{
  left: 660px;
}
img {
  /*float: left;*/
  width: 230px;
  height: 350px;
  margin: 50px 50px;
  position: absolute;
}
img:hover {
  /*position: relative;*/
  /*float: right;*/
  /*right: 50%;*/
  width: 350px;
  height: 500px;
  margin: 0px auto;
}
</style>
